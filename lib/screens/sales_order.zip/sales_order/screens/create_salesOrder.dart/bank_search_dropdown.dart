import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../sales_order_providers/bank_search_provider.dart';

class BankSearchDropdown extends StatefulWidget {
  const BankSearchDropdown({Key? key}) : super(key: key);

  @override
  _BankSearchDropdownState createState() => _BankSearchDropdownState();
}

class _BankSearchDropdownState extends State<BankSearchDropdown> {
  @override
  void initState() {
    super.initState();
    _bankFocusNode.addListener(() {
      if (!_bankFocusNode.hasFocus) {
        _removeSuggestionsOverlay();
      }
    });
  }

  final FocusNode _bankFocusNode = FocusNode();
  final LayerLink _layerLink = LayerLink();
  OverlayEntry? _overlayEntry;

  void _onBankNameChanged(String value) {
    final provider = context.read<BankSearchProvider>();
    print('1.................');
    provider.fetchSuggestions(value);

    // Show overlay when typing
    if (value.isNotEmpty) {
      _showSuggestionsOverlay();
    } else {
      _removeSuggestionsOverlay();
    }
  }

  void _showSuggestionsOverlay() {
    _removeSuggestionsOverlay();
    _overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(_overlayEntry!);
  }

  void _removeSuggestionsOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  OverlayEntry _createOverlayEntry() {
    final bankProvider =
        Provider.of<BankSearchProvider>(context, listen: false);
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;

    return OverlayEntry(
      builder: (context) => Positioned(
        width: size.width,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(0, size.height + 5.0),
          child: Consumer<BankSearchProvider>(
            builder: (context, provider, child) {
              return Material(
                elevation: 8.0,
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue.shade100.withOpacity(0.8),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  constraints: const BoxConstraints(maxHeight: 300),
                  child: ListView.builder(
                    padding: EdgeInsets.zero,
                    itemCount: provider.suggestions.length + 1,
                    itemBuilder: (context, index) {
                      if (index < provider.suggestions.length) {
                        final suggestion = provider.suggestions[index];
                        // return ListTile(
                        //   title: Text(suggestion['bankName'] ?? 'Unknown Bank'),
                        //   onTap: () {
                        //     print('suggestion: ${suggestion['bankName']}');
                        //     print('from here');
                        //     _onSuggestionSelected(suggestion, bankProvider);
                        //     print('end................................');
                        //     // _removeSuggestionsOverlay();
                        //   },
                        // );

                        return GestureDetector(
                          onTap: () {
                            print('suggestion: ${suggestion['bankName']}');
                            _onSuggestionSelected(suggestion, bankProvider);
                          },
                          child: ListTile(
                            title:
                                Text(suggestion['bankName'] ?? 'Unknown Bank'),
                          ),
                        );
                      }
                      return ListTile(
                        leading: const Icon(Icons.add, color: Colors.green),
                        title: const Text('Add Bank Name'),
                        onTap: () {
                          _showAddBankDialog(bankProvider);
                          _removeSuggestionsOverlay();
                        },
                      );
                    },
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  // void _onSuggestionSelected(
  //     Map<String, dynamic> suggestion, BankSearchProvider bankProvider) {
  //   // print('2..........................');
  //   // bankProvider.bankNameController.text = suggestion['bankName'] ?? '';
  //   // print('bankNameController.text: ${bankProvider.bankNameController.text}');
  //   // FocusScope.of(context).unfocus();
  //   print('2..........................');
  //   bankProvider.bankNameController.value = TextEditingValue(
  //     text: suggestion['bankName'] ?? '',
  //     selection: TextSelection.collapsed(
  //         offset: (suggestion['bankName'] ?? '').length),
  //   );
  // }

  void _onSuggestionSelected(
      Map<String, dynamic> suggestion, BankSearchProvider bankProvider) {
    print('2..........................');
    bankProvider.updateBankName(suggestion['bankName'] ?? '');
    print('bankNameController.text: ${bankProvider.bankNameController.text}');
    FocusScope.of(context).unfocus();
  }

  void _showAddBankDialog(BankSearchProvider bankProvider) {
    // final TextEditingController bankNameController =
    //     TextEditingController(text: bankProvider.bankNameController.text);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          title: const Row(
            children: [
              Icon(Icons.account_balance, color: Colors.blue),
              SizedBox(width: 8),
              Text(
                'Add Bank',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: bankProvider.bankNameController,
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(24),
                    FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z ]*$')),
                  ],
                  decoration: InputDecoration(
                    labelText: 'Bank Name',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                'Cancel',
                style:
                    TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                final String bankName =
                    bankProvider.bankNameController.text.trim();

                if (bankName.isNotEmpty) {
                  final response = await bankProvider.addBank(bankName);
                  if (response) {
                    // Update the fields with the new bank data
                    bankProvider.bankNameController.text = bankName;

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Bank "$bankName" added successfully!',
                          style: const TextStyle(color: Colors.white),
                        ),
                        backgroundColor: Colors.green,
                      ),
                    );
                    Navigator.pop(context);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Failed to add bank. Please try again.'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please enter a valid bank name.'),
                      backgroundColor: Colors.orange,
                    ),
                  );
                }
              },
              child: const Text('Submit'),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _bankFocusNode.dispose();
    _overlayEntry?.remove();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bankProvider =
        Provider.of<BankSearchProvider>(context, listen: false);
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        _removeSuggestionsOverlay();
      },
      child: Column(
        children: [
          Row(
            children: [
              const Padding(padding: EdgeInsets.all(5)),
              Expanded(
                child: CompositedTransformTarget(
                  link: _layerLink,
                  child: TextFormField(
                    controller: bankProvider.bankNameController,
                    focusNode: _bankFocusNode,
                    inputFormatters: [
                      LengthLimitingTextInputFormatter(24),
                      FilteringTextInputFormatter.allow(
                          RegExp(r'^[a-zA-Z ]*$')),
                    ],
                    decoration: InputDecoration(
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            BorderSide(color: Colors.blue.shade600, width: 2),
                      ),
                      border: const OutlineInputBorder(),
                      labelText: 'Bank Name',
                      labelStyle: TextStyle(color: Colors.blue.shade800),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      prefixIcon: Icon(Icons.account_balance,
                          color: Colors.blue.shade600),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.blue.shade200),
                      ),
                      isDense: false,
                    ),
                    style: TextStyle(fontSize: 14),
                    onChanged: _onBankNameChanged,
                  ),
                ),
              ),
              const Padding(padding: EdgeInsets.all(5)),
            ],
          ),
        ],
      ),
    );
  }
}
