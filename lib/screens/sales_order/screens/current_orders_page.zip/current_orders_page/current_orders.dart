import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../sales_order_print/todat_orders_print.dart';
import '../../sales_order_providers/editcustomerscreenProvider.dart';
import '../all_orders_page/services/get_sales_order_service.dart';
import '../create_salesOrder.dart/create_sales_order.dart';
import '../create_salesOrder.dart/editcustomerdetails.dart';
import '../model/sales_order_model.dart';

import 'current_order_widget/empty_order_state.dart';
import 'current_order_widget/order_details.dart';
import 'current_order_widget/order_list.dart';

class CurrentOrdersPage extends StatefulWidget {
  const CurrentOrdersPage({super.key});

  @override
  State<CurrentOrdersPage> createState() => _CurrentOrdersPageState();
}

class _CurrentOrdersPageState extends State<CurrentOrdersPage> {
  int? _selectedTransactionIndex;
  final TextEditingController _searchController = TextEditingController();
  Timer? _debounce;

  @override
  void dispose() {
    _searchController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final apiService = context.watch<ApiServiceSalesOrderProvider>();
    final filteredSalesOrders = apiService.hivefilteredOrders
        .map((order) => SalesOrderDisplay.fromMap(order))
        .where((order) => order.status != "Open Order")
        .toList();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context, apiService, filteredSalesOrders),
      body: Row(
        children: [
          Expanded(
            flex: 1,
            child: OrderList(
              orders: filteredSalesOrders,
              apiService: apiService,
              selectedIndex: _selectedTransactionIndex,
              onOrderSelected: (index) => setState(() {
                _selectedTransactionIndex = index;
              }),
            ),
          ),
          const VerticalDivider(),
          Expanded(
            flex: 1,
            child: Consumer<EditCustomerScreenProvider>(
              builder: (context, provider, child) {
                return filteredSalesOrders.isNotEmpty &&
                        _selectedTransactionIndex != null
                    ? EditCustomerDetails(
                        key: ValueKey(
                            '${_selectedTransactionIndex}_${provider.isModifyMode}'),
                        selectedOrder:
                            filteredSalesOrders[_selectedTransactionIndex!],
                        isEditing: provider.isModifyMode.value,
                        orderType: 'CurrentOrder',
                      )
                    : const EmptyOrderState();
              },
            ),
          ),
          const VerticalDivider(),
          Expanded(
            flex: 1,
            child: OrderDetails(
              orders: filteredSalesOrders,
              selectedIndex: _selectedTransactionIndex,
              apiService: apiService,
            ),
          ),
        ],
      ),
    );
  }

  AppBar _buildAppBar(
    BuildContext context,
    ApiServiceSalesOrderProvider apiService,
    List<SalesOrderDisplay> orders,
  ) {
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Colors.white,
      title: Row(
        children: [
          Text("${orders.length} "),
          const Text('Current Orders', style: TextStyle(color: Colors.black)),
          const SizedBox(width: 10),
          IconButton(
            onPressed: () => apiService.changeDate(const Duration(days: -1)),
            icon: const Icon(Icons.arrow_back_ios, color: Colors.blue),
            tooltip: "Previous Date",
          ),
          const SizedBox(width: 10),
          Text(
            DateFormat('dd-MM-yy').format(apiService.selectedDate!),
            style: const TextStyle(fontSize: 11),
          ),
          const SizedBox(width: 10),
          IconButton(
            onPressed: () => apiService.changeDate(const Duration(days: 1)),
            icon: const Icon(Icons.arrow_forward_ios, color: Colors.blue),
            tooltip: "Next Date",
          ),
          const SizedBox(width: 4),
          ElevatedButton(
            onPressed: () async {
              PrintUtility.printReceiptDetails(context, orders);
            },
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0),
              ),
              backgroundColor: Colors.white,
              foregroundColor: Colors.blue,
              elevation: 2,
            ),
            child: const Text('Print'),
          ),
        ],
      ),
      centerTitle: false,
      flexibleSpace: Align(
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                backgroundColor: Colors.white,
                foregroundColor: Colors.blue,
                elevation: 2,
              ),
              child: const Text('Current Order'),
            ),
            const SizedBox(width: 10),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pushNamed('/all-orders'),
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                elevation: 2,
              ),
              child: const Text('All Orders'),
            ),
            const SizedBox(width: 10),
            ElevatedButton(
              onPressed: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const SalesOrderScreen()),
              ),
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                elevation: 2,
              ),
              child: const Text('Create Order'),
            ),
          ],
        ),
      ),
      toolbarHeight: kToolbarHeight,
    );
  }
}




























// import 'dart:async';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:provider/provider.dart';
// import '../../../../Global/custom_button_reuse.dart';
// import '../../../../Global/custom_colors.dart';
// import '../../../../Global/custom_sized_box.dart';
// import '../../../../Global/smartsearchtextfield.dart';
// import '../../sales_order_print/currentOrderPrint.dart';
// import '../../sales_order_print/todat_orders_print.dart';
// import '../../sales_order_providers/editcustomerscreenProvider.dart';
// import '../all_orders_page/services/get_sales_order_service.dart';
// import '../create_salesOrder.dart/create_sales_order.dart';
// import '../create_salesOrder.dart/editcustomerdetails.dart';
// import '../model/sales_order_model.dart';

// class CurrentOrdersPage extends StatefulWidget {
//   const CurrentOrdersPage({super.key});

//   @override
//   _CurrentOrdersPageState createState() => _CurrentOrdersPageState();
// }

// class _CurrentOrdersPageState extends State<CurrentOrdersPage> {
//   int? _selectedTransactionIndex;
//   final TextEditingController _searchController = TextEditingController();
//   Timer? _debounce;

//   DateTime? _ToDate;

//   @override
//   void dispose() {
//     // _searchController.dispose();
//     // _debounce?.cancel();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final apiService = context.watch<ApiServiceSalesOrderProvider>();
//     final filteredSalesOrders = apiService.hivefilteredOrders
//         .map((order) => SalesOrderDisplay.fromMap(order))
//         .where(
//             (order) => order.status != "Open Order") // <-- Exclude Open Order
//         .toList();
//     print("filteredSalesOrders: $filteredSalesOrders");

//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: _buildAppBar(
//           context, apiService, filteredSalesOrders.cast<SalesOrderDisplay>()),
//       body: Row(
//         children: [
//           Expanded(
//             flex: 1,
//             child: _buildOrderList(
//                 filteredSalesOrders.cast<SalesOrderDisplay>(),
//                 apiService,
//                 _selectedTransactionIndex),
//           ),
//           // const VerticalDivider(),
//           // Expanded(flex: 1, child: EditCustomerDetails()),
//           const VerticalDivider(),
//           Expanded(
//             flex: 1,
//             child: Consumer<EditCustomerScreenProvider>(
//               builder: (context, customerScreenProvider, child) {
//                 return filteredSalesOrders.isNotEmpty &&
//                         _selectedTransactionIndex != null
//                     ? EditCustomerDetails(
//                         key: ValueKey(
//                             '${_selectedTransactionIndex}_${customerScreenProvider.isModifyMode}'),
//                         selectedOrder:
//                             filteredSalesOrders[_selectedTransactionIndex!],
//                         isEditing: customerScreenProvider.isModifyMode.value,
//                         orderType: 'CurrentOrder',
//                       )
//                     : _buildEmptyOrderState();
//               },
//             ),
//           ),
//           const VerticalDivider(),
//           Expanded(
//             flex: 1,
//             child: _buildOrderDetails(
//                 filteredSalesOrders, _selectedTransactionIndex, apiService),
//           ),
//         ],
//       ),
//     );
//   }

//   AppBar _buildAppBar(
//       BuildContext context,
//       ApiServiceSalesOrderProvider apiService,
//       List<SalesOrderDisplay> hivefilteredSalesOrders) {
//     return AppBar(
//       automaticallyImplyLeading: false,
//       backgroundColor: Colors.white,
//       title: Row(
//         mainAxisAlignment: MainAxisAlignment.start,
//         children: [
//           Text("${hivefilteredSalesOrders.length} "),
//           const Text(
//             'Current Orders',
//             style: TextStyle(color: Colors.black),
//           ),
//           const SizedBox(width: 10),
//           IconButton(
//             onPressed: () {
//               apiService.changeDate(Duration(days: -1));
//             },
//             icon: const Icon(Icons.arrow_back_ios, color: Colors.blue),
//             tooltip: "Previous Date",
//           ),
//           const SizedBox(width: 10),
//           Text(
//             DateFormat('dd-MM-yy').format(apiService.selectedDate!),
//             style: const TextStyle(fontSize: 11),
//           ),
//           const SizedBox(width: 10),
//           IconButton(
//             onPressed: () {
//               apiService.changeDate(Duration(days: 1));
//             },
//             icon: const Icon(Icons.arrow_forward_ios, color: Colors.blue),
//             tooltip: "Next Date",
//           ),
//           const SizedBox(width: 4),
//           ElevatedButton(
//             onPressed: () async {
//               PrintUtility.printReceiptDetails(
//                   context, hivefilteredSalesOrders);
//             },
//             child: const Text('Print'),
//             style: ElevatedButton.styleFrom(
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(8.0),
//               ),
//               backgroundColor: Colors.white,
//               foregroundColor: Colors.blue,
//               elevation: 2,
//             ),
//           ),
//         ],
//       ),
//       centerTitle: false,
//       flexibleSpace: Align(
//         alignment: Alignment.center,
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             ElevatedButton(
//               onPressed: () {},
//               style: ElevatedButton.styleFrom(
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(8.0),
//                 ),
//                 backgroundColor: Colors.white,
//                 foregroundColor: Colors.blue,
//                 elevation: 2,
//               ),
//               child: const Text('Current Order'),
//             ),
//             const SizedBox(width: 10),
//             ElevatedButton(
//               onPressed: () {
//                 Navigator.of(context).pushNamed('/all-orders');
//               },
//               style: ElevatedButton.styleFrom(
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(8.0),
//                 ),
//                 backgroundColor: Colors.blue,
//                 foregroundColor: Colors.white,
//                 elevation: 2,
//               ),
//               child: const Text('All Orders'),
//             ),
//             const SizedBox(width: 10),
//             ElevatedButton(
//               onPressed: () {
//                 Navigator.pushReplacement(
//                   context,
//                   MaterialPageRoute(builder: (context) => SalesOrderScreen()),
//                 );
//               },
//               style: ElevatedButton.styleFrom(
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(8.0),
//                 ),
//                 backgroundColor: Colors.blue,
//                 foregroundColor: Colors.white,
//                 elevation: 2,
//               ),
//               child: const Text('Create Order'),
//             ),
//           ],
//         ),
//       ),
//       toolbarHeight: kToolbarHeight,
//     );
//   }

//   Widget _buildOrderList(
//     List<SalesOrderDisplay> filteredSalesOrders,
//     ApiServiceSalesOrderProvider apiService,
//     int? selectedIndex,
//   ) {
//     return Column(
//       children: [
//         Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: SmartSearchField(
//             controller: _searchController,
//             onSearch: apiService.searchOrders,
//           ),
//         ),
//         Expanded(
//           child: filteredSalesOrders.isEmpty
//               ? const Center(child: Text("No orders available"))
//               : ListView.builder(
//                   itemCount: filteredSalesOrders.length,
//                   itemBuilder: (context, index) {
//                     final order = filteredSalesOrders[index];
//                     return Card(
//                       color: order.status == "dispatched"
//                           ? Colors.red[200]
//                           : Colors.white,
//                       margin: const EdgeInsets.symmetric(
//                         horizontal: 10,
//                         vertical: 5,
//                       ),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       child: Padding(
//                         padding: const EdgeInsets.all(10.0),
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.end,
//                               children: [
//                                 Container(
//                                   padding: const EdgeInsets.symmetric(
//                                     horizontal: 8,
//                                     vertical: 4,
//                                   ),
//                                   decoration: BoxDecoration(
//                                     color: Colors.indigo[200],
//                                     borderRadius: BorderRadius.circular(4),
//                                   ),
//                                   child: Text(
//                                     order.orderType ?? '',
//                                     style: const TextStyle(
//                                       color: Colors.white,
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             const SizedBox(height: 8),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Expanded(
//                                   child: Text(
//                                     'Order ID',
//                                     style: TextStyle(
//                                       fontWeight: FontWeight.bold,
//                                       color: Colors.grey[700],
//                                     ),
//                                   ),
//                                 ),
//                                 Expanded(
//                                   child: Text(
//                                     'Order Taken By',
//                                     style: TextStyle(
//                                       fontWeight: FontWeight.bold,
//                                       color: Colors.grey[700],
//                                     ),
//                                   ),
//                                 ),
//                                 Expanded(
//                                   child: Text(
//                                     'Status',
//                                     style: TextStyle(
//                                       fontWeight: FontWeight.bold,
//                                       color: Colors.grey[700],
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             const SizedBox(height: 4),
//                             ListTile(
//                               title: Row(
//                                 children: [
//                                   Expanded(child: Text(order.saleOrderNo)),
//                                   Expanded(
//                                     child: Text(order.employeeName ?? 'N/A'),
//                                   ),
//                                   Expanded(child: Text(order.status)),
//                                 ],
//                               ),
//                               selected: selectedIndex == index,
//                               onTap: () => setState(() {
//                                 _selectedTransactionIndex = index;
//                               }),
//                             ),
//                           ],
//                         ),
//                       ),
//                     );
//                   },
//                 ),
//         ),
//       ],
//     );
//   }
//   // Helper Functions

//   Widget _buildOrderDetails(List<SalesOrderDisplay> hivefilteredSalesOrders,
//       int? selectedIndex, ApiServiceSalesOrderProvider apiService) {
//     print("11");
//     if (selectedIndex == null || hivefilteredSalesOrders.isEmpty) {
//       print("12");
//       return _buildEmptyOrderState();
//     }

//     final salesOrder = hivefilteredSalesOrders[selectedIndex];
//     print("$salesOrder");
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           _buildOrderHeader(salesOrder),
//           Divider(color: Colors.grey[400]),
//           _buildOrderItemsList(salesOrder),
//           _buildOrderSummary(salesOrder),
//           _buildOrderActions(context, salesOrder),
//         ],
//       ),
//     );
//   }

//   Widget _buildEmptyOrderState() {
//     return Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(Icons.shopping_cart_outlined,
//               size: 100, color: const Color.fromARGB(255, 97, 220, 236)),
//           SizedBox(height: 20),
//           Text("Select an order to view details",
//               style: TextStyle(color: Colors.grey, fontSize: 18)),
//         ],
//       ),
//     );
//   }

//   Widget _buildOrderHeader(SalesOrderDisplay salesOrder) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Payment Type',
//                 style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
//             Text(salesOrder.paymentType, style: TextStyle(fontSize: 11)),
//           ],
//         ),
//         Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('Order ID',
//                 style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
//             Text(
//               salesOrder.salesOrderId.length > 5
//                   ? salesOrder.salesOrderId
//                       .substring(salesOrder.salesOrderId.length - 5)
//                   : salesOrder.salesOrderId,
//               style: TextStyle(fontSize: 11),
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildOrderItemsList(SalesOrderDisplay salesOrder) {
//     // Check if isBoxItem and varianceName are not null and have the same length
//     if (salesOrder.isBoxItem == null ||
//         salesOrder.varianceName == null ||
//         salesOrder.isBoxItem!.length != salesOrder.varianceName.length) {
//       return Center(child: Text('Data is incomplete or invalid'));
//     }

//     // Separate box items and non-box items while maintaining original order
//     List<int> boxItemIndices = [];
//     List<int> nonBoxItemIndices = [];

//     // Populate boxItemIndices and nonBoxItemIndices
//     for (int i = 0; i < salesOrder.varianceName.length; i++) {
//       print("Box item: ${salesOrder.isBoxItem![i]}");
//       if (salesOrder.isBoxItem![i].toLowerCase() == 'yes' ?? false) {
//         boxItemIndices.add(i);
//       } else {
//         nonBoxItemIndices.add(i);
//       }
//     }

//     // Ensure itemCount is valid; if no items, return an empty container
//     int itemCount =
//         nonBoxItemIndices.length + (boxItemIndices.isNotEmpty ? 1 : 0);

//     if (itemCount == 0) {
//       return SizedBox(); // Return an empty widget if no items to display
//     }

//     return Expanded(
//       child: ListView.separated(
//         itemCount: itemCount,
//         separatorBuilder: (context, index) => SizedBox(height: 8),
//         itemBuilder: (context, index) {
//           // Show box items card first if present
//           if (boxItemIndices.isNotEmpty && index == 0) {
//             return _buildBoxItemsCard(salesOrder, boxItemIndices);
//           }

//           // Adjust index for non-box items
//           final adjustedIndex = index - (boxItemIndices.isNotEmpty ? 1 : 0);

//           // Ensure the adjustedIndex is within bounds for nonBoxItemIndices
//           if (adjustedIndex >= nonBoxItemIndices.length) {
//             return SizedBox(); // Return an empty widget if index is out of bounds
//           }

//           return _buildOrderItemTile(
//               salesOrder, nonBoxItemIndices[adjustedIndex],
//               showAsBoxItem: false);
//         },
//       ),
//     );
//   }

//   Widget _buildBoxItemsCard(
//       SalesOrderDisplay salesOrder, List<int> boxIndices) {
//     return Card(
//       elevation: 4,
//       margin: EdgeInsets.symmetric(vertical: 0, horizontal: 0),
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(12),
//         side: BorderSide(
//           color: Colors.blue.shade300,
//           width: 1.5,
//         ),
//       ),
//       child: Container(
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(12),
//           gradient: LinearGradient(
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//             colors: [Colors.white, Colors.blue.shade50],
//           ),
//         ),
//         child: Padding(
//           padding: EdgeInsets.all(12),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Container(
//                 decoration: BoxDecoration(
//                   color: Colors.blue.shade100.withOpacity(0.5),
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//                 child: Row(
//                   children: [
//                     Icon(
//                       Icons.inventory_2,
//                       size: 18,
//                       color: Colors.blue.shade700,
//                     ),
//                     SizedBox(width: 8),
//                     // Display boxqty here
//                     Text(
//                       '${salesOrder.boxQty} ×', // Your box quantity field
//                       style: TextStyle(
//                         color: Colors.blue.shade800,
//                         fontWeight: FontWeight.bold,
//                         fontSize: 14,
//                       ),
//                     ),
//                     SizedBox(width: 8),
//                     Text(
//                       'BOX ITEMS',
//                       style: TextStyle(
//                         color: Colors.blue.shade800,
//                         fontWeight: FontWeight.bold,
//                         fontSize: 14,
//                         letterSpacing: 0.5,
//                       ),
//                     ),
//                     Spacer(),
//                     Container(
//                       padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                       decoration: BoxDecoration(
//                         color: Colors.blue.shade600,
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                       child: Text(
//                         '${boxIndices.length}',
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontWeight: FontWeight.bold,
//                           fontSize: 12,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               SizedBox(height: 10),
//               Container(
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: Column(
//                   children: boxIndices
//                       .map((index) => Padding(
//                             padding: EdgeInsets.only(
//                                 bottom: index == boxIndices.last ? 0 : 8),
//                             child: Container(
//                               child: _buildOrderItemTile(
//                                 salesOrder,
//                                 index,
//                                 showAsBoxItem: true,
//                               ),
//                             ),
//                           ))
//                       .toList(),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildOrderItemTile(SalesOrderDisplay salesOrder, int index,
//       {bool showAsBoxItem = false}) {
//     // Debugging output to verify values
//     print('[Box Item Debug] Index: $index');
//     print('Qty: ${salesOrder.qty[index]}');
//     print('Price: ${salesOrder.price[index]}');
//     print('Amount: ${salesOrder.amount[index]}');
//     print('Is Box Item: ${salesOrder.isBoxItem?[index]}');

//     return ListTile(
//       contentPadding: EdgeInsets.zero,
//       title: Text(
//         salesOrder.varianceName[index],
//         style: TextStyle(
//           fontSize: 12,
//           color: showAsBoxItem ? Colors.blue.shade800 : Colors.grey,
//         ),
//       ),
//       subtitle: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Text(
//             salesOrder.uom[index] != 'Kgs'
//                 ? '${salesOrder.qty[index]} ${salesOrder.uom[index]} x ${salesOrder.price[index]}'
//                 : '${salesOrder.weight[index]} ${salesOrder.uom[index]} x ${salesOrder.price[index]}',
//             style: TextStyle(fontSize: 10),
//           ),
//         ],
//       ),
//       trailing: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Text(
//             '₹${salesOrder.amount[index].toStringAsFixed(2)}',
//             style: TextStyle(
//               fontSize: 12,
//               fontWeight: FontWeight.bold,
//               color: showAsBoxItem ? Colors.blue.shade800 : Colors.black,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildOrderSummary(SalesOrderDisplay salesOrder) {
//     return Align(
//       alignment: Alignment.centerRight, // Align summary to the right
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.end, // Align text to the right
//         mainAxisSize: MainAxisSize.min, // Minimize height to fit content
//         children: [
//           if (salesOrder.discount > 0)
//             Text(
//               'Discount: ${salesOrder.discountAmount}%',
//               style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
//             ),
//           if (salesOrder.customCharge > 0)
//             Text(
//               'Custom Charge: ₹${salesOrder.customCharge.toStringAsFixed(0)}',
//               style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
//             ),
//           Text(
//             'Total Amount: ₹${salesOrder.totalAmount.toStringAsFixed(0)}',
//             style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
//           ),
//           Text(
//             // 'Advance Amount: ₹${salesOrder.advanceAmount.toStringAsFixed(0)}',
//             'Advance Amount: ₹${salesOrder.advanceAmount}',
//             style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildOrderActions(
//       BuildContext context, SalesOrderDisplay salesOrder) {
//     return Column(
//       children: [
//         SizedBox(height: 20),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             CustomButton(
//               text: 'Pay ₹ ${salesOrder.balanceAmount}',
//               onPressed: salesOrder.status != "SalesOrder Completed"
//                   ? () => _showPaymentDialog(context, salesOrder)
//                   : () {},
//               backgroundColor: salesOrder.status != "SalesOrder Completed"
//                   ? CustomColors.primaryColor
//                   : Colors.grey,
//               textColor: CustomColors.whiteColor,
//               padding: EdgeInsets.symmetric(horizontal: 100, vertical: 22),
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   void _showPaymentDialog(BuildContext context, SalesOrderDisplay salesOrder) {
//     double totalAmount = salesOrder.balanceAmount;

//     if (totalAmount != 0) {
//       showDialog(
//         barrierDismissible: false,
//         context: context,
//         builder: (BuildContext context) {
//           return Dialog(
//             backgroundColor: Colors.white,
//             child: CustomSizedBox(
//               width: MediaQuery.of(context).size.width * 0.7,
//               child: OrderManagementPayandPrint(
//                 totalAmount: totalAmount,
//                 holdBillId: '',
//                 orderId: salesOrder.saleOrderNo,
//                 employee: salesOrder.employeeName,
//                 discount: salesOrder.discount,
//                 customerNumber: salesOrder.customerNumber,
//                 salesOrder: salesOrder,
//               ),
//             ),
//           );
//         },
//       );
//     }
//   }
// }












