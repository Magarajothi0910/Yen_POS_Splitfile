import 'approval_order_model.dart';

class SalesOrder {
  List<String> itemName;
  List<String> varianceName;
  List<double> weight;
  List<int> qty;
  List<int> price;
  String? branchName;
  List<String> itemCode;
  List<int> tax;
  List<String> uom;
  List<double> amount;
  String? deliveryDate;
  String? deliveryTime;
  String event;
  String? branchId;
  String customerNumber;
  String customerName;
  String deliveryType;
  String address;
  String landmark;
  double discount;
  double discountAmount;
  String remark;
  double? customCharge;
  List<double> advanceAmount;
  double totalAmount;
  double? totalAmount2;
  double? cash;
  double? card;
  double? upi;
  List<String>? advancePaymentType;
  double finalPrice;
  double balanceAmount;
  String saleOrderNo;
  String? orderDate;
  String? orderTime;
  String employeeName;
  String status;
  String? companyName;
  String? companyAddress;
  String? companyGST;
  List<String>? advanceDateTime;
  String? orderType;
  String? approvalStatus;
  String? approvalType;
  String? eventDate;
  List<String>? isBoxItem;
  List<double>? itemWiseDiscount;
  List<double>? itemWiseDiscountAmount;
  List<int>? boxQty;
  List<ApprovalOrderDetail>? approvalDetails;
  SalesOrder(
      {required this.itemName,
      required this.itemCode,
      required this.varianceName,
      this.branchName,
      this.branchId,
      this.itemWiseDiscount,
      this.itemWiseDiscountAmount,
      required this.weight,
      required this.amount,
      required this.tax,
      this.totalAmount2,
      required this.uom,
      required this.qty,
      required this.price,
      required this.totalAmount,
      this.deliveryDate,
      this.deliveryTime,
      required this.event,
      this.boxQty,
      this.cash,
      this.card,
      this.upi,
      required this.customerNumber,
      required this.customerName,
      required this.deliveryType,
      required this.address,
      required this.landmark,
      required this.discount,
      required this.discountAmount,
      required this.remark,
      this.customCharge,
      required this.advanceAmount,
      this.advancePaymentType,
      required this.finalPrice,
      required this.balanceAmount,
      required this.saleOrderNo,
      this.orderDate,
      this.orderTime,
      required this.employeeName,
      required this.status,
      this.companyGST,
      this.companyAddress,
      this.companyName,
      this.advanceDateTime,
      this.orderType,
      this.approvalType,
      this.approvalStatus,
      this.isBoxItem,
      this.approvalDetails,
      this.eventDate});

  factory SalesOrder.fromJson(Map<String, dynamic> json) {
    return SalesOrder(
      itemName: List<String>.from(json['itemName'] ?? []),
      varianceName: List<String>.from(json['varianceName'] ?? []),
      itemCode: List<String>.from(json['itemCode'] ?? []),
      qty: List<int>.from(json['qty'] ?? []),
      tax: List<int>.from(json['tax'] ?? []),
      uom: List<String>.from(json['uom'] ?? []),
      amount: List<double>.from(json['amount']?.map((x) => x.toDouble()) ?? []),
      weight: List<double>.from(json['weight']?.map((x) => x.toDouble()) ?? []),
      price: List<int>.from(json['price'] ?? []),
      totalAmount2: json['totalAmount2']?.toDouble(),
      totalAmount: json['totalAmount']?.toDouble() ?? 0.0,
      deliveryDate: json['deliveryDate'],
      deliveryTime: json['deliveryTime'],
      branchId: json['branchId'],
      branchName: json['branchName'],
      event: json['event'] ?? '',
      customerNumber: json['customerNumber'] ?? '',
      customerName: json['customerName'] ?? '',
      deliveryType: json['deliveryType'] ?? '',
      address: json['address'] ?? '',
      landmark: json['landmark'] ?? '',
      discount: json['discount']?.toDouble() ?? 0.0,
      discountAmount: json['discountAmount']?.toDouble() ?? 0.0,
      remark: json['remark'] ?? '',
      customCharge: json['customCharge']?.toDouble() ?? 0.0,
      advanceAmount: List<double>.from(
        json['advanceAmount']?.map((x) => x.toDouble()) ?? [],
      ),
      advancePaymentType: json['advancePaymentType'] != null
          ? List<String>.from(json['advancePaymentType'])
          : null,
      finalPrice: json['finalPrice']?.toDouble() ?? 0.0,
      balanceAmount: json['balanceAmount']?.toDouble() ?? 0.0,
      saleOrderNo: json['saleOrderNo'] ?? '',
      orderDate: json['orderDate'],
      orderTime: json['orderTime'],
      employeeName: json['employeeName'] ?? '',
      status: json['status'] ?? '',
      cash: json['cash']?.toDouble(),
      card: json['card']?.toDouble(),
      upi: json['upi']?.toDouble(),
      advanceDateTime: json['advanceDateTime'] != null
          ? List<String>.from(json['advanceDateTime'])
          : null,
      companyGST: json['companyGST'],
      companyAddress: json['companyAddress'],
      companyName: json['companyName'],
      orderType: json['orderType'],
      approvalStatus: json['approvalStatus'],
      approvalType: json['approvalType'],
      eventDate: json['eventDate'],
      isBoxItem: json['isBoxItem'] != null
          ? List<String>.from(json['isBoxItem'])
          : null,
      approvalDetails: json['approvalDetails'] != null
          ? List<ApprovalOrderDetail>.from(
              json['approvalDetails'].map(
                (x) => ApprovalOrderDetail.fromJson(x),
              ),
            )
          : null,
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'itemName': itemName,
      'varianceName': varianceName,
      'itemCode': itemCode,
      'qty': qty,
      'tax': tax,
      'uom': uom,
      'amount': amount,
      'branchId': branchId,
      'branchName': branchName,
      'price': price,
      'weight': weight,
      'totalAmount2': totalAmount2,
      'deliveryDate': deliveryDate,
      'deliveryTime': deliveryTime,
      'totalAmount': totalAmount,
      'event': event,
      'customerNumber': customerNumber,
      'customerName': customerName,
      'deliveryType': deliveryType,
      'address': address,
      'landmark': landmark,
      'discount': discount,
      'discountAmount': discountAmount,
      'remark': remark,
      'customCharge': customCharge,
      'advanceAmount': advanceAmount,
      'advancePaymentType': advancePaymentType,
      'finalPrice': finalPrice,
      'balanceAmount': balanceAmount,
      'saleOrderNo': saleOrderNo,
      'orderDate': orderDate,
      'orderTime': orderTime,
      'employeeName': employeeName,
      'status': status,
      'cash': cash,
      'card': card,
      'upi': upi,
      'advanceDateTime': advanceDateTime,
      'companyGST': companyGST,
      'companyAddress': companyAddress,
      'companyName': companyName,
      'orderType': orderType,
      'approvalStatus': approvalStatus,
      'approvalType': approvalType,
      'eventDate': eventDate,
      'isBoxItem': isBoxItem,
      'itemWiseDiscount': itemWiseDiscount,
      'itemWiseDiscountAmount': itemWiseDiscountAmount,
      'boxQty': boxQty,
      'approvalDetails': approvalDetails?.map((x) => x.toJson()).toList(),
    };
  }
}
