library;

import 'screens/model/sales_invoicemodel.dart';
import 'sales_order_providers/cartProvider.dart';
import 'sales_order_providers/modifyOrderProvider.dart';

List<CartItem> cartItems = [];
List<SalesOrderItem> invoiceItems = [];
List<modifyCartItem> modifyItems = [];
String deviceName = 'POS001';
