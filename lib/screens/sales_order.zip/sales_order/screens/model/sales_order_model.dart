import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';

import 'sales_invoicemodel.dart';

// class SalesOrderDisplay {
//   final String salesOrderId;
//   final List<String> itemName;
//   final List<int> qty;
//   final List<double> price;
//   final List<String> itemCode;
//   final List<double> weight;
//   final List<double> amount;
//   final List<int> tax;
//   final List<String> uom;
//   final double totalAmount;
//   final double? totalAmount2;
//   final double netPrice;
//   final String orderInvoiceNo;
//   final String branchId;
//   final String branchName;
//   final String invoiceDate;
//   final double cash;
//   final double card;
//   final double upi;
//   final String deliveryPartners;
//   final double otherPayments;
//   final String deliveryPartnerName;
//   final String shiftId;
//   final String shiftName;
//   final String user;
//   final String deliveryDate;
//   final String deliveryTime;
//   final String event;
//   final String customerNumber;
//   final String customerName;
//   final String deliveryType;
//   final String address;
//   final String landmark;
//   final int discount;
//   final double discountAmount;
//   final String remark;
//   final double customCharge;
//   // final double advanceAmount;
//   final List<double> advanceAmount;
//   final String paymentType;
//   final double finalPrice;
//   final double balanceAmount;
//   final String saleOrderNo;
//   final String orderDate;
//   final String orderTime;
//   final String employeeName;
//   final String status;
//   final String cancelOrderRemark;
//   String? audioUrl;

//   SalesOrderDisplay({
//     required this.salesOrderId,
//     required this.itemName,
//     required this.qty,
//     required this.price,
//     required this.itemCode,
//     required this.weight,
//     required this.amount,
//     required this.tax,
//     required this.uom,
//     required this.totalAmount,
//     required this.totalAmount2,
//     required this.netPrice,
//     required this.orderInvoiceNo,
//     required this.branchId,
//     required this.branchName,
//     required this.invoiceDate,
//     required this.cash,
//     required this.card,
//     required this.upi,
//     required this.deliveryPartners,
//     required this.otherPayments,
//     required this.deliveryPartnerName,
//     required this.shiftId,
//     required this.shiftName,
//     required this.user,
//     required this.deliveryDate,
//     required this.deliveryTime,
//     required this.event,
//     required this.customerNumber,
//     required this.customerName,
//     required this.deliveryType,
//     required this.address,
//     required this.landmark,
//     required this.discount,
//     required this.discountAmount,
//     required this.remark,
//     required this.customCharge,
//     required this.advanceAmount,
//     required this.paymentType,
//     required this.finalPrice,
//     required this.balanceAmount,
//     required this.saleOrderNo,
//     required this.orderDate,
//     required this.orderTime,
//     required this.employeeName,
//     required this.status,
//     required this.cancelOrderRemark,
//     this.audioUrl,
//   });

//   factory SalesOrderDisplay.fromMap(Map<String, dynamic> map) {
//     return SalesOrderDisplay(
//       salesOrderId: map['salesOrderId'] ?? '',
//       itemName: List<String>.from(map['itemName'] ?? []),
//       qty: List<int>.from(map['qty'] ?? []),
//       price: List<double>.from(map['price']?.map((x) => x.toDouble()) ?? []),
//       itemCode: List<String>.from(map['itemCode'] ?? []),
//       weight: List<double>.from(map['weight']?.map((x) => x.toDouble()) ?? []),
//       amount: List<double>.from(map['amount']?.map((x) => x.toDouble()) ?? []),
//       tax: List<int>.from(map['tax'] ?? []),
//       uom: List<String>.from(map['uom'] ?? []),
//       totalAmount: (map['totalAmount']?.toDouble() ?? 0.0),
//       totalAmount2: (map['totalAmount2']?.toDouble() ?? 0.0),
//       netPrice: (map['netPrice']?.toDouble() ?? 0.0),
//       orderInvoiceNo: map['orderInvoiceNo'] ?? '',
//       branchId: map['branchId'] ?? '',
//       branchName: map['branchName'] ?? '',
//       invoiceDate: map['invoiceDate'] ?? '',
//       cash: (map['cash']?.toDouble() ?? 0.0),
//       card: (map['card']?.toDouble() ?? 0.0),
//       upi: (map['upi']?.toDouble() ?? 0.0),
//       deliveryPartners: map['deliveryPartners'] ?? '',
//       otherPayments: (map['otherPayments']?.toDouble() ?? 0.0),
//       deliveryPartnerName: map['deliveryPartnerName'] ?? '',
//       shiftId: map['shiftId'] ?? '',
//       shiftName: map['shiftName'] ?? '',
//       user: map['user'] ?? '',
//       deliveryDate: map['deliveryDate'] ?? '',
//       deliveryTime: map['deliveryTime'] ?? '',
//       event: map['event'] ?? '',
//       customerNumber: map['customerNumber'] ?? '',
//       customerName: map['customerName'] ?? '',
//       deliveryType: map['deliveryType'] ?? '',
//       address: map['address'] ?? '',
//       landmark: map['landmark'] ?? '',
//       discount: map['discount'] ?? 0,
//       discountAmount: (map['discountAmount']?.toDouble() ?? 0.0),
//       remark: map['remark'] ?? '',
//       customCharge: (map['customCharge']?.toDouble() ?? 0.0),
//       // advanceAmount: (map['advanceAmount']?.toDouble() ?? 0.0),
//       // advanceAmount: (map['advanceAmount'] is List)
//       //     ? (map['advanceAmount'] as List<dynamic>).isNotEmpty
//       //         ? (map['advanceAmount'] as List<dynamic>)[0].toDouble()
//       //         : 0.0
//       //     : (map['advanceAmount'] is double)
//       //         ? map[
//       //             'advanceAmount'] // If it's already a double, use it directly
//       //         : 0.0, // Default to 0.0 if it's neither a List nor a double
//       advanceAmount: (map['advanceAmount'] is List)
//           ? List<double>.from(map['advanceAmount'].map((x) => x.toDouble()))
//           : [
//               map['advanceAmount']?.toDouble() ?? 0.0
//             ], // Wrap the single value in a list

//       paymentType: map['paymentType'] ?? '',
//       finalPrice: (map['finalPrice']?.toDouble() ?? 0.0),
//       balanceAmount: (map['balanceAmount']?.toDouble() ?? 0.0),
//       saleOrderNo: map['saleOrderNo'] ?? '',
//       orderDate: map['orderDate'] ?? '',
//       orderTime: map['orderTime'] ?? '',
//       employeeName: map['employeeName'] ?? '',
//       status: map['status'] ?? '',
//       cancelOrderRemark: map['cancelOrderRemark'] ?? '',
//     );
//   }

//   Iterable<SalesOrderItem> get items sync* {
//     for (int i = 0; i < itemName.length; i++) {
//       yield SalesOrderItem(
//         itemName: itemName[i],
//         qty: qty[i],
//         price: price[i],
//         itemCode: itemCode[i],
//         weight: weight[i],
//         amount: amount[i],
//         tax: tax[i],
//         uom: uom[i],
//       );
//     }
//   }
// }

class ModifyOrder {
  final String previousId; // Matches with salesOrderId
  final String saleOrderNo; // Matches with saleOrderNo
  // final List<String> itemName;
  final List<String> varianceName;
  final List<double> qty;
  final List<String> uom;
  final List<double> price;
  final List<double> amount;
  List<double>? weight;
  List<String>? isBoxItem;
  ModifyOrder({
    required this.previousId,
    required this.varianceName,
    required this.saleOrderNo,
    // required this.itemName,
    required this.qty,
    required this.uom,
    required this.price,
    required this.amount,
    this.weight,
    this.isBoxItem,
  });

  factory ModifyOrder.fromJson(Map<String, dynamic> json) {
    return ModifyOrder(
      previousId: json['previousOrderId'] ?? '',
      saleOrderNo: json['saleOrderNo'] ?? '',
      // itemName: (json['itemName'] as List<dynamic>?)
      //         ?.map((item) => item.toString())
      //         .toList() ??
      //     [],
      varianceName: (json['varianceName'] as List<dynamic>?)
              ?.map((item) => item.toString())
              .toList() ??
          [],
      qty: (json['qty'] as List<dynamic>?)
              ?.map((qty) => (qty as num?)?.toDouble() ?? 0.0)
              .toList() ??
          [],
      uom: (json['uom'] as List<dynamic>?)
              ?.map((uom) => uom.toString())
              .toList() ??
          [],
      price: (json['price'] as List<dynamic>?)
              ?.map((price) => (price as num?)?.toDouble() ?? 0.0)
              .toList() ??
          [],
      amount: (json['amount'] as List<dynamic>?)
              ?.map((amt) => (amt as num?)?.toDouble() ?? 0.0)
              .toList() ??
          [],
      weight: (json['weight'] as List<dynamic>?)
              ?.map((weight) => (weight as num?)?.toDouble() ?? 0.0)
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'previousOrderId': previousId,
      'saleOrderNo': saleOrderNo,
      'varianceName': varianceName,
      'qty': qty,
      'uom': uom,
      'price': price,
      'amount': amount,
      'weight': weight,
    };
  }
}

// class ToApprove {
//   final String previousId; // Matches with salesOrderId
//   final String salesOrderNo; // Matches with saleOrderNo
//   // final List<String> itemName;
//   final List<String> varianceName;
//   final List<double> qty;
//   final List<String> uom;
//   final List<double> price;
//   final List<double> amount;
//   List<String>? isBoxItem;
//   ToApprove({
//     required this.previousId,
//     required this.salesOrderNo,
//     // required this.itemName,
//     required this.varianceName,
//     required this.qty,
//     required this.uom,
//     required this.price,
//     required this.amount,
//     this.isBoxItem,
//   });

//   factory ToApprove.fromJson(Map<String, dynamic> json) {
//     return ToApprove(
//       previousId: json['previousOrderId'] ?? '',
//       salesOrderNo: json['saleOrderNo'] ?? '',
//       // itemName: (json['itemName'] as List<dynamic>?)
//       //         ?.map((item) => item.toString())
//       //         .toList() ??
//       //     [],
//       varianceName: (json['varianceName'] as List<dynamic>?)
//               ?.map((item) => item.toString())
//               .toList() ??
//           [],
//       qty: (json['qty'] as List<dynamic>?)
//               ?.map((qty) => (qty as num?)?.toDouble() ?? 0.0)
//               .toList() ??
//           [],
//       uom: (json['uom'] as List<dynamic>?)
//               ?.map((uom) => uom.toString())
//               .toList() ??
//           [],
//       price: (json['price'] as List<dynamic>?)
//               ?.map((price) => (price as num?)?.toDouble() ?? 0.0)
//               .toList() ??
//           [],
//       amount: (json['amount'] as List<dynamic>?)
//               ?.map((amt) => (amt as num?)?.toDouble() ?? 0.0)
//               .toList() ??
//           [],
//     );
//   }
//   Map<String, dynamic> toJson() {
//     return {
//       'previousOrderId': previousId,
//       'saleOrderNo': salesOrderNo,
//       'varianceName': varianceName,
//       'qty': qty,
//       'uom': uom,
//       'price': price,
//       'amount': amount,
//       // 'weight': weight,
//     };
//   }
// }

class ToApprove {
  final String previousId; // Matches with salesOrderId
  final String saleOrderNo; // Matches with saleOrderNo
  // final List<String> itemName;
  final List<String> varianceName;
  final List<double> qty;
  final List<String> uom;
  final List<double> price;
  final List<double> amount;
  List<double>? weight;
  List<String>? isBoxItem;
  ToApprove({
    required this.previousId,
    required this.varianceName,
    required this.saleOrderNo,
    // required this.itemName,
    required this.qty,
    required this.uom,
    required this.price,
    required this.amount,
    this.weight,
    this.isBoxItem,
  });

  factory ToApprove.fromJson(Map<String, dynamic> json) {
    return ToApprove(
      previousId: json['previousOrderId'] ?? '',
      saleOrderNo: json['saleOrderNo'] ?? '',
      // itemName: (json['itemName'] as List<dynamic>?)
      //         ?.map((item) => item.toString())
      //         .toList() ??
      //     [],
      varianceName: (json['varianceName'] as List<dynamic>?)
              ?.map((item) => item.toString())
              .toList() ??
          [],
      qty: (json['qty'] as List<dynamic>?)
              ?.map((qty) => (qty as num?)?.toDouble() ?? 0.0)
              .toList() ??
          [],
      uom: (json['uom'] as List<dynamic>?)
              ?.map((uom) => uom.toString())
              .toList() ??
          [],
      price: (json['price'] as List<dynamic>?)
              ?.map((price) => (price as num?)?.toDouble() ?? 0.0)
              .toList() ??
          [],
      amount: (json['amount'] as List<dynamic>?)
              ?.map((amt) => (amt as num?)?.toDouble() ?? 0.0)
              .toList() ??
          [],
      weight: (json['weight'] as List<dynamic>?)
              ?.map((weight) => (weight as num?)?.toDouble() ?? 0.0)
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'previousOrderId': previousId,
      'saleOrderNo': saleOrderNo,
      'varianceName': varianceName,
      'qty': qty,
      'uom': uom,
      'price': price,
      'amount': amount,
      'weight': weight,
    };
  }
}

class SalesOrderDisplay {
  final String salesOrderId;
  final List<String> itemName;
  final List<String> varianceName;
  final List<int> qty;
  final List<double> price;
  final List<String> itemCode;
  final List<double> weight;
  final List<double> amount;
  final List<int> tax;
  final List<String> uom;
  double totalAmount;
  final double? totalAmount2;
  final double netPrice;
  final String orderInvoiceNo;
  final String branchId;
  final String branchName;
  final String invoiceDate;
  final double cash;
  final double card;
  final double upi;
  final String deliveryPartners;
  final double otherPayments;
  final String deliveryPartnerName;
  final String shiftId;
  final String shiftName;
  final String user;
  String deliveryDate;
  final String deliveryTime;
  final String event;
  final String customerNumber;
  final String customerName;
  final String deliveryType;
  final String address;
  final String landmark;
  final int discount;
  final double discountAmount;
  final String remark;
  final double customCharge;
  List<double>? advanceAmount;
  List<String> advanceDateTime;
  List<String> advancePaymentType;
  String? orderType;
  final String paymentType;
  final double finalPrice;
  final double balanceAmount;
  final String saleOrderNo;
  final String orderDate;
  final String orderTime;
  final String employeeName;
  final String status;
  final String cancelOrderRemark;
  String? audioUrl;
  String? eventDate;
  List<String>? isBoxItem;
  List<double>? itemWiseDiscount;
  List<double>? itemWiseDiscountAmount;
  List<int>? boxQty;
  List<bool>? isItemReduced;
  final String? hiveId;
  // final List<ModifiedOrder>? modifiedOrders;
  final List<ModifyOrder>? modifiedOrders;
  final List<ToApprove>? toApprove;
  String? image1;
  String? image2;
  String? audio;
  SalesOrderDisplay(
      {required this.salesOrderId,
      required this.itemName,
      required this.varianceName,
      required this.qty,
      required this.price,
      required this.itemCode,
      required this.weight,
      required this.amount,
      required this.tax,
      required this.uom,
      required this.totalAmount,
      required this.totalAmount2,
      required this.netPrice,
      required this.orderInvoiceNo,
      required this.branchId,
      required this.branchName,
      required this.invoiceDate,
      required this.cash,
      required this.card,
      required this.upi,
      required this.deliveryPartners,
      required this.otherPayments,
      required this.deliveryPartnerName,
      required this.shiftId,
      required this.shiftName,
      required this.user,
      required this.deliveryDate,
      required this.deliveryTime,
      required this.event,
      required this.customerNumber,
      required this.customerName,
      required this.deliveryType,
      required this.address,
      required this.landmark,
      required this.discount,
      required this.discountAmount,
      required this.remark,
      required this.customCharge,
      this.advanceAmount,
      required this.advanceDateTime,
      required this.advancePaymentType,
      required this.paymentType,
      required this.finalPrice,
      required this.balanceAmount,
      required this.saleOrderNo,
      required this.orderDate,
      required this.orderTime,
      required this.employeeName,
      required this.status,
      required this.cancelOrderRemark,
      this.audioUrl,
      this.isItemReduced,
      this.modifiedOrders,
      this.isBoxItem,
      this.itemWiseDiscount,
      this.itemWiseDiscountAmount,
      this.boxQty,
      this.toApprove,
      this.eventDate,
      this.image1,
      this.image2,
      this.audio,
      this.hiveId,
      this.orderType});

  String get formattedDeliveryDate {
    try {
      DateTime parsedDate = DateTime.parse(deliveryDate);
      return DateFormat("dd-MM-yyyy").format(parsedDate);
    } catch (e) {
      print("Error parsing date: $e");
      return deliveryDate; // Return original string if parsing fails
    }
  }

//create a tojson method
  Map<String, dynamic> toJson() {
    return {
      'salesOrderId': salesOrderId,
      'itemName': itemName,
      'varianceName': varianceName,
      'qty': qty,
      'price': price,
      'itemCode': itemCode,
      'weight': weight,
      'amount': amount,
      'tax': tax,
      'uom': uom,
      'totalAmount': totalAmount,
      'totalAmount2': totalAmount2,
      'netPrice': netPrice,
      'orderInvoiceNo': orderInvoiceNo,
      'branchId': branchId,
      'branchName': branchName,
      'invoiceDate': invoiceDate,
      'cash': cash,
      'card': card,
      'upi': upi,
      'deliveryPartners': deliveryPartners,
      'otherPayments': otherPayments,
      'deliveryPartnerName': deliveryPartnerName,
      'shiftId': shiftId,
      'shiftName': shiftName,
      'user': user,
      'deliveryDate': deliveryDate,
      'deliveryTime': deliveryTime,
      'event': event,
      'customerNumber': customerNumber,
      'customerName': customerName,
      'deliveryType': deliveryType,
      'address': address,
      'landmark': landmark,
      'discount': discount,
      'discountAmount': discountAmount,
      'remark': remark,
      'customCharge': customCharge,
      'advanceAmount': advanceAmount,
      'advanceDateTime': advanceDateTime,
      'advancePaymentType': advancePaymentType,
      'paymentType': paymentType,
      'finalPrice': finalPrice,
      'balanceAmount': balanceAmount,
      'saleOrderNo': saleOrderNo,
      'orderDate': orderDate,
      'orderTime': orderTime,
      'employeeName': employeeName,
      'status': status,
      'cancelOrderRemark': cancelOrderRemark,
      'audioUrl': audioUrl,
      'eventDate': eventDate,
      'orderType': orderType,
      'modifiedOrders': modifiedOrders?.map((x) => x.toJson()).toList(),
      //  'toApprove': toApprove?.map((x) => x.toJson()).toList(),
      'isItemReduced': isItemReduced,
      'isBoxItem': isBoxItem,

      'image1': image1,
      'image2': image2,
      'audio': audio,
    };
  }

  factory SalesOrderDisplay.fromJson(Map<String, dynamic> json) {
    return SalesOrderDisplay(
      salesOrderId: json['salesOrderId'] ?? '',
      itemName: List<String>.from(json['itemName'] ?? []),
      varianceName: List<String>.from(json['varianceName'] ?? []),
      qty: (json[''] as List<dynamic>?)
              ?.map((e) => (e as int).toInt())
              .toList() ??
          [],
      price: (json[''] as List<dynamic>?)
              ?.map((x) => (x as num).toDouble())
              .toList() ??
          [],
      itemCode: List<String>.from(json['itemCode'] ?? []),
      weight: (json[''] as List<dynamic>?)
              ?.map((x) => (x as num).toDouble())
              .toList() ??
          [],
      amount: (json[''] as List<dynamic>?)
              ?.map((x) => (x as num).toDouble())
              .toList() ??
          [],
      tax: (json[''] as List<dynamic>?)
              ?.map((e) => (e as num).toInt())
              .toList() ??
          [],
      uom: List<String>.from(json['uom'] ?? []),
      totalAmount: (json[''] as num?)?.toDouble() ?? 0.0,
      totalAmount2: (json[''] as num?)?.toDouble(),
      netPrice: (json[''] as num?)?.toDouble() ?? 0.0,
      orderInvoiceNo: json[''] ?? '',
      branchId: json[''] ?? '',
      branchName: json[''] ?? '',
      invoiceDate: json[''] ?? '',
      cash: (json[''] as num?)?.toDouble() ?? 0.0,
      card: (json[''] as num?)?.toDouble() ?? 0.0,
      upi: (json[''] as num?)?.toDouble() ?? 0.0,
      deliveryPartners: json[''] ?? '',
      otherPayments: (json[''] as num?)?.toDouble() ?? 0.0,
      deliveryPartnerName: json[''] ?? '',
      shiftId: json[''] ?? '',
      shiftName: json[''] ?? '',
      user: json[''] ?? '',
      deliveryDate: json[''] ?? '',
      deliveryTime: json[''] ?? '',
      event: json[''] ?? '',
      customerNumber: json[''] ?? '',
      customerName: json[''] ?? '',
      deliveryType: json[''] ?? '',
      address: json[''] ?? '',
      landmark: json[''] ?? '',
      discount: (json[''] as num?)?.toInt() ?? 0,
      discountAmount: (json[''] as num?)?.toDouble() ?? 0.0,
      remark: json[''] ?? '',
      customCharge: (json[''] as num?)?.toDouble() ?? 0.0,
      advanceAmount: (json[''] is List)
          ? (json[''] as List<dynamic>)
              .map((x) => (x as num).toDouble())
              .toList()
          : [(json[''] as num?)?.toDouble() ?? 0.0],
      advanceDateTime: List<String>.from(json[''] ?? []),
      advancePaymentType: List<String>.from(json[''] ?? []),
      paymentType: json[''] ?? '',
      finalPrice: (json[''] as num?)?.toDouble() ?? 0.0,
      balanceAmount: (json[''] as num?)?.toDouble() ?? 0.0,
      saleOrderNo: json[''] ?? '',
      orderDate: json[''] ?? '',
      orderTime: json[''] ?? '',
      employeeName: json[''] ?? '',
      status: json[''] ?? '',
      cancelOrderRemark: json[''] ?? '',
      audioUrl: json[''],
      eventDate: json[''] ?? '',
      orderType: json[''] ?? '',
      modifiedOrders: json[''] != null
          ? (json[''] as List).map((x) => ModifyOrder.fromJson(x)).toList()
          : null,
      toApprove: json[''] != null
          ? (json[''] as List).map((x) => ToApprove.fromJson(x)).toList()
          : null,
      isItemReduced: json[''] != null ? List<bool>.from(json['']) : null,
      isBoxItem: json[''] != null ? List<String>.from(json['']) : null,
    );
  }

  // factory SalesOrderDisplay.fromMap(Map<String, dynamic> map) {
  //   // Map<String, dynamic> orderMap = map;

  //   // // Handle 'data' field (check if it's a Map instead of List)
  //   // if (map.containsKey('data') && map['data'] is Map<String, dynamic>) {
  //   //   orderMap = Map<String, dynamic>.from(map['data'] as Map);
  //   // }

  //   Map<String, dynamic> orderMap = map;

  //   // Handle 'data' field if it's a Map
  //   if (map.containsKey('data') && map['data'] is Map<String, dynamic>) {
  //     orderMap = Map<String, dynamic>.from(map['data'] as Map);
  //   }

  //   // Helper function to safely parse lists
  //   List<T> _parseList<T>(dynamic input, T Function(dynamic) converter) {
  //     if (input == null) return [];
  //     if (input is List) {
  //       return input.map(converter).whereType<T>().toList();
  //     } else {
  //       return [converter(input)].whereType<T>().toList();
  //     }
  //   }

  //   print('from map${orderMap['saleOrderNo']}');
  //   return SalesOrderDisplay(
  //     hiveId: orderMap['hiveId'] ?? '',
  //     salesOrderId: orderMap['salesOrderId'] ?? '',
  //     itemName: List<String>.from(orderMap['itemName'] ?? []),
  //     varianceName: List<String>.from(orderMap['varianceName'] ?? []),
  //     qty: (orderMap['qty'] as List<dynamic>?)
  //             ?.map((e) => int.tryParse(e.toString()) ?? 0)
  //             .toList() ??
  //         [],
  //     price: (orderMap['price'] as List<dynamic>?)
  //             ?.map((x) => (x as num).toDouble())
  //             .toList() ??
  //         [],
  //     itemCode: List<String>.from(orderMap['itemCode'] ?? []),
  //     weight: (orderMap['weight'] as List<dynamic>?)
  //             ?.map((x) => (x as num).toDouble())
  //             .toList() ??
  //         [],
  //     amount: (orderMap['amount'] as List<dynamic>?)
  //             ?.map((x) => (x as num).toDouble())
  //             .toList() ??
  //         [],
  //     tax: (orderMap['tax'] as List<dynamic>?)
  //             ?.map((e) => int.tryParse(e.toString()) ?? 0)
  //             .toList() ??
  //         [],
  //     uom: List<String>.from(orderMap['uom'] ?? []),
  //     totalAmount: (orderMap['totalAmount']?.toDouble() ?? 0.0),
  //     totalAmount2: (orderMap['totalAmount2']?.toDouble()),
  //     netPrice: (orderMap['netPrice']?.toDouble() ?? 0.0),
  //     orderInvoiceNo: orderMap['orderInvoiceNo'] ?? '',
  //     branchId: orderMap['branchId'] ?? '',
  //     branchName: orderMap['branchName'] ?? '',
  //     invoiceDate: orderMap['invoiceDate'] ?? '',
  //     cash: (orderMap['cash']?.toDouble() ?? 0.0),
  //     card: (orderMap['card']?.toDouble() ?? 0.0),
  //     upi: (orderMap['upi']?.toDouble() ?? 0.0),
  //     deliveryPartners: orderMap['deliveryPartners'] ?? '',
  //     otherPayments: (orderMap['otherPayments']?.toDouble() ?? 0.0),
  //     deliveryPartnerName: orderMap['deliveryPartnerName'] ?? '',
  //     shiftId: orderMap['shiftId'] ?? '',
  //     shiftName: orderMap['shiftName'] ?? '',
  //     user: orderMap['user'] ?? '',
  //     deliveryDate: orderMap['deliveryDate'] ?? '',
  //     deliveryTime: orderMap['deliveryTime'] ?? '',
  //     event: orderMap['event'] ?? '',
  //     customerNumber: orderMap['customerNumber'] ?? '',
  //     customerName: orderMap['customerName'] ?? '',
  //     deliveryType: orderMap['deliveryType'] ?? '',
  //     address: orderMap['address'] ?? '',
  //     landmark: orderMap['landmark'] ?? '',
  //     discount: orderMap['discount'] != null
  //         ? (orderMap['discount'] as num).toInt()
  //         : 0,
  //     discountAmount: (orderMap['discountAmount']?.toDouble() ?? 0.0),
  //     remark: orderMap['remark'] ?? '',
  //     customCharge: (orderMap['customCharge']?.toDouble() ?? 0.0),
  //     advanceAmount: (orderMap['advanceAmount'] is List)
  //         ? List<double>.from((orderMap['advanceAmount'] as List<dynamic>)
  //             .map((x) => (x as num).toDouble()))
  //         : [orderMap['advanceAmount']?.toDouble() ?? 0.0],
  //     advanceDateTime: List<String>.from(orderMap['advanceDateTime'] ?? []),
  //     advancePaymentType:
  //         List<String>.from(orderMap['advancePaymentType'] ?? []),
  //     paymentType: orderMap['paymentType'] ?? '',
  //     finalPrice: (orderMap['finalPrice']?.toDouble() ?? 0.0),
  //     balanceAmount: (orderMap['balanceAmount']?.toDouble() ?? 0.0),
  //     saleOrderNo: orderMap['saleOrderNo'] ?? '',
  //     orderDate: orderMap['orderDate'] ?? '',
  //     orderTime: orderMap['orderTime'] ?? '',
  //     employeeName: orderMap['employeeName'] ?? '',
  //     status: orderMap['status'] ?? '',
  //     cancelOrderRemark: orderMap['cancelOrderRemark'] ?? '',
  //     eventDate: orderMap['eventDate'] ?? '',
  //     orderType: orderMap['orderType'] ?? '',
  //     modifiedOrders: null, // handle if needed
  //     toApprove: null, // handle if needed
  //     audioUrl: orderMap['audioUrl'],
  //     isItemReduced: null, // handle if needed
  //     isBoxItem: List<String>.from(orderMap['isBoxItem'] ?? []),
  //   );
  // }

  factory SalesOrderDisplay.fromMap(Map<String, dynamic> map) {
    // Extract nested 'data' map if present
    Map<String, dynamic> imageMap = map;
    final orderMap = map.containsKey('data') && map['data'] is Map
        ? Map<String, dynamic>.from(map['data'])
        : map;

    // List<T> _parseList<T>(
    //     dynamic input, T Function(dynamic) parser, T defaultValue) {
    //   if (input == null) return [defaultValue];
    //   if (input is List) {
    //     return input.map((v) => parser(v) ?? defaultValue).toList();
    //   }
    //   return [parser(input) ?? defaultValue];
    // }

    List<T> _parseList<T>(
        dynamic input, T Function(dynamic) parser, T defaultValue) {
      if (input == null) return [defaultValue];
      if (input is List) {
        return input.map((v) => parser(v) ?? defaultValue).toList();
      }
      // Explicitly handle String or single value
      try {
        return [parser(input) ?? defaultValue];
      } catch (e) {
        debugPrint('❌ Failed to parse input: $input, error: $e');
        return [defaultValue];
      }
    }

    var encoder = JsonEncoder.withIndent('  ');
    print("orderMap: \n${encoder.convert(orderMap)}");

    // Ensure the image1, image2, and audio fields are present and print them
    String image1 = "";
    String image2 = "";
    String audio = "";

    // Check if the fields exist in the response, otherwise, print a helpful message
    if (imageMap.containsKey('image1')) {
      print("Sale Order Image 1: ${imageMap['image1']}");
      image1 = imageMap['image1'] ?? 'No image1 available';
    } else {
      print("Sale Order Image 1: No image1 found");
    }

    if (imageMap.containsKey('image2')) {
      print("Sale Order Image 2: ${imageMap['image2']}");
      image2 = imageMap['image2'] ?? 'No image2 available';
    } else {
      print("Sale Order Image 2: No image2 found");
    }

    if (imageMap.containsKey('audio')) {
      print("Sale Order Audio: ${imageMap['audio']}");
      audio = imageMap['audio'] ?? 'No audio available';
    } else {
      print("Sale Order Audio: No audio found");
    }

    print("SOrder Image 1: $image1");
    print("SOrder Image 2: $image2");
    print("SOrder Audio: $audio");

    return SalesOrderDisplay(
      hiveId: orderMap['hiveId']?.toString() ?? '',
      salesOrderId: orderMap['salesOrderId']?.toString() ?? '',
      itemName:
          _parseList<String>(orderMap['itemName'], (v) => v.toString(), 'N/A'),
      varianceName: _parseList<String>(
          orderMap['varianceName'], (v) => v.toString(), 'N/A'),
      qty: _parseList<int>(
          orderMap['qty'], (v) => int.tryParse(v.toString()) ?? 0, 0),

      // qty: (orderMap['qty'] as List<dynamic>?)
      //         ?.map((e) => int.tryParse(e.toString()) ?? 0)
      //         .toList() ??
      //     [],
      price: _parseList<double>(
          orderMap['price'], (v) => double.tryParse(v.toString()) ?? 0.0, 0.0),
      itemCode:
          _parseList<String>(orderMap['itemCode'], (v) => v.toString(), 'N/A'),
      weight: _parseList<double>(
          orderMap['weight'], (v) => double.tryParse(v.toString()) ?? 0.0, 0.0),
      amount: _parseList<double>(
          orderMap['amount'], (v) => double.tryParse(v.toString()) ?? 0.0, 0.0),
      // tax: (orderMap['tax'] as List<dynamic>?)
      //         ?.map((e) => int.tryParse(e.toString()) ?? 0)
      //         .toList() ??
      //     [],
      // uom: List<String>.from(orderMap['uom'] ?? []),
      totalAmount: (orderMap['totalAmount']?.toDouble() ?? 0.0),
      totalAmount2: (orderMap['totalAmount2']?.toDouble()),
      netPrice: (orderMap['netPrice']?.toDouble() ?? 0.0),
      orderInvoiceNo: orderMap['orderInvoiceNo'] ?? '',
      branchId: orderMap['branchId'] ?? '',
      branchName: orderMap['branchName'] ?? '',
      invoiceDate: orderMap['invoiceDate'] ?? '',
      cash: (orderMap['cash']?.toDouble() ?? 0.0),
      card: (orderMap['card']?.toDouble() ?? 0.0),
      upi: (orderMap['upi']?.toDouble() ?? 0.0),
      deliveryPartners: orderMap['deliveryPartners'] ?? '',
      otherPayments: (orderMap['otherPayments']?.toDouble() ?? 0.0),
      deliveryPartnerName: orderMap['deliveryPartnerName'] ?? '',
      shiftId: orderMap['shiftId'] ?? '',
      shiftName: orderMap['shiftName'] ?? '',
      user: orderMap['user'] ?? '',
      deliveryDate: orderMap['deliveryDate'] ?? '',
      deliveryTime: orderMap['deliveryTime'] ?? '',
      event: orderMap['event'] ?? '',
      customerNumber: orderMap['customerNumber'] ?? '',
      customerName: orderMap['customerName'] ?? '',
      deliveryType: orderMap['deliveryType'] ?? '',
      address: orderMap['address'] ?? '',
      landmark: orderMap['landmark'] ?? '',
      discount: orderMap['discount'] != null
          ? (orderMap['discount'] as num).toInt()
          : 0,
      discountAmount: (orderMap['discountAmount']?.toDouble() ?? 0.0),
      remark: orderMap['remark'] ?? '',
      customCharge: (orderMap['customCharge']?.toDouble() ?? 0.0),
      // advanceAmount: (orderMap['advanceAmount'] is List)
      //     ? List<double>.from((orderMap['advanceAmount'] as List<dynamic>)
      //         .map((x) => (x as num).toDouble()))
      //     : [orderMap['advanceAmount']?.toDouble() ?? 0.0],
      // advanceDateTime: List<String>.from(orderMap['advanceDateTime'] ?? []),
      // advancePaymentType:
      //     List<String>.from(orderMap['advancePaymentType'] ?? []),
      tax: (orderMap['tax'] as List<dynamic>?)
              ?.map((e) => int.tryParse(e.toString()) ?? 0)
              .toList() ??
          [],
      uom: List<String>.from(orderMap['uom'] ?? []),
      advanceAmount: (orderMap['advanceAmount'] is List)
          ? List<double>.from((orderMap['advanceAmount'] as List<dynamic>)
              .map((x) => (x as num).toDouble()))
          : [orderMap['advanceAmount']?.toDouble() ?? 0.0],
      advanceDateTime: List<String>.from(orderMap['advanceDateTime'] ?? []),
      advancePaymentType:
          List<String>.from(orderMap['advancePaymentType'] ?? []),
      paymentType: orderMap['paymentType'] ?? '',
      finalPrice: (orderMap['finalPrice']?.toDouble() ?? 0.0),
      balanceAmount: (orderMap['balanceAmount']?.toDouble() ?? 0.0),
      saleOrderNo: orderMap['saleOrderNo'] ?? '',
      orderDate: orderMap['orderDate'] ?? '',
      orderTime: orderMap['orderTime'] ?? '',
      employeeName: orderMap['employeeName'] ?? '',
      status: orderMap['status'] ?? '',
      cancelOrderRemark: orderMap['cancelOrderRemark'] ?? '',
      eventDate: orderMap['eventDate'] ?? '',
      orderType: orderMap['orderType'] ?? '',
      modifiedOrders: null, // handle if needed
      toApprove: null, // handle if needed
      audioUrl: orderMap['audioUrl'],
      image1: image1,
      image2: image2,
      audio: audio,
      isItemReduced: null, // handle if needed
      // isBoxItem: List<String>.from(orderMap['isBoxItem'] ?? []),
      isBoxItem: _parseList<String>(
          orderMap['isBoxItem'], (v) => v.toString(), 'N/A' // Default if needed
          ),
    );
  }

  SalesOrderDisplay copyWith({
    List<ModifyOrder>? modifiedOrders,
    List<ToApprove>? toApprove,
    // List<String>? isBoxItem,
    // double? totalAmount, // ✅ Add this
    // double? balanceAmount, // ✅ Add this
    // List<double>? advanceAmount,
    // List<String>? itemName,
    // List<int>? qty,
    // List<String>? uom,
    // List<double>? weight,
    // List<double>? amount,
    // List<double>? price,
  }) {
    print('modifiedOrders from map: $modifiedOrders');
    print('toApprove from map: $toApprove');
    return SalesOrderDisplay(
      salesOrderId: salesOrderId,
      itemName: itemName,
      varianceName: varianceName,
      qty: qty,
      price: price,
      itemCode: itemCode,
      weight: weight,
      amount: amount,
      tax: tax,
      uom: uom,
      totalAmount: totalAmount,
      totalAmount2: totalAmount2,
      netPrice: netPrice,
      orderInvoiceNo: orderInvoiceNo,
      branchId: branchId,
      branchName: branchName,
      invoiceDate: invoiceDate,
      cash: cash,
      card: card,
      upi: upi,
      deliveryPartners: deliveryPartners,
      otherPayments: otherPayments,
      deliveryPartnerName: deliveryPartnerName,
      shiftId: shiftId,
      shiftName: shiftName,
      user: user,
      deliveryDate: deliveryDate,
      deliveryTime: deliveryTime,
      event: event,
      customerNumber: customerNumber,
      customerName: customerName,
      deliveryType: deliveryType,
      address: address,
      landmark: landmark,
      discount: discount,
      discountAmount: discountAmount,
      remark: remark,
      customCharge: customCharge,
      advanceAmount: advanceAmount,
      advanceDateTime: advanceDateTime,
      advancePaymentType: advancePaymentType,
      paymentType: paymentType,
      finalPrice: finalPrice,
      balanceAmount: balanceAmount,
      saleOrderNo: saleOrderNo,
      orderDate: orderDate,
      orderTime: orderTime,
      employeeName: employeeName,
      status: status,
      cancelOrderRemark: cancelOrderRemark,
      audioUrl: audioUrl,
      isItemReduced: isItemReduced,
      orderType: orderType,
      image1: image1,
      image2: image2,
      audio: audio,
      modifiedOrders: modifiedOrders ?? this.modifiedOrders,
      toApprove: toApprove ?? this.toApprove,
      // isBoxItem: isBoxItem ?? this.isBoxItem,
      isBoxItem: this.isBoxItem ?? [],
    );
  }

  SalesOrderDisplay copytoapprove({
    List<ToApprove>? toApprove,
  }) {
    return SalesOrderDisplay(
      salesOrderId: salesOrderId,
      itemName: itemName,
      varianceName: varianceName,
      qty: qty,
      price: price,
      itemCode: itemCode,
      weight: weight,
      amount: amount,
      tax: tax,
      uom: uom,
      totalAmount: totalAmount,
      totalAmount2: totalAmount2,
      netPrice: netPrice,
      orderInvoiceNo: orderInvoiceNo,
      branchId: branchId,
      branchName: branchName,
      invoiceDate: invoiceDate,
      cash: cash,
      card: card,
      upi: upi,
      deliveryPartners: deliveryPartners,
      otherPayments: otherPayments,
      deliveryPartnerName: deliveryPartnerName,
      shiftId: shiftId,
      shiftName: shiftName,
      user: user,
      deliveryDate: deliveryDate,
      deliveryTime: deliveryTime,
      event: event,
      customerNumber: customerNumber,
      customerName: customerName,
      deliveryType: deliveryType,
      address: address,
      landmark: landmark,
      discount: discount,
      discountAmount: discountAmount,
      remark: remark,
      customCharge: customCharge,
      advanceAmount: advanceAmount,
      advanceDateTime: advanceDateTime,
      advancePaymentType: advancePaymentType,
      paymentType: paymentType,
      finalPrice: finalPrice,
      balanceAmount: balanceAmount,
      saleOrderNo: saleOrderNo,
      orderDate: orderDate,
      orderTime: orderTime,
      employeeName: employeeName,
      status: status,
      cancelOrderRemark: cancelOrderRemark,
      audioUrl: audioUrl,
      isItemReduced: isItemReduced,
      orderType: orderType,
      image1: image1,
      image2: image2,
      audio: audio,
      isBoxItem: this.isBoxItem ?? [],
      toApprove: toApprove ?? this.toApprove,
    );
  }

  Iterable<SalesOrderItem> get items sync* {
    for (int i = 0; i < varianceName.length; i++) {
      yield SalesOrderItem(
        varianceName: varianceName[i],
        itemName: itemName[i],
        qty: qty[i],
        price: price[i],
        itemCode: itemCode[i],
        weight: weight[i],
        amount: amount[i],
        tax: tax[i],
        uom: uom[i],
      );
    }
  }
}
