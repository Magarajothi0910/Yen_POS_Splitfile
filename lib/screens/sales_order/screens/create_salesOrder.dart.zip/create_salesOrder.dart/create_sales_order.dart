import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../Global/custom_textWidgets.dart';
import '../../sales_order_providers/cartProvider.dart';
import '../../sales_order_providers/cart_selection_provider.dart';
import '../../sales_order_providers/customerScreen_provider.dart';
import '../../sales_order_providers/detailsProvider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../globals.dart' as globals;
import '../all_orders_page/services/get_sales_order_service.dart';
import 'salesorder_Customerdetails.dart';
import 'numeric_Calculator.dart';
import 'search_drop_filed.dart';

class SalesOrderScreen extends StatefulWidget {
  const SalesOrderScreen({super.key});

  @override
  SalesOrderScreenState createState() => SalesOrderScreenState();
}

class SalesOrderScreenState extends State<SalesOrderScreen> {
  bool isStoreTypeSelected = false;
  String selectedStoreType = 'Warehouse';
  final TextEditingController _allBoxQtyController = TextEditingController();
  final Map<String, TextEditingController> _boxQtyControllers = {};
  bool isStoreTypeDialogShowing = false;
  bool _isDialogShownToday = false;
  final Map<String, TextEditingController> _discountControllers = {};
  final TextEditingController _bulkDiscountController = TextEditingController();
  bool showCheckBoxes = false; // To control if checkboxes should be shown
  List<bool> itemSelections = []; // List to track selection state of each item

  final Map<String, bool> _itemSelectionState = {};
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // _checkAndShowStoreTypeDialog();
      final customerProvider =
          Provider.of<CustomerScreenProvider>(context, listen: false);
      customerProvider.checkAndShowStoreTypeDialog(context);
      // final detailsProvider =
      //     Provider.of<DetailsProvider>(context, listen: false);
      // detailsProvider.fetchEmployeeNames();
    });
  }

  @override
  void dispose() {
    _allBoxQtyController.dispose();
    for (final controller in _boxQtyControllers.values) {
      controller.dispose();
    }
    for (final controller in _discountControllers.values) {
      controller.dispose();
    }
    _bulkDiscountController.dispose();
    super.dispose();
  }

  // Future<void> _checkAndShowStoreTypeDialog() async {
  //   if (_isDialogShownToday) return;

  //   final prefs = await SharedPreferences.getInstance();
  //   final lastShownTimestamp = prefs.getInt('lastShownTimestamp') ?? 0;
  //   final storedStoreType = prefs.getString('storeType') ?? '';

  //   final lastShownDate =
  //       DateTime.fromMillisecondsSinceEpoch(lastShownTimestamp);
  //   final currentDate = DateTime.now();

  //   final isSameDay = lastShownDate.year == currentDate.year &&
  //       lastShownDate.month == currentDate.month &&
  //       lastShownDate.day == currentDate.day;

  //   if (storedStoreType.isNotEmpty) {
  //     setState(() {
  //       selectedStoreType = storedStoreType;
  //     });
  //   }

  //   if (!isSameDay || storedStoreType.isEmpty) {
  //     await _showStoreTypeDialog();
  //     _isDialogShownToday = true;
  //   } else {
  //     setState(() {
  //       isStoreTypeSelected = true;
  //     });
  //   }
  // }

  Future<void> _saveStoreType(String type) async {
    final prefs = await SharedPreferences.getInstance();
    final currentTimestamp = DateTime.now().millisecondsSinceEpoch;

    await prefs.setString('storeType', type);
    await prefs.setInt('lastShownTimestamp', currentTimestamp);

    setState(() {
      selectedStoreType = type;
      isStoreTypeSelected = true;
    });
  }

  Future<void> _showStoreTypeDialog() {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StoreTypeSelectionDialog(
        onStoreTypeSelected: _saveStoreType,
      ),
    );
  }

  void _initializeItemIfNeeded(String key) {
    if (!_boxQtyControllers.containsKey(key)) {
      _boxQtyControllers[key] = TextEditingController();
    }
    if (!_discountControllers.containsKey(key)) {
      _discountControllers[key] = TextEditingController();
    }
  }

  void _removeItemState(String key) {
    final selectionProvider =
        Provider.of<CartSelectionProvider>(context, listen: false);
    selectionProvider.toggleItemSelection(
        key, false); // Explicitly unselect the item
    _boxQtyControllers.remove(key)?.dispose();
    _discountControllers.remove(key)?.dispose();
  }

  Future<void> _showClearCartConfirmationDialog(
      CartProvider cartProvider) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Clear Cart'),
        content: const Text('Are you sure you want to Clear the cart?'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              _clearCartAndResetState(cartProvider);
              _bulkDiscountController.clear();
              Navigator.of(context).pop();
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  // void _applySingleItemDiscount(String key, String value) {
  //   double? discount = double.tryParse(value);
  //   if (discount != null && discount >= 0) {
  //     setState(() {
  //       _discountControllers[key]?.text = value;
  //       final itemIndex =
  //           globals.cartItems.indexWhere((item) => item.varianceName == key);
  //       if (itemIndex != -1) {
  //         globals.cartItems[itemIndex].itemWiseDiscount = discount;
  //         int originalPrice = globals.cartItems[itemIndex].quantity *
  //             globals.cartItems[itemIndex].pricePerKg;

  //         // Calculate the actual discount amount
  //         double discountAmount = originalPrice * (discount / 100);

  //         // Store both the discount amount and final price
  //         globals.cartItems[itemIndex].itemWiseDiscountAmount =
  //             originalPrice - discountAmount;
  //         ; // This is now the actual discount
  //         // globals.cartItems[itemIndex].finalPrice =
  //         //     originalPrice - discountAmount;
  //       }
  //     });
  //   }
  // }

  // void _applyBulkDiscount(String value) {
  //   double? discount = double.tryParse(value);
  //   if (discount != null && discount >= 0) {
  //     setState(() {
  //       final selectionProvider =
  //           Provider.of<CartSelectionProvider>(context, listen: false);
  //       selectionProvider.itemSelectionState.forEach((key, isSelected) {
  //         if (isSelected) {
  //           _discountControllers[key]?.text = value;
  //           final itemIndex = globals.cartItems
  //               .indexWhere((item) => item.varianceName == key);
  //           if (itemIndex != -1) {
  //             globals.cartItems[itemIndex].itemWiseDiscount = discount;
  //             int originalPrice = globals.cartItems[itemIndex].quantity *
  //                 globals.cartItems[itemIndex].pricePerKg;

  //             // Calculate actual discount amount
  //             double discountAmount = originalPrice * (discount / 100);

  //             // Store both the discount amount and final price
  //             globals.cartItems[itemIndex].itemWiseDiscountAmount =
  //                 originalPrice - discountAmount;
  //             // globals.cartItems[itemIndex].finalPrice =
  //             //     originalPrice - discountAmount;

  //             print('''
  //             Item: ${globals.cartItems[itemIndex].varianceName}
  //             Original Price: $originalPrice
  //             Discount: ${discount}% (Rs.$discountAmount)
  //             Final Price: ${globals.cartItems[itemIndex].finalPrice}
  //           ''');
  //           }
  //         }
  //       });
  //     });
  //   }
  // }

  void _applySingleItemDiscount(String key, String value) {
    if (value.isEmpty) {
      setState(() {
        _discountControllers[key]?.text = '';
        final itemIndex =
            globals.cartItems.indexWhere((item) => item.varianceName == key);
        if (itemIndex != -1) {
          globals.cartItems[itemIndex].itemWiseDiscount = 0.0;
          globals.cartItems[itemIndex].itemWiseDiscountAmount = 0.0;
        }
      });
      return;
    }

    double? discount = double.tryParse(value);
    if (discount != null && discount >= 0) {
      setState(() {
        _discountControllers[key]?.text = value;
        final itemIndex =
            globals.cartItems.indexWhere((item) => item.varianceName == key);
        if (itemIndex != -1) {
          globals.cartItems[itemIndex].itemWiseDiscount = discount;
          int originalPrice = globals.cartItems[itemIndex].quantity *
              globals.cartItems[itemIndex].pricePerKg;
          double discountAmount = originalPrice * (discount / 100);
          globals.cartItems[itemIndex].itemWiseDiscountAmount =
              originalPrice - discountAmount;
        }
      });
    }
  }

  void _applyBulkDiscount(String value) {
    if (value.isEmpty) {
      setState(() {
        final selectionProvider =
            Provider.of<CartSelectionProvider>(context, listen: false);
        selectionProvider.itemSelectionState.forEach((key, isSelected) {
          if (isSelected) {
            _discountControllers[key]?.text = '';
            final itemIndex = globals.cartItems
                .indexWhere((item) => item.varianceName == key);
            if (itemIndex != -1) {
              globals.cartItems[itemIndex].itemWiseDiscount = 0.0;
              globals.cartItems[itemIndex].itemWiseDiscountAmount = 0.0;
            }
          }
        });
      });
      return;
    }

    double? discount = double.tryParse(value);
    if (discount != null && discount >= 0) {
      setState(() {
        final selectionProvider =
            Provider.of<CartSelectionProvider>(context, listen: false);
        selectionProvider.itemSelectionState.forEach((key, isSelected) {
          if (isSelected) {
            _discountControllers[key]?.text = value;
            final itemIndex = globals.cartItems
                .indexWhere((item) => item.varianceName == key);
            if (itemIndex != -1) {
              globals.cartItems[itemIndex].itemWiseDiscount = discount!;
              int originalPrice = globals.cartItems[itemIndex].quantity *
                  globals.cartItems[itemIndex].pricePerKg;
              double discountAmount = originalPrice * (discount / 100);
              globals.cartItems[itemIndex].itemWiseDiscountAmount =
                  originalPrice - discountAmount;
            }
          }
        });
      });
    }
  }

  void _clearCartAndResetState(CartProvider cartProvider) {
    cartProvider.clearCart();
    _allBoxQtyController.clear();
    Provider.of<CartSelectionProvider>(context, listen: false)
        .clearSelections();
    for (final controller in _boxQtyControllers.values) {
      controller.clear();
    }
    for (final controller in _discountControllers.values) {
      controller.clear();
    }
  }

  void clearCartAndResetState(CartProvider cartProvider) {
    cartProvider.clearCart();
    _allBoxQtyController.clear();
    _bulkDiscountController.clear();
    Provider.of<CartSelectionProvider>(context, listen: false)
        .clearSelections();
    for (final controller in _boxQtyControllers.values) {
      controller.clear();
    }
    for (final controller in _discountControllers.values) {
      controller.clear();
    }
  }

  void _applyBulkBoxQtyUpdate(String value) {
    int? newQty = int.tryParse(value);
    if (newQty != null && newQty > 0) {
      setState(() {
        final selectionProvider =
            Provider.of<CartSelectionProvider>(context, listen: false);
        final cartProvider = Provider.of<CartProvider>(context, listen: false);

        selectionProvider.itemSelectionState.forEach((key, isSelected) {
          if (isSelected) {
            _boxQtyControllers[key]?.text = value;
            final itemIndex = globals.cartItems
                .indexWhere((item) => item.varianceName == key);
            if (itemIndex != -1) {
              // Update the quantity in the cart item
              globals.cartItems[itemIndex].quantity = newQty;
              globals.cartItems[itemIndex].boxQuantity = newQty;
              // Update the cart provider to trigger a rebuild
              cartProvider.updateQuantity(itemIndex, newQty);
            }
          }
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);
    final selectionProvider = Provider.of<CartSelectionProvider>(context);
    final apiService =
        Provider.of<ApiServiceSalesOrderProvider>(context, listen: false);

    if (!isStoreTypeSelected && _isDialogShownToday == true) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!isStoreTypeDialogShowing) {
          isStoreTypeDialogShowing = true;
          _showStoreTypeDialog().then((_) {
            isStoreTypeDialogShowing = false;
          });
        }
      });
    }

    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).pushNamed('/all-orders');
        return false;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: _buildAppBar(context, apiService, selectionProvider),
        body: Row(
          children: [
            Expanded(
              flex: 2,
              child: _buildLeftSideContent(
                  context, cartProvider, selectionProvider),
            ),
            const VerticalDivider(thickness: 1, width: 1, color: Colors.grey),
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: CustomerDetails(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(
      BuildContext context,
      ApiServiceSalesOrderProvider apiService,
      CartSelectionProvider selectionProvider) {
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Colors.white,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            'Create Orders',
            style: TextStyle(color: Colors.black),
          ),
        ],
      ),
      centerTitle: false,
      flexibleSpace: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Row(
          children: [
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildNavButton(
                    label: 'Current Orders',
                    onPressed: () =>
                        Navigator.of(context).pushNamed('/current-orders'),
                  ),
                  const SizedBox(width: 10),
                  _buildNavButton(
                    label: 'All Orders',
                    onPressed: () async {
                      apiService.clearAllOrders();
                      // await apiService.fetchAllOrders();
                      Navigator.of(context).pushNamed('/all-orders');
                    },
                  ),
                  const SizedBox(width: 10),
                  _buildCreateOrderButton(selectionProvider),
                ],
              ),
            ),
            _buildStoreTypeToggle(),
          ],
        ),
      ),
      toolbarHeight: kToolbarHeight,
    );
  }

  Widget _buildNavButton(
      {required String label, required VoidCallback onPressed}) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        elevation: 2,
      ),
      child: Text(label),
    );
  }

  Widget _buildCreateOrderButton(CartSelectionProvider selectionProvider) {
    return ElevatedButton(
      onPressed: () {
        // selectionProvider.toggleCheckBoxVisibility();
      },
      style: ElevatedButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.blue,
        elevation: 2,
      ),
      child: Text('Create Order'),
    );
  }

  Widget _buildStoreTypeToggle() {
    final customerProvider = Provider.of<CustomerScreenProvider>(context);

    return ToggleButtons(
      constraints: BoxConstraints(
        minHeight: 40.0,
        minWidth: 80.0,
      ),
      borderRadius: BorderRadius.circular(8.0),
      borderWidth: 2,
      borderColor: Colors.blueGrey,
      selectedBorderColor: Colors.blue,
      fillColor: Colors.blue,
      splashColor: Colors.blue.withOpacity(0.3),
      color: Colors.black,
      selectedColor: Colors.white,
      isSelected: [
        customerProvider.selectedStoreType == 'Inhouse',
        customerProvider.selectedStoreType == 'Warehouse',
      ],
      onPressed: (index) {
        final type = index == 0 ? 'Inhouse' : 'Warehouse';
        customerProvider.saveStoreType(type);
      },
      children: [
        _buildToggleButtonLabel('Inhouse'),
        _buildToggleButtonLabel('Warehouse'),
      ],
    );
  }

  Widget _buildToggleButtonLabel(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildLeftSideContent(BuildContext context, CartProvider cartProvider,
      CartSelectionProvider selectionProvider) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SearchDropdown(),
          const SizedBox(height: 16.0),
          _buildCartDetailsHeader(cartProvider, selectionProvider),
          const Divider(),
          Flexible(
            child: _buildCartItemsList(cartProvider, selectionProvider),
          ),
          const SizedBox(height: 16.0),
          _buildCartFooter(cartProvider, selectionProvider),
        ],
      ),
    );
  }

  Widget _buildCartDetailsHeader(
      CartProvider cartProvider, CartSelectionProvider selectionProvider) {
    final selectedCount = selectionProvider.itemSelectionState.values
        .where((isSelected) => isSelected)
        .length;

    return Row(
      children: [
        const Text(
          'Cart Details',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        Spacer(),
        ElevatedButton(
          onPressed: () {
            selectionProvider.toggleCheckBoxVisibility();
          },
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8.0),
            ),
            backgroundColor: Colors.blue,
            foregroundColor: Colors.white,
            elevation: 2,
          ),
          child: Text(
            selectionProvider.showCheckBoxes
                ? 'UNSELECT ITEMS'
                : 'GIFTED ITEMS',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
        ),
        if (selectionProvider.showCheckBoxes) ...[
          SizedBox(width: 10),
          Text(
            '$selectedCount selected',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
        SizedBox(width: 10),
        IconButton(
          onPressed: globals.cartItems.isNotEmpty
              ? () {
                  _showClearCartConfirmationDialog(cartProvider);
                }
              : null,
          style: ElevatedButton.styleFrom(
            backgroundColor:
                globals.cartItems.isNotEmpty ? Colors.red : Colors.red,
          ),
          icon: Icon(
            Icons.delete,
            color: globals.cartItems.isNotEmpty ? Colors.white : Colors.grey,
          ), // Use icon instead of text
          tooltip: 'Clear Cart',
        ),
      ],
    );
  }

  Widget _buildAllBoxQtyField() {
    return SizedBox(
      width: 90,
      child: TextField(
        controller: _allBoxQtyController,
        decoration: InputDecoration(
          labelText: 'Box Qty',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade700,
              width: 1.5,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade700,
              width: 2.0,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade300,
              width: 1.5,
            ),
          ),
          filled: true,
          fillColor: Colors.blue.shade50,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 12.0,
            vertical: 8.0,
          ),
          labelStyle: TextStyle(
            color: Colors.blue.shade700,
          ),
        ),
        keyboardType: TextInputType.number,
        onChanged: _applyBulkBoxQtyUpdate,
      ),
    );
  }

  Widget _buildCartItemsList(
      CartProvider cartProvider, CartSelectionProvider selectionProvider) {
    return Builder(builder: (context) {
      final reversedCartItems = globals.cartItems.reversed.toList();
      final selectedItems = reversedCartItems
          .where((item) =>
              selectionProvider.itemSelectionState[item.varianceName] ?? false)
          .toList();
      final unselectedItems = reversedCartItems
          .where((item) =>
              !(selectionProvider.itemSelectionState[item.varianceName] ??
                  false))
          .toList();
      // double selectedTotalAmount = selectedItems.fold(
      //     0,
      //     (sum, item) =>
      //         sum +
      //         (item.itemWiseDiscountAmount ??
      //             (item.pricePerKg * item.quantity)));

      double selectedTotalAmount = selectedItems.fold(
          0,
          (sum, item) =>
              sum +
              ((item.pricePerKg * (item.quantity)) - (item.finalPrice ?? 0)));
      return ListView(
        children: [
          if (selectedItems.isNotEmpty)
            Container(
              margin: const EdgeInsets.all(10.0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
                border: Border.all(color: Colors.blue.shade100, width: 1.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Text(
                      "Selected Items",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        flex: selectionProvider.showCheckBoxes ? 2 : 3,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: selectedItems.map((item) {
                            final key = item.varianceName;
                            _initializeItemIfNeeded(key);
                            final originalIndex =
                                globals.cartItems.indexOf(item);
                            return _buildCartItemTile(
                              item: item,
                              key: key,
                              originalIndex: originalIndex,
                              cartProvider: cartProvider,
                              selectionProvider: selectionProvider,
                            );
                          }).toList(),
                        ),
                      ),
                      if (selectionProvider.showCheckBoxes) SizedBox(width: 12),
                      if (selectionProvider.showCheckBoxes)
                        Expanded(
                          flex: 1,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _buildAllBoxQtyField(),
                              SizedBox(height: 10),
                              _buildBulkDiscountField(),
                              SizedBox(height: 10),
                              Padding(
                                padding: const EdgeInsets.only(top: 10.0),
                                child: Text(
                                  "Total Box Amount: ${selectedTotalAmount.toStringAsFixed(0)}",
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.green[700],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ...unselectedItems.map((item) {
            final key = item.varianceName;
            _initializeItemIfNeeded(key);
            final originalIndex = globals.cartItems.indexOf(item);
            return _buildCartItemTile(
              item: item,
              key: key,
              originalIndex: originalIndex,
              cartProvider: cartProvider,
              selectionProvider: selectionProvider,
            );
          }).toList(),
        ],
      );
    });
  }

  Widget _buildBulkDiscountField() {
    return SizedBox(
      width: 90,
      child: TextField(
        decoration: InputDecoration(
          labelText: 'Discount',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade700,
              width: 1.5,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade700,
              width: 2.0,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade300,
              width: 1.5,
            ),
          ),
          filled: true,
          fillColor: Colors.blue.shade50,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 12.0,
            vertical: 8.0,
          ),
          labelStyle: TextStyle(
            color: Colors.blue.shade700,
            fontSize: 11,
          ),
          suffixIcon: Icon(Icons.percent, size: 17),
        ),
        controller: _bulkDiscountController,
        keyboardType: TextInputType.number,
        inputFormatters: [
          FilteringTextInputFormatter.allow(RegExp(r'^\d{0,2}(\.\d{0,2})?$')),
        ],
        onChanged: _applyBulkDiscount,
      ),
    );
  }

  Widget _buildCartItemTile({
    required dynamic item,
    required String key,
    required int originalIndex,
    required CartProvider cartProvider,
    required CartSelectionProvider selectionProvider,
  }) {
    return Dismissible(
      key: Key(key),
      onDismissed: (direction) {
        cartProvider.removeItemFromCart(originalIndex);
        _removeItemState(key);
      },
      background: Container(
        decoration: BoxDecoration(
          color: Colors.red,
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: const Icon(Icons.delete, color: Colors.white, size: 28),
      ),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 2,
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: _buildCartItemContent(
          item: item,
          key: key,
          originalIndex: originalIndex,
          cartProvider: cartProvider,
          selectionProvider: selectionProvider,
        ),
      ),
    );
  }

  Widget _buildCartItemContent({
    required dynamic item,
    required String key,
    required int originalIndex,
    required CartProvider cartProvider,
    required CartSelectionProvider selectionProvider,
  }) {
    return GestureDetector(
      onTap: () {
        if (item.uom == 'Kgs' || item.uom == 'Kg') {
          showDialog(
            context: context,
            builder: (context) => NumericCalculator(
              varianceName: item.varianceName,
              onValueSelected: (double newValue) {
                setState(() {
                  item.weight = newValue;
                });
              },
            ),
          );
        }
      },
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                if (selectionProvider.showCheckBoxes)
                  Checkbox(
                    value: selectionProvider.itemSelectionState[key] ?? false,
                    // onChanged: (bool? value) {
                    //   selectionProvider.toggleItemSelection(
                    //       key, value ?? false);
                    //   if (value == true) {
                    //     item.isBoxItem = 'yes';
                    //     item.itemWiseDiscount = 0.0;
                    //     item.itemWiseDiscountAmount = 0.0;
                    //   } else {
                    //     item.isBoxItem = 'no';
                    //     item.itemWiseDiscount = 0.0;
                    //     item.itemWiseDiscountAmount = 0.0;
                    //     _discountControllers[key]?.clear();
                    //   }
                    // },

                    onChanged: (bool? value) {
                      selectionProvider.toggleItemSelection(
                          key, value ?? false);
                      if (value == true) {
                        item.isBoxItem = 'yes';
                        item.itemWiseDiscount = 0.0;
                        item.itemWiseDiscountAmount = 0.0;

                        // Apply current bulk values to the newly selected item
                        if (_allBoxQtyController.text.isNotEmpty) {
                          _applyBulkBoxQtyUpdate(_allBoxQtyController.text);
                        }
                        if (_bulkDiscountController.text.isNotEmpty) {
                          _applyBulkDiscount(_bulkDiscountController.text);
                        }
                      } else {
                        item.isBoxItem = 'no';
                        item.itemWiseDiscount = 0.0;
                        item.itemWiseDiscountAmount = 0.0;
                        _discountControllers[key]?.clear();
                      }
                    },
                  ),
                const SizedBox(width: 6),
                Expanded(
                  child: _buildItemDetails(item),
                ),
                // if (selectionProvider.itemSelectionState[key] == false &&
                //     selectionProvider.showCheckBoxes)
                if (!selectionProvider.showCheckBoxes &&
                        (selectionProvider.itemSelectionState[key] ?? false) ||
                    (selectionProvider.showCheckBoxes &&
                        !(selectionProvider.itemSelectionState[key] ?? false)))
                  _buildDiscountField(key),
                _buildItemPriceAndControls(
                  item: item,
                  originalIndex: originalIndex,
                  cartProvider: cartProvider,
                  key: key,
                  selectionProvider: selectionProvider,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildItemDetails(dynamic item) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          item.varianceName,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          _getItemPriceDescription(item),
          style: const TextStyle(
            fontSize: 13,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }

  String _getItemPriceDescription(dynamic item) {
    String priceDescription;
    if (item.uom == 'Kgs' || item.uom == 'Kg') {
      priceDescription = item.weight >= 1
          ? '${item.weight.toStringAsFixed(2)} kg × Rs.${item.pricePerKg.toStringAsFixed(0)}/kg'
          : '${(item.weight * 1000).toStringAsFixed(0)} grams × Rs.${item.pricePerKg.toStringAsFixed(0)}/kg';
    } else {
      priceDescription =
          '${item.quantity.toStringAsFixed(0)} ${item.uom} × Rs.${item.pricePerKg.toStringAsFixed(0)}/${item.uom}';
    }

    if (item.itemWiseDiscount != null && item.itemWiseDiscount != 0) {
      priceDescription +=
          '\nDiscount: ${item.itemWiseDiscount}% (Rs.${item.itemWiseDiscountAmount?.toStringAsFixed(0)})';
    }

    return priceDescription;
  }

  Widget _buildItemPriceAndControls({
    required dynamic item,
    required int originalIndex,
    required CartProvider cartProvider,
    required String key,
    required CartSelectionProvider selectionProvider,
  }) {
    int originalPrice = ((item.uom == 'Kg' || item.uom == 'Kgs')
            ? (item.quantity * item.pricePerKg * item.weight)
            : (item.quantity * item.pricePerKg))
        .toInt();
    // final originalPrice = item.quantity * item.pricePerKg;
    final discountPercent = item.itemWiseDiscount ?? 0; // Handle null case
    final discountAmount =
        discountPercent > 0 ? originalPrice * (discountPercent / 100) : 0;
    final finalPrice = item.itemWiseDiscountAmount ?? originalPrice;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            if (!selectionProvider.showCheckBoxes) _buildDiscountField(key),
            SizedBox(width: 10),
            _buildQuantityControls(
              item: item,
              originalIndex: originalIndex,
              cartProvider: cartProvider,
            ),
          ],
        ),
        const SizedBox(height: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Original Price
            Text(
              'Rs.${originalPrice.round()}',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
                decoration: discountPercent > 0
                    ? TextDecoration.lineThrough
                    : TextDecoration.none,
              ),
            ),

            // Discount Information (only shown if discount exists)
            if (discountPercent > 0) ...[
              Text(
                'Discount:  -Rs.${discountAmount.toStringAsFixed(0)}',
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.red,
                ),
              ),
              Text(
                'Final Price: Rs.${finalPrice.toStringAsFixed(0)}',
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.green,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }

  Widget _buildDiscountField(String key) {
    return SizedBox(
      width: 90,
      child: TextField(
        controller: _discountControllers[key],
        decoration: InputDecoration(
          labelText: 'Discount',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade700,
              width: 1.5,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade700,
              width: 2.0,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: Colors.blue.shade300,
              width: 1.5,
            ),
          ),
          filled: true,
          fillColor: Colors.blue.shade50,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 12.0,
            vertical: 8.0,
          ),
          labelStyle: TextStyle(
            color: Colors.blue.shade700,
            fontSize: 11,
          ),
          suffixIcon: Icon(Icons.percent, size: 17),
        ),
        // keyboardType: TextInputType.number,
        keyboardType: TextInputType.numberWithOptions(decimal: true),
        inputFormatters: [
          FilteringTextInputFormatter.allow(RegExp(r'^\d{0,2}(\.\d{0,2})?$')),
        ],
        // onChanged: (value) {
        //   _applySingleItemDiscount(key, value);
        // },
        onChanged: (value) {
          if (value.isEmpty) {
            // Clear discount when field is empty
            _applySingleItemDiscount(key, '');
          } else {
            _applySingleItemDiscount(key, value);
          }
        },
      ),
    );
  }

  // String _getItemTotalPrice(dynamic item) {
  //   int itemTotal;
  //   if (item.uom == 'Kgs') {
  //     itemTotal = item.weight * item.quantity * item.pricePerKg;
  //   } else {
  //     itemTotal = item.quantity * item.pricePerKg;
  //   }
  //   return 'Rs.${itemTotal.toStringAsFixed(0)}';
  // }

  Widget _buildQuantityControls({
    required dynamic item,
    required int originalIndex,
    required CartProvider cartProvider,
  }) {
    return Row(
      children: [
        _buildQuantityButton(
          icon: Icons.remove,
          onPressed: () {
            if (item.quantity > 0) {
              if (item.quantity == 1) {
                cartProvider.removeItemFromCart(originalIndex);
              } else {
                cartProvider.updateQuantity(originalIndex, item.quantity - 1);
              }
            }
          },
        ),
        // _buildQuantityButton(
        //   icon: Icons.remove,
        //   onPressed: () {
        //     if (item.quantity > 1) {
        //       // Changed from > 0 to > 1
        //       cartProvider.updateQuantity(originalIndex, item.quantity - 1);
        //     } else {
        //       // Show a message or prevent deletion
        //       ScaffoldMessenger.of(context).showSnackBar(
        //         SnackBar(content: Text('Minimum quantity is 1')),
        //       );
        //     }
        //   },
        // ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () {
            cartProvider.showQuantityDialog(
              context,
              originalIndex,
              item.quantity,
              item.uom,
            );
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.blue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              item.quantity.toStringAsFixed(0),
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.blue,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        _buildQuantityButton(
          icon: Icons.add,
          onPressed: () {
            cartProvider.updateQuantity(originalIndex, item.quantity + 1);
            cartProvider.calculateSubtotal();
          },
        ),
      ],
    );
  }

  Widget _buildQuantityButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: IconButton(
        icon: Icon(icon, color: Colors.blue),
        iconSize: 16,
        padding: EdgeInsets.zero,
        onPressed: onPressed,
      ),
    );
  }

  void _showSelectedItemsDialog(CartSelectionProvider selectionProvider) {
    showDialog(
      context: context,
      builder: (context) => SelectedItemsDialog(
        itemSelectionState: selectionProvider.itemSelectionState,
        cartItems: globals.cartItems,
      ),
    );
  }

  Widget _buildCartFooter(
      CartProvider cartProvider, CartSelectionProvider selectionProvider) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // ElevatedButton(
        //   onPressed: globals.cartItems.isNotEmpty
        //       ? () => _showClearCartConfirmationDialog(cartProvider)
        //       : null,
        //   style: ElevatedButton.styleFrom(
        //     backgroundColor:
        //         globals.cartItems.isNotEmpty ? Colors.red : Colors.grey,
        //   ),
        //   child:
        //       const Text('Clear Cart', style: TextStyle(color: Colors.white)),
        // ),
        SizedBox(
          width: 180, // Adjust width to be responsive
          height: 50, // Adjust height for better visibility
          child: TextFormField(
            // controller: customChargeController,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(5),
            ],
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10), // Rounded corners
                borderSide: BorderSide(
                    color: Colors.blueAccent,
                    width: 1), // Border color and thickness
              ),
              hintText: 'Enter custom charge',
              hintStyle: TextStyle(
                color: Colors.grey.shade600,
                fontSize: 14,
              ),
            ),
            onChanged: (value) {
              // setState(() {
              //   customCharge = double.tryParse(value) ?? 0;
              //   totalAmount = orderAmount + customCharge - deductedAmount;
              //   updatePaymentData();
              // });
            },
          ),
        ),

        CustomText(
          text:
              ' TotalAmount ₹${cartProvider.getTotalAmount().toStringAsFixed(0)}',
          style: const TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        SizedBox(
          width: 80,
          child: ElevatedButton(
            onPressed: () {
              _showSelectedItemsDialog(selectionProvider);
            },
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.all<Color>(Colors.blue),
            ),
            child: Text(
              "View",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }

  // Future<void> showExitConfirmationDialog(CartProvider cartProvider) async {
  //   // if (!mounted) return;

  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (context) {
  //       return AlertDialog(
  //         title: const Text('Exit Application'),
  //         content: const Text('Are you sure you want to exit the application?'),
  //         actions: <Widget>[
  //           TextButton(
  //             onPressed: () => Navigator.of(context).pop(),
  //             child: const Text('Cancel'),
  //           ),
  //           TextButton(
  //             onPressed: () {
  //               cartProvider.clearCart();
  //               Navigator.of(context).pop();
  //               // if (mounted) {

  //               // }
  //               // Clear the cart data
  //               cartProvider.clearCart();

  //               // Clear the "All Box Qty" field
  //               _allBoxQtyController.clear();

  //               // Clear each individual "Box Qty" field
  //               _boxQtyControllers.forEach((key, controller) {
  //                 controller.clear();
  //               });

  //               // Optionally reset selection states and UI flags
  //               setState(() {
  //                 showCheckBoxes = false;
  //                 itemSelections = [];
  //                 _itemSelectionState.clear();
  //               });
  //             },
  //             child: const Text('Clear'),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }
}

class SelectedItemsDialog extends StatelessWidget {
  final Map<String, bool> itemSelectionState;
  final List<dynamic> cartItems;

  const SelectedItemsDialog({
    super.key,
    required this.itemSelectionState,
    required this.cartItems,
  });

  @override
  Widget build(BuildContext context) {
    final selectedItems = cartItems
        .where((item) => itemSelectionState[item.varianceName] == true)
        .toList();

    double normalTotal = 0.0;
    double discountedTotal = 0.0;

    for (var item in selectedItems) {
      final itemTotal = item.quantity * item.pricePerKg;
      normalTotal += itemTotal;
      final discountAmount = item.itemWiseDiscount != null
          ? itemTotal * (item.itemWiseDiscount / 100)
          : 0.0;
      discountedTotal += (itemTotal - discountAmount);
    }

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 10,
      child: Container(
        padding: const EdgeInsets.all(16),
        width: MediaQuery.of(context).size.width * 0.45,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.white,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: Colors.blue.shade600,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(12),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.shopping_cart, color: Colors.white),
                  const SizedBox(width: 10),
                  Text(
                    'Selected Items',
                    style: GoogleFonts.robotoCondensed(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // Items List
            Container(
              height: 300,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: selectedItems.length,
                separatorBuilder: (context, index) =>
                    Divider(color: Colors.grey.shade300),
                itemBuilder: (context, index) {
                  final item = selectedItems[index];
                  final itemTotal = item.quantity * item.pricePerKg;
                  final discountAmount = item.itemWiseDiscount != null
                      ? itemTotal * (item.itemWiseDiscount / 100)
                      : 0.0;
                  final discountedTotal = itemTotal - discountAmount;

                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.blue.shade100,
                      child: Text(
                        '${item.quantity}',
                        style: TextStyle(
                          color: Colors.blue.shade800,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    title: Text(
                      item.varianceName,
                      style: GoogleFonts.openSans(fontWeight: FontWeight.w600),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${item.quantity} ${item.uom} × ${item.pricePerKg} ',
                          style: TextStyle(color: Colors.grey.shade600),
                        ),
                        if (item.itemWiseDiscount != null)
                          Text(
                            'Discount: ${item.itemWiseDiscount.toStringAsFixed(0)}%',
                            style: TextStyle(
                              color: Colors.red.shade600,
                              fontSize: 13,
                            ),
                          ),
                      ],
                    ),
                    trailing: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '₹${itemTotal.toStringAsFixed(2)}',
                          style: GoogleFonts.robotoMono(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.green.shade700,
                          ),
                        ),
                        if (discountAmount > 0)
                          Text(
                            '-₹${discountAmount.toStringAsFixed(2)}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.red.shade700,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        if (discountAmount > 0)
                          Text(
                            '₹${discountedTotal.toStringAsFixed(2)}',
                            style: GoogleFonts.robotoMono(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.green.shade700,
                            ),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ),

            // Total & Close Button
            const SizedBox(height: 10),
            Divider(color: Colors.grey.shade400),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Normal Total:',
                        style: GoogleFonts.robotoCondensed(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '₹${normalTotal.toStringAsFixed(2)}',
                        style: GoogleFonts.robotoMono(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.green.shade800,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Discounted Total:',
                        style: GoogleFonts.robotoCondensed(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '₹${discountedTotal.toStringAsFixed(2)}',
                        style: GoogleFonts.robotoMono(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.green.shade800,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 15),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue.shade600,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 40,
                  vertical: 12,
                ),
              ),
              child: Text(
                'Close',
                style: GoogleFonts.robotoCondensed(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Extracted widget for store type selection dialog
class StoreTypeSelectionDialog extends StatelessWidget {
  final void Function(String) onStoreTypeSelected;

  const StoreTypeSelectionDialog({
    super.key,
    required this.onStoreTypeSelected,
  });

  @override
  Widget build(BuildContext context) {
    final ColorScheme cs = Theme.of(context).colorScheme;

    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      titlePadding: const EdgeInsets.fromLTRB(24, 24, 24, 12),
      contentPadding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
      title: Center(
        child: Text(
          'Select  Type',
          style: Theme.of(context)
              .textTheme
              .titleMedium!
              .copyWith(fontWeight: FontWeight.w600),
        ),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.storefront_outlined, size: 20),
                  label: const Text('In‑house'),
                  style: ElevatedButton.styleFrom(
                    foregroundColor: cs.onPrimary, // text/icon color
                    backgroundColor: cs.primary,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: () {
                    onStoreTypeSelected('Inhouse');
                    Navigator.pop(context);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.local_shipping_outlined, size: 20),
                  label: const Text('Warehouse'),
                  style: ElevatedButton.styleFrom(
                    foregroundColor: cs.onSecondary,
                    backgroundColor: cs.secondary,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: () {
                    onStoreTypeSelected('Warehouse');
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
