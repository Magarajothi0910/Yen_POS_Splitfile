import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../globals.dart' as globals;

class modifyCartItem {
  final String itemName;
  final String variancename;
  final String itemCode;
  final int pricePerKg;
  final int tax;
  final String uom; // Add the uom field
  int quantity;
  double weight;

  modifyCartItem({
    required this.itemName,
    required this.variancename,
    required this.pricePerKg,
    required this.tax,
    required this.itemCode,
    required this.uom, // Initialize uom
    required this.quantity,
    required this.weight,
  });
}

class ModifyCartProvider extends ChangeNotifier {
  final List<modifyCartItem> _closingStockItems = []; // Closing stock cart
  TextEditingController searchController = TextEditingController();

  final List<List<modifyCartItem>> _savedBills = [];
  int? _currentBillIndex; // Tracks the index of the currently loaded bill

  List<modifyCartItem> get closingStockItems => _closingStockItems;
  List<List<modifyCartItem>> get savedBills => _savedBills;

  final List<Map<String, dynamic>> _addedVariances = [];

  List<Map<String, dynamic>> get addedVariances => _addedVariances;
  List<Map<String, dynamic>> filteredItems = [];

  double get totalWeight {
    double total = 0;

    // Calculate the weight of predefined variances
    total += _addedVariances.fold(
        0, (sum, variance) => sum + (variance['weight'] ?? 0));

    return total;
  }

  void addVariance(Map<String, dynamic> variance) {
    _addedVariances.add(variance);
    notifyListeners(); // Notify listeners about the change
  }

  void removeVariance(Map<String, dynamic> variance) {
    _addedVariances.removeWhere(
        (item) => item['varianceName'] == variance['varianceName']);
    notifyListeners();
  }

  get items => null;

  // Main Cart Methods
  void updateQuantity(int index, int quantity) {
    print("Attempting to update quantity at index: $index");
    print("Current cart items: ${globals.modifyItems}");

    if (globals.modifyItems.isNotEmpty &&
        index >= 0 &&
        index < globals.modifyItems.length) {
      globals.modifyItems[index].quantity = quantity;
      notifyListeners();
    } else {
      print("Invalid index: $index or empty cart.");
    }
  }

  // void updateWeight(int index, double newWeight) {
  //   globals.cartItems[index].weight = newWeight;
  //   notifyListeners();
  // }

  // Add item to cart function
  // void addItemToCart(CartItem newItem) {
  //   int existingItemIndex = globals.cartItems
  //       .indexWhere((item) => item.itemCode == newItem.itemCode);
  //   if (existingItemIndex != -1) {
  //     globals.cartItems[existingItemIndex].quantity += newItem.quantity;
  //     globals.cartItems[existingItemIndex].weight += newItem.weight;
  //   } else {
  //     globals.cartItems.add(newItem);
  //   }
  //   print("_cartitems123");
  //   print(globals.cartItems);
  //   notifyListeners();
  // }

  void addItemToCart(modifyCartItem newItem) {
    // Check if an item with the same name and UOM exists but with different attributes
    int existingItemIndex = globals.modifyItems.indexWhere((item) =>
        item.variancename == newItem.variancename &&
        item.uom == newItem.uom &&
        item.weight == newItem.weight);

    if (existingItemIndex != -1) {
      // Update quantity for identical items
      globals.modifyItems[existingItemIndex].quantity += newItem.quantity;
    } else {
      // Add a new entry for items with different weights or attributes
      globals.modifyItems.add(newItem);
    }

    print("_cartItems123: ${globals.modifyItems}");
    notifyListeners();
  }

  // void updateItemCount(String itemName, int newCount) {
  //   // Find the item in the cart and update its count
  //   for (var cartItem in cartItems) {
  //     if (cartItem.name == itemName) {
  //       cartItem.count = newCount;
  //       break;
  //     }
  //   }
  //   notifyListeners();
  // }

  void increaseQuantity(int index) {
    globals.modifyItems[index].quantity++;
    notifyListeners();
  }

  void decreaseQuantity(int index) {
    if (globals.modifyItems[index].quantity > 1) {
      globals.modifyItems[index].quantity--;
    } else {
      globals.modifyItems.removeAt(index);
    }
    notifyListeners();
  }

  void clearCart() {
    globals.modifyItems.clear();
    notifyListeners();
  }

  // Closing Stock Cart Methods

  void addItemToClosingStock(modifyCartItem newItem) {
    int existingItemIndex = _closingStockItems
        .indexWhere((item) => item.itemName == newItem.itemName);
    if (existingItemIndex != -1) {
      _closingStockItems[existingItemIndex].quantity += newItem.quantity;
    } else {
      _closingStockItems.add(newItem);
    }
    notifyListeners();
  }

  void increaseClosingStockQuantity(int index) {
    _closingStockItems[index].quantity++;
    notifyListeners();
  }

  void decreaseClosingStockQuantity(int index) {
    if (_closingStockItems[index].quantity > 1) {
      _closingStockItems[index].quantity--;
    } else {
      _closingStockItems.removeAt(index);
    }
    notifyListeners();
  }

  void clearClosingStockCart() {
    _closingStockItems.clear();
    notifyListeners();
  }

  // Save and Load Bill Methods

  void saveBill() {
    if (globals.modifyItems.isNotEmpty) {
      if (_currentBillIndex == null) {
        _savedBills.add(List.from(globals.modifyItems));
      } else {
        _savedBills[_currentBillIndex!] = List.from(globals.modifyItems);
      }
      clearCart(); // Clear the cart after saving
      _currentBillIndex = null; // Reset the current bill index
      notifyListeners();
    }
  }

  void loadSavedBill(int index) {
    _currentBillIndex = index; // Set the current bill index
    globals.modifyItems =
        List.from(_savedBills[index]); // Load the saved bill into the cart
    notifyListeners();
  }

  void deleteSavedBill(int index) {
    _savedBills.removeAt(index);
    notifyListeners();
  }

  void deleteCurrentBill() {
    if (_currentBillIndex != null) {
      _savedBills.removeAt(_currentBillIndex!);
      _currentBillIndex = null;
      notifyListeners();
    }
  }

  double getTotalAmount() {
    double totalAmount = 0;

    for (var item in globals.modifyItems) {
      if (item.uom == 'Kgs') {
        // Calculate based on weight for items in kilograms
        totalAmount += item.weight * item.quantity * item.pricePerKg;
      } else {
        // Calculate based on quantity for items in pieces
        totalAmount += item.quantity * item.pricePerKg;
      }
    }

    return totalAmount;
  }

  double calculateSubtotal() {
    double subtotal = 0.0;
    for (var item in globals.modifyItems) {
      subtotal += item.quantity * item.pricePerKg;
    }
    return subtotal;
  }

  String get formattedSubtotal {
    final subtotal = calculateSubtotal();
    return NumberFormat.currency(symbol: '₹')
        .format(subtotal); // Format as currency
  }

  // Remove item from the cart by index
  void removeItemFromCart(int index) {
    if (index >= 0 && index < globals.modifyItems.length) {
      globals.modifyItems.removeAt(index);
      notifyListeners();
    }
  }

  void updateWeight(int index, double newWeight) {
    // Update weight for the item at the given index
    globals.modifyItems[index].weight = newWeight;
    notifyListeners();
  }

  // void showQuantityDialog(
  //     BuildContext context, int index, int currentQuantity, String uom) {
  //   final TextEditingController quantityController =
  //       TextEditingController(text: currentQuantity.toString());

  //   showDialog(
  //     context: context,
  //     builder: (context) {
  //       return AlertDialog(
  //         shape: RoundedRectangleBorder(
  //           borderRadius: BorderRadius.circular(15.0), // Rounded corners
  //         ),
  //         title: const Text(
  //           'Update Quantity',
  //           style: TextStyle(
  //             color: Colors.black, // Primary color for title
  //             fontWeight: FontWeight.bold,
  //           ),
  //         ),
  //         content: Column(
  //           mainAxisSize: MainAxisSize.min,
  //           children: [
  //             TextField(
  //               controller: quantityController,
  //               keyboardType: TextInputType.number,
  //               decoration: InputDecoration(
  //                 labelText: 'Enter quantity',
  //                 border: OutlineInputBorder(
  //                   borderRadius:
  //                       BorderRadius.circular(8.0), // Rounded input border
  //                 ),
  //                 filled: true,
  //                 fillColor:
  //                     Colors.grey[200], // Light background color for input
  //               ),
  //             ),
  //           ],
  //         ),
  //         actions: [
  //           TextButton(
  //             onPressed: () {
  //               Navigator.of(context).pop(); // Close the dialog
  //             },
  //             child: const Text(
  //               'Cancel',
  //               style: TextStyle(color: Colors.grey),
  //             ),
  //           ),
  //           ElevatedButton(
  //             onPressed: () {
  //               // Update quantity based on UOM and close the dialog
  //               final newQuantity = int.tryParse(quantityController.text);

  //               if (newQuantity != null && newQuantity >= 0) {
  //                 // Check if the item is in "pcs" and round down to an integer if it's a float
  //                 if (uom == 'Pcs' || uom == 'Pkt') {
  //                   updateQuantity(index, newQuantity);
  //                 } else {
  //                   // For other UOMs like "Kgs", accept the float value as is
  //                   updateWeight(index, newQuantity.toDouble());
  //                 }
  //               }
  //               Navigator.of(context).pop(); // Close the dialog
  //             },
  //             style: ElevatedButton.styleFrom(
  //               backgroundColor: Colors.blue,
  //               foregroundColor: Colors.white,
  //               shape: RoundedRectangleBorder(
  //                 borderRadius: BorderRadius.circular(
  //                     8.0), // Rounded corners for the button
  //               ),
  //             ),
  //             child: const Text('OK'),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  void showQuantityDialog(
      BuildContext context, int index, int currentQuantity, String uom) {
    final TextEditingController quantityController =
        TextEditingController(text: currentQuantity.toString());

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0), // Rounded corners
          ),
          title: const Text(
            'Update Quantity',
            style: TextStyle(
              color: Colors.black, // Primary color for title
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: quantityController,
                keyboardType: TextInputType.numberWithOptions(
                  decimal: uom != 'Pcs' &&
                      uom != 'Pkt', // Allow decimal only if not "Pcs" or "Pkt"
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                    RegExp(
                      uom == 'Pcs' || uom == 'Pkt' ? r'^\d+$' : r'^\d*\.?\d*',
                    ),
                  ),
                ],
                decoration: InputDecoration(
                  labelText: 'Enter quantity',
                  border: OutlineInputBorder(
                    borderRadius:
                        BorderRadius.circular(8.0), // Rounded input border
                  ),
                  filled: true,
                  fillColor:
                      Colors.grey[200], // Light background color for input
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text(
                'Cancel',
                style: TextStyle(color: Colors.grey),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                // Update quantity based on UOM and close the dialog

                final newQuantity = double.tryParse(quantityController.text);
                if (newQuantity == 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Cannot addd 0 quantity'),
                    ),
                  );
                  return;
                }
                if (newQuantity != null && newQuantity >= 0) {
                  // For "Pcs" or "Pkt", use integer values
                  if (uom == 'Pcs' || uom == 'Pkt') {
                    updateQuantity(index, newQuantity.toInt());
                  } else {
                    // For other UOMs like "Kgs", accept the float value
                    updateWeight(index, newQuantity);
                  }
                }
                Navigator.of(context).pop(); // Close the dialog
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                      8.0), // Rounded corners for the button
                ),
              ),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  // Future<void> patchModifiedItems(SalesOrder salesOrder) async {
  //   final apiUrl =
  //       "http://$ipAddress/CurrentOrder/withoutpagination/${salesOrder.salesOrderId}";

  //   // Create a deep copy of the salesOrder fields for modification
  //   final updatedItemCodes = List<String>.from(salesOrder.itemCode ?? []);
  //   final updatedItemNames = List<String>.from(salesOrder.itemName ?? []);
  //   final updatedQuantities =
  //       List<int>.from((salesOrder.qty ?? []).map((q) => q.toInt()));
  //   final updatedWeights =
  //       List<double>.from((salesOrder.weight ?? []).map((w) => w.toDouble()));
  //   final updatedAmounts =
  //       List<double>.from((salesOrder.amount ?? []).map((a) => a.toDouble()));
  //   final updatedPrices =
  //       List<int>.from((salesOrder.price ?? []).map((p) => p.toInt()));

  //   // Debug initial state
  //   print("Initial updatedItemCodes: $updatedItemCodes");
  //   print("Initial updatedItemNames: $updatedItemNames");

  //   // Merge modifications
  //   for (var modifyItem in globals.modifyItems) {
  //     // Log the modifyItem details
  //     print(
  //         "Processing modifyItem: ${modifyItem.itemCode}, ${modifyItem.name}");

  //     // Skip modification if itemCode is invalid
  //     if (modifyItem.itemCode.isEmpty) {
  //       print("Skipping item due to empty itemCode: ${modifyItem.name}");
  //       continue; // Skip this item
  //     }

  //     final index = updatedItemCodes.indexOf(modifyItem.itemCode);

  //     if (index != -1) {
  //       // Update existing item
  //       updatedQuantities[index] += modifyItem.quantity.toInt();
  //       updatedWeights[index] += modifyItem.weight.toDouble();
  //       updatedAmounts[index] +=
  //           (modifyItem.quantity.toDouble() * modifyItem.pricePerKg.toDouble());
  //       print("Updated item at index $index: ${modifyItem.itemCode}");
  //     } else {
  //       // Add new item
  //       updatedItemCodes.add(modifyItem.itemCode);
  //       updatedItemNames.add(modifyItem.name);
  //       updatedQuantities.add(modifyItem.quantity.toInt());
  //       updatedWeights.add(modifyItem.weight.toDouble());
  //       updatedPrices.add(modifyItem.pricePerKg.toInt());
  //       updatedAmounts.add((modifyItem.quantity.toDouble() *
  //           modifyItem.pricePerKg.toDouble()));
  //       print("Added new item: ${modifyItem.itemCode}");
  //     }
  //   }

  //   // Debug final state
  //   print("Final updatedItemCodes: $updatedItemCodes");
  //   print("Final updatedItemNames: $updatedItemNames");

  //   // Prepare the updated salesOrder payload
  //   final updatedSalesOrder = {
  //     "salesOrderId": salesOrder.salesOrderId,
  //     "itemCode": updatedItemCodes,
  //     "itemName": updatedItemNames,
  //     "qty": updatedQuantities,
  //     "price": updatedPrices,
  //     "weight": updatedWeights,
  //     "amount": updatedAmounts,
  //     "totalAmount": updatedAmounts.reduce((a, b) => a + b).toDouble(),
  //     "netPrice": updatedAmounts.reduce((a, b) => a + b).toDouble(),
  //     "branchId": salesOrder.branchId,
  //     "branchName": salesOrder.branchName,
  //     "customerName": salesOrder.customerName,
  //     "customerNumber": salesOrder.customerNumber,
  //     // Add any additional fields required for the API
  //   };

  //   // Convert to JSON for the API
  //   final body = jsonEncode(updatedSalesOrder);

  //   // Send PATCH request
  //   try {
  //     final response = await http.patch(
  //       Uri.parse(apiUrl),
  //       headers: {'Content-Type': 'application/json'},
  //       body: body,
  //     );

  //     if (response.statusCode == 200) {
  //       print("Order patched successfully!");
  //       print(response.body);
  //     } else {
  //       print("Failed to patch order: ${response.statusCode}");
  //       print("Response: ${response.body}");
  //     }
  //   } catch (e) {
  //     print("Error patching order: $e");
  //   }
  // }
}
