import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:collection/collection.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';
import 'package:mime/mime.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:math' as math;

import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../../../Global/branchSelection.dart';
import '../../../data/global_data_manager.dart';
import '../../../services/websocketService.dart';
import '../../bottomNavigation_Regular_Page/takeorderNavigator.dart';
import '../sales_order_print/invoicePrint.dart';
import '../screens/all_orders_page/modified_order_print.dart';
import '../screens/all_orders_page/services/get_sales_order_service.dart';
import '../screens/model/sales_order_model.dart';
import 'package:http_parser/http_parser.dart';
import '../../../Global/globals_data.dart' as globalbranch;
import '../globals.dart' as globals;
import '../../kot_screen/global/globals.dart' as webSocketglobals;
import 'customerScreen_provider.dart';

class EditCustomerScreenProvider with ChangeNotifier {
  EditCustomerScreenProvider() {
    storedBranch = branchProvider.getStoredBranch(globalbranch.branchName);
    _initWebSocket();
  }
  List<Map<String, String>> suggestions = [];
  bool isFormValid = true;
  TextEditingController customerNameController = TextEditingController();
  TextEditingController dateController = TextEditingController();
  TextEditingController timeController = TextEditingController();
  TextEditingController mobileNoController = TextEditingController();
  TextEditingController searchController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController landmarkController = TextEditingController();
  TextEditingController companyNameController = TextEditingController();
  TextEditingController companyAddressController = TextEditingController();
  TextEditingController companygstNumberController = TextEditingController();
  TextEditingController advanceAmountController = TextEditingController();
  TextEditingController birthdaydateController = TextEditingController();
  String? selectedOrderType;
  BranchProvider branchProvider = BranchProvider();
  Branch? storedBranch;
  Timer? _debounce;
  String? _selectedEvent;
  String? get selectedEvent => _selectedEvent;
  String recordedFilePath = '';
  String? audioPlayerId;
  String? photoScreenId;
  String? previousAudioId;
  String? previousImageId;
  File? _pickedImage1;
  File? _pickedImage2;
  late modifiedSalesOrderReceiptPrinter receiptPrinter;
  Map<String, dynamic>? here;
  String selectedPaymentMethod = 'Cash';
  int? selectedTransactionIndex;
  bool isModifyMode = false;

  late WebSocketChannel _channel;

  void _initWebSocket() {
    // Replace these with your actual server IP and port defined in globals.
    _channel = WebSocketChannel.connect(
      Uri.parse('ws://${webSocketglobals.serverip}:${webSocketglobals.port}'),
    );
    // Listen for messages from the server.
    _channel.stream.listen(
      (data) {
        print('Received dataCustomerProvider: $data');
        // WebSocketService();
        WebSocketService(
          CustomerScreenProvider(),
          SalesInvoiceReceiptPrinter(),
        ).handleMessage(data);
      },
      onError: (error) {
        print('WebSocket error: $error');
      },
    );
  }

  void setSelectedOrderType(String? newValue) {
    selectedOrderType = newValue;
    notifyListeners(); // Notify listeners to update the UI
  }

  void setModifyMode(bool value) {
    isModifyMode = value;
    // selectedTransactionIndex = null;
    notifyListeners();
  }

  void resetSelection() {
    selectedTransactionIndex = null;
    isModifyMode = false;
    quantityChanges.clear();
    increasedItems.clear();
    decreasedItems.clear();
    notifyListeners();
  }

  // Map<int, double> quantityChanges = {};
  Map<int, double> quantityChanges = {};
  List<Map<String, dynamic>> increasedItems = [];
  List<Map<String, dynamic>> decreasedItems = [];

  void addItemToOrder(Map<String, dynamic> item, double weightOrQuantity) {
    print(
        "🔹 addItemToOrder called with item: $item and weightOrQuantity: $weightOrQuantity");

    // Check if the item already exists in increasedItems
    int existingIndex = increasedItems.indexWhere(
        (element) => element['varianceName'] == item['varianceName']);

    bool isKgUnit = item['varianceUom']?.toLowerCase() == 'kg' ||
        item['varianceUom']?.toLowerCase() == 'kgs';

    print("📌 Item is ${isKgUnit ? 'measured in KG' : 'measured in units'}");

    if (existingIndex != -1) {
      print("✅ Item already exists in increasedItems at index $existingIndex");

      // Update existing item quantity/weight and amount
      if (isKgUnit) {
        // Update weight for kg items
        increasedItems[existingIndex]['weight'] += weightOrQuantity;
        print("🔄 Updated weight: ${increasedItems[existingIndex]['weight']}");
      } else {
        // Update quantity for non-kg items
        increasedItems[existingIndex]['quantity'] += weightOrQuantity;
        print(
            "🔄 Updated quantity: ${increasedItems[existingIndex]['quantity']}");
      }

      increasedItems[existingIndex]['amount'] = increasedItems[existingIndex]
              ['price'] *
          (isKgUnit
              ? increasedItems[existingIndex]['weight']
              : increasedItems[existingIndex]['quantity']);

      print("💰 Updated amount: ${increasedItems[existingIndex]['amount']}");
    } else {
      print("➕ Adding new item to increasedItems");

      // Add as new item if it doesn't exist
      Map<String, dynamic> newItem = {
        'varianceName': item['varianceName'],
        'itemName': item['itemName'],
        'quantity': isKgUnit ? 1.0 : weightOrQuantity,
        'weight': isKgUnit ? weightOrQuantity : 0,
        'uom': item['varianceUom'],
        'price': item['variancePrice'],
        'tax': item['variancetax'] ?? 0,
        'itemCode': item['varianceitemCode'],
        'amount': item['variancePrice'] *
            (isKgUnit ? weightOrQuantity : weightOrQuantity),
      };

      increasedItems.add(newItem);

      print("🆕 New item added: $newItem");
    }

    notifyListeners();
    print("📢 State updated. Current increasedItems: $increasedItems");
  }

  // void addItemToOrder(Map<String, dynamic> item, double weightOrQuantity) {
  //   int existingIndex = increasedItems
  //       .indexWhere((element) => element['itemName'] == item['varianceName']);

  //   bool isKgUnit = item['varianceUom']?.toLowerCase() == 'kg' ||
  //       item['varianceUom']?.toLowerCase() == 'kgs';

  //   if (existingIndex != -1) {
  //     if (isKgUnit) {
  //       increasedItems[existingIndex]['weight'] += weightOrQuantity;
  //     } else {
  //       increasedItems[existingIndex]['quantity'] += weightOrQuantity;
  //     }

  //     increasedItems[existingIndex]['amount'] = increasedItems[existingIndex]
  //             ['price'] *
  //         (isKgUnit
  //             ? increasedItems[existingIndex]['weight']
  //             : increasedItems[existingIndex]['quantity']);
  //   } else {
  //     increasedItems.add({
  //       'itemName': item['varianceName'],
  //       'quantity': isKgUnit ? 1 : weightOrQuantity,
  //       'weight': isKgUnit ? weightOrQuantity : 0,
  //       'uom': item['varianceUom'],
  //       'price': item['variancePrice'],
  //       'tax': item['varianceTax'],
  //       'itemCode': item['varianceitemCode'],
  //       'amount': item['variancePrice'] *
  //           (isKgUnit ? weightOrQuantity : weightOrQuantity),
  //     });
  //   }
  //   notifyListeners();
  // }

  // void _addItemToOrder(Map<String, dynamic> item, double weightOrQuantity) {
  //   setState(() {
  //     // Check if the item already exists in increasedItems
  //     int existingIndex = increasedItems
  //         .indexWhere((element) => element['itemName'] == item['varianceName']);

  //     bool isKgUnit = item['varianceUom']?.toLowerCase() == 'kg' ||
  //         item['varianceUom']?.toLowerCase() == 'kgs';

  //     if (existingIndex != -1) {
  //       // Update existing item quantity/weight and amount
  //       if (isKgUnit) {
  //         // Update weight for kg items
  //         increasedItems[existingIndex]['weight'] += weightOrQuantity;
  //       } else {
  //         // Update quantity for non-kg items
  //         increasedItems[existingIndex]['quantity'] += weightOrQuantity;
  //       }

  //       increasedItems[existingIndex]['amount'] = increasedItems[existingIndex]
  //               ['price'] *
  //           (isKgUnit
  //               ? increasedItems[existingIndex]['weight']
  //               : increasedItems[existingIndex]['quantity']);
  //     } else {
  //       // Add as new item if it doesn't exist
  //       increasedItems.add({
  //         'itemName': item['varianceName'],
  //         'quantity': isKgUnit ? 1 : weightOrQuantity,
  //         'weight': isKgUnit ? weightOrQuantity : 0,
  //         'uom': item['varianceUom'],
  //         'price': item['variancePrice'],
  //         'tax': item['varianceTax'],
  //         'itemCode': item['varianceitemCode'],
  //         'amount': item['variancePrice'] *
  //             (isKgUnit ? weightOrQuantity : weightOrQuantity),
  //       });
  //     }
  //   });
  // }
  void handleTransactionSelection(int newIndex) {
    if (selectedTransactionIndex != newIndex) {
      resetSelection();
      selectedTransactionIndex = newIndex;
      notifyListeners();
    }
  }

  void updateWeight(Map<String, dynamic> item, double newWeight) {
    item['weight'] = newWeight;
    notifyListeners();
  }

  void increaseQuantity(Map<String, dynamic> item) {
    item['quantity'] += 1;
    notifyListeners();
  }

  // Decrease quantity (but not below 1)
  void decreaseQuantity(Map<String, dynamic> item) {
    if (item['quantity'] > 1) {
      item['quantity'] -= 1;
      notifyListeners();
    }
  }

  void updateQuantityWithWeight(
      SalesOrderDisplay salesOrder, int index, double newWeight) {
    // setState(() {
    double difference = newWeight - salesOrder.weight[index];
    quantityChanges[index] = difference;

    Map<String, dynamic> item = {
      'varianceName': salesOrder.varianceName[index],
      'itemName': salesOrder.itemName[index],
      'quantity': difference.abs(),
      'weight': newWeight,
      'uom': salesOrder.uom[index],
      'price': salesOrder.price[index],
      'amount': difference.abs() * salesOrder.price[index],
    };

    if (difference > 0) {
      increasedItems.removeWhere(
          (item) => item['varianceName'] == salesOrder.varianceName[index]);
      increasedItems.add(item);
      decreasedItems.removeWhere(
          (item) => item['varianceName'] == salesOrder.varianceName[index]);
    } else if (difference < 0) {
      decreasedItems.removeWhere(
          (item) => item['varianceName'] == salesOrder.varianceName[index]);
      decreasedItems.add(item);
      increasedItems.removeWhere(
          (item) => item['varianceName'] == salesOrder.varianceName[index]);
    }
    notifyListeners();
    // });
  }

  double calculateModifiedTotal(SalesOrderDisplay salesOrder) {
    double originalTotal = salesOrder.totalAmount;

    // Calculate total for increased items
    double increasedTotal = increasedItems.fold(0.0, (sum, item) {
      return sum + (item['amount'] ?? 0.0);
    });

    // Calculate total for decreased items
    double decreasedTotal = decreasedItems.fold(0.0, (sum, item) {
      return sum + (item['amount'] ?? 0.0);
    });

    // Final total: original + increased - decreased
    double modifiedTotal = originalTotal + increasedTotal - decreasedTotal;
    notifyListeners();
    return modifiedTotal;
  }

  void updateQuantity(SalesOrderDisplay salesOrder, int index, double newQty) {
    // setState(() {
    double difference = newQty - salesOrder.qty[index];
    quantityChanges[index] = difference;

    Map<String, dynamic> item = {
      'varianceName': salesOrder.varianceName[index],
      'itemName': salesOrder.itemName[index],
      'quantity': difference.abs(),
      'uom': salesOrder.uom[index],
      'price': salesOrder.price[index],
      'amount': difference.abs() * salesOrder.price[index],
    };

    if (difference > 0) {
      increasedItems.removeWhere(
          (item) => item['varianceName'] == salesOrder.varianceName[index]);
      increasedItems.add(item);
      decreasedItems.removeWhere(
          (item) => item['varianceName'] == salesOrder.varianceName[index]);
    } else if (difference < 0) {
      decreasedItems.removeWhere(
          (item) => item['varianceName'] == salesOrder.varianceName[index]);
      decreasedItems.add(item);
      increasedItems.removeWhere(
          (item) => item['varianceName'] == salesOrder.varianceName[index]);
    }
    notifyListeners();
    // });
  }

  @override
  void dispose() {
    dateController.dispose();
    timeController.dispose();
    mobileNoController.dispose();
    customerNameController.dispose();
    addressController.dispose();
    landmarkController.dispose();
    searchController.dispose();
    // advanceAmountController.dispose(); // Dispose all controllers
    super.dispose();
  }

  void handleRecordingComplete(String path) {
    // setState(() {
    recordedFilePath = path;
    notifyListeners();
    // });
    print('Recording completed. File path: $path');
  }

  void removeAddedItem(Map<String, dynamic> item) {
    increasedItems.removeWhere(
        (element) => element['varianceName'] == item['varianceName']);
    notifyListeners();
  }

  // void handleRecordingComplete(String path) {
  //   // Store the audio file path in Hive after recording
  //   saveRecordingToHive(path);
  // }

  // Future<void> saveRecordingToHive(String path) async {
  //   var box = await Hive.openBox('recordings');
  //   await box.add(path); // Store the file path in Hive
  //   print("Recording saved at: $path");
  // }

  Future<void> printReceipt(
      BuildContext context, Map<String, dynamic> modifieddata) async {
    print('print clicked');
    try {
      if (!context.mounted) {
        return;
      }
      await receiptPrinter.printReceiptDetails(context, modifieddata);
      print("Receipt printed successfully.");
    } catch (e) {
      print("Error printing receipt: $e");
    }
  }

  void onImagesSelected(File? image1, File? image2) {
    // setState(() {
    _pickedImage1 = image1;
    _pickedImage2 = image2;
    notifyListeners();
    // });
  }

  void fetchCompanySuggestionsDebounced(String query) {
    if (_debounce?.isActive ?? false) _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      fetchCompanySuggestions(query);
    });
  }

  Future<void> batchUpdateCustomId(
      String currentCustomId, String newCustomId) async {
    final url = Uri.parse("http://$ipAddress/imageOrder/media/batch_update");

    try {
      // Prepare the request body
      final body = {
        'current_custom_id': currentCustomId,
        'new_custom_id': newCustomId,
      };

      // Send the PATCH request
      final response = await http.patch(
        url,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: body,
      );

      if (response.statusCode == 200) {
        // Parse the response if needed
        final data = json.decode(response.body);
        print("Batch update successful: $data");
      } else {
        print("Failed to update: ${response.statusCode}");
        print("Error: ${response.body}");
      }
    } catch (e) {
      print("An error occurred: $e");
    }
  }

  Future<void> sendPaymentDataToServer(Map<String, dynamic> paymentData) async {
    try {
      final jsonData = jsonEncode(paymentData);
      _channel.sink.add(jsonData);
      print('Payment data sent to server: $jsonData');
    } catch (e) {
      print('Error sending payment data to server: $e');
    }
  }

  Future<bool> addCompany(String name, String address, String gst) async {
    try {
      final response = await http.post(
        Uri.parse('http://$ipAddress/companies/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'companyName': name,
          'companyAddress': address,
          'companyGST': gst,
          'status': '1',
        }),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        return true;
      } else {
        debugPrint(
            'Failed to add customer. Status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      debugPrint('Error adding customer: $e');
      return false;
    }
  }

  void showAdvancePaymentPopup(
      BuildContext context,
      SalesOrderDisplay salesorder,
      List<Map<String, dynamic>> increasedItems,
      List<Map<String, dynamic>> decreasedItems,
      String? path,
      ApiServiceSalesOrderProvider apiprovider,
      File? img1,
      File? img2,
      double modifiedTotal
      // String customerType,
      // String? audioOrderId,
      // String? holdId
      ) {
    double orderAmount = modifiedTotal;

    double discount = 0;
    double customCharge = 0;
    double totalAdvance = 0;
    double deductedAmount = 0;
    double totalAmount = modifiedTotal + customCharge - deductedAmount;
    // double totalAmount = customCharge - deductedAmount;
    TextEditingController discountController = TextEditingController();
    TextEditingController customChargeController = TextEditingController();
    TextEditingController advanceController = TextEditingController();
    TextEditingController remarkController = TextEditingController();

    advanceAmountController.clear();

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          void updatePaymentData() {
            Map<String, dynamic> paymentData = {
              "type": "paymentDetails",
              "orderAmount": orderAmount,
              "discountPercentage": discount,
              "discountAmount": deductedAmount,
              "customCharge": customCharge,
              "total": totalAmount,
              "advance": totalAdvance,
              "paymentMethod": selectedPaymentMethod,
              "remark": remarkController.text,
              "sync": "No",
              "edit": "No"
            };

            // Call your API service method here
            sendPaymentDataToServer(paymentData);
          }

          return AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            title: const Text(
              'Payment Details',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            content: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Order Amount: ₹$orderAmount',
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          child: TextFormField(
                            controller: discountController,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter
                                  .digitsOnly, // Allow digits only
                              LengthLimitingTextInputFormatter(
                                  2), // Restrict to 2 digits
                            ],
                            decoration: const InputDecoration(
                              labelText: 'Discount (%)',
                              border: OutlineInputBorder(),
                              hintText: 'Enter discount percentage',
                            ),
                            onChanged: (value) {
                              setState(() {
                                discount = double.tryParse(value) ?? 0;
                                deductedAmount = (discount / 100) * orderAmount;
                                totalAmount =
                                    orderAmount + customCharge - deductedAmount;

                                // Check if the discount exceeds 6
                                if (discount > 6) {
                                  // Display an alert dialog
                                  showDialog(
                                    context: context,
                                    builder: (context) {
                                      return AlertDialog(
                                        title: const Text('Approval Required'),
                                        content: const Text(
                                            'Discount exceeds the allowed limit of 6%. Approval is needed.'),
                                        actions: [
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context)
                                                  .pop(); // Close the dialog
                                            },
                                            child: const Text('OK'),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                }
                                updatePaymentData();
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          '-₹${deductedAmount.toStringAsFixed(2)}',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: remarkController,
                      keyboardType: TextInputType.text,
                      decoration: const InputDecoration(
                        labelText: 'Remark',
                        border: OutlineInputBorder(),
                        hintText: 'Optional remarks',
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: customChargeController,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter
                            .digitsOnly, // Allow digits only
                        LengthLimitingTextInputFormatter(
                            5), // Restrict to 2 digits
                      ],
                      decoration: const InputDecoration(
                        labelText: 'Custom Charge',
                        border: OutlineInputBorder(),
                        hintText: 'Enter custom charge',
                      ),
                      onChanged: (value) {
                        setState(() {
                          customCharge = double.tryParse(value) ?? 0;
                          totalAmount =
                              modifiedTotal + customCharge - deductedAmount;
                          updatePaymentData();
                        });
                      },
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Payment Method:',
                      style: TextStyle(fontSize: 16),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Radio<String>(
                          value: 'Cash',
                          groupValue: selectedPaymentMethod,
                          onChanged: (value) {
                            setState(() {
                              selectedPaymentMethod = value!;
                              updatePaymentData();
                            });
                          },
                        ),
                        const Text('Cash'),
                        Radio<String>(
                          value: 'Card',
                          groupValue: selectedPaymentMethod,
                          onChanged: (value) {
                            setState(() {
                              selectedPaymentMethod = value!;
                              updatePaymentData();
                            });
                          },
                        ),
                        const Text('Card'),
                        Radio<String>(
                          value: 'UPI',
                          groupValue: selectedPaymentMethod,
                          onChanged: (value) {
                            setState(() {
                              selectedPaymentMethod = value!;
                              updatePaymentData();
                            });
                          },
                        ),
                        const Text('UPI'),
                      ],
                    ),
                    TextFormField(
                      controller: advanceController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Advance',
                        border: OutlineInputBorder(),
                        hintText: 'Enter advance amount',
                      ),
                      onChanged: (value) {
                        setState(() {
                          double enteredValue = double.tryParse(value) ?? 0;
                          if (enteredValue > totalAmount) {
                            // Prevent exceeding total amount
                            advanceController.text =
                                totalAmount.toStringAsFixed(0);
                            advanceController.selection =
                                TextSelection.fromPosition(
                              TextPosition(
                                  offset: advanceController.text.length),
                            );
                            totalAdvance = totalAmount;
                          } else {
                            totalAdvance = enteredValue;
                          }
                          updatePaymentData();
                        });
                      },
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Total Advance: ₹$totalAdvance',
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Total Amount: ₹$totalAmount',
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Balance Amount: ₹${totalAmount - totalAdvance}',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              ElevatedButton(
                onPressed: () {
                  if (discount > 6) {
                    // Display an alert dialog for approval requirement
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: const Text('Approval Required'),
                          content: const Text(
                              'Discount exceeds the allowed limit of 6%. Approval is needed.'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop(); // Close the dialog
                              },
                              child: const Text('OK'),
                            ),
                          ],
                        );
                      },
                    );
                    return; // Stop further execution if approval is required
                  }
                  Navigator.pop(context);
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: const Text('Confirm Order'),
                        content: const Text(
                            'Are you sure you want to complete the order?'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text('Cancel'),
                          ),
                          TextButton(
                            onPressed: () async {
                              double balanceAmount = totalAmount - totalAdvance;
                              // if (customerType == 'Normal') {
                              //   await _saveOrder(
                              //       cartProvider,
                              //       totalAdvance,
                              //       // orderAmount,
                              //       discount,
                              //       deductedAmount,
                              //       customCharge,
                              //       totalAmount,
                              //       remarkController.text,
                              //       path,
                              //       apiprovider,
                              //       img1,
                              //       img2,
                              //       audioOrderId,
                              //       holdId,
                              //       context);
                              //   Navigator.pop(context);
                              // }
                              await saveModifiedOrder(
                                  salesorder,
                                  increasedItems,
                                  decreasedItems,
                                  recordedFilePath,
                                  _pickedImage1,
                                  _pickedImage2,
                                  totalAmount,
                                  totalAdvance,
                                  balanceAmount,
                                  context);
                              // Navigator.push(
                              //   context,
                              //   MaterialPageRoute(
                              //     builder: (context) => AllOrdersPage(),
                              //   ),
                              // );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                            ),
                            child: const Text(
                              'Confirm',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                ),
                child: const Text(
                  'Complete Order',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          );
        });
      },
    );
  }

  void initializeReceiptPrinter({
    required TextEditingController employeeNameController,
    required TextEditingController customerNumberController,
    required double discountController,
    required double customChargeController,
    required String selectedPaymentOptionValue,
    required double totalAmount,
    // required BuildContext context,
    required double advanceAmount,
    required String deliverydateprint,
    required String deliveryTime,
    required TextEditingController customAmountController,
    required String selectedPaymentOption,
    required double balanceAmount,
    required String customerType,
    Map<String, dynamic>? modifieddata,
    // required Function saveInvoiceToHiveAndPrint,
  }) {
    receiptPrinter = modifiedSalesOrderReceiptPrinter(
      employeeNameController: employeeNameController,
      customerNumberController: customerNumberController,
      discountController: discountController,
      customChargeController: customChargeController,
      selectedPaymentOptionValue: selectedPaymentOptionValue,
      totalAmount: totalAmount,
      advanceAmount: advanceAmount,
      balanceAmount: balanceAmount,
      customerType: customerType,
      // context: context,
      deliveryDateprint: dateController.text,
      deliveryTimeprint: timeController.text,
      customAmountController: customAmountController,
      selectedPaymentOption: selectedPaymentOption,
      modifiedOrderData: here,
      // saveInvoiceToHiveAndPrint: saveInvoiceToHiveAndPrint,
    );
  }

  // Future<void> _postAudioFile(String customId, String filePath) async {
  //   print('Posting audio with customId: $customId');
  //   final uri = Uri.parse('https://yenerp.com/fastapi/audios/upload_audio');

  //   try {
  //     // Determine the content type based on the file extension (simplified example)
  //     String fileExtension = filePath.split('.').last.toLowerCase();
  //     String contentType = 'audio/$fileExtension';

  //     // Create a new MultipartRequest
  //     final request = http.MultipartRequest('POST', uri);

  //     // Add the audio file with dynamic content type
  //     var file = await http.MultipartFile.fromPath(
  //       'file',
  //       filePath,
  //       contentType: MediaType.parse(contentType),
  //     );
  //     request.files.add(file);

  //     // Debug: Check what is being added to the request
  //     print('Adding custom_id to form: $customId');

  //     // Pass customId in the form fields
  //     if (customId.isNotEmpty) {
  //       request.fields['custom_id'] = customId;
  //     }

  //     // Debug: Check the request before sending it
  //     print('Request fields: ${request.fields}');

  //     // Send the request
  //     final response = await request.send();
  //     final responseBody =
  //         await response.stream.bytesToString(); // Read response body

  //     // Debug: Check the server's response
  //     if (response.statusCode == 200) {
  //       print('Audio uploaded successfully');
  //       print('Server response: $responseBody');
  //     } else {
  //       print('Failed to upload audio: ${response.statusCode}');
  //       print('Server response: $responseBody');
  //     }
  //   } catch (e) {
  //     print('Error uploading audio: $e');
  //     // Optionally, handle error more gracefully (e.g., display a user-friendly message)
  //   }
  // }

  Future<void> _postAudioFileAndPatch(
      String salesOrderId, String filePath, BuildContext context) async {
    final postUri = Uri.parse('http://$ipAddress/audioOrder/upload_audio');
    final patchUri = Uri.parse('http://$ipAddress/media/patch_audio_id');

    try {
      // Post the audio file
      print('Uploading audio for Sales Order ID: $salesOrderId');

      // Create multipart request
      String fileExtension = filePath.split('.').last.toLowerCase();
      String contentType = 'audio/$fileExtension';

      final request = http.MultipartRequest('POST', postUri);
      var file = await http.MultipartFile.fromPath(
        'file',
        filePath,
        contentType: MediaType.parse(contentType),
      );
      request.files.add(file);

      final postResponse = await request.send();
      final postResponseBody = await postResponse.stream.bytesToString();

      if (postResponse.statusCode != 200) {
        throw Exception('Failed to upload audio: ${postResponse.statusCode}');
      }

      // Extract custom_id from response
      final postResult = jsonDecode(postResponseBody);
      String currentCustomId =
          postResult['custom_id']; // Assuming response includes this field
      print('Audio uploaded successfully with custom_id: $currentCustomId');

      // Patch the audio ID
      print('Patching audio custom_id to match Sales Order ID: $salesOrderId');
      final patchResponse = await http.patch(
        patchUri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'current_custom_id': currentCustomId,
          'new_custom_id': salesOrderId,
        }),
      );

      if (patchResponse.statusCode != 200) {
        throw Exception(
            'Failed to patch audio custom_id: ${patchResponse.statusCode}');
      }

      print('Audio custom_id successfully updated to: $salesOrderId');
    } catch (e) {
      print('Error during audio upload/patch: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error during audio upload/patch: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // Future<void> updateCustomId(String curentCustomId, String customId) async {
  //   final String currentCustomId =
  //       curentCustomId; // Replace with actual custom ID
  //   final String newCustomId = customId; // New custom ID

  //   final url = Uri.parse(
  //       'http://192.168.1.100:8888/audioOrder/media/$currentCustomId/audio');

  //   final response = await http.patch(
  //     url,
  //     body: {
  //       'new_custom_id': newCustomId,
  //     },
  //   );

  //   if (response.statusCode == 200) {
  //     print('Custom ID updated successfully');
  //   } else {
  //     print('Failed to update Custom ID: ${response.statusCode}');
  //   }
  // }

  Future<void> updateCustomId(
      String currentCustomId, String newCustomId) async {
    // Define the API endpoint
    final Uri url = Uri.parse(
      'http://$ipAddress/audioOrder/media/$currentCustomId/audio',
    );

    try {
      // Make the PATCH request
      final http.Response response = await http.patch(
        url,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: {
          'new_custom_id': newCustomId,
        },
      );

      // Handle the response
      if (response.statusCode == 200) {
        print('Custom ID updated successfully');
        print('Response: ${response.body}');
      } else {
        // Decode the server response for detailed error messages
        final String errorMessage = utf8.decode(response.bodyBytes);
        print(
            'Failed to update Custom ID: ${response.statusCode}\nServer Response: $errorMessage');
      }
    } catch (e) {
      // Handle exceptions like network issues
      print('Error occurred while updating Custom ID: $e');
    }
  }

  // Future<void> saveModifiedOrder(
  //   SalesOrderDisplay originalOrder,
  //   List<Map<String, dynamic>> increasedItems,
  //   List<Map<String, dynamic>> decreasedItems,
  //   String? audioPath,
  //   File? newImage1,
  //   File? newImage2,
  //   double totalAmount,
  //   double totalAdvance,
  //   double balanceAmount,
  //   BuildContext context,
  // ) async {
  //   try {
  //     print("1...................................................");
  //     // Step 1: Post existing data to the Modify API
  //     Map<String, dynamic> originalOrderData = {
  //       'previousOrderId': originalOrder.salesOrderId,
  //       'itemName': originalOrder.itemName,
  //       'qty': originalOrder.qty,
  //       'uom': originalOrder.uom,
  //       'weight': originalOrder.weight,
  //       'amount': originalOrder.amount,
  //       'price': originalOrder.price,
  //       'totalAmount': originalOrder.totalAmount,
  //       'totalAmount2': originalOrder.totalAmount,
  //       'branchId': originalOrder.branchId,
  //       'branchName': originalOrder.branchName,
  //       'event': originalOrder.event,
  //       'deliveryType': originalOrder.deliveryType,
  //       'address': originalOrder.address,
  //       'landmark': originalOrder.landmark,
  //       'discount': originalOrder.discount,
  //       'discountAmount': originalOrder.discountAmount,
  //       'remark': originalOrder.remark,
  //       'customCharge': originalOrder.customCharge,
  //       'advanceAmount': originalOrder.advanceAmount,
  //       'advancePaymentType': originalOrder.advancePaymentType,
  //       'advanceDateTime': originalOrder.advanceDateTime,
  //       'customerName': originalOrder.customerName,
  //       'customerNumber': originalOrder.customerNumber,
  //       'deliveryDate': originalOrder.deliveryDate,
  //       'deliveryTime': originalOrder.deliveryTime,
  //       // 'address': originalOrder.address,
  //       // 'landmark': originalOrder.landmark,
  //       'totalAmout': originalOrder.totalAmount,
  //       // 'advanceAmount': originalOrder.advanceAmount,
  //       'balanceAmount': originalOrder.balanceAmount
  //     };
  //     print("2...................................................");
  //     final postResponse = await http.post(
  //       Uri.parse('http://$ipAddress/modify/'),
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(originalOrderData),
  //     );
  //     print("3...................................................");
  //     if (postResponse.statusCode != 200) {
  //       throw Exception(
  //           'Failed to send original order data: ${postResponse.statusCode}');
  //     }
  //     print("4...................................................");
  //     print('responsebody${jsonDecode(postResponse.body)}');
  //     final responseBody = jsonDecode(postResponse.body);
  //     String modifyId = responseBody;
  //     print('Retrieved salesOrderId from response: $modifyId');
  //     List<double> advanceAmountList = [totalAdvance];
  //     double cashAdvance = 0.0;
  //     double cardAdvance = 0.0;
  //     double upiAdvance = 0.0;
  //     // if (audioPath != null || audioPlayerId != null) {
  //     //   // await _postAudioFileAndPatch(
  //     //   //     originalOrder.salesOrderId, audioPath, context);
  //     //   if (audioPlayerId != null && audioPath != null) {
  //     //     print('audioplayreId${audioPlayerId}');
  //     //     await updateCustomId(originalOrder.salesOrderId, modifyId);
  //     //     await _postAudioFile(modifyId, audioPath!);
  //     //   }
  //     //   // if (audioPath != null && audioPlayerId == null) {
  //     //   //   await _postAudioFile(originalOrder.salesOrderId, audioPath);
  //     //   // }
  //     // }
  //     // if (previousAudioId != null || audioPath != null) {
  //     //   if (previousAudioId != null && audioPath != null) {
  //     //     await updateCustomId(originalOrder.salesOrderId, modifyId);
  //     //     print('posting ......post the audio in salesorder');
  //     //     await _postAudioFile(originalOrder.salesOrderId, audioPath);
  //     //   }
  //     //   // if (previousAudioId == null && audioPath != null) {
  //     //   //   await _postAudioFile(originalOrder.salesOrderId, audioPath);
  //     //   // }
  //     // }

  //     if (previousImageId != null) {
  //       if (previousImageId != null) {
  //         await batchUpdateCustomId(originalOrder.salesOrderId, modifyId);
  //         // print('posting ......post the audio in salesorder');
  //         // await _postAudioFile(originalOrder.salesOrderId, audioPath);
  //         print("photo 1..................................................");
  //         print(_pickedImage1 != null);
  //         print("photo 2..................................................");
  //         print(_pickedImage2 != null);
  //         if (_pickedImage1 != null || _pickedImage2 != null) {
  //           // print('Retrieved salesOrderId from response: $modifyId');
  //           print(
  //               "posting 1..................................................");
  //           await _postImages(
  //               originalOrder.salesOrderId, _pickedImage1, _pickedImage2);
  //         }
  //       }
  //     }
  //     print('audioPlayerId$audioPlayerId');

  //     // Step 2: Process and merge data for the PATCH request
  //     List<String> mergedItemNames = [...originalOrder.itemName];
  //     List<num> mergedQty = [...originalOrder.qty];
  //     List<String> mergedUom = [...originalOrder.uom];
  //     List<num> mergedWeight = [...originalOrder.weight];
  //     List<num> mergedAmount = [...originalOrder.amount];
  //     List<num> mergedPrice = [...originalOrder.price];
  //     print("5...................................................");

  //     for (var item in increasedItems) {
  //       int existingIndex = mergedItemNames.indexOf(item['itemName']);
  //       if (existingIndex != -1) {
  //         // Update the existing item
  //         if (mergedUom[existingIndex].toLowerCase() == 'kg' ||
  //             mergedUom[existingIndex].toLowerCase() == 'kgs') {
  //           // For 'kg' or 'kgs', update the amount only
  //           mergedWeight[existingIndex] = item['weight'];
  //           mergedAmount[existingIndex] = item['amount'];
  //         } else {
  //           // For other uoms, add the quantity and amount
  //           mergedQty[existingIndex] += item['quantity'];
  //           mergedAmount[existingIndex] += item['amount'];
  //         }
  //       } else {
  //         // Add a new item
  //         mergedItemNames.add(item['itemName']);
  //         mergedQty.add(item['quantity']);
  //         mergedUom.add(item['uom']);
  //         mergedWeight.add(item['weight']);
  //         mergedAmount.add(item['amount']);
  //         mergedPrice.add(item['price']);
  //       }
  //     }

  //     print("6...................................................");
  //     for (var item in decreasedItems) {
  //       int existingIndex = mergedItemNames.indexOf(item['itemName']);
  //       if (existingIndex != -1) {
  //         mergedQty[existingIndex] -= item['quantity'];
  //         mergedAmount[existingIndex] -= item['amount'];
  //         if (mergedQty[existingIndex] <= 0) {
  //           mergedItemNames.removeAt(existingIndex);
  //           mergedQty.removeAt(existingIndex);
  //           mergedUom.removeAt(existingIndex);
  //           mergedWeight.removeAt(existingIndex);
  //           mergedAmount.removeAt(existingIndex);
  //           mergedPrice.removeAt(existingIndex);
  //         }
  //       }
  //     }
  //     print("7...................................................");
  //     print('mergedweight$mergedWeight');
  //     Map<String, dynamic> modifiedOrderData = {
  //       // 'salesOrderId': originalOrder.salesOrderId,
  //       'itemName': mergedItemNames,
  //       'qty': mergedQty,
  //       'uom': mergedUom,
  //       'weight': mergedWeight,
  //       'amount': mergedAmount,
  //       'price': mergedPrice,
  //       'customerName': customerNameController.text,
  //       'customerNumber': mobileNoController.text,
  //       'deliveryDate': dateController.text,
  //       'deliveryTime': timeController.text,
  //       'event': selectedEvent,
  //       'deliveryType': selectedDeliveryType,
  //       'address': addressController.text,
  //       'landmark': landmarkController.text,
  //       'totalAmount': totalAmount,
  //       'advanceAmount': advanceAmountList,
  //       'balanceAmount': balanceAmount,
  //       'status':
  //           decreasedItems.isNotEmpty ? 'Pending Approval' : 'Confirm Order',
  //     };
  //     initializeReceiptPrinter(
  //         deliveryTime: timeController.text,
  //         deliverydateprint: dateController.text,
  //         employeeNameController: searchController,
  //         customerNumberController: mobileNoController,
  //         discountController: 2,
  //         customChargeController: 2,
  //         selectedPaymentOptionValue: "cash",
  //         totalAmount: totalAmount,
  //         advanceAmount: totalAdvance,
  //         balanceAmount: 100,
  //         customerType: 'SalesOrder',
  //         // context: context,
  //         customAmountController: mobileNoController,
  //         selectedPaymentOption: "cash",
  //         // saveInvoiceToHiveAndPrint: () {}
  //         modifieddata: modifiedOrderData);

  //     // await handleImageUpload(originalOrder.salesOrderId, _pickedImage1, newImage2);

  //     // Step 3: Patch the modified data to the sales order API
  //     final patchResponse = await http.patch(
  //       Uri.parse(
  //           'http://$ipAddress/CurrentOrder/withoutpagination/${originalOrder.salesOrderId}'),
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(modifiedOrderData),
  //     );
  //     print('patchrersponse${patchResponse.body}');
  //     if (patchResponse.statusCode == 200) {
  //       // if (originalOrder.salesOrderId != null) {
  //       print('audiopath$audioPath');
  //       // if (audioPath != null && audioPath.isNotEmpty) {
  //       //   await _postAudioFile(originalOrder.salesOrderId, audioPath);
  //       // }
  //       if (context.mounted) {
  //         // await printModifiedReceipt(context, modifiedOrderData);
  //         print('globals.modifyitems');
  //         print(globals.modifyItems);
  //         await printReceipt(context, modifiedOrderData);
  //         ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(
  //             content: Text(decreasedItems.isNotEmpty
  //                 ? 'Order sent for approval'
  //                 : 'Order modified successfully'),
  //             backgroundColor: Colors.green,
  //           ),
  //         );

  //         final apiProvider =
  //             Provider.of<ApiServiceSalesOrderProvider>(context, listen: false);
  //         apiProvider.fetchAllOrders();
  //       }
  //     } else {
  //       throw Exception('Failed to patch modified order: ');
  //       // ${patchResponse.statusCode}
  //     }
  //   } catch (e) {
  //     if (context.mounted) {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(
  //           content: Text('Error occurred: $e'),
  //           backgroundColor: Colors.red,
  //         ),
  //       );
  //     }
  //   }
  // }

  Future<void> sendModifyDataToServer(Map<String, dynamic> invoiceData) async {
    try {
      final jsonData = jsonEncode(invoiceData);
      _channel.sink.add(jsonData);
      print('sendModifyOrderToServer$jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  Future<void> _sendPatchedDataToServer(
      Map<String, dynamic> invoiceData) async {
    try {
      final jsonData = jsonEncode(invoiceData);
      _channel.sink.add(jsonData);
      print('sendModifyOrderToServer$jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  Future<void> saveModifiedOrder(
    SalesOrderDisplay originalOrder,
    List<Map<String, dynamic>> increasedItems,
    List<Map<String, dynamic>> decreasedItems,
    String? audioPath,
    File? newImage1,
    File? newImage2,
    double totalAmount,
    double totalAdvance,
    double balanceAmount,
    BuildContext context,
  ) async {
    debugPrint("Starting order modification process...");
    try {
      String jsonSalesOrder = jsonEncode({
        "data": originalOrder.toJson(),
        "deviceName": globals.deviceName,
        "type": "modifySaleOrder",
        'salesOrderId': originalOrder.salesOrderId,
        'sync': "No",
        'edit': 'No'
      });
      // Step 1: Post Original Order Data
      print('originalOrder.salesOrderId${originalOrder.salesOrderId}');

      await sendModifyDataToServer(jsonDecode(jsonSalesOrder));
      // String modifyId = await _postOriginalOrderData(originalOrder);

      // if (modifyId.isEmpty) {
      //   throw Exception("Failed to retrieve modifyId");
      // }

      // // Step 2: Handle Images and Audio (if applicable)
      // await _handleMediaUpload(originalOrder.salesOrderId, modifyId, audioPath,
      //     newImage1, newImage2);

      // // Step 3: Merge Increased and Decreased Items
      Map<String, dynamic> modifiedOrderData = _mergeOrderModifications(
        originalOrder,
        increasedItems,
        decreasedItems,
        totalAmount,
        totalAdvance,
        balanceAmount,
      );
      print('saleOrderId${originalOrder.salesOrderId}');
      String jsonModifiedSalesOrder = jsonEncode({
        "data": modifiedOrderData,
        "deviceName": globals.deviceName,
        "type": "patchSaleOrder",
        'salesOrderId': originalOrder.saleOrderNo,
        'sync': "No",
        'edit': 'Yes'
      });
      // // // Step 4: Patch Modified Order Data
      await _sendPatchedDataToServer(jsonDecode(jsonModifiedSalesOrder));
      print('jsonModifiedSalesOrder$jsonModifiedSalesOrder');
      debugPrint("Order modification completed successfully.");
    } catch (e, stackTrace) {
      debugPrint("Error occurred: $e\nStackTrace: $stackTrace");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Error occurred: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      Navigator.of(context).pop();
    }
  }

//  String jsonSalesOrder = jsonEncode({
//         "data": [
//           orderData.toJson(),
//         ],
//         "deviceName": globals.deviceName,
//         "type": "salesOrder",
//         'sync': "No",
//         'edit': 'No'
//       });

  /// Posts the original order data to the modify API and returns the modifyId.
  Future<String> _postOriginalOrderData(SalesOrderDisplay originalOrder) async {
    // DateTime parsedDate = DateTime.parse(originalOrder.deliveryDate);
    // DateFormat('dd-MM-yyyy').format(parsedDate);
    // String formateddate =
    //     DateFormat('dd-MM-yyyy').format(originalOrder.deliveryDate);
    try {
      // DateTime parsedDate = DateTime.parse(originalOrder.deliveryDate);
      // String formateddate = DateFormat('dd-MM-yyyy').format(parsedDate);
      print('originalOrder.deliveryDate${originalOrder.deliveryDate}');
      Map<String, dynamic> orderData = {
        'previousOrderId': originalOrder.salesOrderId,
        'varianceName': originalOrder.varianceName,
        'itemName': originalOrder.itemName,
        'qty': originalOrder.qty,
        'uom': originalOrder.uom,
        'weight': originalOrder.weight,
        'amount': originalOrder.amount,
        'price': originalOrder.price,
        'totalAmount': originalOrder.totalAmount,
        'branchId': originalOrder.branchId,
        'branchName': originalOrder.branchName,
        'event': originalOrder.event,
        'deliveryType': originalOrder.deliveryType,
        'address': originalOrder.address,
        'landmark': originalOrder.landmark,
        'discount': originalOrder.discount,
        'discountAmount': originalOrder.discountAmount,
        'remark': originalOrder.remark,
        'customCharge': originalOrder.customCharge,
        'advanceAmount': originalOrder.advanceAmount,
        'advancePaymentType': originalOrder.advancePaymentType,
        'advanceDateTime': originalOrder.advanceDateTime,
        'customerName': originalOrder.customerName,
        'customerNumber': originalOrder.customerNumber,
        'deliveryDate': originalOrder.deliveryDate,
        // 'deliveryDate': dateController.text,
        'deliveryTime': originalOrder.deliveryTime,
        'balanceAmount': originalOrder.balanceAmount,
      };

      print('orderData${orderData}');

      final response = await http.post(
        Uri.parse('http://$ipAddress/modify/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(orderData),
      );
      print('response${response.body}');
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception(
            'Failed to post original order data. Status: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint("Error in _postOriginalOrderData: $e");
      return "";
    }
  }

  /// Handles uploading images and audio if available.
  Future<void> _handleMediaUpload(String orderId, String modifyId,
      String? audioPath, File? image1, File? image2) async {
    try {
      if (audioPath != null && audioPath.isNotEmpty) {
        await _postAudioFile(modifyId, audioPath);
      }

      if (image1 != null || image2 != null) {
        await _postImages(orderId, image1, image2);
      }
    } catch (e) {
      debugPrint("Error in _handleMediaUpload: $e");
    }
  }

  /// Merges increased and decreased items into the existing order.
  Map<String, dynamic> _mergeOrderModifications(
    SalesOrderDisplay originalOrder,
    List<Map<String, dynamic>> increasedItems,
    List<Map<String, dynamic>> decreasedItems,
    double totalAmount,
    double totalAdvance,
    double balanceAmount,
  ) {
    List<String> varianceNames = [...originalOrder.varianceName];
    List<String> itemNames = [...originalOrder.itemName];
    // List<num> qty = [...originalOrder.qty];
    List<int> qty = originalOrder.qty.map((n) => n.toInt()).toList();
    List<String> uom = [...originalOrder.uom];
    List<num> weight = [...originalOrder.weight];
    List<num> amount = [...originalOrder.amount];
    List<num> price = [...originalOrder.price];

    for (var item in increasedItems) {
      int existingIndex = varianceNames.indexOf(item['varianceName']);
      if (existingIndex != -1) {
        if (uom[existingIndex].toLowerCase() == 'kg' ||
            uom[existingIndex].toLowerCase() == 'kgs') {
          weight[existingIndex] = item['weight'];
          amount[existingIndex] = item['amount'];
        } else {
          // qty[existingIndex] += item['quantity'];
          qty[existingIndex] += (item['quantity'] as num).toInt();
          amount[existingIndex] += item['amount'];
        }
      } else {
        varianceNames.add(item['varianceName']);
        itemNames.add(item['itemName']);
        qty.add(item['quantity']);
        uom.add(item['uom']);
        weight.add(item['weight']);
        amount.add(item['amount']);
        price.add(item['price']);
      }
    }

    for (var item in decreasedItems) {
      int existingIndex = varianceNames.indexOf(item['varianceName']);
      if (existingIndex != -1) {
        // qty[existingIndex] -= item['quantity'];
        qty[existingIndex] -= (item['quantity'] as num).toInt();
        amount[existingIndex] -= item['amount'];
        if (qty[existingIndex] <= 0) {
          varianceNames.removeAt(existingIndex);
          itemNames.removeAt(existingIndex);
          qty.removeAt(existingIndex);
          uom.removeAt(existingIndex);
          weight.removeAt(existingIndex);
          amount.removeAt(existingIndex);
          price.removeAt(existingIndex);
        }
      }
    }

    return {
      'varianceName': varianceNames,
      'itemName': itemNames,
      'qty': qty,
      'uom': uom,
      'weight': weight,
      'amount': amount,
      'price': price,
      'totalAmount': totalAmount,
      'totalAmount2': totalAmount,
      'advanceAmount': [totalAdvance],
      'balanceAmount': balanceAmount,
      'status':
          decreasedItems.isNotEmpty ? 'Pending Approval' : 'Confirm Order',
      'event': selectedEvent,
      'deliveryType': selectedDeliveryType,
      'address': addressController.text ?? '',
      'landmark': landmarkController.text ?? '',
      'customerName': customerNameController.text,
      'customerNumber': mobileNoController.text,
      'deliveryDate': dateController.text,
      'deliveryTime': timeController.text,
      'eventDate': birthdaydateController.text
    };
  }

  /// Patches modified order data to the API.
  Future<void> _patchModifiedOrder(String orderId,
      Map<String, dynamic> modifiedOrderData, BuildContext context) async {
    try {
      final response = await http.patch(
        Uri.parse('http://$ipAddress/CurrentOrder/withoutpagination/$orderId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(modifiedOrderData),
      );
      print('responsebody${response.body}');
      if (response.statusCode == 200) {
        if (context.mounted) {
          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //       builder: (context) => const AllOrdersPage(),
          //     ));

          Navigator.of(context).pop();
          Provider.of<ApiServiceSalesOrderProvider>(context, listen: false)
              .fetchAllOrders();
          resetSelection();
          // TakeAwayOrdersNavigator.navigatorKey.currentState
          //     ?.pushNamed('/all-orders');

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text('Order modified successfully'),
                backgroundColor: Colors.green),
          );
        }
      } else {
        throw Exception(
            'Failed to patch modified order. Status: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint("Error in _patchModifiedOrder: $e");
    } finally {
      setModifyMode(false);
    }
  }

  Timer? _debounceTimer; // Timer for debouncing

  Future<void> fetchSuggestions(String query) async {
    print('Query: $query');

    // Cancel previous timer if a new request comes in before delay
    _debounceTimer?.cancel();

    // Start a new timer (300ms delay before fetching)
    _debounceTimer = Timer(Duration(milliseconds: 300), () async {
      if (query.isEmpty) {
        suggestions = [];
        notifyListeners();
        return;
      }

      final url = Uri.parse('http://$ipAddress/customer/');
      try {
        final response = await http.get(url);
        if (response.statusCode == 200) {
          final List customers = json.decode(response.body);
          print('customers: $customers');

          // Filter customers based on query
          suggestions = customers
              .where((customer) =>
                  customer['customerPhoneNumber'].toString().startsWith(query))
              .map((customer) => {
                    'mobileNo': customer['customerPhoneNumber'].toString(),
                    'name': customer['customerName'].toString(),
                  })
              .toList();

          notifyListeners();
        } else {
          throw Exception('Failed to load customers');
        }
      } catch (e) {
        print('Error: $e');
        suggestions = [];
        notifyListeners();
      }
    });
  }

  // Future<void> saveModifiedOrder(
  //   SalesOrderDisplay originalOrder,
  //   List<Map<String, dynamic>> increasedItems,
  //   List<Map<String, dynamic>> decreasedItems,
  //   String? audioPath,
  //   File? newImage1,
  //   File? newImage2,
  //   double totalAmount,
  //   double totalAdvance,
  //   double balanceAmount,
  //   BuildContext context,
  // ) async {
  //   try {
  //     print("START: saveModifiedOrder");

  //     // Step 1: Post existing data to the Modify API
  //     print("Step 1: Preparing original order data for Modify API...");
  //     Map<String, dynamic> originalOrderData = {
  //       'previousOrderId': originalOrder.salesOrderId,
  //       'itemName': originalOrder.itemName,
  //       'qty': originalOrder.qty,
  //       'uom': originalOrder.uom,
  //       'weight': originalOrder.weight,
  //       'amount': originalOrder.amount,
  //       'price': originalOrder.price,
  //       'totalAmount': originalOrder.totalAmount,
  //       'branchId': originalOrder.branchId,
  //       'branchName': originalOrder.branchName,
  //       'event': originalOrder.event,
  //       'deliveryType': originalOrder.deliveryType,
  //       'address': originalOrder.address,
  //       'landmark': originalOrder.landmark,
  //       'discount': originalOrder.discount,
  //       'discountAmount': originalOrder.discountAmount,
  //       'remark': originalOrder.remark,
  //       'customCharge': originalOrder.customCharge,
  //       'advanceAmount': originalOrder.advanceAmount,
  //       'advancePaymentType': originalOrder.advancePaymentType,
  //       'advanceDateTime': originalOrder.advanceDateTime,
  //       'customerName': originalOrder.customerName,
  //       'customerNumber': originalOrder.customerNumber,
  //       'deliveryDate': originalOrder.deliveryDate,
  //       'deliveryTime': originalOrder.deliveryTime,
  //       'balanceAmount': originalOrder.balanceAmount
  //     };

  //     print("Sending POST request to Modify API...");
  //     final postResponse = await http.post(
  //       Uri.parse('http://$ipAddress/modify/'),
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(originalOrderData),
  //     );

  //     print(
  //         "Modify API response received with status: ${postResponse.statusCode}");
  //     if (postResponse.statusCode != 200) {
  //       print("Error: Modify API failed with response: ${postResponse.body}");
  //       throw Exception('Failed to send original order data');
  //     }

  //     final responseBody = jsonDecode(postResponse.body);
  //     String modifyId = responseBody;
  //     print("Modify API success: Retrieved modifyId: $modifyId");

  //     List<double> advanceAmountList = [totalAdvance];
  //     double cashAdvance = 0.0;
  //     double cardAdvance = 0.0;
  //     double upiAdvance = 0.0;

  //     if (audioPath != null) {
  //       print("Handling audio file upload...");
  //       await updateCustomId(originalOrder.salesOrderId, modifyId);
  //       await _postAudioFile(modifyId, audioPath);
  //       print("Audio file uploaded successfully");
  //     }

  //     if (newImage1 != null || newImage2 != null) {
  //       print("Handling image uploads...");
  //       await batchUpdateCustomId(originalOrder.salesOrderId, modifyId);
  //       await _postImages(originalOrder.salesOrderId, newImage1, newImage2);
  //       print("Images uploaded successfully");
  //     }

  //     print("Merging original, increased, and decreased items...");
  //     List<String> mergedItemNames = [...originalOrder.itemName];
  //     List<num> mergedQty = [...originalOrder.qty];
  //     List<String> mergedUom = [...originalOrder.uom];
  //     List<num> mergedWeight = [...originalOrder.weight];
  //     List<num> mergedAmount = [...originalOrder.amount];
  //     List<num> mergedPrice = [...originalOrder.price];

  //     for (var item in increasedItems) {
  //       print("Processing increased item: ${item['itemName']}");
  //       int existingIndex = mergedItemNames.indexOf(item['itemName']);
  //       if (existingIndex != -1) {
  //         mergedQty[existingIndex] += item['quantity'];
  //         mergedWeight[existingIndex] += item['weight'];
  //         mergedAmount[existingIndex] += item['amount'];
  //         print("Updated item: ${mergedItemNames[existingIndex]}");
  //       } else {
  //         mergedItemNames.add(item['itemName']);
  //         mergedQty.add(item['quantity']);
  //         mergedUom.add(item['uom']);
  //         mergedWeight.add(item['weight']);
  //         mergedAmount.add(item['amount']);
  //         mergedPrice.add(item['price']);
  //         print("Added new item: ${item['itemName']}");
  //       }
  //     }

  //     for (var item in decreasedItems) {
  //       print("Processing decreased item: ${item['itemName']}");
  //       int existingIndex = mergedItemNames.indexOf(item['itemName']);
  //       if (existingIndex != -1) {
  //         mergedQty[existingIndex] -= item['quantity'];
  //         mergedAmount[existingIndex] -= item['amount'];
  //         if (mergedQty[existingIndex] <= 0) {
  //           print("Removing item: ${mergedItemNames[existingIndex]}");
  //           mergedItemNames.removeAt(existingIndex);
  //           mergedQty.removeAt(existingIndex);
  //           mergedUom.removeAt(existingIndex);
  //           mergedWeight.removeAt(existingIndex);
  //           mergedAmount.removeAt(existingIndex);
  //           mergedPrice.removeAt(existingIndex);
  //         }
  //       }
  //     }

  //     print("Final merged item data:");
  //     print("Items: $mergedItemNames");
  //     print("Quantities: $mergedQty");
  //     print("Weights: $mergedWeight");

  //     Map<String, dynamic> modifiedOrderData = {
  //       'itemName': mergedItemNames,
  //       'qty': mergedQty,
  //       'uom': mergedUom,
  //       'weight': mergedWeight,
  //       'amount': mergedAmount,
  //       'price': mergedPrice,
  //       'customerName': customerNameController.text,
  //       'customerNumber': mobileNoController.text,
  //       'deliveryDate': dateController.text,
  //       'deliveryTime': timeController.text,
  //       'event': selectedEvent,
  //       'deliveryType': selectedDeliveryType,
  //       'address': addressController.text,
  //       'landmark': landmarkController.text,
  //       'totalAmount': totalAmount,
  //       'advanceAmount': advanceAmountList,
  //       'balanceAmount': balanceAmount,
  //       'status':
  //           decreasedItems.isNotEmpty ? 'Pending Approval' : 'Confirm Order',
  //     };

  //     print("Sending PATCH request with modified order data...");
  //     final patchResponse = await http.patch(
  //       Uri.parse(
  //           'http://$ipAddress/CurrentOrder/withoutpagination/${originalOrder.salesOrderId}'),
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(modifiedOrderData),
  //     );

  //     print(
  //         "PATCH API response received with status: ${patchResponse.statusCode}");
  //     if (patchResponse.statusCode == 200) {
  //       print("Order modified successfully");
  //       if (context.mounted) {
  //         ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(
  //             content: Text(decreasedItems.isNotEmpty
  //                 ? 'Order sent for approval'
  //                 : 'Order modified successfully'),
  //             backgroundColor: Colors.green,
  //           ),
  //         );
  //       }
  //     } else {
  //       print("Error: Failed to modify order. Response: ${patchResponse.body}");
  //       throw Exception('Failed to patch modified order');
  //     }
  //   } catch (e) {
  //     print("Exception occurred: $e");
  //     if (context.mounted) {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(
  //           content: Text('Error occurred: $e'),
  //           backgroundColor: Colors.red,
  //         ),
  //       );
  //     }
  //   } finally {
  //     print("END: saveModifiedOrder");
  //   }
  // }

  Future<void> sendToApproval(
    SalesOrderDisplay originalOrder,
    List<Map<String, dynamic>> increasedItems,
    List<Map<String, dynamic>> decreasedItems,
    String? audioPath,
    File? newImage1,
    File? newImage2,
    double totalAmount,
    double totalAdvance,
    double balanceAmount,
    BuildContext context,
  ) async {
    try {
      print("Step 1: Starting sendToApproval...");

      // Print initial variables
      print("Original Order: $originalOrder");
      print("Increased Items: $increasedItems");
      print("Decreased Items: $decreasedItems");
      print("Audio Path: $audioPath");
      print("Image 1: ${newImage1?.path}");
      print("Image 2: ${newImage2?.path}");
      print("Total Amount: $totalAmount");
      print("Total Advance: $totalAdvance");
      print("Balance Amount: $balanceAmount");

      List<double> advanceAmountList = [totalAdvance];
      print("Advance Amount List: $advanceAmountList");

      // Copy original order data into merged lists
      List<String> mergedItemNames = [...originalOrder.itemName];
      List<String> mergedVarianceNames = [...originalOrder.varianceName];

      List<num> mergedQty = [...originalOrder.qty];
      List<String> mergedUom = [...originalOrder.uom];
      List<num> mergedWeight = [...originalOrder.weight];
      List<num> mergedAmount = [...originalOrder.amount];
      List<num> mergedPrice = [...originalOrder.price];

      print("Step 2: Initial merged data:");
      print("Item Names: $mergedItemNames");
      print("Quantities: $mergedQty");
      print("UOMs: $mergedUom");
      print("Weights: $mergedWeight");
      print("Amounts: $mergedAmount");
      print("Prices: $mergedPrice");

      // Process increased items
      print("Step 3: Processing increased items...");
      for (var item in increasedItems) {
        print("Processing increased item: $item");
        int existingIndex = mergedItemNames.indexOf(item['varianceName']);
        if (existingIndex != -1) {
          print("Item exists, updating quantity and amount...");
          mergedQty[existingIndex] += item['quantity'];
          mergedAmount[existingIndex] += item['amount'];
        } else {
          print("Item does not exist, adding new item...");
          mergedVarianceNames.add(item['varianceName']);
          mergedItemNames.add(item['itemName']);
          mergedQty.add(item['quantity']);
          mergedUom.add(item['uom']);
          mergedWeight.add(item['weight']);
          mergedAmount.add(item['amount']);
          mergedPrice.add(item['price']);
        }
      }

      // Print merged data after processing increased items
      print("After processing increased items:");
      print("Item Names: $mergedItemNames");
      print("Quantities: $mergedQty");
      print("UOMs: $mergedUom");
      print("Weights: $mergedWeight");
      print("Amounts: $mergedAmount");
      print("Prices: $mergedPrice");

      // Process decreased items
      print("Step 4: Processing decreased items...");
      // for (var item in decreasedItems) {
      //   print("Processing decreased item: $item");
      //   int existingIndex = mergedItemNames.indexOf(item['itemName']);
      //   if (existingIndex != -1) {
      //     print("Item exists, reducing quantity and amount...");
      //     mergedQty[existingIndex] -= item['quantity'];
      //     mergedAmount[existingIndex] -= item['amount'];
      //     if (mergedQty[existingIndex] <= 0) {
      //       print("Quantity is zero or less, removing item...");
      //       mergedItemNames.removeAt(existingIndex);
      //       mergedQty.removeAt(existingIndex);
      //       mergedUom.removeAt(existingIndex);
      //       mergedWeight.removeAt(existingIndex);
      //       mergedAmount.removeAt(existingIndex);
      //       mergedPrice.removeAt(existingIndex);
      //     }
      //   }
      // }
      // Process decreased items
      print("Step 4: Processing decreased items...");
      // Process decreased items
      print("Step 4: Processing decreased items...");
      for (var item in decreasedItems) {
        print("Processing decreased item: $item");
        int existingIndex = mergedVarianceNames.indexOf(item['varianceName']);

        if (existingIndex != -1) {
          print("Item exists, reducing weight and amount...");

          // Get the current values
          num newQuantity = mergedQty[existingIndex];
          num newAmount = mergedAmount[existingIndex];
          num newWeight = mergedWeight[existingIndex];

          // Check the unit of measure (UOM)
          if (mergedUom[existingIndex].toLowerCase() == 'kg' ||
              mergedUom[existingIndex].toLowerCase() == 'kgs') {
            // If the UOM is kg, reduce the weight and amount, but don't change quantity
            double reducedWeight =
                item['weight']; // Reduced weight from the item
            newWeight -= reducedWeight; // Subtract the reduced weight
            newAmount -= item['amount']; // Subtract the amount

            print("New Weight (kg): $newWeight");
          } else {
            // For other units like Pcs or Pkt, reduce qty and amount
            newQuantity -= item['quantity'];
            newAmount -= item['amount'];

            print("New Quantity (Pcs/Pkt): $newQuantity");
          }

          print("New Amount: $newAmount");

          // Update the values if still valid
          if (newQuantity > 0 && newWeight >= 0) {
            mergedQty[existingIndex] = newQuantity;
            mergedAmount[existingIndex] = newAmount;
            mergedWeight[existingIndex] = newWeight;
          } else {
            // Remove the item if quantity or weight is zero or less
            print("Quantity or weight is zero or less, removing item...");
            mergedItemNames.removeAt(existingIndex);
            mergedVarianceNames.removeAt(existingIndex);
            mergedQty.removeAt(existingIndex);
            mergedUom.removeAt(existingIndex);
            mergedWeight.removeAt(existingIndex);
            mergedAmount.removeAt(existingIndex);
            mergedPrice.removeAt(existingIndex);
          }
        } else {
          print("Item not found in the merged list.");
        }
      }

      print("After processing decreased items:");
      print("Item Names: $mergedItemNames");
      print("Quantities: $mergedQty");
      print("UOMs: $mergedUom");
      print("Weights: $mergedWeight");
      print("Amounts: $mergedAmount");
      print("Prices: $mergedPrice");

      print("Step 5: Preparing modified order data...");
      Map<String, dynamic> modifiedOrderData = {
        'previousOrderId': originalOrder.salesOrderId,
        'itemName': mergedItemNames,
        'varianceName': mergedVarianceNames,
        'qty': mergedQty,
        'uom': mergedUom,
        'weight': mergedWeight,
        'amount': mergedAmount,
        'price': mergedPrice,
        'saleOrderNo': originalOrder.saleOrderNo,
        'customerName': customerNameController.text,
        'customerNumber': mobileNoController.text,
        'deliveryDate': dateController.text,
        'deliveryTime': timeController.text,
        'event': selectedEvent,
        'deliveryType': selectedDeliveryType,
        'address': addressController.text,
        'landmark': landmarkController.text,
        'totalAmount': totalAmount,
        'advanceAmount': advanceAmountList,
        'balanceAmount': balanceAmount,
        'status': 'toApprove Orders',
        'approvalType': 'ModifyOrder',
      };

      // Print the final payload
      print("Modified Order Data: $modifiedOrderData");

      String jsonModifiedSalesOrder = jsonEncode({
        "data": modifiedOrderData,
        "deviceName": globals.deviceName,
        "type": "postToApprove",
        'salesOrderId': originalOrder.saleOrderNo,
        'sync': "No",
        'edit': 'No'
      });

      Map<String, dynamic> patchData = {
        "status": "toApprove Orders",
        "approvalType": "ModifyOrder",
      };
      String serverPatchData = jsonEncode({
        "data": patchData,
        "deviceName": globals.deviceName,
        "type": "patchSaleOrder",
        'salesOrderId': originalOrder.saleOrderNo,
        'sync': "No",
        'edit': 'Yes',
        'waitingForApprovalResult': 'Yes',
        "saleOrderNo": originalOrder.saleOrderNo,
      });

      await _sendPostToapproveDataToServer(jsonDecode(jsonModifiedSalesOrder));
      await _sendPatchForSaleOrderDataToServer(jsonDecode(serverPatchData));
      // print("Step 6: Sending HTTP POST request...");
      // final patchResponse = await http.post(
      //   Uri.parse('http://$ipAddress/toapprove/'),
      //   headers: {'Content-Type': 'application/json'},
      //   body: jsonEncode(modifiedOrderData),
      // );

      // print("HTTP Response Status: ${patchResponse.statusCode}");
      // print("HTTP Response Body: ${patchResponse.body}");

      // if (patchResponse.statusCode == 200 && context.mounted) {
      //   print("Request successful. Handling response...");
      //   print("Audio Path: $audioPath");
      //   final patchData = jsonEncode({
      //     "status": "toApprove Orders",
      //     "approvalType": "ModifyOrder",
      //   });
      //   final patchResponseForApproval = await http.patch(
      //     Uri.parse(
      //         'http://$ipAddress/CurrentOrder/withoutpagination/${originalOrder.salesOrderId}'),
      //     headers: {'Content-Type': 'application/json'},
      //     body: patchData,
      //   );
      //   print('patchData$patchData');
      //   if (patchResponseForApproval.statusCode == 200 && context.mounted) {
      //     print("Status updated successfully.");

      //     // if (context.mounted) {

      //     ScaffoldMessenger.of(context).showSnackBar(
      //       SnackBar(
      //         content: Text(decreasedItems.isNotEmpty
      //             ? 'Order sent for approval'
      //             : 'Order modified successfully'),
      //         backgroundColor: Colors.green,
      //       ),
      //     );
      //     await printReceipt(context, modifiedOrderData);
      //     // }
      //     if (context.mounted) {
      //       final apiProvider = Provider.of<ApiServiceSalesOrderProvider>(
      //           context,
      //           listen: false);
      //       apiProvider.fetchAllOrders();
      //     }
      //   }
      // } else {
      //   throw Exception('Failed to patch modified order.');
      // }
    } catch (e) {
      print("Error occurred: $e");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error occurred: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _sendPostToapproveDataToServer(
      Map<String, dynamic> invoiceData) async {
    try {
      final jsonData = jsonEncode(invoiceData);
      _channel.sink.add(jsonData);
      print('sendModifyOrderToServer$jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  // Future<void> _sendPatchForSaleOrderDataToServer(
  //     Map<String, dynamic> patchData) async {
  //   try {
  //     final jsonData = jsonEncode(patchData);
  //     _channel.sink.add(jsonData);
  //     print('sendModifyOrderToServer$jsonData');
  //   } catch (e) {
  //     print('Error sending invoice data to server: $e');
  //   }
  // }

  int _sendCount = 0; // Add this as a member variable of your class

  Future<void> _sendPatchForSaleOrderDataToServer(
      Map<String, dynamic> patchData) async {
    try {
      final jsonData = jsonEncode(patchData);
      _channel.sink.add(jsonData);
      _sendCount++; // Increment the counter
      print('sendModifyOrderToServer$jsonData');
      print('Data has been sent $_sendCount time(s).');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  Future<void> handleAudioOrder(
      String? audioOrderId, String salesOrderId, String? path) async {
    print('path');
    print(path);
    if (path == null || path.isEmpty) {
      return;
    }
    if (audioOrderId != null) {
      // await updateCustomId(audioOrderId, salesOrderId);
    } else {
      await _postAudioFile(salesOrderId, path);
    }
  }

  Future<void> handleImageUpload(
      String salesOrderId, File? img1, File? img2) async {
    if (img1 != null || img2 != null) {
      await _postImages(salesOrderId, img1, img2);
    }
  }

  Future<void> _postImages(
      String salesOrderId, File? pickedImage1, File? pickedImage2) async {
    try {
      print("Sending HTTP request for images...");

      var uri = Uri.parse(
          "http://$ipAddress/imageOrder/upload_photo"); // Change to your FastAPI endpoint
      var request = http.MultipartRequest('POST', uri);

      // Attach the salesOrderId to the request
      request.fields['custom_id'] = salesOrderId;

      // Check and add image1 if it's picked
      if (pickedImage1 != null) {
        var image1Bytes = await pickedImage1.readAsBytes();
        var image1MimeType = lookupMimeType(pickedImage1.path) ??
            'image/jpeg'; // Default to 'image/jpeg' if MIME type is not found

        // Add image1 as a multipart file
        request.files.add(http.MultipartFile.fromBytes(
          'files', // The field name expected by FastAPI
          image1Bytes,
          filename: pickedImage1.path
              .split('/')
              .last, // Extract the filename from the path
          contentType:
              MediaType.parse(image1MimeType), // Use the correct MIME type
        ));
      }

      // Check and add image2 if it's picked
      if (pickedImage2 != null) {
        var image2Bytes = await pickedImage2.readAsBytes();
        var image2MimeType = lookupMimeType(pickedImage2.path) ??
            'image/jpeg'; // Default to 'image/jpeg' if MIME type is not found

        // Add image2 as a multipart file
        request.files.add(http.MultipartFile.fromBytes(
          'files', // The field name expected by FastAPI
          image2Bytes,
          filename: pickedImage2.path
              .split('/')
              .last, // Extract the filename from the path
          contentType:
              MediaType.parse(image2MimeType), // Use the correct MIME type
        ));
      }

      // Send the request and await the response
      var response = await request.send();
      print("Status Code: ${response.statusCode}");

      if (response.statusCode == 200) {
        var responseBody = await response.stream.bytesToString();
        var responseData = jsonDecode(responseBody);
        print('Response Data: $responseData');

        // Process the response to get the uploaded image URLs
        var uploadedPhotos = responseData['uploaded_photos'];
        for (var photo in uploadedPhotos) {
          print('Uploaded Photo URL: ${photo['photo_url']}');
        }
      } else {
        print('Failed to upload images: ${response.statusCode}');
        print('Server Error: ${response.headers}');
      }
    } catch (e) {
      print('Error while posting images: $e');
    }
  }

  Future<void> _postAudioFile(String customId, String filePath) async {
    print('Posting audio with customId: $customId');
    // final uri = Uri.parse('https://yenerp.com/fastapi/audios/upload_audio');
    final uri = Uri.parse('http://$ipAddress/audioOrder/upload_audio');

    try {
      // Determine the content type based on the file extension (simplified example)
      String fileExtension = filePath.split('.').last.toLowerCase();
      String contentType = 'audio/$fileExtension';

      // Create a new MultipartRequest
      final request = http.MultipartRequest('POST', uri);

      // Add the audio file with dynamic content type
      var file = await http.MultipartFile.fromPath(
        'file',
        filePath,
        contentType: MediaType.parse(contentType),
      );
      request.files.add(file);

      // Debug: Check what is being added to the request
      print('Adding custom_id to form: $customId');

      // Pass customId in the form fields
      if (customId.isNotEmpty) {
        request.fields['custom_id'] = customId;
      }

      // Debug: Check the request before sending it
      print('Request fields: ${request.fields}');

      // Send the request
      final response = await request.send();
      final responseBody =
          await response.stream.bytesToString(); // Read response body

      // Debug: Check the server's response
      if (response.statusCode == 200) {
        print('Audio uploaded successfully');
        print('Server response: $responseBody');
      } else {
        print('Failed to upload audio: ${response.statusCode}');
        print('Server response: $responseBody');
      }
    } catch (e) {
      print('Error uploading audio: $e');
      // Optionally, handle error more gracefully (e.g., display a user-friendly message)
    }
  }

// Helper function to calculate new total
  double _calculateNewTotal(
      double originalTotal,
      List<Map<String, dynamic>> increasedItems,
      List<Map<String, dynamic>> decreasedItems) {
    double increasedAmount = increasedItems.fold(
      0.0,
      (sum, item) => sum + (item['amount'] as double),
    );

    double decreasedAmount = decreasedItems.fold(
      0.0,
      (sum, item) => sum + (item['amount'] as double),
    );

    return originalTotal + increasedAmount - decreasedAmount;
  }

// Helper function to print modified receipt

  Future<void> fetchCompanySuggestions(String query) async {
    if (query.isEmpty) {
      suggestions = [];
      notifyListeners();
      return;
    }

    final url = Uri.parse('http://$ipAddress/companies/');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final List customers = json.decode(response.body);

        suggestions = customers
            .where((customer) => customer['companyName']
                .toString()
                .startsWith(query)) // Filter by company name prefix
            .map((customer) => {
                  'name': customer['companyName'].toString(),
                  'address': customer['companyAddress'].toString(),
                  'gst': customer['companyGST'].toString(),
                })
            .toList();
        notifyListeners();
      } else {
        throw Exception('Failed to load companies');
      }
    } catch (e) {
      print(e);
      suggestions = [];
      notifyListeners();
    }
  }

  void setSelectedEvent(String? event) {
    _selectedEvent = event;
    notifyListeners();
  }

  void setSelectedDeliveryType(String? newValue) {
    selectedDeliveryType = newValue;
    notifyListeners();
  }

  String? selectedDeliveryType;
  Future<bool> addCustomer(String mobile, String name) async {
    try {
      final response = await http.post(
        Uri.parse('http://$ipAddress/customer/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'customerPhoneNumber': mobile,
          'customerName': name,
          'status': '1'
        }),
      );
      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      debugPrint('Error adding customer: $e');
      return false;
    }
  }

  void onSuggestionSelected(Map<String, String> suggestion) {
    mobileNoController.text = suggestion['mobileNo']!;
    customerNameController.text = suggestion['name']!;
    suggestions = []; // Clear suggestions after selection
    notifyListeners();
  }

  Future<List<Map<String, String>>> fetchCustomerList() async {
    try {
      final response = await http.get(
        // Uri.parse('http://192.168.1.103:8888/fastapi/customers/'),
        Uri.parse('http://$ipAddress/customer/'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> customerData = json.decode(response.body);
        return customerData.map((data) {
          return {
            'customerName': data['customerName'] as String,
            'customerPhoneNumber': data['customerPhoneNumber'] as String,
          };
        }).toList();
      } else {
        throw Exception('Failed to load customers');
      }
    } catch (e) {
      throw Exception('Error fetching customers: $e');
    }
  }

  Widget buildCustomerInputFields(BuildContext context, bool enable) {
    Future<void> fetchSuggestions(String query) async {
      print('query');
      print(query);
      if (query.isEmpty) {
        suggestions = [];
        notifyListeners();
        return;
      }

      final url = Uri.parse('http://$ipAddress/customer/');
      try {
        final response = await http.get(url);
        if (response.statusCode == 200) {
          final List customers = json.decode(response.body);
          print('customers:$customers');
          suggestions = customers
              .where((customer) => customer['customerPhoneNumber']
                  .toString()
                  .startsWith(query)) // Filter by mobile number prefix
              .map((customer) => {
                    'mobileNo': customer['customerPhoneNumber'].toString(),
                    'name': customer['customerName'].toString(),
                  })
              .toList();
          notifyListeners();
        } else {
          throw Exception('Failed to load customers');
        }
      } catch (e) {
        print(e);

        suggestions = [];
        notifyListeners();
      }
    }

    return Column(
      children: [
        Row(
          children: [
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                controller: mobileNoController,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(10),
                ],
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Search Mobile Number',
                  labelStyle: TextStyle(fontSize: 10),
                  enabled: enable,
                  isDense: true, // Makes the field more compact
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 8, vertical: 6), // Same padding as above
                ),
                onChanged: (value) {
                  // Clear customer name when mobile number changes
                  customerNameController.clear();
                  fetchSuggestions(value);
                },
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Customer Mobile No is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                enabled: false,
                controller: customerNameController,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(24),
                  FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z0-9 ]*$')),
                ],
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Customer Name',
                  labelStyle: TextStyle(fontSize: 10),
                  isDense: true, // Makes the field more compact
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 8, vertical: 6), // Same padding as above
                ),
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Customer Name is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
          ],
        ),
        const SizedBox(height: 8.0),

        // Only show suggestions container when mobile number is not empty AND customer name is empty
        if (mobileNoController.text.isNotEmpty &&
            customerNameController.text.isEmpty)
          Container(
            height: 100,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: ListView.builder(
              itemCount: suggestions.isEmpty ? 1 : suggestions.length + 1,
              itemBuilder: (context, index) {
                // Show suggestions if available
                if (suggestions.isNotEmpty &&
                    index < suggestions.length &&
                    enable) {
                  final suggestion = suggestions[index];
                  return ListTile(
                    title: Text(suggestion['mobileNo'] ?? 'Unknown Mobile'),
                    subtitle: Text(suggestion['name'] ?? 'Unknown Name'),
                    onTap: () {
                      onSuggestionSelected(suggestion);
                      // Set focus to next field or clear focus
                      FocusScope.of(context).unfocus();
                    },
                  );
                }

                // Show "Add Customer Details" as the last item
                return ListTile(
                  leading: const Icon(Icons.add, color: Colors.green),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 8.0, vertical: 4.0), // Reduced padding
                  title: const Text('Add Customer Details'),
                  onTap: () async {
                    await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        final TextEditingController mobileController =
                            TextEditingController(
                                text: mobileNoController.text);
                        final TextEditingController nameController =
                            TextEditingController();
                        return AlertDialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16.0),
                          ),
                          title: const Row(
                            children: [
                              Icon(Icons.person_add, color: Colors.blue),
                              SizedBox(width: 8),
                              Text('Add Customer',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 10)),
                            ],
                          ),
                          content: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TextFormField(
                                  controller: mobileController,
                                  keyboardType: TextInputType.phone,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly,
                                    LengthLimitingTextInputFormatter(10),
                                  ],
                                  decoration: InputDecoration(
                                    labelText: 'Mobile Number',
                                    prefixText: '+91 ',
                                    prefixStyle:
                                        const TextStyle(color: Colors.black),
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(8.0)),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                TextFormField(
                                  controller: nameController,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(24),
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'^[a-zA-Z ]*$')),
                                  ],
                                  decoration: InputDecoration(
                                    labelText: 'Customer Name',
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(8.0)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('Cancel',
                                  style: TextStyle(
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold)),
                            ),
                            ElevatedButton(
                              onPressed: () async {
                                final String mobile =
                                    mobileController.text.trim();
                                final String name = nameController.text.trim();

                                if (mobile.length == 10 &&
                                    RegExp(r'^\d+$').hasMatch(mobile) &&
                                    name.isNotEmpty) {
                                  final response =
                                      await addCustomer(mobile, name);
                                  if (response) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                            'Customer "$name" added successfully!',
                                            style: const TextStyle(
                                                color: Colors.white)),
                                        backgroundColor: Colors.green,
                                      ),
                                    );
                                    await fetchSuggestions(mobile);
                                    Navigator.pop(context);
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            'Failed to add customer. Please try again.'),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                  }
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                          'Please enter a valid mobile number and name.'),
                                      backgroundColor: Colors.orange,
                                    ),
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: const Text(
                                'Submit',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
      ],
    );
  }

  Widget buildCompanyInputFields(BuildContext context) {
    return Column(
      children: [
        // Company-specific fields
        Row(
          children: [
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                controller: companyNameController,
                keyboardType: TextInputType.text,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z0-9 ]*$')),
                  LengthLimitingTextInputFormatter(50),
                ],
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Company Name',
                  // prefixIcon: Icon(Icons.search),
                  isDense: true, // Makes the field more compact
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                ),
                onChanged: (value) {
                  fetchCompanySuggestionsDebounced(value);
                },
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Company Name is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
          ],
        ),

        if (companyNameController.text.isNotEmpty &&
            companyAddressController.text.isEmpty)
          Container(
            height: 100,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: ListView.builder(
              itemCount: suggestions.isEmpty ? 1 : suggestions.length + 1,
              itemBuilder: (context, index) {
                // Show suggestions if available
                if (suggestions.isNotEmpty && index < suggestions.length) {
                  final company = suggestions[index];
                  return ListTile(
                    title: Text(company['name'] ?? ""),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(company['address'] ?? ""),
                        Text('GST: ${company['gst']}'),
                      ],
                    ),
                    onTap: () {
                      companyNameController.text = company['name'] ?? "";
                      companyAddressController.text = company['address'] ?? "";
                      companygstNumberController.text = company['gst'] ?? "";
                      suggestions.clear();
                      // FocusScope.of(context).unfocus();
                      notifyListeners();
                    },
                  );
                }
                // Show "Add Customer Details" as the last item
                return ListTile(
                  leading: const Icon(Icons.add, color: Colors.green),
                  title: const Text('Add Company Details'),
                  onTap: () async {
                    await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        final TextEditingController nameController =
                            TextEditingController();
                        final TextEditingController addressController =
                            TextEditingController();
                        final TextEditingController gstController =
                            TextEditingController();

                        return AlertDialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16.0),
                          ),
                          title: const Row(
                            children: [
                              Icon(Icons.business, color: Colors.blue),
                              SizedBox(width: 8),
                              Text('Add Company',
                                  style:
                                      TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                          content: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TextFormField(
                                  controller: nameController,
                                  decoration: const InputDecoration(
                                    labelText: 'Company Name',
                                    border: OutlineInputBorder(),
                                    isDense:
                                        true, // Makes the field more compact
                                    contentPadding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 6),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                TextFormField(
                                  controller: addressController,
                                  decoration: const InputDecoration(
                                    labelText: 'Company Address',
                                    border: OutlineInputBorder(),
                                    isDense:
                                        true, // Makes the field more compact
                                    contentPadding: EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 8),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                TextFormField(
                                  controller: gstController,
                                  decoration: const InputDecoration(
                                    labelText: 'Company GST',
                                    border: OutlineInputBorder(),
                                    isDense:
                                        true, // Makes the field more compact
                                    contentPadding: EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 8),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('Cancel',
                                  style: TextStyle(
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold)),
                            ),
                            ElevatedButton(
                              onPressed: () async {
                                final String name = nameController.text.trim();
                                final String address =
                                    addressController.text.trim();
                                final String gst = gstController.text.trim();

                                if (name.isNotEmpty &&
                                    address.isNotEmpty &&
                                    gst.isNotEmpty) {
                                  final response =
                                      await addCompany(name, address, gst);

                                  if (response) {
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(SnackBar(
                                      content: Text(
                                          'Company "$name" added successfully!',
                                          style: const TextStyle(
                                              color: Colors.white)),
                                      backgroundColor: Colors.green,
                                    ));
                                    fetchCompanySuggestionsDebounced('');
                                    Navigator.pop(context);
                                  } else {
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(const SnackBar(
                                      content: Text(
                                          'Failed to add company. Please try again.'),
                                      backgroundColor: Colors.red,
                                    ));
                                  }
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                          'Please fill in all fields correctly.'),
                                      backgroundColor: Colors.orange,
                                    ),
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: const Text('Submit',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white)),
                            ),
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),

        const SizedBox(height: 10),
        Row(
          children: [
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                enabled: false,
                controller: companyAddressController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Company Address',
                  isDense: true, // Makes the field more compact
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                ),
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Company Address is required';
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(width: 10), // Spacing between the two fields
            Expanded(
              child: TextFormField(
                enabled: false,
                controller: companygstNumberController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Company GST',
                  isDense: true, // Makes the field more compact
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                ),
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Company GST is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
          ],
        ),
      ],
    );
  }

  String? selectedFilter = 'All Order';

  File? pickedImage1;
  File? pickedImage2;

  void setFilter(String? value) {
    selectedFilter = value;
    notifyListeners();
  }

  Map<String, Map<int, double>> modifiedQuantities = {};
  Map<String, Map<int, double>> modifiedAmounts = {};

  // New methods to support item-by-item editing

  // Track which items are currently being edited
  Set<String> itemsInEditMode = {};

  // Toggle edit mode for a specific item
  void toggleItemEditMode(SalesOrderDisplay salesOrder, int index) {
    String itemKey = '${salesOrder.varianceName[index]}_$index';
    if (itemsInEditMode.contains(itemKey)) {
      itemsInEditMode.remove(itemKey);
    } else {
      itemsInEditMode.add(itemKey);
    }
    notifyListeners();
  }

  // Check if an item is in edit mode
  bool isItemInEditMode(SalesOrderDisplay salesOrder, int index) {
    String itemKey = '${salesOrder.varianceName[index]}_$index';
    return itemsInEditMode.contains(itemKey);
  }

  // Get the unique key for an order item
  String _getOrderItemKey(SalesOrderDisplay salesOrder) {
    return salesOrder.salesOrderId ?? '';
  }

  // Check if an item has been modified
  bool isItemModified(SalesOrderDisplay salesOrder, int index) {
    String orderKey = _getOrderItemKey(salesOrder);

    return modifiedQuantities.containsKey(orderKey) &&
        modifiedQuantities[orderKey]!.containsKey(index) &&
        modifiedQuantities[orderKey]![index] != salesOrder.qty[index];
  }

  // Get modified quantity for an item
  num getModifiedQuantity(SalesOrderDisplay salesOrder, int index) {
    String orderKey = _getOrderItemKey(salesOrder);

    if (modifiedQuantities.containsKey(orderKey) &&
        modifiedQuantities[orderKey]!.containsKey(index)) {
      return modifiedQuantities[orderKey]![index]!;
    }

    return salesOrder.qty[index];
  }

  // Get modified amount for an item
  double getModifiedAmount(SalesOrderDisplay salesOrder, int index) {
    String orderKey = _getOrderItemKey(salesOrder);

    if (modifiedAmounts.containsKey(orderKey) &&
        modifiedAmounts[orderKey]!.containsKey(index)) {
      return modifiedAmounts[orderKey]![index]!;
    }

    return salesOrder.amount[index];
  }

  // Increase item quantity
  void increaseItemQuantity(SalesOrderDisplay salesOrder, int index) {
    String orderKey = _getOrderItemKey(salesOrder);

    // Initialize maps if needed
    if (!modifiedQuantities.containsKey(orderKey)) {
      modifiedQuantities[orderKey] = {};
      modifiedAmounts[orderKey] = {};
    }

    // Get current quantity (either modified or original)
    double currentQty = getModifiedQuantity(salesOrder, index) as double;
    bool isKg = salesOrder.uom[index].toLowerCase() == 'kg' ||
        salesOrder.uom[index].toLowerCase() == 'kgs';

    // Increment by 0.1 for kg, 1 for other units
    double newQty = isKg ? currentQty + 0.1 : currentQty + 1;

    // Update quantity and calculate new amount
    modifiedQuantities[orderKey]![index] = newQty;
    modifiedAmounts[orderKey]![index] = newQty * salesOrder.price[index];

    // Update increased/decreased items for summary
    _updateModifiedItemsList(salesOrder, index, newQty);

    notifyListeners();
  }

  // Decrease item quantity
  void decreaseItemQuantity(SalesOrderDisplay salesOrder, int index) {
    String orderKey = _getOrderItemKey(salesOrder);

    // Initialize maps if needed
    if (!modifiedQuantities.containsKey(orderKey)) {
      modifiedQuantities[orderKey] = {};
      modifiedAmounts[orderKey] = {};
    }

    // Get current quantity (either modified or original)
    double currentQty = getModifiedQuantity(salesOrder, index) as double;
    bool isKg = salesOrder.uom[index].toLowerCase() == 'kg' ||
        salesOrder.uom[index].toLowerCase() == 'kgs';

    // Only decrease if quantity is greater than minimum
    if ((isKg && currentQty > 0.1) || (!isKg && currentQty > 1)) {
      // Decrement by 0.1 for kg, 1 for other units
      double newQty = isKg ? currentQty - 0.1 : currentQty - 1;

      // Update quantity and calculate new amount
      modifiedQuantities[orderKey]![index] = newQty;
      modifiedAmounts[orderKey]![index] = newQty * salesOrder.price[index];

      // Update increased/decreased items for summary
      _updateModifiedItemsList(salesOrder, index, newQty);

      notifyListeners();
    }
  }

  // Reset item quantity to original
  void resetItemQuantity(SalesOrderDisplay salesOrder, int index) {
    String orderKey = _getOrderItemKey(salesOrder);

    if (modifiedQuantities.containsKey(orderKey) &&
        modifiedQuantities[orderKey]!.containsKey(index)) {
      modifiedQuantities[orderKey]!.remove(index);
      modifiedAmounts[orderKey]!.remove(index);

      // Remove from increased/decreased items
      _removeFromModifiedLists(salesOrder, index);

      notifyListeners();
    }
  }

  // Helper to update the increased/decreased items lists
  void _updateModifiedItemsList(
      SalesOrderDisplay salesOrder, int index, double newQty) {
    String itemName = salesOrder.varianceName[index];
    int originalQty = salesOrder.qty[index];
    double unitPrice = salesOrder.price[index];
    String uom = salesOrder.uom[index];

    // Calculate weight for Kg items
    double? weight;
    if (uom.toLowerCase() == 'kg' || uom.toLowerCase() == 'kgs') {
      weight = salesOrder.weight != null && salesOrder.weight!.length > index
          ? salesOrder.weight![index]
          : null;
    }

    // Create the item info map
    Map<String, dynamic> itemInfo = {
      'varianceName': itemName,
      'originalQuantity': originalQty,
      'quantity': newQty,
      'uom': uom,
      'price': unitPrice,
      'amount': newQty * unitPrice,
      'originalAmount': originalQty * unitPrice,
    };

    if (weight != null) {
      itemInfo['weight'] = weight;
    }

    // Remove from both lists first
    _removeFromModifiedLists(salesOrder, index);

    // Add to appropriate list
    if (newQty > originalQty) {
      increasedItems.add(itemInfo);
    } else if (newQty < originalQty) {
      decreasedItems.add(itemInfo);
    }
  }

  // Helper to remove item from increased/decreased lists
  void _removeFromModifiedLists(SalesOrderDisplay salesOrder, int index) {
    String itemName = salesOrder.varianceName[index];

    increasedItems.removeWhere((item) =>
        item['varianceName'] == itemName &&
        item['originalQuantity'] == salesOrder.qty[index]);

    decreasedItems.removeWhere((item) =>
        item['varianceName'] == itemName &&
        item['originalQuantity'] == salesOrder.qty[index]);
  }

  void addToIncreasedItems(
    SalesOrderDisplay order,
    int index,
    double newQty,
  ) {
    final item = _createItemMap(order, index, newQty);

    // Remove from decreased if exists
    decreasedItems.removeWhere((i) =>
        i['varianceName'] == item['varianceName'] &&
        i['salesOrderId'] == item['salesOrderId']);

    increasedItems.add(item);
    notifyListeners();
  }

  void addToDecreasedItems(
    SalesOrderDisplay order,
    int index,
    double newQty,
  ) {
    final item = _createItemMap(order, index, newQty);

    // Remove from increased if exists
    increasedItems.removeWhere((i) =>
        i['varianceName'] == item['varianceName'] &&
        i['salesOrderId'] == item['salesOrderId']);

    decreasedItems.add(item);
    notifyListeners();
  }

  Map<String, dynamic> _createItemMap(
    SalesOrderDisplay order,
    int index,
    double newQty,
  ) {
    return {
      'salesOrderId': order.salesOrderId,
      'varianceName': order.varianceName[index],
      'originalQty': order.qty[index],
      'newQty': newQty,
      'price': order.price[index],
      'uom': order.uom[index],
      'amount': (newQty - order.qty[index]) * order.price[index],
    };
  }

  void updateIncreasedItems(
    SalesOrderDisplay order,
    int index,
    double newQty,
  ) {
    final itemIndex = increasedItems.indexWhere((i) =>
        i['varianceName'] == order.varianceName[index] &&
        i['salesOrderId'] == order.salesOrderId);

    if (itemIndex != -1) {
      increasedItems[itemIndex]['newQty'] = newQty;
      increasedItems[itemIndex]['amount'] =
          (newQty - order.qty[index]) * order.price[index];
      notifyListeners();
    }
  }

  void updateDecreasedItems(
    SalesOrderDisplay order,
    int index,
    double newQty,
  ) {
    final itemIndex = decreasedItems.indexWhere((i) =>
        i['varianceName'] == order.varianceName[index] &&
        i['salesOrderId'] == order.salesOrderId);

    if (itemIndex != -1) {
      decreasedItems[itemIndex]['newQty'] = newQty;
      decreasedItems[itemIndex]['amount'] =
          (order.qty[index] - newQty) * order.price[index];
      notifyListeners();
    }
  }

  void updateItemInOrder(
      Map<String, dynamic> item, double difference, int originalIndex) {
    print(
        "🔹 updateItemInOrder called with difference: $difference and original index: $originalIndex");

    bool isKgUnit = item['varianceUom']?.toLowerCase() == 'kg' ||
        item['varianceUom']?.toLowerCase() == 'kgs';

    // Check if this item is already tracked in modifications
    int modifiedIndex = _findItemInModifications(item['varianceName']);

    if (modifiedIndex != -1) {
      // Item already exists in modifications, update it
      _updateExistingModification(modifiedIndex, difference, isKgUnit);
    } else {
      // Create a new modification entry
      _createNewModification(item, difference, isKgUnit);
    }

    // Update order total calculations
    _recalculateOrderTotals();

    notifyListeners();
  }

// Helper method to find an item in both modification lists
  int _findItemInModifications(String varianceName) {
    // Check in increased items
    int increasedIndex = increasedItems
        .indexWhere((element) => element['varianceName'] == varianceName);

    if (increasedIndex != -1) {
      return increasedIndex;
    }

    // Check in decreased items
    int decreasedIndex = decreasedItems
        .indexWhere((element) => element['varianceName'] == varianceName);

    if (decreasedIndex != -1) {
      return -(decreasedIndex +
          1); // Use negative index to indicate it's in decreasedItems
    }

    return -1; // Not found in either list
  }

// Helper method to update an existing modification
  // void _updateExistingModification(
  //     int modifiedIndex, double difference, bool isKgUnit) {
  //   // Determine if the item is in the increased or decreased list
  //   bool isInIncreasedList = modifiedIndex >= 0;
  //   List<Map<String, dynamic>> targetList =
  //       isInIncreasedList ? increasedItems : decreasedItems;

  //   // Convert negative index for decreased items
  //   int actualIndex = isInIncreasedList ? modifiedIndex : (-modifiedIndex - 1);

  //   // Get the current item
  //   Map<String, dynamic> existingItem = targetList[actualIndex];

  //   // Update quantity or weight
  //   if (isKgUnit) {
  //     double currentWeight = existingItem['weight'] ?? 0.0;
  //     double newWeight = currentWeight + difference;

  //     // If new weight becomes negative or zero, handle appropriately
  //     if (newWeight <= 0 && isInIncreasedList) {
  //       // Move from increased to decreased
  //       targetList.removeAt(actualIndex);
  //       if (newWeight < 0) {
  //         existingItem['weight'] = -newWeight;
  //         decreasedItems.add(existingItem);
  //       }
  //     } else if (newWeight >= 0 && !isInIncreasedList) {
  //       // Move from decreased to increased
  //       targetList.removeAt(actualIndex);
  //       if (newWeight > 0) {
  //         existingItem['weight'] = newWeight;
  //         increasedItems.add(existingItem);
  //       }
  //     } else {
  //       // Just update the weight
  //       existingItem['weight'] = isInIncreasedList ? newWeight : -newWeight;
  //     }

  //     // Recalculate amount
  //     if (existingItem['weight'] > 0) {
  //       existingItem['amount'] = existingItem['price'] * existingItem['weight'];
  //     }
  //   } else {
  //     // Similar logic for non-kg items using quantity
  //     double currentQty = existingItem['quantity'] ?? 0.0;
  //     double newQty = currentQty + difference;

  //     if (newQty <= 0 && isInIncreasedList) {
  //       targetList.removeAt(actualIndex);
  //       if (newQty < 0) {
  //         existingItem['quantity'] = -newQty;
  //         decreasedItems.add(existingItem);
  //       }
  //     } else if (newQty >= 0 && !isInIncreasedList) {
  //       targetList.removeAt(actualIndex);
  //       if (newQty > 0) {
  //         existingItem['quantity'] = newQty;
  //         increasedItems.add(existingItem);
  //       }
  //     } else {
  //       existingItem['quantity'] = isInIncreasedList ? newQty : -newQty;
  //     }

  //     // Recalculate amount
  //     if (existingItem['quantity'] > 0) {
  //       existingItem['amount'] =
  //           existingItem['price'] * existingItem['quantity'];
  //     }
  //   }
  // }

  void _updateExistingModification(
      int modifiedIndex, double difference, bool isKgUnit) {
    // Determine which list the item is in and get actual index
    bool isInIncreased = modifiedIndex >= 0;
    List<Map<String, dynamic>> currentList =
        isInIncreased ? increasedItems : decreasedItems;
    int actualIndex = isInIncreased ? modifiedIndex : (-modifiedIndex - 1);

    Map<String, dynamic> existingItem = currentList[actualIndex];
    double currentValue = isKgUnit
        ? (existingItem['weight'] ?? 0.0)
        : (existingItem['quantity'] ?? 0.0);

    // Always add to the existing modification
    double newValue = currentValue + difference;

    if (isInIncreased) {
      if (newValue <= 0) {
        // Move from increased to decreased if crossing zero
        currentList.removeAt(actualIndex);
        if (newValue < 0) {
          _addToDecreased(existingItem, -newValue, isKgUnit);
        }
      } else {
        // Update existing increased item
        _updateItemValue(existingItem, newValue, isKgUnit);
      }
    } else {
      if (newValue <= 0) {
        // Remove if decrease is canceled
        currentList.removeAt(actualIndex);
      } else {
        // Update existing decreased item
        _updateItemValue(existingItem, newValue, isKgUnit);
      }
    }

    // Cleanup zero values
    increasedItems.removeWhere(
        (item) => (isKgUnit ? item['weight'] : item['quantity']) <= 0);
    decreasedItems.removeWhere(
        (item) => (isKgUnit ? item['weight'] : item['quantity']) <= 0);

    _recalculateOrderTotals();
    notifyListeners();
  }

  void _addToDecreased(Map<String, dynamic> item, double value, bool isKgUnit) {
    decreasedItems.add({
      ...item,
      'weight': isKgUnit ? value : null,
      'quantity': !isKgUnit ? value : null,
      'amount': item['price'] * value,
    });
  }

  void _updateItemValue(
      Map<String, dynamic> item, double newValue, bool isKgUnit) {
    if (isKgUnit) {
      item['weight'] = newValue;
    } else {
      item['quantity'] = newValue;
    }
    item['amount'] = item['price'] * newValue;
  }
  // List<Map<String, dynamic>> removedItems = [];

  // void updateItemInOrder(Map<String, dynamic> item, double delta, int index) {
  //   final isKg = item['varianceUom'].toLowerCase() == 'kg' ||
  //       item['varianceUom'].toLowerCase() == 'kgs';
  //   final originalQty =
  //       isKg ? item['existingWeight'] : item['existingQuantity'];
  //   final price = item['variancePrice'];
  //   final varianceName = item['varianceName'];

  //   if (delta > 0) {
  //     // Handle increases... (keep previous implementation)
  //   } else if (delta < 0) {
  //     double remainingDelta = delta.abs();

  //     // 1. First offset any existing increases
  //     final increasedIndex =
  //         increasedItems.indexWhere((e) => e['varianceName'] == varianceName);

  //     if (increasedIndex != -1) {
  //       final currentIncrease =
  //           increasedItems[increasedIndex]['quantity'] ?? 0.0;
  //       final reduction = math.min(currentIncrease as double, remainingDelta);

  //       increasedItems[increasedIndex]['quantity'] =
  //           currentIncrease - reduction;
  //       increasedItems[increasedIndex]['amount'] =
  //           (currentIncrease - reduction) * price;

  //       remainingDelta -= reduction;

  //       if (increasedItems[increasedIndex]['quantity'] <= 0) {
  //         increasedItems.removeAt(increasedIndex);
  //       }
  //     }

  //     // 2. Handle remaining decrease
  //     if (remainingDelta > 0) {
  //       final decreasedIndex =
  //           decreasedItems.indexWhere((e) => e['varianceName'] == varianceName);

  //       double existingDecrease = 0.0;
  //       if (decreasedIndex != -1) {
  //         existingDecrease = decreasedItems[decreasedIndex]['quantity'] ?? 0.0;
  //       }

  //       // Calculate maximum possible decrease
  //       final maxDecrease = originalQty - existingDecrease;
  //       final appliedDelta = math.min(maxDecrease as double, remainingDelta);

  //       if (appliedDelta > 0) {
  //         final newTotalDecrease = existingDecrease + appliedDelta;

  //         // Check if item should be completely removed
  //         if (newTotalDecrease >= originalQty) {
  //           removedItems.add(item);
  //           if (decreasedIndex != -1) {
  //             decreasedItems.removeAt(decreasedIndex);
  //           }
  //         } else {
  //           if (decreasedIndex != -1) {
  //             // Update existing decrease
  //             decreasedItems[decreasedIndex]['quantity'] = newTotalDecrease;
  //             decreasedItems[decreasedIndex]['amount'] =
  //                 newTotalDecrease * price;
  //           } else {
  //             // Add new decrease
  //             decreasedItems.add({
  //               ...item,
  //               'quantity': appliedDelta,
  //               'amount': appliedDelta * price,
  //               'originalQuantity': originalQty,
  //               'modifiedType': 'decrease',
  //             });
  //           }
  //         }
  //       }
  //     }
  //   }

  //   notifyListeners();
  // }

// Helper method to create a new modification entry
  void _createNewModification(
      Map<String, dynamic> item, double difference, bool isKgUnit) {
    // Determine if this is an increase or decrease
    bool isIncrease = difference > 0;
    List<Map<String, dynamic>> targetList =
        isIncrease ? increasedItems : decreasedItems;

    Map<String, dynamic> newItem = {
      'varianceName': item['varianceName'],
      'itemName': item['itemName'],
      'quantity': isKgUnit
          ? 1.0
          : isIncrease
              ? difference
              : -difference,
      'weight': isKgUnit ? (isIncrease ? difference : -difference) : 0,
      'uom': item['varianceUom'],
      'price': item['variancePrice'],
      'tax': item['variancetax'] ?? 0,
      'itemCode': item['varianceitemCode'],
      'amount': item['variancePrice'] *
          (isKgUnit
              ? (isIncrease ? difference : -difference)
              : (isIncrease ? difference : -difference)),
      'originalQuantity': item['existingQuantity'],
      'originalWeight': item['existingWeight'],
      'originalAmount': item['existingAmount'],
    };

    targetList.add(newItem);
  }

// Helper method to recalculate order totals
  void _recalculateOrderTotals() {
    // Implement total calculations based on your business logic
    // This might include subtotals, taxes, etc.
  }
}
