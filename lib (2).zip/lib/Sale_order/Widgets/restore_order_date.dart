import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart'; // for safer date formatting
import 'package:yenpos/Global/Widget/scaffold_global.dart';
import 'package:yenpos/Sale_order/Models/held_order_model.dart';
import 'package:yenpos/Sale_order/Provider/cartProvider.dart';
import 'package:yenpos/Sale_order/Provider/customerScreen_provider.dart';
import 'package:yenpos/Sale_order/Provider/detailsProvider.dart';

bool _isRestoringHeldOrder = false;

Future<void> restoreHeldOrderData(BuildContext context, HeldOrder order) async {
  if (_isRestoringHeldOrder) return;
  _isRestoringHeldOrder = true;

  try {
    // ---------------------- GET PROVIDERS ----------------------
    final customerScreenProvider = Provider.of<CustomerScreenProvider>(
      context,
      listen: false,
    );
    final cartProvider = Provider.of<CartProvider>(context, listen: false);
    final detailsProvider = Provider.of<DetailsProvider>(
      context,
      listen: false,
    );

    // ---------------------- RESET CONTROLLERS ----------------------
    customerScreenProvider.resetControllers();

    // ---------------------- RESTORE CUSTOMER DETAILS ----------------------
    if (order.deliveryDate != null && order.deliveryDate!.isNotEmpty) {
      try {
        DateTime parsedDate = DateTime.parse(order.deliveryDate!).toLocal();
        customerScreenProvider.dateController.text = DateFormat(
          'dd-MM-yyyy',
        ).format(parsedDate);
        customerScreenProvider.timeController.text = DateFormat(
          'hh:mm a',
        ).format(parsedDate);
      } catch (_) {
        customerScreenProvider.dateController.text = '';
        customerScreenProvider.timeController.text = '';
      }
    }

    if (order.eventDate != null && order.eventDate!.isNotEmpty) {
      try {
        DateTime parsedEventDate = DateTime.parse(order.eventDate!).toLocal();
        customerScreenProvider.birthdaydateController.text = DateFormat(
          'dd-MM-yyyy',
        ).format(parsedEventDate);
      } catch (_) {
        customerScreenProvider.birthdaydateController.text = '';
      }
    }

    customerScreenProvider.setSelectedEvent(order.event);
    customerScreenProvider.setSelectedDeliveryType(order.deliveryType);
    customerScreenProvider.landmarkController.text = order.landmark ?? '';
    customerScreenProvider.addressController.text = order.address ?? '';
    customerScreenProvider.remarkController.text = order.remark ?? '';
    customerScreenProvider.patchHoldOrderId = order.holdOrderId ?? '';
    customerScreenProvider.setSelectedHoldOrderId(order.holdOrderId);

    customerScreenProvider.customerNameController.text =
        order.customerName ?? '';
    customerScreenProvider.mobileNoController.text = order.customerNumber ?? '';
    customerScreenProvider.customerCombinedController.text =
        "${order.customerNumber ?? ''} - ${order.customerName ?? ''}";
    customerScreenProvider.searchController.text = order.employeeName ?? '';

    customerScreenProvider.selectedChargeType = order.customChargeType;
    customerScreenProvider.customChargeController.text =
        order.customCharge?.toString() ?? '';

    // ---------------------- RESTORE CART ITEMS ----------------------
    cartProvider.clearCart();

    // Determine minimum length of all lists to avoid RangeError
    int itemCount = [
      order.itemName.length,
      order.varianceName.length,
      order.itemCode.length,
      order.uom.length,
      order.qty.length,
      order.weight.length,
      order.price.length,
      order.tax.length,
      order.itemWiseDiscount?.length ?? order.itemName.length,
      order.itemWiseDiscountAmount?.length ?? order.itemName.length,
    ].reduce((a, b) => a < b ? a : b);

    for (int i = 0; i < itemCount; i++) {
      cartProvider.addItemToCart(
        CartItem(
          itemName: order.itemName[i],
          varianceName: order.varianceName[i],
          itemCode: order.itemCode[i],
          uom: order.uom[i],
          quantity: order.qty[i],
          weight: order.weight[i],
          pricePerKg: order.price[i],
          tax: order.tax[i],
          itemWiseDiscount: order.itemWiseDiscount?[i] ?? 0,
          itemWiseDiscountAmount: order.itemWiseDiscountAmount?[i] ?? 0,
          boxQuantity: order.boxQty,
        ),
      );
    }

    cartProvider.updateCart();

    // ---------------------- SHOW SUCCESS ----------------------
    GlobalScaffold.showMessage(
      message: 'Held order restored successfully',
      backgroundColor: Colors.green,
      textColor: Colors.white,
    );
  } catch (e, stack) {
    print("Error restoring held order: $e\n$stack");
    GlobalScaffold.showMessage(
      message: 'Failed to restore held order',
      backgroundColor: Colors.red,
      textColor: Colors.white,
    );
  } finally {
    _isRestoringHeldOrder = false;
  }
}
