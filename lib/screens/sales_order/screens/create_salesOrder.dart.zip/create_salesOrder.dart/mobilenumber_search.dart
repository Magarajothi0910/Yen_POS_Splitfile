import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../sales_order_providers/customerScreen_provider.dart';
import '../../sales_order_providers/customer_search_provider.dart';

class CustomerSearchDropdown extends StatefulWidget {
  const CustomerSearchDropdown({Key? key}) : super(key: key);

  @override
  _CustomerSearchDropdownState createState() => _CustomerSearchDropdownState();
}

class _CustomerSearchDropdownState extends State<CustomerSearchDropdown> {
  // final TextEditingController mobileNoController = TextEditingController();
  // final TextEditingController customerNameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _mobileFocusNode.addListener(() {
      if (!_mobileFocusNode.hasFocus) {
        _removeSuggestionsOverlay();
      }
    });
  }

  final FocusNode _mobileFocusNode = FocusNode();
  final LayerLink _layerLink = LayerLink();
  OverlayEntry? _overlayEntry;

  void _onMobileNumberChanged(String value) {
    final provider = context.read<CustomerSearchProvider>();
    provider.fetchSuggestions(value);

    // Show overlay when typing
    if (value.isNotEmpty) {
      // _showSuggestionsOverlay();
    } else {
      _removeSuggestionsOverlay();
    }
  }

  void _showSuggestionsOverlay() {
    _removeSuggestionsOverlay();
    _overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(_overlayEntry!);
  }

  void _removeSuggestionsOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  OverlayEntry _createOverlayEntry() {
    final customerProvider =
        Provider.of<CustomerScreenProvider>(context, listen: false);
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;

    return OverlayEntry(
      builder: (context) => Positioned(
        width: size.width,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(0, size.height + 5.0),
          child: Consumer<CustomerSearchProvider>(
            builder: (context, provider, child) {
              return Material(
                elevation: 8.0,
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue.shade100.withOpacity(0.8),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  constraints: const BoxConstraints(maxHeight: 300),
                  child: ListView.builder(
                    padding: EdgeInsets.zero,
                    itemCount: provider.suggestions.length + 1,
                    itemBuilder: (context, index) {
                      if (index < provider.suggestions.length) {
                        final suggestion = provider.suggestions[index];
                        return ListTile(
                          title:
                              Text(suggestion['mobileNo'] ?? 'Unknown Mobile'),
                          subtitle: Text(suggestion['name'] ?? 'Unknown Name'),
                          onTap: () {
                            _onSuggestionSelected(suggestion, customerProvider);
                            _removeSuggestionsOverlay();
                          },
                        );
                      }
                      return ListTile(
                        leading: const Icon(Icons.add, color: Colors.green),
                        title: const Text('Add Customer Details'),
                        onTap: () {
                          _showAddCustomerDialog(customerProvider);
                          _removeSuggestionsOverlay();
                        },
                      );
                    },
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  void _onSuggestionSelected(Map<String, dynamic> suggestion,
      CustomerScreenProvider customerProvider) {
    customerProvider.mobileNoController.text = suggestion['mobileNo'] ?? '';
    customerProvider.customerNameController.text = suggestion['name'] ?? '';
    FocusScope.of(context).unfocus();
  }

  void _showAddCustomerDialog(CustomerScreenProvider customerProvider) {
    final TextEditingController mobileController =
        TextEditingController(text: customerProvider.mobileNoController.text);
    final TextEditingController nameController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          title: const Row(
            children: [
              Icon(Icons.person_add, color: Colors.blue),
              SizedBox(width: 8),
              Text(
                'Add Customer',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: mobileController,
                  keyboardType: TextInputType.phone,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(10),
                  ],
                  decoration: InputDecoration(
                    labelText: 'Mobile Number',
                    prefixText: '+91 ',
                    prefixStyle: const TextStyle(color: Colors.black),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: nameController,
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(24),
                    FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z ]*$')),
                  ],
                  decoration: InputDecoration(
                    labelText: 'Customer Name',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                'Cancel',
                style:
                    TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                print('Adding customer...');
                final String mobile = mobileController.text.trim();
                final String name = nameController.text.trim();

                if (mobile.length == 10 &&
                    RegExp(r'^\d+$').hasMatch(mobile) &&
                    name.isNotEmpty) {
                  await customerProvider.sendNewCustomer(mobile, name);
                  final bool ok =
                      true; // Assume success or handle differently if needed

                  if (ok) {
                    // Populate the UI fields
                    customerProvider.mobileNoController.text = mobile;
                    customerProvider.customerNameController.text = name;

                    // UI feedback
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Customer “$name” added successfully!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                    Navigator.pop(context);
                  }
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content:
                          Text('Please enter a valid mobile number and name.'),
                      backgroundColor: Colors.orange,
                    ),
                  );
                }
              },
              child: const Text('Submit'),
            )
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    // mobileNoController.dispose();
    // customerNameController.dispose();
    _mobileFocusNode.dispose();
    _overlayEntry?.remove();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final customerProvider =
        Provider.of<CustomerScreenProvider>(context, listen: false);
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        _removeSuggestionsOverlay();
      },
      child: Column(
        children: [
          Row(
            children: [
              const Padding(padding: EdgeInsets.all(5)),
              Expanded(
                child: CompositedTransformTarget(
                  link: _layerLink,
                  child: TextFormField(
                    controller: customerProvider.mobileNoController,
                    focusNode: _mobileFocusNode,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(10),
                    ],
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: 'Customer Mobile Number',
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      isDense: false,
                    ),
                    style: TextStyle(fontSize: 14),
                    onChanged: _onMobileNumberChanged,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextFormField(
                  enabled: false,
                  controller: customerProvider.customerNameController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    // contentPadding:
                    //     EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    labelText: 'Customer Name',
                    isDense: false,
                  ),
                  style: TextStyle(fontSize: 14),
                ),
              ),
              const Padding(padding: EdgeInsets.all(5)),
            ],
          ),
        ],
      ),
    );
  }
}
