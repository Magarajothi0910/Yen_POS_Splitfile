import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:yen_pos/Global/globals_data.dart';
import 'package:yen_pos/Sale_order/Widgets/Send_data_to_server.dart';
import 'package:yen_pos/Server_Client/sendDataToClients.dart';
import 'package:yen_pos/main.dart';

Future<void> sendApprove(
  BuildContext context,
  List<dynamic> ordersForSeat,
  String tableNumber,
  String seat,
) async {
  // Show your approval dialog here
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Approval Required'),
      content: const Text('Do you want to approve canceling this order?'),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: const Text('No'),
        ),
        ElevatedButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          child: const Text('Send Approve'),
        ),
      ],
    ),
  );

  if (result == true) {
    final approvePayload = {
      'type': 'approveCancelOrder',
      'status': 'pending',
      'tableNumber': tableNumber,
      'seat': seat,
      'orders': ordersForSeat,
    };
    sendataToServer(approvePayload);
  } else {}
}

Future<void> handleApproveCancelOrder(
  Map<String, dynamic> data,
  Set<WebSocketChannel> clients,
) async {
  try {
    debugPrint("handleApproveCancelOrder data ::$data");
    final packageInfo = await PackageInfo.fromPlatform();

    final approveTable = data['tableNumber'];
    final approveSeat = data['seat'];
    final approveStatus = data['status'];
    final approveOrders = data['orders'];
    final seathiveOrderId = data['orders'][0]['seathiveOrderId'];

    final key = '${approveTable}_${approveSeat}_$seathiveOrderId';

    final HiveData = {
      'tableNumber': approveTable,
      'seat': approveSeat,
      'status': approveStatus,
      'seathiveOrderId': seathiveOrderId,
    };
    final box = await Hive.openBox('approvelOrdersKOT');
    await box.put(key, HiveData);

    // if (appType != "server") {
    //   debugPrint(
    //     "Cancel order approved for Table: $approveTable, appType: $appType",
    //   );
    //   showApproveDialog(
    //     table: approveTable,
    //     seat: approveSeat,
    //     orders: approveOrders,
    //     status: approveStatus,
    //   );
    // }

    final ApproveData = {
      'action': 'approveCancelOrder',
      'status': 'pending',
      'tableNumber': approveTable,
      'seat': approveSeat,
      'orders': data['orders'],
    };
    if (appType == "server") sendDataToClients(ApproveData, clients);
  } catch (e) {
    debugPrint("handleApproveCancelOrder :: $e");
  }
}

void showApproveDialog({
  required String table,
  required String seat,
  required String status,
  required List<dynamic> orders,
}) {
  final context = MyApp.navigatorKey.currentContext;
  if (context == null) return;

  final order = orders.first; // assuming single order per request

  showDialog(
    context: context,
    barrierDismissible: true,
    builder: (_) => AlertDialog(
      title: Row(
        children: const [
          Icon(Icons.info, color: Colors.blue),
          SizedBox(width: 8),
          Text('Cancel Order Approval'),
        ],
      ),
      content: SizedBox(
        width: MediaQuery.of(context).size.width * 0.5,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 🔹 Info text
              Text(
                'Cancel order approval request for Table $table, Seat $seat.',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 12),

              const Divider(),

              // 🔹 Order details header
              Text(
                'Order Details - $status',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),

              // 🔹 Item list
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: order['itemNames'].length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            order['itemNames'][index],
                            style: const TextStyle(fontWeight: FontWeight.w500),
                          ),
                        ),
                        Text('x${order['quantities'][index]}'),
                        const SizedBox(width: 10),
                        Text(
                          '₹${order['amounts'][index]}',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  );
                },
              ),

              const Divider(),

              // 🔹 Total amount
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'Total: ₹${order['totalAmount']}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
            sendataToServer({
              'type': 'cancelOrderApprovalResponse',
              'status': 'declined',
              'tableNumber': table,
              'seat': seat,
              'orders': orders,
            });
          },
          child: const Text('Decline', style: TextStyle(color: Colors.red)),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.of(context).pop();
            sendataToServer({
              'type': 'cancelOrderApprovalResponse',
              'status': 'approved',
              'tableNumber': table,
              'seat': seat,
              'orders': orders,
            });
          },
          child: const Text('Approve'),
        ),
      ],
    ),
  );
}
