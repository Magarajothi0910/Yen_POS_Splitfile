import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:yenpos/Global/globals_data.dart';
import 'package:yenpos/Hive_Manager/hive_manager_saleOrder.dart';
import 'package:yenpos/Sale_order/Provider/customerScreen_provider.dart';
import 'package:yenpos/Sale_order/Provider/customer_search_provider.dart';

// DialogStateProvider class must be defined or imported
class DialogStateProvider extends ChangeNotifier {
  bool _isPlacingOrder = false;
  bool _isHoldingOrder = false;

  bool get isPlacingOrder => _isPlacingOrder;
  bool get isHoldingOrder => _isHoldingOrder;

  void setPlacingOrder(bool value) {
    _isPlacingOrder = value;
    notifyListeners();
  }

  void setHoldingOrder(bool value) {
    _isHoldingOrder = value;
    notifyListeners();
  }

  void resetAll() {
    _isPlacingOrder = false;
    _isHoldingOrder = false;
    notifyListeners();
  }
}

class CustomerSearchDropdown extends StatefulWidget {
  const CustomerSearchDropdown({Key? key}) : super(key: key);

  @override
  _CustomerSearchDropdownState createState() => _CustomerSearchDropdownState();
}

class _CustomerSearchDropdownState extends State<CustomerSearchDropdown> {
  // Controllers and nodes
  final FocusNode _mobileFocusNode = FocusNode();
  final LayerLink _layerLink = LayerLink();

  // Overlay
  OverlayEntry? _overlayEntry;

  // State flags
  bool _isAddingCustomer = false;
  bool _dialogShown = false;
  bool _userInteracted = false;

  // Data
  String _lastProcessedMobile = '';
  bool _justAddedCustomer = false;
  String? _justAddedMobile;

  // Timer for debouncing
  Timer? _debounceTimer;

  // Provider references - initialized in build method
  late CustomerScreenProvider _customerProvider;
  late CustomerSearchProvider _searchProvider;
  late DialogStateProvider _dialogStateProvider;
  bool _providersInitialized = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Initialize providers in next frame
      if (mounted) {
        setState(() {
          _initializeProviders();
          _setupControllerListeners();
          _searchProvider.refreshCustomersFromHive();
        });
      }
    });
  }

  void _initializeProviders() {
    _customerProvider = context.read<CustomerScreenProvider>();
    _searchProvider = context.read<CustomerSearchProvider>();
    _dialogStateProvider = context.read<DialogStateProvider>();
    _providersInitialized = true;

    // Initialize combined controller
    _updateCombinedController();
  }

  void _setupControllerListeners() {
    _updateCombinedController();
    _customerProvider.customerCombinedController.addListener(
      _combinedControllerListener,
    );
  }

  void _combinedControllerListener() {
    // Skip if blocked by order operations
    if (_dialogStateProvider.isPlacingOrder ||
        _dialogStateProvider.isHoldingOrder ||
        _customerProvider.isRestoringOrder) {
      return;
    }

    _onMobileNumberChanged(_customerProvider.customerCombinedController.text);
  }

  void _onMobileNumberChanged(String value) {
    // Debounce input to prevent rapid consecutive calls
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 300), () {
      _processMobileNumberChange(value);
    });
  }

  void _processMobileNumberChange(String value) {
    // Early exit conditions
    if (!_userInteracted ||
        _isAddingCustomer ||
        _dialogShown ||
        _customerProvider.isRestoringOrder ||
        _dialogStateProvider.isPlacingOrder ||
        _dialogStateProvider.isHoldingOrder) {
      return;
    }

    final mobile = _extractMobileNumber(value);
    _customerProvider.mobileNoController.text = mobile;

    if (mobile.isEmpty) {
      _clearSuggestions();
      return;
    }

    if (mobile == _lastProcessedMobile) return;

    _lastProcessedMobile = mobile;
    _handleMobileNumberLogic(mobile);
  }

  String _extractMobileNumber(String value) {
    return value.split(' - ').first.replaceAll(RegExp(r'[^0-9]'), '');
  }

  Future<void> _handleMobileNumberLogic(String mobile) async {
    await _searchProvider.fetchSuggestions(mobile);

    if (_searchProvider.suggestions.isNotEmpty) {
      _showSuggestionsOverlay();
      return;
    }

    if (mobile.length != 10) {
      _removeSuggestionsOverlay();
      return;
    }

    // Final safety check
    if (_dialogStateProvider.isPlacingOrder ||
        _dialogStateProvider.isHoldingOrder) {
      return;
    }

    _isAddingCustomer = true;
    _dialogShown = true;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;

      if (_dialogStateProvider.isPlacingOrder ||
          _dialogStateProvider.isHoldingOrder) {
        _resetDialogFlags();
        return;
      }

      await _showAddCustomerDialog(mobile);
      _resetDialogFlags();
    });
  }

  void _resetDialogFlags() {
    _isAddingCustomer = false;
    _dialogShown = false;
  }

  void _updateCombinedController() {
    final mobile = _customerProvider.mobileNoController.text;
    final name = _customerProvider.customerNameController.text;
    _customerProvider.customerCombinedController.text =
        (mobile.isNotEmpty && name.isNotEmpty)
        ? '$mobile - $name'
        : mobile.isNotEmpty
        ? mobile
        : '';
  }

  // Overlay Management
  void _showSuggestionsOverlay() {
    _removeSuggestionsOverlay();
    _overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(_overlayEntry!);
  }

  void _removeSuggestionsOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  OverlayEntry _createOverlayEntry() {
    final renderBox = context.findRenderObject() as RenderBox;
    final size = renderBox.size;

    return OverlayEntry(
      builder: (context) => Positioned(
        width: size.width,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(0, size.height + 5.0),
          child: _buildSuggestionsList(),
        ),
      ),
    );
  }

  Widget _buildSuggestionsList() {
    return Material(
      elevation: 8.0,
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.blue.shade100.withOpacity(0.8),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        constraints: const BoxConstraints(maxHeight: 180),
        child: Consumer<CustomerSearchProvider>(
          builder: (context, provider, child) {
            return ListView.builder(
              padding: EdgeInsets.zero,
              itemCount: provider.suggestions.length,
              itemBuilder: (context, index) {
                final suggestion = provider.suggestions[index];
                return ListTile(
                  title: Text(suggestion['mobile'] ?? 'Unknown Mobile'),
                  subtitle: Text(suggestion['name'] ?? 'Unknown Name'),
                  onTap: () => _onSuggestionSelected(suggestion),
                );
              },
            );
          },
        ),
      ),
    );
  }

  void _onSuggestionSelected(Map<String, dynamic> suggestion) {
    _removeSuggestionsOverlay();
    _searchProvider.clearSuggestions();

    // Temporarily remove listener to prevent loops
    _customerProvider.customerCombinedController.removeListener(
      _combinedControllerListener,
    );

    final mobile = suggestion['mobile'] ?? '';
    final name = suggestion['name'] ?? '';

    _customerProvider.mobileNoController.text = mobile;
    _customerProvider.customerNameController.text = name;
    _customerProvider.customerCombinedController.text = name.isNotEmpty
        ? '$mobile - $name'
        : mobile;

    // Restore listener
    _customerProvider.customerCombinedController.addListener(
      _combinedControllerListener,
    );

    FocusScope.of(context).unfocus();
  }

  void _clearSuggestions() {
    _removeSuggestionsOverlay();
    _dialogShown = false;
    _lastProcessedMobile = '';
  }

  // API & Hive Operations
  Future<bool> _checkCustomerExists(String mobile) async {
    // Check Hive first
    try {
      final box = HiveManager.customers;
      final existsInHive = box.values.any(
        (c) => c['mobile']?.toString() == mobile,
      );
      if (existsInHive) return true;
    } catch (e) {
      // Continue to API check
    }

    // Check API
    try {
      final uri = Uri.parse(
        "https://yenerp.com/fluttertestapi/customers/by-customer?customerPhoneNumber=$mobile",
      );
      final response = await http.get(uri);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data is List) return data.isNotEmpty;
        if (data is Map) return data.isNotEmpty;
      }
    } catch (e) {
      // API call failed
    }

    return false;
  }

  String _generateCustId() {
    final random = Random();
    return "CUST${random.nextInt(999999).toString().padLeft(6, '0')}";
  }

  // Dialog Methods
  Future<void> _showAddCustomerDialog(String currentMobile) async {
    if (_dialogStateProvider.isPlacingOrder ||
        _dialogStateProvider.isHoldingOrder) {
      return;
    }

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => _AddCustomerDialog(
        currentMobile: currentMobile,
        onCustomerAdded: _handleNewCustomerAdded,
        checkCustomerExists: _checkCustomerExists,
        generateCustId: _generateCustId,
        customerProvider: _customerProvider,
      ),
    );
  }

  Future<void> _handleNewCustomerAdded(String mobile, String name) async {
    await _customerProvider.sendNewCustomer(mobile, name, context);

    _customerProvider.mobileNoController.text = mobile;
    _customerProvider.customerNameController.text = name;
    _updateCombinedController();

    setState(() {
      _justAddedCustomer = true;
      _justAddedMobile = mobile;
      _lastProcessedMobile = '';
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Customer "$name" added successfully!'),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    _mobileFocusNode.dispose();
    _customerProvider.customerCombinedController.removeListener(
      _combinedControllerListener,
    );
    _overlayEntry?.remove();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Initialize providers if not already done
    if (_customerProvider == null) {
      _initializeProviders();
    }

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        _removeSuggestionsOverlay();
      },
      child: Column(
        children: [
          CompositedTransformTarget(
            link: _layerLink,
            child: _buildCustomerTextField(),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerTextField() {
    return TextField(
      readOnly: true,
      showCursor: true,
      controller: _customerProvider.customerCombinedController,
      focusNode: _mobileFocusNode,
      inputFormatters: [LengthLimitingTextInputFormatter(10)],
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        labelText: 'Customer MobileNo',
        suffixIcon: IconButton(
          icon: const Icon(Icons.close),
          onPressed: _clearCustomerField,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      ),
      style: const TextStyle(fontSize: 14),
      onChanged: _onMobileNumberChanged,
      onTap: _handleTextFieldTap,
    );
  }

  void _clearCustomerField() {
    if (_dialogStateProvider.isPlacingOrder ||
        _dialogStateProvider.isHoldingOrder) {
      return;
    }

    _userInteracted = false;
    _customerProvider.mobileNoController.clear();
    _customerProvider.customerNameController.clear();
    _customerProvider.customerCombinedController.clear();
    _removeSuggestionsOverlay();
    FocusScope.of(context).unfocus();
  }

  void _handleTextFieldTap() {
    _userInteracted = true;

    if (_dialogStateProvider.isPlacingOrder ||
        _dialogStateProvider.isHoldingOrder) {
      return;
    }

    ActiveField.activate(
      context: context,
      ctrl: _customerProvider.customerCombinedController,
      node: _mobileFocusNode,
      numeric: true,
      fieldType: "customer number",
    );
  }
}

// Extracted Dialog Widget
class _AddCustomerDialog extends StatefulWidget {
  final String currentMobile;
  final Function(String, String) onCustomerAdded;
  final Future<bool> Function(String) checkCustomerExists;
  final String Function() generateCustId;
  final CustomerScreenProvider customerProvider;

  const _AddCustomerDialog({
    required this.currentMobile,
    required this.onCustomerAdded,
    required this.checkCustomerExists,
    required this.generateCustId,
    required this.customerProvider,
  });

  @override
  _AddCustomerDialogState createState() => _AddCustomerDialogState();
}

class _AddCustomerDialogState extends State<_AddCustomerDialog> {
  late final TextEditingController _mobileController;
  late final TextEditingController _nameController;
  late final GlobalKey<FormState> _formKey;

  @override
  void initState() {
    super.initState();
    _mobileController = TextEditingController(text: widget.currentMobile);
    _nameController = TextEditingController(text: widget.generateCustId());
    _formKey = GlobalKey<FormState>();
  }

  @override
  void dispose() {
    _mobileController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 500, vertical: 40),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              blurRadius: 20,
              spreadRadius: 2,
              color: Colors.black.withOpacity(0.1),
            ),
          ],
        ),
        child: _buildDialogContent(),
      ),
    );
  }

  Widget _buildDialogContent() {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDialogHeader(),
          const SizedBox(height: 20),
          _buildMobileField(),
          const SizedBox(height: 16),
          _buildNameField(),
          const SizedBox(height: 24),
          _buildDialogActions(),
        ],
      ),
    );
  }

  Widget _buildDialogHeader() {
    return Row(
      children: const [
        Icon(Icons.person_add_alt_1, color: Colors.blue, size: 26),
        SizedBox(width: 10),
        Text(
          "Add Customer",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
      ],
    );
  }

  Widget _buildMobileField() {
    return TextFormField(
      controller: _mobileController,
      keyboardType: TextInputType.phone,
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
        LengthLimitingTextInputFormatter(10),
      ],
      decoration: InputDecoration(
        labelText: 'Mobile Number',
        prefixText: '+91 ',
        filled: true,
        fillColor: Colors.grey.shade100,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
      ),
      validator: _validateMobileNumber,
    );
  }

  String? _validateMobileNumber(String? value) {
    final trimmed = value?.trim() ?? '';
    if (trimmed.isEmpty) return 'Mobile number required';
    if (!RegExp(r'^[6-9]\d{9}$').hasMatch(trimmed)) {
      return 'Enter a valid 10-digit number';
    }
    return null;
  }

  Widget _buildNameField() {
    return TextFormField(
      controller: _nameController,
      inputFormatters: [
        LengthLimitingTextInputFormatter(24),
        FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z ]')),
      ],
      decoration: InputDecoration(
        labelText: 'Customer Name',
        filled: true,
        fillColor: Colors.grey.shade100,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
      ),
      onChanged: (_) => setState(() {}),
    );
  }

  Widget _buildDialogActions() {
    final isSubmitEnabled = _nameController.text.trim().isNotEmpty;

    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text(
            "Cancel",
            style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(width: 12),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: isSubmitEnabled ? Colors.blue : Colors.grey,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          onPressed: isSubmitEnabled ? _handleSubmit : null,
          child: const Text(
            "Submit",
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
      ],
    );
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    final mobile = _mobileController.text.trim();
    final name = _nameController.text.trim();

    final exists = await widget.checkCustomerExists(mobile);
    if (exists) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('This number already exists!'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    await widget.onCustomerAdded(mobile, name);
    Navigator.of(context).pop();
  }
}
