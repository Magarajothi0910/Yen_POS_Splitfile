import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../../../../services/websocketService.dart';
import '../../create_salesOrder.dart/models/held_order_model.dart';
import '../../model/sales_order_model.dart';
// import '../../model/sales_order_model.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

class ApiServiceSalesOrderProvider extends ChangeNotifier {
  ApiServiceSalesOrderProvider({required this.webSocketService}) {
    _fetchOrdersFromHive();
    _setupHiveListener();
    print('_fetchOrdersFromHive called');
  }
  Future<void> _fetchOrdersFromHive() async {
    print("══════════════════════════════════════════════════════════════");
    print("🛠️ Starting _fetchOrdersFromHive");
    try {
      // Step 1: Fetch sales orders from Hive
      print("\n🔍 Step 1: Fetching sales orders from Hive");
      final hiveOrders = await webSocketService.getSavedSalesOrders();
      print("✅ Raw Hive sales orders data:");
      print(hiveOrders);
      print("\n📦 Fetched ${hiveOrders.length} orders from Hive");

      List<SalesOrderDisplay> salesOrderData = [];
      if (hiveOrders.isNotEmpty) {
        print("\n🔄 Processing sales orders:");
        salesOrderData = hiveOrders.map((json) {
          print("\n📄 Raw JSON for order:");
          print(json);
          final order = SalesOrderDisplay.fromMap(json);
          print("🆔 Processed Order ID: ${order.salesOrderId}");
          print("📛 Order No: ${order.saleOrderNo}");
          print("📅 Order Date: ${order.orderDate}");
          print("🚚 Delivery Date: ${order.deliveryDate}");
          print("📦 isBoxItem: ${order.isBoxItem}");
          print("📊 Total Items: ${order.varianceName.length}");
          print("📦 isBoxItem list length: ${order.isBoxItem?.length ?? 0}");
          print("🔢 Box Items Details:");
          if (order.isBoxItem != null) {
            for (int i = 0; i < order.isBoxItem!.length; i++) {
              print("  Item $i: ${order.isBoxItem![i]}");
            }
          }
          print("----------------------------------------");
          return order;
        }).toList();

        print("\n🔎 Original status filter: 'Confirm Order'");

        _allSalesOrders = salesOrderData;

// Apply initial filter to _filteredAllSalesOrders
        _filteredAllSalesOrders = _allSalesOrders
            .where((order) => order.status == "Confirm Order")
            .toList()
            .reversed
            .toList();

        _originalSalesOrder = List.from(
            _filteredAllSalesOrders); // Store original filtered orders
        print('filterallsaledOrder$filteredAllSalesOrders');
        print('_allSalesOrders$_allSalesOrders');
      } else {
        print("❌ No sales orders found in Hive.");
      }

      // Step 2: Fetch modified orders from Hive
      print("\n🔍 Step 2: Fetching modified orders from Hive");
      final hiveModifiedOrders = await webSocketService.getModifyOrder();
      print("✅ Raw Hive modified orders data:");
      print(hiveModifiedOrders);
      print(
          "\n📦 Fetched ${hiveModifiedOrders.length} modified orders from Hive");

      if (hiveModifiedOrders.isNotEmpty) {
        _modifiedOrders = hiveModifiedOrders.map((entry) {
          print("\n📄 Raw modified order entry:");
          print(entry);
          final modOrder = ModifyOrder.fromJson(
              Map<String, dynamic>.from(entry)); // Pass entry directly
          print("🆔 Modified Order ID: ${modOrder.saleOrderNo}");
          print("📛 Ori ginal Order No: ${modOrder.saleOrderNo}");
          print("📋 Modified Items: ${modOrder.varianceName.length}");
          return modOrder;
        }).toList();

        // print("\n📋 Parsed _modifiedOrders:");
        // _modifiedOrders.forEach((modOrder) {
        //   print("\n🆔 Modified Order ID: ${modOrder.saleOrderNo}");
        //   print("📛 Linked to Order No: ${modOrder.saleOrderNo}");
        //   print("📋 Modified Items Count: ${modOrder.varianceName.length}");
        // });
      }
      // Step 3: Fetch to-approve orders from Hive
      print("\n🔍 Step 3: Fetching to-approve orders from Hive");
      final hiveToApproveOrders = await webSocketService.getToApproveOrder();
      print("✅ Raw Hive to-approve orders data:");
      print(hiveToApproveOrders);
      print(
          "\n📦 Fetched ${hiveToApproveOrders.length} to-approve orders from Hive");

      if (hiveToApproveOrders.isNotEmpty) {
        // _toApprove = hiveToApproveOrders
        //     .where((entry) => entry['data'] != null)
        //     .map((entry) {
        //   print("\n📄 Raw to-approve order entry:");
        //   print(entry);
        //   final approveOrder =
        //       ToApprove.fromJson(Map<String, dynamic>.from(entry['data']));

        //   return approveOrder;
        // }).toList();
        _toApprove = hiveToApproveOrders.map((entry) {
          print("\n📄 Raw modified order entry:");
          print(entry);
          final modOrder = ToApprove.fromJson(
              Map<String, dynamic>.from(entry)); // Pass entry directly
          print("🆔 toapprove Order ID: ${modOrder.saleOrderNo}");
          print("📛 Ori ginal Order No: ${modOrder.saleOrderNo}");
          print("📋 toapprove Items: ${modOrder.varianceName.length}");
          return modOrder;
        }).toList();

        print("\n📋 Parsed _toApprove:");
      }

      // Step 4: Merge data
      print("\n🔍 Step 4: Merging data");
      print("📦 Initial _allSalesOrders count: ${_allSalesOrders.length}");

      _allSalesOrders = _allSalesOrders.map((order) {
        print("\n🔄 Processing order ${order.salesOrderId}");
        print("📛 Order No: ${order.saleOrderNo}");

        final matchingModifiedOrders = _modifiedOrders
            .where((modOrder) => modOrder.saleOrderNo == order.saleOrderNo)
            .toList();

        print("🔗 Found ${matchingModifiedOrders.length} modified orders");
        matchingModifiedOrders.forEach(
            (modOrder) => print("  Modified ID: ${modOrder.saleOrderNo}"));

        final matchingToApproveOrders = _toApprove
            .where(
                (approveOrder) => approveOrder.saleOrderNo == order.saleOrderNo)
            .toList();

        print("\n📋 Parsed _modifiedOrders:");
        _toApprove.forEach((modOrder) {
          print("\n🆔 Modified Order ID: ${modOrder.saleOrderNo}");
          print("📛 Linked to Order No: ${modOrder.saleOrderNo}");
          print("📋 Modified Items Count: ${modOrder.varianceName.length}");
        });

        final updatedOrder = order
            .copyWith(modifiedOrders: matchingModifiedOrders)
            .copytoapprove(toApprove: matchingToApproveOrders);

        print("🆕 Updated Order Details:");
        print(
            "📦 Modified Orders Count: ${updatedOrder.modifiedOrders?.length ?? 0}");
        print("📋 To-Approve Count: ${updatedOrder.toApprove?.length ?? 0}");
        print("📦 isBoxItem after merge: ${updatedOrder.isBoxItem}");

        return updatedOrder;
      }).toList();

      notifyListeners();
      print("\n✅ Successfully fetched and processed Hive data");
      print("══════════════════════════════════════════════════════════════");
    } catch (e) {
      print("\n❌ Error fetching orders from Hive: $e");
      print("══════════════════════════════════════════════════════════════");
      rethrow;
    }
  }

  List<Map<String, dynamic>> _rawOrders = [];
  List<Map<String, dynamic>> get rawOrders => _rawOrders;
  List<Map<String, dynamic>> _hivefilteredOrders = [];
  List<Map<String, dynamic>> get hivefilteredOrders => _hivefilteredOrders;

  // Future<void> fetchOrdersFromHive() async {
  //   print("Step 1: Entering _fetchOrdersFromHive...");
  //   try {
  //     print("Step 2: Calling webSocketService.getSavedSalesOrders()");
  //     List<Map<String, dynamic>> hiveOrders =
  //         await webSocketService.getSavedSalesOrders();

  //     print("Step 3: Hive orders fetched: ${hiveOrders.length}");
  //     for (int i = 0; i < hiveOrders.length; i++) {
  //       print("Step 4: Hive order $i: ${hiveOrders[i]}");
  //     }

  //     print(
  //         "Step 5: Storing raw hive orders into _rawOrders and _filteredOrders.");
  //     _rawOrders = hiveOrders;
  //     _hivefilteredOrders = List.from(_rawOrders);
  //     print("Step 6: Total orders stored: ${_rawOrders.length}");

  //     print("Step 7: Notifying listeners about the new data.");
  //     notifyListeners();
  //     print("Step 8: _fetchOrdersFromHive completed successfully.");
  //   } catch (e) {
  //     print("Error fetching orders from Hive: $e");
  //   }
  // }

  // Future<void> fetchOrdersFromHive() async {
  //   print("Step 1: Entering fetchOrdersFromHive...");
  //   try {
  //     print("Step 2: Fetching sales orders from Hive");
  //     List<Map<String, dynamic>> hiveOrders =
  //         await webSocketService.getSavedSalesOrders();
  //     print("Step 3: Hive orders fetched: ${hiveOrders.length}");

  //     // Convert Hive sales orders to SalesOrderDisplay objects
  //     List<SalesOrderDisplay> salesOrderList = hiveOrders
  //         .map((orderMap) => SalesOrderDisplay.fromMap(orderMap))
  //         .toList();
  //     print('salesOrderList$salesOrderList');
  //     print("Step 4: Fetching modify orders from Hive");
  //     var modifyOrderBox = await Hive.openBox('modifyOrderBox');
  //     print('modifyOrderBox$modifyOrderBox');
  //     // List<ModifyOrder> modifyOrders = modifyOrderBox.values
  //     //     .map((item) => ModifyOrder.fromJson(Map<String, dynamic>.from(item)))
  //     //     .toList();
  //     _modifiedOrders = modifyOrderBox.values
  //         .map((item) => ModifyOrder.fromJson(Map<String, dynamic>.from(item)))
  //         .toList();
  //     print('objects${_modifiedOrders.length}');
  //     print("Step 5: Fetching toApprove orders from Hive");
  //     var toApproveBox = await Hive.openBox('toApproveBox');
  //     List<ToApprove> toApproveList = toApproveBox.values
  //         .map((item) => ToApprove.fromJson(Map<String, dynamic>.from(item)))
  //         .toList();

  //     print("Step 6: Merging data into sales orders");
  //     List<SalesOrderDisplay> mergedOrders = salesOrderList.map((order) {
  //       // Find matching modify orders
  //       List<ModifyOrder> matchingModify = _modifiedOrders
  //           .where((modify) =>
  //               // modify.previousId == order.salesOrderId ||
  //               modify.salesOrderNo == order.saleOrderNo)
  //           .toList();
  //       print('matchingModify$matchingModify');

  //       // Find matching toApprove orders
  //       List<ToApprove> matchingToApprove = toApproveList
  //           .where((toApprove) =>
  //               toApprove.previousId == order.salesOrderId ||
  //               toApprove.salesOrderNo == order.saleOrderNo)
  //           .toList();

  //       // Merge into the sales order
  //       return order
  //           .copyWith(modifiedOrders: matchingModify)
  //           .copytoapprove(toApprove: matchingToApprove);
  //     }).toList();

  //     print("Step 7: Applying filters and updating state");
  //     // Filter orders with status "Confirm Order" and reverse the list
  //     List<SalesOrderDisplay> filteredOrders = mergedOrders
  //         .where((order) => order.status == "Confirm Order")
  //         .toList()
  //         .reversed
  //         .toList();

  //     // Update state variables
  //     _allSalesOrders = filteredOrders;
  //     _filteredAllSalesOrders = filteredOrders;
  //     _originalSalesOrder = filteredOrders;

  //     print("Step 8: Notifying listeners");
  //     notifyListeners();
  //     print("Step 9: fetchOrdersFromHive completed successfully.");
  //   } catch (e) {
  //     print("Error fetching orders from Hive: $e");
  //   }
  // }
  // void filterOrdersByDate(DateTime selectedDate) {
  //   print(
  //       "Step 1: Filtering orders by date: ${DateFormat('yyyy-MM-dd').format(selectedDate)}");
  //   _hivefilteredOrders = _rawOrders.where((order) {
  //     if (order.containsKey('deliveryDate')) {
  //       DateTime orderDate = DateTime.parse(order['deliveryDate']);
  //       return DateFormat('yyyy-MM-dd').format(orderDate) ==
  //           DateFormat('yyyy-MM-dd').format(selectedDate);
  //     }
  //     return false;
  //   }).toList();
  //   print("Step 2: Orders after date filtering: ${_hivefilteredOrders.length}");
  //   notifyListeners();
  //   print("Step 3: Notified listeners about updated date filter.");
  // }

  // void filterOrdersByDate(DateTime selectedDate) {
  //   print(
  //       "Step 1: Filtering orders by date: ${DateFormat('yyyy-MM-dd').format(selectedDate)}");
  //   _hivefilteredOrders = _rawOrders.where((order) {
  //     if (order.containsKey('deliveryDate')) {
  //       try {
  //         DateTime orderDate = DateFormat('dd-MM-yyyy').parse(
  //             order['deliveryDate']); // Adjusting to match "31-03-2025" format
  //         return DateFormat('yyyy-MM-dd').format(orderDate) ==
  //             DateFormat('yyyy-MM-dd').format(selectedDate);
  //       } catch (e) {
  //         print("Error parsing date: ${order['deliveryDate']} - $e");
  //         return false;
  //       }
  //     }
  //     return false;
  //   }).toList();
  //   print("Step 2: Orders after date filtering: ${_hivefilteredOrders.length}");
  //   notifyListeners();
  //   print("Step 3: Notified listeners about updated date filter.");
  // }

  void filterOrdersByDate(DateTime selectedDate) {
    print(
        "Step 1: Filtering orders by date: ${DateFormat('yyyy-MM-dd').format(selectedDate)}");

    _filteredAllSalesOrders = _allSalesOrders.where((order) {
      if (order.deliveryDate != null) {
        try {
          // Parse order's delivery date from 'dd-MM-yyyy' format
          DateTime orderDate =
              DateFormat('dd-MM-yyyy').parse(order.deliveryDate!);
          // Compare dates in 'yyyy-MM-dd' format for accurate comparison
          return DateFormat('yyyy-MM-dd').format(orderDate) ==
              DateFormat('yyyy-MM-dd').format(selectedDate);
        } catch (e) {
          print("Error parsing date: ${order.deliveryDate} - $e");
          return false;
        }
      }
      return false;
    }).toList();

    print(
        "Step 2: Orders after date filtering: ${_filteredAllSalesOrders.length}");
    notifyListeners();
    print("Step 3: Notified listeners about updated date filter.");
  }

  Future<void> _setupHiveListener() async {
    final saleOrderBox = await Hive.openBox('saleOrderBox');
    saleOrderBox.watch().listen((event) {
      print("Hive box changed. Event: $event");
      refreshOrders();
    });
  }

  Future<void> refreshOrders() async {
    await _fetchOrdersFromHive(); // Re-fetch data from Hive
    notifyListeners(); // Notify UI to rebuild
  }

  bool _groupByDeliveryDate = true;
  bool get groupByDeliveryDate => _groupByDeliveryDate;

  List<CreditOrder> _creditOrders = [];
  List<SalesOrderDisplay> _filteredSalesOrders = [];
  List<SalesOrderDisplay> _filteredAllSalesOrders = [];
  List<SalesOrderDisplay> _allSalesOrders = [];
  List<SalesOrderDisplay> _originalSalesOrder = [];
  bool _isLoading = false;
  Timer? _debounce;
  List<ModifyOrder> _modifiedOrders = [];
  List<ToApprove> _toApprove = [];
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  List<CreditOrder> get creditOrders => _creditOrders;
  List<SalesOrderDisplay> get filteredSalesOrders => _filteredSalesOrders;
  List<ModifyOrder> get modifyorder => _modifiedOrders;
  List<ToApprove> get toApprove => _toApprove;
  List<SalesOrderDisplay> get allSalesOrders => _allSalesOrders;
  List<SalesOrderDisplay> get originalSalesOrders => _originalSalesOrder;
  bool get isLoading => _isLoading;
  String? _searchQuery;

  DateTime fetchDate = DateTime.now();
  DateTime get date => fetchDate;
  DateTime? _selectedDate = DateTime.now();
  DateTime? get selectedDate => _selectedDate;
  final ScrollController scrollController = ScrollController();
  bool isLoadingMore = false;
  int currentPage = 1;
  final int pageSize = 10;
  final WebSocketService webSocketService;

  List<SalesOrderDisplay> _salesOrders = [];
  List<SalesOrderDisplay> get salesOrders => _salesOrders;
  Map<String, List<SalesOrderDisplay>> _ordersByDate = {};
  List<String> _sortedDates = [];
  String _todayDate = DateFormat('dd-MM-yyyy').format(DateTime.now());

  // Add getters
  Map<String, List<SalesOrderDisplay>> get ordersByDate => _ordersByDate;
  List<String> get sortedDates => _sortedDates;
  String get todayDate => _todayDate;

  void scanQRCode(String qrCode) {
    _searchQuery = qrCode.trim(); // Remove unnecessary whitespace
    notifyListeners();
    searchOrders(_searchQuery!); // Trigger the search logic with the QR code
  }

  void changeDate(Duration duration) {
    _selectedDate = _selectedDate!.add(duration);
    filterOrdersByDate(
        _selectedDate!); // Call filterOrdersByDate with the updated date
    notifyListeners();
  }

  List<SalesOrderDisplay> get filteredAllSalesOrders {
    print("🔄 Starting to filter all sales orders...\n");

    // Now process each sales order
    return _allSalesOrders.map((order) {
      print(
          "\n🔍 Processing Sales Order: ${order.saleOrderNo} (ID: ${order.salesOrderId})");

      final matchingModifiedOrders = _modifiedOrders
          .where((modOrder) => modOrder.saleOrderNo == order.saleOrderNo)
          .toList();

      // print(
      //     "  ✅ Found ${matchingModifiedOrders.length} matching modified orders:");
      // for (var mod in matchingModifiedOrders) {
      //   print(
      //       "    → Modified Order: ${mod.saleOrderNo} (Previous ID: ${mod.previousId})");
      // }

      final matchingToApprovedOrders = _toApprove
          .where((modOrder) => modOrder.saleOrderNo == order.saleOrderNo)
          .toList();

      print(
          "  ✅ Found ${matchingToApprovedOrders.length} matching modified orders:");
      for (var mod in matchingToApprovedOrders) {
        print(
            "    → Modified Order: ${mod.saleOrderNo} (Previous ID: ${mod.previousId})");
      }

      final resultOrder = order.copyWith(
          modifiedOrders: matchingModifiedOrders,
          toApprove: matchingToApprovedOrders);

      print(
          "  🛠 Created new SalesOrderDisplay with ${resultOrder.modifiedOrders?.length ?? 0} modified orders.\n");

      return resultOrder;
    }).toList();
  }

  // void filterOrdersByStatus(String selectedFilter) {
  //   print("Filtering orders by status: $selectedFilter");

  //   if (selectedFilter == "All Order") {
  //     // Reset to show all orders
  //     _filteredAllSalesOrders = List.from(_allSalesOrders);
  //     print("Showing all orders (${_filteredAllSalesOrders.length})");
  //   } else {
  //     String targetStatus = selectedFilter;

  //     // Map UI filter names to actual status values
  //     if (selectedFilter == "Cancel") {
  //       targetStatus = "Cancel Order";
  //     } else if (selectedFilter == "Confirm") {
  //       targetStatus = "Confirm Order";
  //     }

  //     print("Filtering for status: $targetStatus");

  //     // Filter from the original list, not the filtered one
  //     final filtered = _allSalesOrders.where((order) {
  //       final statusMatch = order.status != null &&
  //           order.status!.toLowerCase() == targetStatus.toLowerCase();

  //       print("Order ${order.saleOrderNo} - Status: ${order.status} - "
  //           "${statusMatch ? "MATCHES" : "NO MATCH"}");
  //       return statusMatch;
  //     }).toList();

  //     _filteredAllSalesOrders = filtered;
  //     print(
  //         "Found ${_filteredAllSalesOrders.length} orders with status $targetStatus");
  //   }

  //   notifyListeners();
  //   print("Notified listeners about status filter change");
  // }

  void filterOrdersByStatus(String selectedFilter) {
    print("══════════════════════════════════════════════════════════════");
    print("🛠️ Starting filterOrdersByStatus with filter: '$selectedFilter'");
    print("📦 Initial _allSalesOrders count: ${_allSalesOrders.length}");

    if (selectedFilter == "All Order") {
      print("\n🔀 Resetting to all orders");
      _allSalesOrders = List.from(_allSalesOrders);
      print("✅ Showing all ${_filteredAllSalesOrders.length} orders");
    } else {
      String targetStatus = selectedFilter;

      print("\n🔍 Original filter name: '$selectedFilter'");
      if (selectedFilter == "Cancel") {
        targetStatus = "Cancel Order";
      } else if (selectedFilter == "Confirm") {
        targetStatus = "Confirm Order";
      }
      print("🎯 Mapped target status: '$targetStatus'");

      print("\n🔎 Starting filtering process...");
      _allSalesOrders = _allSalesOrders.where((order) {
        final status = order.status;
        final cleanedStatus = status?.trim().toLowerCase() ?? 'no-status';
        final cleanedTarget = targetStatus;

        print("➤ Order ${order.saleOrderNo} status: '${status ?? 'null'}' "
            "→ cleaned: '$cleanedStatus'");

        final match = status == cleanedTarget;
        print(match ? "   ✅ MATCHES" : "   ❌ NO MATCH");

        return match;
      }).toList();

      print("\n📊 Filter result: ${_allSalesOrders.length} orders match "
          "'$targetStatus'");
    }
    // _allSalesOrders.clear();
    print("\n🔔 Notifying listeners");
    notifyListeners();
    print("══════════════════════════════════════════════════════════════");
  }

  void fetchFilteredOrders({DateTime? startDate, DateTime? endDate}) {
    if (startDate == null && endDate == null) {
      // No filtering if both dates are null.
      _hivefilteredOrders = List.from(_rawOrders);
    } else {
      _hivefilteredOrders = _rawOrders.where((order) {
        if (order.containsKey('deliveryDate')) {
          try {
            DateTime deliveryDate =
                DateFormat('dd-MM-yyyy').parse(order['deliveryDate']);
            bool matches = true;
            if (startDate != null) {
              // Check deliveryDate is on or after startDate.
              matches = matches &&
                  (deliveryDate.isAtSameMomentAs(startDate) ||
                      deliveryDate.isAfter(startDate));
            }
            if (endDate != null) {
              // Check deliveryDate is on or before endDate.
              matches = matches &&
                  (deliveryDate.isAtSameMomentAs(endDate) ||
                      deliveryDate.isBefore(endDate));
            }
            return matches;
          } catch (e) {
            print(
                "Error parsing order date: ${order['deliveryDate']}, error: $e");
            return false;
          }
        }
        return false;
      }).toList();
    }
    notifyListeners();
  }

  Future<void> fetchAllOrders() async {
    try {
      // Fetch original sales orders
      final salesOrderResponse = await http.get(Uri.parse(
          'http://192.168.29.246:8881/fastapi/salesorders/withoutpagination/'));

      if (salesOrderResponse.statusCode == 200) {
        // final salesOrderData = jsonDecode(salesOrderResponse.body) as List;
        final responseBody = jsonDecode(salesOrderResponse.body);
        if (responseBody is List) {
          final salesOrderData = responseBody
              .map((json) => SalesOrderDisplay.fromMap(json))
              .toList();
          //  _allSalesOrders = salesOrderData
          //     .map((json) => SalesOrderDisplay.fromMap(json))
          //     .toList();
          _filteredAllSalesOrders = salesOrderData
              .where((order) => order.status == "Confirm Order")
              .toList()
              .reversed
              .toList();
          _originalSalesOrder = _filteredAllSalesOrders;
          _allSalesOrders = _filteredAllSalesOrders;
        } else if (responseBody is Map<String, dynamic>) {
          final salesOrderData = responseBody['data'] as List;
          _allSalesOrders = salesOrderData
              .map((json) => SalesOrderDisplay.fromMap(json))
              .toList();
          _filteredAllSalesOrders = _allSalesOrders
              .where((order) => order.status == "Confirm Order")
              .toList()
              .reversed
              .toList();
          _originalSalesOrder = _filteredAllSalesOrders;
          _allSalesOrders = _filteredAllSalesOrders;
          print('_allSalesOrders$_allSalesOrders');
        } else {
          throw Exception('Failed to load sales orders');
        }
      }

      // Fetch modified orders
      final modifiedOrderResponse = await http
          .get(Uri.parse('http://192.168.29.246:8881/fastapi/modify/'));
      if (modifiedOrderResponse.statusCode == 200) {
        final modifiedOrderData =
            jsonDecode(modifiedOrderResponse.body) as List;
        _modifiedOrders = modifiedOrderData
            .map((json) => ModifyOrder.fromJson(json))
            .toList();
      } else {
        throw Exception('Failed to load modified orders');
      }

      // Fetch toApprove orders
      final toApproveResponse = await http
          .get(Uri.parse('http://192.168.29.246:8881/fastapi/toapprove/'));
      if (toApproveResponse.statusCode == 200) {
        final toApproveData = jsonDecode(toApproveResponse.body) as List;
        _toApprove =
            toApproveData.map((json) => ToApprove.fromJson(json)).toList();
        print('_toApprove4$_toApprove');
      } else {
        throw Exception('Failed to load toApprove orders');
      }

      // Merge modified and toApprove data into sales orders
      _allSalesOrders = _allSalesOrders.map((order) {
        // Find matching modified orders
        final matchingModifiedOrders = _modifiedOrders
            .where((modOrder) =>
                modOrder.previousId == order.salesOrderId ||
                modOrder.saleOrderNo == order.saleOrderNo)
            .toList();

        // Find matching toApprove orders
        final matchingToApproveOrders = _toApprove
            .where((approveOrder) =>
                approveOrder.previousId == order.salesOrderId ||
                approveOrder.saleOrderNo == order.saleOrderNo)
            .toList();

        // Return order with matched modifications and approvals
        return order
            .copyWith(modifiedOrders: matchingModifiedOrders)
            .copytoapprove(toApprove: matchingToApproveOrders);
      }).toList();

      notifyListeners();
    } catch (e) {
      print('Error fetching orders: $e');
    }
  }

  void toggleGrouping() {
    _groupByDeliveryDate = !_groupByDeliveryDate;
    // _allSalesOrders.clear();
    // _ordersByDate.clear();
    // print('_groupByDeliveryDate${_groupByDeliveryDate}');
    // fetchAllOrders(); // This will fetch with the new grouping

    notifyListeners();
  }

  void clearAllOrders() {
    _ordersByDate.clear();
    _allSalesOrders.clear();
    _filteredAllSalesOrders.clear();
    _originalSalesOrder.clear();
    _sortedDates.clear();
    notifyListeners();
  }

  Future<void> _fetchModifiedOrders() async {
    final response =
        await http.get(Uri.parse('http://192.168.29.246:8881/fastapi/modify/'));
    if (response.statusCode == 200) {
      final body = jsonDecode(response.body);
      print('body$body');
      if (body is List) {
        _modifiedOrders =
            body.map((json) => ModifyOrder.fromJson(json)).toList();
      }
    }
  }

  Future<void> _fetchToApproveOrders() async {
    final response = await http
        .get(Uri.parse('http://192.168.29.246:8881/fastapi/toapprove/'));
    if (response.statusCode == 200) {
      final body = jsonDecode(response.body);
      if (body is List) {
        _toApprove = body.map((json) => ToApprove.fromJson(json)).toList();
      }
    }
  }

  void filterGroupedOrders({
    DateTime? startDate,
    DateTime? endDate,
    String? status,
    String? searchQuery,
  }) {
    _filteredAllSalesOrders = _allSalesOrders.where((order) {
      bool matchesDate = true;
      // if (startDate != null && endDate != null) {

      //   matchesDate =
      //       order.deliveryDate.isAfter(startDate.subtract(Duration(days: 1))) &&
      //           order.deliveryDate.isBefore(endDate.add(Duration(days: 1)));
      // }
      DateTime? deliveryDate;
      try {
        deliveryDate = DateFormat("dd-MM-yyyy").parse(order.deliveryDate);
      } catch (e) {
        print("Error parsing date: $e");
        return false;
      }

      // Check if the order falls within the selected date range
      if (startDate != null && endDate != null) {
        matchesDate =
            deliveryDate.isAfter(startDate.subtract(Duration(days: 1))) &&
                deliveryDate.isBefore(endDate.add(Duration(days: 1)));
      }

      bool matchesStatus = true;
      if (status != null && status != 'All Order') {
        matchesStatus = order.status == status;
      }

      bool matchesSearch = true;
      if (searchQuery != null && searchQuery.isNotEmpty) {
        matchesSearch = order.saleOrderNo
                .toLowerCase()
                .contains(searchQuery.toLowerCase()) ||
            (order.employeeName?.toLowerCase() ?? '')
                .contains(searchQuery.toLowerCase());
      }

      return matchesDate && matchesStatus && matchesSearch;
    }).toList();

    // Update grouped orders based on filtered results
    _updateGroupedOrders();
    notifyListeners();
  }

  // Helper method to update grouped orders
  void _updateGroupedOrders() {
    _ordersByDate = {};
    for (var order in _filteredAllSalesOrders) {
      // final orderDate = DateFormat('dd-MM-yyyy').format(order.deliveryDate);
      final orderDate = order.deliveryDate;
      final DateTime parsedDate = DateTime.parse(orderDate);

// Now you can format it into 'dd-MM-yyyy'
      final String formattedDate = DateFormat('dd-MM-yyyy').format(parsedDate);

      if (_ordersByDate.containsKey(formattedDate)) {
        _ordersByDate[formattedDate]!.add(order);
      } else {
        _ordersByDate[formattedDate] = [order];
      }
    }

    _sortedDates = _ordersByDate.keys.toList()
      ..sort((a, b) => DateFormat('dd-MM-yyyy')
          .parse(b)
          .compareTo(DateFormat('dd-MM-yyyy').parse(a)));
  }

  //  void updateOrderStatusLocally(String orderId, String newStatus, String approvalType) {
  //   final orderIndex = _allSalesOrders.indexWhere((order) => order.salesOrderId == orderId);
  //   if (orderIndex != -1) {
  //     _allSalesOrders[orderIndex] = _allSalesOrders[orderIndex].copyWith(
  //       status: newStatus,
  //       approvalType: approvalType,
  //     );
  //     notifyListeners();
  //   }
  // }

  Future<void> filterCanceledOrders() async {
    _isLoading = true;
    notifyListeners(); // Notify listeners that the loading state has changed

    try {
      // Base URL for fetching orders
      String url = baseUrl;

      // If start and end dates are provided, filter by them
      if (_startDate != null && _endDate != null) {
        final formattedStartDate = DateFormat('dd-MM-yyyy').format(_startDate!);
        final formattedEndDate = DateFormat('dd-MM-yyyy').format(_endDate!);
        print('formattedStart');
        print(formattedStartDate);
        print('formattedEnd');
        print(formattedEndDate);
        url =
            '$url?deliveryStartDate=$formattedStartDate&deliveryEndDate=$formattedEndDate';
      }

      // Otherwise, fetch all orders without date filters
      else {
        url = url; // Default URL without date filters
      }
      print(url);

      // Log the URL before making the request
      print('Fetching data from URL: $url');

      final response = await http.get(Uri.parse(url));

      // Log the status code and response body for debugging
      print('Status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      // Check if the response was successful
      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);

        // Store all orders in _allSalesOrders
        _allSalesOrders =
            data.map((json) => SalesOrderDisplay.fromMap(json)).toList();
        print('Above the _filterALLSalesorder$_allSalesOrders');
        // Filter only "Open Order" status and reverse the list
        _filteredAllSalesOrders = _allSalesOrders
            .where((order) => order.status == "Order Cancelled")
            .toList()
            .reversed
            .toList();
        _allSalesOrders = _filteredAllSalesOrders;
        print('_allsalesdorss$_allSalesOrders');
      } else {
        throw Exception(
            'Failed to load orders. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
      throw Exception('Failed to load orders: $e');
    } finally {
      _isLoading = false;
      notifyListeners(); // Notify listeners that the loading is complete
    }
  }

  Future<void> filterModifyOrders() async {
    _isLoading = true;
    notifyListeners(); // Notify listeners that the loading state has changed

    try {
      // Base URL for fetching orders
      String url = baseUrl;

      // If start and end dates are provided, filter by them
      if (_startDate != null && _endDate != null) {
        final formattedStartDate = DateFormat('dd-MM-yyyy').format(_startDate!);
        final formattedEndDate = DateFormat('dd-MM-yyyy').format(_endDate!);
        print('formattedStart');
        print(formattedStartDate);
        print('formattedEnd');
        print(formattedEndDate);
        url =
            '$url?deliveryStartDate=$formattedStartDate&deliveryEndDate=$formattedEndDate';
      }

      // Otherwise, fetch all orders without date filters
      else {
        url = url; // Default URL without date filters
      }
      print(url);

      // Log the URL before making the request
      print('Fetching data from URL: $url');

      final response = await http.get(Uri.parse(url));

      // Log the status code and response body for debugging
      print('Status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      // Check if the response was successful
      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);

        // Store all orders in _allSalesOrders
        _allSalesOrders =
            data.map((json) => SalesOrderDisplay.fromMap(json)).toList();
        print('Above the _filterALLSalesorder$_allSalesOrders');
        // Filter only "Open Order" status and reverse the list
        _filteredAllSalesOrders = _allSalesOrders
            .where((order) => order.status == "Modify Request")
            .toList()
            .reversed
            .toList();
        _allSalesOrders = _filteredAllSalesOrders;
        print('_allsalesdorss$_allSalesOrders');
      } else {
        throw Exception(
            'Failed to load orders. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
      throw Exception('Failed to load orders: $e');
    } finally {
      _isLoading = false;
      notifyListeners(); // Notify listeners that the loading is complete
    }
  }

  Future<void> filterPendingOrders() async {
    _isLoading = true;
    notifyListeners(); // Notify listeners that the loading state has changed

    try {
      // Base URL for fetching orders
      String url = baseUrl;

      // If start and end dates are provided, filter by them
      if (_startDate != null && _endDate != null) {
        final formattedStartDate = DateFormat('dd-MM-yyyy').format(_startDate!);
        final formattedEndDate = DateFormat('dd-MM-yyyy').format(_endDate!);
        print('formattedStart');
        print(formattedStartDate);
        print('formattedEnd');
        print(formattedEndDate);
        url =
            '$url?deliveryStartDate=$formattedStartDate&deliveryEndDate=$formattedEndDate';
      }

      // Otherwise, fetch all orders without date filters
      else {
        url = url; // Default URL without date filters
      }
      print(url);

      // Log the URL before making the request
      print('Fetching data from URL: $url');

      final response = await http.get(Uri.parse(url));

      // Log the status code and response body for debugging
      print('Status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      // Check if the response was successful
      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);

        // Store all orders in _allSalesOrders
        _allSalesOrders =
            data.map((json) => SalesOrderDisplay.fromMap(json)).toList();
        print('Above the _filterALLSalesorder$_allSalesOrders');
        // Filter only "Open Order" status and reverse the list
        _filteredAllSalesOrders = _allSalesOrders
            .where((order) => order.status == "Waiting for approval")
            .toList()
            .reversed
            .toList();
        _allSalesOrders = _filteredAllSalesOrders;
        print('_allsalesdorss$_allSalesOrders');
      } else {
        throw Exception(
            'Failed to load orders. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
      throw Exception('Failed to load orders: $e');
    } finally {
      _isLoading = false;
      notifyListeners(); // Notify listeners that the loading is complete
    }
  }

  void showCreditDialog(String salesOrderId, BuildContext context) async {
    final updateStatusUrl =
        Uri.parse('https://yenerp.com/fastapi/salesorders/$salesOrderId');
    final creditBillUrl = Uri.parse(
        'http://192.168.29.246:8881/fastapi/creditbills/?salesorderid=$salesOrderId');

    try {
      // First API Call: Update the status to 'Credit Pending'
      final updateResponse = await http.patch(
        updateStatusUrl,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'status': 'Credit Pending'}),
      );
//server
      if (updateResponse.statusCode == 200) {
        // If the first call succeeds, make the second API Call
        final creditResponse = await http.post(
          creditBillUrl,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'salesorderid': salesOrderId}),
        );

        if (creditResponse.statusCode == 201) {
          print('Credit bill created successfully: ${creditResponse.body}');
          // Show success snackbar
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Credit bill created successfully!'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 1),
            ),
          );
        } else {
          print('Failed to create credit bill: ${creditResponse.statusCode}');
          // Show failure snackbar
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to create credit bill. Please try again.'),
              backgroundColor: Colors.red,
              duration: Duration(seconds: 1),
            ),
          );
        }
        // 'ws://$serverip:$port', // Replace `port` with your WebSocket server's port
      } else {
        print('Failed to update order status: ${updateResponse.statusCode}');
        // Show failure snackbar
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update order status. Please try again.'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 1),
          ),
        );
      }
    } catch (e) {
      print('An error occurred: $e');
      // Show error snackbar
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('An error occurred. Please try again later.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 3),
        ),
      );
    }
  }

  Future<Uint8List> fetchAudioDataByOrderId(String orderId) async {
    try {
      // Make a GET request to your FastAPI endpoint
      print(orderId);
      var response = await http.get(Uri.parse(
          'http://192.168.29.246:8881/fastapi/voiceOrder/voiceOrder/media/$orderId'));

      // Check if the response is successful (HTTP 200)
      if (response.statusCode == 200) {
        // Return the response body as Uint8List (binary audio data)
        return response
            .bodyBytes; // This will return the audio data in byte format
      } else {
        // If the response is not successful, throw an error
        throw Exception('Failed to load audio: ${response.statusCode}');
      }
    } catch (e) {
      // Handle any errors (e.g., network issues)
      print('Error fetching audio data: $e');
      rethrow;
    }
  }

  final String baseUrl = "http://192.168.29.246:8881/fastapi/salesorders";
  Future<void> fetchOrders({DateTime? deliveryDate}) async {
    _isLoading = true;
    notifyListeners(); // Notify listeners that the loading state has changed

    try {
      // Use the provided deliveryDate or the current selectedDate
      _selectedDate = deliveryDate ?? _selectedDate ?? DateTime.now();

      // Format the date in the required format (e.g., dd-MM-yyyy)
      String formattedDate = DateFormat('dd-MM-yyyy').format(_selectedDate!);
      print('Formatted Date: $formattedDate');

      // Construct the URL with the deliveryDate query parameter
      String url = '$baseUrl?deliveryDate=$formattedDate';
      _salesOrders = [];
      _filteredSalesOrders = [];
      notifyListeners();

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        // List<dynamic> data = jsonDecode(response.body);
        final responseBody = jsonDecode(response.body);
        final data = responseBody['data'] as List;
        // final dynamic responseBody = json.decode(response.body);
        // print('data: $responseBody');
        // final List<dynamic> data = responseBody['data'];
        // print('Seconddata: $data');
        // Filter orders for the selected deliveryDate and "Confirm Order" status
        _salesOrders = data
            .map((json) => SalesOrderDisplay.fromMap(json))
            .where((order) {
              try {
                DateTime orderDeliveryDate =
                    DateFormat('dd-MM-yyyy').parse(order.deliveryDate);

                return orderDeliveryDate.year == _selectedDate!.year &&
                    orderDeliveryDate.month == _selectedDate!.month &&
                    orderDeliveryDate.day == _selectedDate!.day &&
                    order.status == "Confirm Order";
              } catch (e) {
                return false;
              }
            })
            .toList()
            .reversed
            .toList();

        // Update filtered sales orders
        _filteredSalesOrders = List.from(_salesOrders);
        print('Filtered Sales Orders: $_filteredSalesOrders');
      } else {
        throw Exception('Failed to load orders');
      }
    } catch (e) {
      print('Error: $e');
      _salesOrders = [];
      _filteredSalesOrders = [];
      throw Exception('Failed to load orders: $e');
    } finally {
      _isLoading = false;
      notifyListeners(); // Notify listeners that loading is complete
    }
  }

  Future<void> fetchOrderById(String orderId) async {
    _isLoading = true;
    notifyListeners(); // Notify listeners that the loading state has changed

    try {
      // Construct the URL for fetching the specific order by ID
      final url = '$baseUrl/$orderId';
      print('Fetching order by ID from URL: $url');

      final response = await http.get(Uri.parse(url));

      // Log the status code and response body for debugging
      print('Status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      // Check if the response was successful
      if (response.statusCode == 200) {
        // Decode the response body and map it to the order model
        final data = jsonDecode(response.body);
        final order = SalesOrderDisplay.fromMap(data);

        // Log the fetched order for debugging
        print('Fetched order: $order');

        // Update the state with the fetched order
        _filteredAllSalesOrders = [order];
      } else {
        throw Exception(
            'Failed to load order by ID. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
      throw Exception('Failed to fetch order by ID: $e');
    } finally {
      _isLoading = false;
      notifyListeners(); // Notify listeners that the loading is complete
    }
  }

  // void searchOrders(String query) async {
  //   if (_debounce?.isActive ?? false) {
  //     _debounce!.cancel(); // Cancel the previous debounce if it's still active
  //   }

  //   _debounce = Timer(const Duration(milliseconds: 300), () async {
  //     _isLoading = true;

  //     if (query.isEmpty) {
  //       // Reset the filtered list when the query is empty
  //       _filteredSalesOrders = salesOrders;
  //     } else {
  //       final String endpoint =
  //           'http://192.168.29.246:8881/fastapi/salesorders/?saleOrderNo=${Uri.encodeComponent(query)}';

  //       try {
  //         final uri = Uri.parse(endpoint);
  //         final response = await http.get(uri);

  //         if (response.statusCode == 200) {
  //           // List<dynamic> data = jsonDecode(response.body);
  //           final responseBody = jsonDecode(response.body);
  //           final data = responseBody['data'] as List;
  //           // Update filtered orders based on the response
  //           _filteredSalesOrders = data
  //               .map((json) => SalesOrderDisplay.fromMap(json))
  //               .where((order) => order.status == 'Confirm Order')
  //               .toList();
  //         } else {
  //           _filteredSalesOrders = []; // Empty the list if the API call fails
  //         }
  //       } catch (e) {
  //         _filteredSalesOrders = []; // Handle network errors
  //       }
  //     }

  //     notifyListeners(); // Notify UI to update
  //     _isLoading = false;
  //   });
  // }

  void searchOrders(String query) {
    print("Step 1: Searching orders with query: $query");
    if (query.isEmpty) {
      print("Step 2: Query is empty, resetting orders to original list.");
      _hivefilteredOrders = List.from(_rawOrders);
    } else {
      print("Step 3: Filtering orders based on query.");
      _hivefilteredOrders = _rawOrders.where((order) {
        return order.values.any((value) =>
            value.toString().toLowerCase().contains(query.toLowerCase()));
      }).toList();
    }
    print("Step 4: Filtered orders count: ${_hivefilteredOrders.length}");
    notifyListeners();
    print("Step 5: Notified listeners about updated search results.");
  }

  void fetchOrdersByDateRange(
      {DateTime? deliveryStartDate, DateTime? deliveryEndDate}) async {
    print("Fetching orders from $deliveryStartDate to $deliveryEndDate");

    _isLoading = true;
    notifyListeners();
    String? formattedStartDate = deliveryStartDate != null
        ? DateFormat('dd-MM-yyyy').format(deliveryStartDate)
        : null;
    String? formattedEndDate = deliveryEndDate != null
        ? DateFormat('dd-MM-yyyy').format(deliveryEndDate)
        : null;
    // Construct base endpoint
    String endpoint =
        'http://192.168.29.246:8881/fastapi/salesorders/grouped-by-delivery-date?status=ConfirmOrder';

    // Append date filters if provided
    if (deliveryStartDate != null && deliveryEndDate != null) {
      endpoint +=
          '&deliveryStartDate=${Uri.encodeComponent(formattedStartDate!)}'
          '&deliveryEndDate=${Uri.encodeComponent(formattedEndDate!)}';
    }

    final uri = Uri.parse(endpoint);
    print("Constructed URI: $uri");

    try {
      final response = await http.get(uri);
      print("HTTP GET request sent.");

      if (response.statusCode == 200) {
        print("Response received. Status Code: 200");

        final responseBody = jsonDecode(response.body);
        final data = responseBody['data'] as List;
        print("Raw response data: $data");

        // Process orders
        final List<SalesOrderDisplay> orders = data.expand((group) {
          return (group["orders"] as List).map((order) {
            return SalesOrderDisplay.fromMap(order);
          });
        }).toList();

        // Group orders by delivery date
        _ordersByDate = groupBy(orders, (order) => order.deliveryDate);
        _allSalesOrders = orders;

        print("Updated _ordersByDate: $_ordersByDate");

        // Sort dates efficiently
        _sortedDates = _ordersByDate.keys.toList()
          ..sort((a, b) => DateFormat("dd-MM-yyyy")
              .parse(a)
              .compareTo(DateFormat("dd-MM-yyyy").parse(b)));

        print("Sorted dates: $_sortedDates");
      } else {
        print("Request failed. Status Code: ${response.statusCode}");
        _allSalesOrders = [];
        _ordersByDate.clear();
        _sortedDates.clear();
      }
    } catch (e) {
      print("Network error occurred: $e");
      _allSalesOrders = [];
      _ordersByDate.clear();
      _sortedDates.clear();
    }

    notifyListeners();
    _isLoading = false;
    print("Fetch orders by date range completed.");
  }

  String? selectedFilter = 'All Order';
  String? status = "Confirm Order";
  void searchAllOrders(String query) async {
    if (query.isEmpty) {
      _allSalesOrders = _originalSalesOrder;
      notifyListeners();
      return;
    }

    final bool isNumericQuery = RegExp(r'^\d+$').hasMatch(query);
    final String endpoint = isNumericQuery ? 'customerNumber' : 'saleOrderNo';

    try {
      print('selectedFilter');
      final response = await http.get(Uri.parse(
          'http://192.168.29.246:8881/fastapi/salesorders/withoutpagination/?status=$status&$endpoint=$query'));
      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        _allSalesOrders =
            data.map((json) => SalesOrderDisplay.fromMap(json)).toList();
      } else {
        throw Exception('Failed to load search results');
      }
    } catch (e) {
      print('Error searching orders: \$e');
    }
    notifyListeners();
  }

  void searchBySaleOrderNo(String saleOrderNo) async {
    if (_debounce?.isActive ?? false) {
      _debounce!.cancel(); // Cancel any active debounce timer
    }

    // Start a new debounce timer
    _debounce = Timer(const Duration(milliseconds: 300), () async {
      _isLoading = true;

      if (saleOrderNo.isEmpty) {
        // Reset to original sales orders if the query is empty
        _filteredSalesOrders = originalSalesOrders;
      } else {
        // Construct the endpoint dynamically
        final String endpoint =
            'http://192.168.29.246:8881/fastapi/salesorders/?saleOrderNo=${Uri.encodeComponent(saleOrderNo)}';
        final uri = Uri.parse(endpoint);

        try {
          final response = await http.get(uri);

          if (response.statusCode == 200) {
            // List<dynamic> data = jsonDecode(response.body);
            final responseBody = jsonDecode(response.body);
            final data = responseBody['data'] as List;

            // Filter and map data to SalesOrderDisplay objects
            _filteredSalesOrders = data
                .map((json) => SalesOrderDisplay.fromMap(json))
                .where((order) =>
                    order.status ==
                    'Confirm Order') // Filter only confirmed orders
                .toList();
          } else {
            // Reset the list if the request fails
            _filteredSalesOrders = [];
          }
        } catch (e) {
          // Handle network or parsing errors
          _filteredSalesOrders = [];
        }
      }

      // Notify listeners for UI update
      notifyListeners();

      _isLoading = false;
    });
  }

  Future<bool> updateOrderStatus(String salesOrderId, String paymenttype,
      int cash, int card, int upi, String status) async {
    try {
      final url = Uri.parse(
          '$baseUrl/create_invoice/$salesOrderId'); // Append ID to URL
      final response = await http.patch(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "paymentType": paymenttype,
          "status": status,
          "cash": cash.toDouble(),
          "card": card.toDouble(),
          "upi": upi.toDouble(),
        }), // Only update the status field
      );
      print('body${response.body}');
      print('Id');
      print(salesOrderId);
      print('status');
      print(status);
      print('cash$cash');
      print('card$card');
      print('upi$upi');
      if (response.statusCode == 200 || response.statusCode == 204) {
        return true; // Update successful
      } else {
        throw Exception(
            'Failed to update status. Status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to update status: $e  ');
    }
  }

  final String baseCreditUrl =
      "http://192.168.29.246:8881/fastapi/creditbills/";

  Future<void> fetchCreditBills() async {
    _isLoading = true;
    notifyListeners(); // Notify listeners that the loading state has changed

    try {
      String url = baseCreditUrl;
      _creditOrders = [];
      notifyListeners();

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        print('response body');
        print(response.body);

        // Parse all orders without filtering for "Open Order"
        _creditOrders = data
            .map((json) => CreditOrder.fromJson(json))
            .toList()
            .reversed
            .toList(); // Reverse the list if needed
      } else {
        throw Exception('Failed to load orders');
      }
    } catch (e) {
      print('Error: $e');
      throw Exception('Failed to load orders: $e');
    } finally {
      _isLoading = false;
      notifyListeners(); // Notify listeners that the loading is complete
    }
  }

  // bool _isLoading = false;
  DateTime? _startDate;
  DateTime? _endDate;

//  bool get isLoading => _isLoading;
  DateTime? get startDate => _startDate;
  DateTime? get endDate => _endDate;

  void setStartDate(DateTime date) {
    _startDate = date;
    notifyListeners(); // Notify listeners about the change
  }

  void setEndDate(DateTime date) {
    _endDate = date;
    notifyListeners(); // Notify listeners about the change
  }

  // Future<void> fetchFilteredOrders() async {
  //   //   _isLoading = true;
  //   notifyListeners();

  //   try {
  //     String url = baseUrl;

  //     // Add date parameters if both start and end dates are selected
  //     if (_startDate != null && _endDate != null) {
  //       final startDateStr = DateFormat('dd-MM-yyyy').format(_startDate!);
  //       final endDateStr = DateFormat('dd-MM-yyyy').format(_endDate!);
  //       url =
  //           '$url/?deliveryStartDate=$startDateStr&deliveryEndDate=$endDateStr';
  //     }

  //     final response = await http.get(Uri.parse(url));

  //     if (response.statusCode == 200) {
  //       // Handle the response as needed
  //       print('Fetched orders successfully!');
  //     } else {
  //       throw Exception('Failed to fetch orders');
  //     }
  //   } catch (e) {
  //     print('Error: $e');
  //   } finally {
  //     // _isLoading = false;
  //     notifyListeners();
  //   }
  // }
}
