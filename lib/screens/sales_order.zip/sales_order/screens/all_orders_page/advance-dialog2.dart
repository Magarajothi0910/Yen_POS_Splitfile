// import 'dart:convert';

// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:provider/provider.dart';
// import 'package:web_socket_channel/web_socket_channel.dart';
// import 'package:yenposapp/screens/kot_screen/global/globals.dart';

// import '../model/sales_order_model.dart';
// import 'services/get_sales_order_service.dart';

// void showPaymentDialog(BuildContext context, SalesOrderDisplay salesOrder) {
//   final WebSocketChannel _channel = WebSocketChannel.connect(
//     Uri.parse(
//       'ws://$serverip:$port',
//     ), // Make sure serverip and port are defined
//   );

//   // Add a listener for WebSocket messages if needed
//   _channel.stream.listen(
//     (data) {
//       print('Received data : $data');
//     },
//     onError: (error) {
//       print('WebSocket error: $error');
//     },
//   );
//   final apiSalesprovider =
//       Provider.of<ApiServiceSalesOrderProvider>(context, listen: false);
//   List<double> totalAmount = List.from(salesOrder.advanceAmount ?? []);
//   TextEditingController advanceController = TextEditingController();
//   int selectedPaymentMethod = 0; // 0 = Cash, 1 = Card, 2 = UPI
//   double totalAdvanceAmount =
//       salesOrder.advanceAmount!.fold(0.0, (sum, value) => sum + value);
//   final total = salesOrder.totalAmount - totalAdvanceAmount;
//   print("");
//   showDialog(
//     context: context,
//     builder: (BuildContext context) {
//       return Dialog(
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(20),
//         ),
//         child: StatefulBuilder(
//           builder: (BuildContext context, StateSetter setState) {
//             return SingleChildScrollView(
//               child: ConstrainedBox(
//                 constraints: BoxConstraints(maxWidth: 400),
//                 child: Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Total Advance Amount: ₹${totalAmount.fold(0.0, (sum, item) => sum + item)}',
//                         style: TextStyle(
//                           fontSize: 18,
//                           fontWeight: FontWeight.bold,
//                           color: Colors.black,
//                         ),
//                       ),
//                       SizedBox(height: 16),

//                       // Text Field for Entering Advance
//                       TextFormField(
//                         controller: advanceController,
//                         keyboardType: TextInputType.number,
//                         decoration: InputDecoration(
//                           labelText: 'Enter Advance Amount',
//                           labelStyle: TextStyle(color: Colors.grey),
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(12),
//                             borderSide: BorderSide(color: Colors.black),
//                           ),
//                           focusedBorder: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(12),
//                             borderSide: BorderSide(color: Colors.black),
//                           ),
//                         ),
//                       ),
//                       SizedBox(height: 16),

//                       // Payment Method Radio Buttons
//                       Text(
//                         'Select Payment Method:',
//                         style: TextStyle(
//                           fontSize: 16,
//                           fontWeight: FontWeight.bold,
//                           color: Colors.black,
//                         ),
//                       ),
//                       SizedBox(height: 8),
//                       Column(
//                         children: [
//                           RadioListTile<int>(
//                             value: 0,
//                             groupValue: selectedPaymentMethod,
//                             onChanged: (int? value) {
//                               setState(() {
//                                 selectedPaymentMethod = value!;
//                               });
//                             },
//                             title: Text("Cash"),
//                           ),
//                           RadioListTile<int>(
//                             value: 1,
//                             groupValue: selectedPaymentMethod,
//                             onChanged: (int? value) {
//                               setState(() {
//                                 selectedPaymentMethod = value!;
//                               });
//                             },
//                             title: Text("Card"),
//                           ),
//                           RadioListTile<int>(
//                             value: 2,
//                             groupValue: selectedPaymentMethod,
//                             onChanged: (int? value) {
//                               setState(() {
//                                 selectedPaymentMethod = value!;
//                               });
//                             },
//                             title: Text("UPI"),
//                           ),
//                         ],
//                       ),
//                       SizedBox(height: 24),

//                       // Submit Button
//                       Align(
//                         alignment: Alignment.center,
//                         child: ElevatedButton(
//                           onPressed: () async {
//                             double advanceAmount =
//                                 double.tryParse(advanceController.text) ?? 0.0;

//                             if (advanceAmount > total) {
//                               ScaffoldMessenger.of(context).showSnackBar(
//                                 SnackBar(
//                                   content: Text(
//                                     'Advance amount cannot exceed the total amount of ₹${salesOrder.totalAmount}',
//                                     style: TextStyle(color: Colors.red),
//                                   ),
//                                 ),
//                               );
//                               return; // Exit early if advance amount exceeds total amount
//                             }

//                             if (advanceAmount > 0) {
//                               // Add the new advance amount
//                               setState(() {
//                                 totalAmount.add(advanceAmount);
//                               });

//                               // Get current datetime
//                               String currentDateTime =
//                                   DateTime.now().toIso8601String();

//                               // Map payment method to a string
//                               String paymentType;
//                               switch (selectedPaymentMethod) {
//                                 case 0:
//                                   paymentType = "Cash";
//                                   break;
//                                 case 1:
//                                   paymentType = "Card";
//                                   break;
//                                 case 2:
//                                   paymentType = "UPI";
//                                   break;
//                                 default:
//                                   paymentType = "Unknown";
//                               }

//                               // Ensure these lists are initialized
//                               salesOrder.advanceDateTime ??= [];
//                               salesOrder.advancePaymentType ??= [];

//                               // Add datetime and payment type
//                               salesOrder.advanceDateTime.add(currentDateTime);
//                               salesOrder.advancePaymentType.add(paymentType);

//                               // Prepare the request body
//                               Map<String, dynamic> requestBody = {
//                                 "advanceAmount": totalAmount,
//                                 "advanceDateTime": salesOrder.advanceDateTime,
//                                 "advancePaymentType":
//                                     salesOrder.advancePaymentType,
//                               };

//                               try {
//                                 // Send PATCH request
//                                 final response = await http.patch(
//                                   Uri.parse(
//                                       'http://$ipAddress/CurrentOrder/withoutpagination/${salesOrder.salesOrderId}'),
//                                   headers: {"Content-Type": "application/json"},
//                                   body: jsonEncode(requestBody),
//                                 );

//                                 if (response.statusCode == 200) {
//                                   // Success
//                                   apiSalesprovider.fetchAllOrders();
//                                   Navigator.of(context).pop();
//                                   ScaffoldMessenger.of(context).showSnackBar(
//                                     SnackBar(
//                                       content: Text(
//                                           'Advance payment updated successfully!'),
//                                     ),
//                                   );
//                                 } else {
//                                   // Error
//                                   ScaffoldMessenger.of(context).showSnackBar(
//                                     SnackBar(
//                                       content: Text(
//                                           'Failed to update advance payment.'),
//                                     ),
//                                   );
//                                 }
//                               } catch (e) {
//                                 ScaffoldMessenger.of(context).showSnackBar(
//                                   SnackBar(content: Text('Error: $e')),
//                                 );
//                               }
//                             } else {
//                               // Invalid input
//                               ScaffoldMessenger.of(context).showSnackBar(
//                                 SnackBar(
//                                   content: Text(
//                                       'Please enter a valid advance amount'),
//                                 ),
//                               );
//                             }
//                           },
//                           style: ElevatedButton.styleFrom(
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(8.0),
//                             ),
//                             backgroundColor: Colors.blue,
//                             foregroundColor: Colors.white,
//                             elevation: 2,
//                           ),
//                           child: Text(
//                             'Submit',
//                             style: TextStyle(
//                               fontSize: 16,
//                               color: Colors.white,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             );
//           },
//         ),
//       );
//     },
//   );
// }

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../../../kot_screen/global/globals.dart';
import '../create_salesOrder.dart/bank_search_dropdown.dart';
import '../model/sales_order_model.dart';
import 'services/get_sales_order_service.dart';

void showPaymentDialog(BuildContext context, SalesOrderDisplay salesOrder) {
  final WebSocketChannel _channel = WebSocketChannel.connect(
    Uri.parse(
      'ws://$serverip:$port',
    ), // Make sure serverip and port are defined
  );

  // Add a listener for WebSocket messages if needed
  _channel.stream.listen(
    (data) {
      print('Received data : $data');
    },
    onError: (error) {
      print('WebSocket error: $error');
    },
  );

  final apiSalesprovider = Provider.of<ApiServiceSalesOrderProvider>(
    context,
    listen: false,
  );
  List<double> totalAmount = List.from(salesOrder.advanceAmount ?? []);
  TextEditingController advanceController = TextEditingController();
  int selectedPaymentMethod = 0; // 0 = Cash, 1 = Card, 2 = UPI
  double totalAdvanceAmount = salesOrder.advanceAmount!.fold(
    0.0,
    (sum, value) => sum + value,
  );
  final total = salesOrder.totalAmount - totalAdvanceAmount;
  String selectedPaymentsMethod = 'Cash'; // Default payment method
  Widget _buildPaymentChip(
    BuildContext context,
    StateSetter setState,
    String label,
    IconData icon,
  ) {
    return ChoiceChip(
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 18,
            color:
                selectedPaymentsMethod == label ? Colors.white : Colors.black87,
          ),
          SizedBox(width: 5),
          Text(label),
        ],
      ),
      selected: selectedPaymentsMethod == label,
      onSelected: (selected) {
        setState(() => selectedPaymentsMethod = label);
      },
      selectedColor: Colors.blueAccent,
      backgroundColor: Colors.grey.shade200,
      labelStyle: TextStyle(
        color: selectedPaymentsMethod == label ? Colors.white : Colors.black87,
      ),
    );
  }

  Widget buildStyledFormField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    String? hintText,
    TextInputType keyboardType = TextInputType.text,
    String? prefixText,
    bool readOnly = false,
  }) {
    return TextFormField(
      controller: controller,
      readOnly: readOnly,
      keyboardType: keyboardType,
      style: TextStyle(fontSize: 16, color: Colors.black87),
      decoration: InputDecoration(
        prefixText: prefixText,
        labelText: labelText,
        hintText: hintText,
        hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 14),
        filled: true,
        fillColor: Colors.grey.shade100,
        prefixIcon: Icon(icon, color: Colors.blueAccent),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blueAccent, width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blueAccent, width: 2),
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      ),
    );
  }

  Future<void> sendInvoiceDataToServer(Map<String, dynamic> invoiceData) async {
    try {
      final jsonData = jsonEncode(invoiceData);
      _channel.sink.add(jsonData);
      print('Invoice data sent to server: $jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  // Cheque-specific controllers
  TextEditingController chequeNumberController = TextEditingController();
  TextEditingController chequeAmountController = TextEditingController();
  TextEditingController chequeNameController = TextEditingController();
  TextEditingController chequeBankController = TextEditingController();
  TextEditingController chequeDateController = TextEditingController();
  Widget buildChequeDetails() {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: buildStyledFormField(
                  controller: chequeNumberController,
                  labelText: 'Cheque Number',
                  icon: Icons.numbers,
                  hintText: 'Enter cheque number',
                  keyboardType: TextInputType.number,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: buildStyledFormField(
                  controller: chequeAmountController,
                  labelText: 'Cheque Amount',
                  icon: Icons.currency_rupee,
                  hintText: 'Enter amount',
                  keyboardType: TextInputType.number,
                  prefixText: '₹ ',
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                      builder: (context, child) {
                        return Theme(
                          data: Theme.of(context).copyWith(
                            colorScheme: const ColorScheme.light(
                              primary: Colors.blueAccent,
                              onPrimary: Colors.white,
                              onSurface: Colors.black,
                            ),
                          ),
                          child: child!,
                        );
                      },
                    );
                    if (picked != null) {
                      chequeDateController.text =
                          "${picked.day}/${picked.month}/${picked.year}";
                    }
                  },
                  child: buildStyledFormField(
                    controller: chequeDateController,
                    labelText: 'Cheque Date',
                    icon: Icons.calendar_today,
                    hintText: 'Select date',
                    readOnly: true,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: buildStyledFormField(
                  controller: chequeNameController,
                  labelText: 'Cheque Holder Name',
                  icon: Icons.person,
                  hintText: 'Enter name on cheque',
                ),
              ),
              const SizedBox(width: 15),
              Expanded(child: BankSearchDropdown()), // Dummy dropdown
            ],
          ),
        ],
      ),
    );
  }

  Widget buildPaymentMethodTile(
    BuildContext context,
    String method,
    IconData icon,
    String selectedMethod,
    ValueChanged<String?> onChanged,
  ) {
    return GestureDetector(
      onTap: () => onChanged(method),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 2, horizontal: 40),
        decoration: BoxDecoration(
          color: selectedMethod == method ? Colors.grey.shade200 : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selectedMethod == method
                ? Colors.grey.shade600
                : Colors.grey.shade300,
            width: 2,
          ),
          boxShadow: selectedMethod == method
              ? [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ]
              : [],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.grey.shade700, size: 28),
            const SizedBox(height: 8),
            Text(
              method,
              style: TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          width: 700,
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.white,
          ),
          child: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title
                  Text(
                    'Advance Payment',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  SizedBox(height: 10),

                  // Total Advance Amount Display
                  Text(
                    'Total Advance Amount: ₹${totalAmount.fold(0.0, (sum, item) => sum + item)}',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent,
                    ),
                  ),
                  Divider(),

                  // Payment Method Selection
                  Text(
                    'Select Payment Method',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),

                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      _buildPaymentChip(context, setState, 'Cash', Icons.money),
                      _buildPaymentChip(
                        context,
                        setState,
                        'Card',
                        Icons.credit_card,
                      ),
                      _buildPaymentChip(
                        context,
                        setState,
                        'UPI',
                        Icons.phone_android,
                      ),
                      _buildPaymentChip(
                        context,
                        setState,
                        'Cheque',
                        Icons.account_balance_wallet,
                      ),
                      _buildPaymentChip(
                        context,
                        setState,
                        'Others',
                        Icons.more_horiz,
                      ),
                    ],
                  ),
                  SizedBox(height: 10),

                  // Cheque Details Input (Visible only if 'Cheque' is selected)
                  if (selectedPaymentsMethod == 'Cheque') buildChequeDetails(),

                  // Advance Amount Input
                  if (selectedPaymentsMethod != 'Cheque')
                    TextField(
                      controller: advanceController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: 'Enter Advance Amount',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  SizedBox(height: 20),

                  // Submit Button
                  Align(
                    alignment: Alignment.center,
                    child: ElevatedButton(
                      onPressed: () async {
                        double advanceAmount =
                            double.tryParse(advanceController.text) ?? 0.0;

                        if (advanceAmount > total) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Advance amount cannot exceed the total amount!',
                                style: TextStyle(color: Colors.red),
                              ),
                            ),
                          );
                          return;
                        }

                        if (advanceAmount > 0) {
                          setState(() {
                            totalAmount.add(advanceAmount);
                          });
                          String currentDateTime =
                              DateTime.now().toIso8601String();
                          salesOrder.advanceDateTime ??= [];
                          salesOrder.advancePaymentType ??= [];
                          salesOrder.advanceDateTime.add(currentDateTime);
                          salesOrder.advancePaymentType.add(
                            selectedPaymentsMethod,
                          );

                          Map<String, dynamic> requestBody = {
                            "advanceAmount": totalAmount,
                            "advanceDateTime": salesOrder.advanceDateTime,
                            "advancePaymentType": salesOrder.advancePaymentType,
                          };

                          try {
                            String jsonadvanceSalesOrder = jsonEncode({
                              "data": requestBody,
                              "saleOrderNo": salesOrder.saleOrderNo,
                              "type": "patchSaleOrder",
                              "sync": "No",
                              "edit": "No",
                            });

                            print(
                              '📝 Invoice order invoiceJSON data to send: $jsonadvanceSalesOrder',
                            );

                            print(
                              "🖨️ Initialized receipt printer with current sales order details.",
                            );
                            print("📡 Sending invoice data via WebSocket...");
                            await sendInvoiceDataToServer(
                              jsonDecode(jsonadvanceSalesOrder),
                            );
                            // final response = await http.patch(
                            //   Uri.parse(
                            //     'http://$ipAddress/CurrentOrder/withoutpagination/${salesOrder.salesOrderId}',
                            //   ),
                            //   headers: {"Content-Type": "application/json"},
                            //   body: jsonEncode(requestBody),
                            // );

                            // if (response.statusCode == 200) {
                            //   apiSalesprovider.fetchAllOrders();
                            //   Navigator.of(context).pop();
                            //   ScaffoldMessenger.of(context).showSnackBar(
                            //     SnackBar(
                            //       content: Text(
                            //         'Advance payment updated successfully!',
                            //       ),
                            //     ),
                            //   );
                            // } else {
                            //   ScaffoldMessenger.of(context).showSnackBar(
                            //     SnackBar(
                            //       content: Text(
                            //         'Failed to update advance payment.',
                            //       ),
                            //     ),
                            //   );
                            // }
                          } catch (e) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Error: $e')),
                            );
                          }
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Please enter a valid advance amount',
                              ),
                            ),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        backgroundColor: Colors.blueAccent,
                        foregroundColor: Colors.white,
                        elevation: 2,
                      ),
                      child: Text(
                        'Submit',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      );
    },
  );
}
