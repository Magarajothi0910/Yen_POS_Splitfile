import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:ai_barcode_scanner/ai_barcode_scanner.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:collection/collection.dart';
import '../../../../Global/advance-dialog.dart';
import '../../../../Global/custom_button_reuse.dart';
import '../../../../Global/custom_colors.dart';
import '../../../../Global/custom_sized_box.dart';
import '../../../../Global/smartsearchtextfield.dart';
import '../../../regular_mode_page/provider/regular_mode_screen_provider.dart';
import '../../sales_order_print/currentOrderPrint.dart';
import '../../sales_order_providers/cartProvider.dart';
import '../../sales_order_providers/detailsProvider.dart';
import '../../sales_order_providers/editcustomerscreenProvider.dart';
import '../create_salesOrder.dart/create_sales_order.dart';
import '../create_salesOrder.dart/editcustomerdetails.dart';
import '../create_salesOrder.dart/numeric_Calculator.dart';
import '../model/sales_order_model.dart';
import 'advance-dialog2.dart';
import 'services/get_sales_order_service.dart';

class AllOrdersPage extends StatefulWidget {
  const AllOrdersPage({super.key});

  @override
  _AllOrdersPageState createState() => _AllOrdersPageState();
}

class _AllOrdersPageState extends State<AllOrdersPage> {
  final TextEditingController _searchController = TextEditingController();
  final MobileScannerController _scannerController = MobileScannerController();
  Timer? _debounce;
  final bool _isAddingOrder = false;
  final Map<String, dynamic> mixbox = {};

  File? _pickedImage1;
  File? _pickedImage2;

  String _selectedFilter = "All Order";

  // The available filter options.
  final List<String> _filterOptions = [
    "All Order",
    "Pending",
    "Approved",
    "Cancel",
    "Rejected",
    'Confirm'
  ];

  Map<int, double> quantityChanges = {};
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final apiService = context.read<ApiServiceSalesOrderProvider>();
      final customerScreenProvider = context.read<EditCustomerScreenProvider>();
      customerScreenProvider.resetSelection();
      if (customerScreenProvider.selectedTransactionIndex != null &&
          customerScreenProvider.selectedTransactionIndex! >=
              apiService.filteredAllSalesOrders.length) {
        customerScreenProvider.resetSelection();
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final apiService = context.watch<ApiServiceSalesOrderProvider>();
    // final filteredSalesOrders = apiService.filteredAllSalesOrders;
    final filteredSalesOrders = apiService.filteredAllSalesOrders;
    // .map((order) => SalesOrderDisplay.fromMap(order))
    // .toList();

    @override
    void didChangeDependencies() {
      super.didChangeDependencies();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final apiService = context.read<ApiServiceSalesOrderProvider>();
        final customerScreenProvider =
            context.read<EditCustomerScreenProvider>();

        if (customerScreenProvider.selectedTransactionIndex != null &&
            customerScreenProvider.selectedTransactionIndex! >=
                apiService.filteredAllSalesOrders.length) {
          customerScreenProvider.resetSelection();
        }
      });
    }

    final cartProvider = Provider.of<CartProvider>(context);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _buildAppBar(context, apiService),
      body: Row(
        children: [
          Expanded(
            flex: 1,
            child: Consumer<EditCustomerScreenProvider>(
              builder: (context, customerScreenProvider, child) {
                return _buildOrderList(
                  filteredSalesOrders,
                  apiService,
                  customerScreenProvider,
                  customerScreenProvider.selectedTransactionIndex,
                );
              },
            ),
          ),
          const VerticalDivider(),
          Expanded(
            flex: 1,
            child: Consumer<EditCustomerScreenProvider>(
              builder: (context, customerScreenProvider, child) {
                return filteredSalesOrders.isNotEmpty &&
                        customerScreenProvider.selectedTransactionIndex != null
                    ? EditCustomerDetails(
                        key: ValueKey(
                          '${customerScreenProvider.selectedTransactionIndex}_${customerScreenProvider.isModifyMode}',
                        ),
                        selectedOrder:
                            //  filteredSalesOrders[
                            //     customerScreenProvider.selectedTransactionIndex!],
                            customerScreenProvider.selectedTransactionIndex !=
                                        null &&
                                    customerScreenProvider
                                            .selectedTransactionIndex! <
                                        filteredSalesOrders.length
                                ? filteredSalesOrders[customerScreenProvider
                                    .selectedTransactionIndex!]
                                : null,
                        isEditing: customerScreenProvider.isModifyMode,
                        orderType: 'AllOrder',
                      )
                    : _buildEmptyOrderState();
              },
            ),
          ),
          const VerticalDivider(),
          Consumer<EditCustomerScreenProvider>(
            builder: (context, customerScreenProvider, child) {
              return Expanded(
                child: _buildOrderDetails(
                  filteredSalesOrders,
                  customerScreenProvider.selectedTransactionIndex,
                  apiService,
                  cartProvider,
                  customerScreenProvider,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildOrderDetails(
    List<SalesOrderDisplay> filteredSalesOrders,
    int? selectedIndex,
    ApiServiceSalesOrderProvider apiService,
    CartProvider cartProvider,
    EditCustomerScreenProvider customerScreenProvider,
  ) {
    if (selectedIndex == null || filteredSalesOrders.isEmpty) {
      return _buildEmptyOrderState();
    }

    final salesOrder = filteredSalesOrders[selectedIndex];
    print('salesorder$salesOrder');
    print('salesorder.id${salesOrder.salesOrderId}');
    print('ModifiedOrder${salesOrder.modifiedOrders}');
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (salesOrder.status == 'Confirm Order')
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment
                      .center, // Center the buttons horizontally
                  children: [
                    if (!customerScreenProvider.isModifyMode)
                      ElevatedButton(
                        onPressed: () async {
                          double totalAdvanceAmount = salesOrder.advanceAmount!
                              .fold(0.0, (sum, value) => sum + value);

                          final result = await AdvanceAmountDialog.show(
                            context,
                            salesOrderId: salesOrder.salesOrderId,
                            advanceAmount: totalAdvanceAmount,
                          );
                          if (result != null) {
                            print('Remarks: ${result['remarks']}');
                            print('SalesPerson: ${result['salesPerson']}');
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              8.0,
                            ), // Small curve
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 6,
                          ),
                        ),
                        child: Text(
                          'Cancel Order',
                          style: TextStyle(color: Colors.white, fontSize: 10),
                        ),
                      ),
                    SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () {
                        customerScreenProvider.setModifyMode(
                          !customerScreenProvider.isModifyMode,
                        );
                        customerScreenProvider.quantityChanges.clear();
                        customerScreenProvider.increasedItems.clear();
                        customerScreenProvider.decreasedItems.clear();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: customerScreenProvider.isModifyMode
                            ? Colors.green
                            : Colors.blue,
                        padding: EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 6,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            8.0,
                          ), // Small curve
                        ),
                      ),
                      child: Text(
                        customerScreenProvider.isModifyMode
                            ? 'Cancel'
                            : 'Modify Order',
                        style: TextStyle(color: Colors.white, fontSize: 10),
                      ),
                    ),
                    if (customerScreenProvider.isModifyMode) SizedBox(width: 8),
                    if (customerScreenProvider.isModifyMode)
                      ElevatedButton(
                        onPressed: () => _showAddItemDialog(
                          context,
                          customerScreenProvider,
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 6,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.add, color: Colors.white, size: 14),
                            SizedBox(width: 4),
                            Text(
                              'Add Item',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                SizedBox(height: 16), // Add spacing below the buttons
              ],
            ),

          SizedBox(height: 16), // Add spacing between buttons and the header
          _buildOrderHeader(salesOrder),
          Divider(color: Colors.grey[400]),
          _buildOrderItemsList(salesOrder, customerScreenProvider),
          _buildOrderSummary(salesOrder, customerScreenProvider),
          _buildOrderActions(
            context,
            salesOrder,
            apiService,
            cartProvider,
            customerScreenProvider,
          ),
        ],
      ),
    );
  }

  AppBar _buildAppBar(
    BuildContext context,
    ApiServiceSalesOrderProvider apiProvider,
  ) {
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Colors.white,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.start, // Align title to the left
        children: [
          Text(
            'All Orders',
            style: TextStyle(color: Colors.black), // Customize text style
          ),
        ],
      ),
      centerTitle: false, // Ensures the title stays on the left
      actions: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: FutureBuilder<List<ConnectivityResult>>(
            future: Connectivity().checkConnectivity(),
            builder: (context, snapshot) {
              String status = "Checking...";
              Color statusColor = Colors.orange;
              IconData statusIcon = Icons.signal_wifi_off;

              if (snapshot.connectionState == ConnectionState.done) {
                if (snapshot.hasData && snapshot.data!.isNotEmpty) {
                  ConnectivityResult connectivity = snapshot.data!.first;
                  switch (connectivity) {
                    case ConnectivityResult.wifi:
                    case ConnectivityResult.mobile:
                      status = "Online";
                      statusColor = Colors.green;
                      statusIcon = Icons.signal_wifi_4_bar;
                      break;
                    case ConnectivityResult.none:
                      status = "Offline";
                      statusColor = Colors.red;
                      statusIcon = Icons.signal_wifi_off;
                      break;
                    default:
                      status = "Network Slow";
                      statusColor = Colors.orange;
                      statusIcon = Icons.signal_wifi_bad;
                  }
                }
              }

              return Row(
                children: [
                  Icon(statusIcon, color: statusColor),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      status,
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ],
      flexibleSpace: Align(
        alignment: Alignment.center,
        child: Padding(
          padding: const EdgeInsets.only(), // Adjust spacing
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center, // Center the buttons
            children: [
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushNamed('/current-orders');
                },
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0), // Small curve
                  ),
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  elevation: 2,
                ),
                child: Text('Current Order'),
              ),
              SizedBox(width: 10),
              ElevatedButton(
                onPressed: () {
                  // Handle "All Orders" action if needed

                  apiProvider.fetchAllOrders();
                },
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0), // Small curve
                  ),
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.blue,
                  elevation: 2,
                ),
                child: Text('All Orders'),
              ),
              SizedBox(width: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => SalesOrderScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0), // Small curve
                  ),
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  elevation: 2,
                ),
                child: Text('Create Order'),
              ),
            ],
          ),
        ),
      ),
      toolbarHeight: kToolbarHeight * 1, // Increase height for buttons layout
    );
  }

  Widget _buildOrderList(
    List<SalesOrderDisplay> filteredSalesOrders,
    ApiServiceSalesOrderProvider apiService,
    EditCustomerScreenProvider customerprovider,
    int? selectedIndex,
  ) {
    final String todayDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
    final ordersByDate = groupBy(
      filteredSalesOrders.where((order) =>
          (apiService.groupByDeliveryDate
              ? order.deliveryDate
              : order.orderDate) !=
          null),
      (SalesOrderDisplay order) => apiService.groupByDeliveryDate
          ? order.deliveryDate!
          : order.orderDate!,
    );

    // Sort the dates with proper null handling
    final sortedDates = ordersByDate.keys.toList()
      ..sort((a, b) {
        try {
          final dateA = DateFormat('dd-MM-yyyy').parse(a);
          final dateB = DateFormat('dd-MM-yyyy').parse(b);
          return dateA.compareTo(dateB);
        } catch (e) {
          return 0; // default to equal if parsing fails
        }
      });
    String? lastDisplayedDate;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SmartSearchField(
                controller: _searchController,
                onSearch: apiService.searchOrders,
              ),
              const SizedBox(height: 10),
              // Date Range Picker
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () async {
                        final selectedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                        );
                        if (selectedDate != null) {
                          apiService.setStartDate(selectedDate);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        elevation: 2,
                      ),
                      child: Text(
                        apiService.startDate != null
                            ? DateFormat(
                                'dd-MM-yyyy',
                              ).format(apiService.startDate!)
                            : 'Start Date',
                        style: TextStyle(fontSize: 10, color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () async {
                        final selectedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                        );
                        if (selectedDate != null) {
                          apiService.setEndDate(selectedDate);
                          apiService.fetchFilteredOrders(
                            startDate: apiService.startDate,
                            endDate: apiService.endDate,
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        elevation: 2,
                      ),
                      child: Text(
                        apiService.endDate != null
                            ? DateFormat(
                                'dd-MM-yyyy',
                              ).format(apiService.endDate!)
                            : 'End Date',
                        style: TextStyle(fontSize: 10, color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _selectedFilter,
                      decoration: InputDecoration(
                        labelText: 'Filter Orders',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      items: _filterOptions.map((String filter) {
                        return DropdownMenuItem<String>(
                          value: filter,
                          child: Text(filter),
                        );
                      }).toList(),
                      onChanged: (String? newFilter) {
                        if (newFilter != null) {
                          setState(() {
                            _selectedFilter = newFilter;
                          });
                          // Call the filtering method from the provider.
                          apiService.filterOrdersByStatus(newFilter);
                          print('called$newFilter');
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '${apiService.groupByDeliveryDate ? 'Orders by deliverydate' : 'Orders by OrderDate'}',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            IconButton(
              icon: Icon(
                apiService.groupByDeliveryDate
                    ? Icons.arrow_downward // Sorting by Delivery Date
                    : Icons.arrow_upward, // Sorting by Order Date
                color: Colors.blue,
              ),
              onPressed: () {
                apiService.toggleGrouping();
              },
              tooltip: apiService.groupByDeliveryDate
                  ? 'Sorting by Delivery Date'
                  : 'Sorting by Order Date',
            ),
          ],
        ),
        Expanded(
          child: apiService.isLoading
              ? const Center(child: CircularProgressIndicator())
              : filteredSalesOrders.isEmpty
                  ? const Center(child: Text("No orders available"))
                  : ListView.builder(
                      itemCount: sortedDates.length,
                      itemBuilder: (context, index) {
                        final date = sortedDates[index];
                        final orders = ordersByDate[date]!;
                        final displayDate = date == todayDate ? "Today" : date;
                        final showDateHeader = lastDisplayedDate != date;

                        if (showDateHeader) {
                          lastDisplayedDate = date;
                        }
                        final currentDate = DateTime.now();
                        final parsedDate = DateFormat('dd-MM-yyyy').parse(date);
                        final isPastDate = parsedDate.isBefore(
                          currentDate.subtract(Duration(days: 1)),
                        );

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (showDateHeader)
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 5,
                                ),
                                child: Text(
                                  displayDate,
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color:
                                        isPastDate ? Colors.red : Colors.black,
                                  ),
                                ),
                              ),
                            ...orders.map((order) {
                              final orderIndex = filteredSalesOrders.indexOf(
                                order,
                              );
                              return Card(
                                color: order.status == "dispatched"
                                    ? Colors.red[200]
                                    : Colors.white,
                                margin: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 5,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 4,
                                            ),
                                            decoration: BoxDecoration(
                                              color: Colors.indigo[200],
                                              borderRadius:
                                                  BorderRadius.circular(
                                                4,
                                              ),
                                            ),
                                            child: Text(
                                              order.orderType ?? '',
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 8),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              'Order ID',
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: Colors.grey[700],
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            child: Text(
                                              'Order Taken By',
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: Colors.grey[700],
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            child: Text(
                                              'Status',
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: Colors.grey[700],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      ListTile(
                                        title: Row(
                                          children: [
                                            Expanded(
                                              child: Text(order.saleOrderNo),
                                            ),
                                            Expanded(
                                              child: Text(
                                                order.employeeName ?? 'N/A',
                                              ),
                                            ),
                                            Expanded(child: Text(order.status)),
                                          ],
                                        ),
                                        selected: selectedIndex == orderIndex,
                                        onTap: () => setState(() {
                                          customerprovider
                                              .handleTransactionSelection(
                                            orderIndex,
                                          );
                                        }),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ],
                        );
                      },
                    ),
        ),
      ],
    );
  }

  Widget _buildEmptyOrderState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.shopping_cart_outlined,
            size: 100,
            color: const Color.fromARGB(255, 97, 220, 236),
          ),
          SizedBox(height: 20),
          Text(
            "Select an order to view details",
            style: TextStyle(color: Colors.grey, fontSize: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderItemTile(
    SalesOrderDisplay salesOrder,
    int index,
    EditCustomerScreenProvider customerProvider,
  ) {
    final isKg = salesOrder.uom[index].toLowerCase() == 'kg' ||
        salesOrder.uom[index].toLowerCase() == 'kgs';
    final quantity = isKg
        ? salesOrder.qty[index].toStringAsFixed(3) ?? ''
        : salesOrder.qty[index].toStringAsFixed(0) ?? '';
    final isBoxItem = salesOrder.isBoxItem != null &&
        salesOrder.isBoxItem!.length > index &&
        salesOrder.isBoxItem![index].toLowerCase() == "yes";

    Map<String, dynamic>? modifiedItem;
    bool hasIncrease = false;
    bool hasDecrease = false;

    if (customerProvider.isModifyMode) {
      int increasedIndex = customerProvider.increasedItems.indexWhere(
          (element) =>
              element['varianceName'] == salesOrder.varianceName[index]);
      if (increasedIndex != -1) {
        modifiedItem = customerProvider.increasedItems[increasedIndex];
        hasIncrease = true;
      } else {
        // int decreasedIndex = customerProvider.decreasedItems.indexWhere(
        //     (element) =>
        //         element['varianceName'] == salesOrder.varianceName[index]);
        // if (decreasedIndex != -1) {
        //   modifiedItem = customerProvider.decreasedItems[decreasedIndex];
        //   hasDecrease = true;
        // }
        int decreasedIndex = customerProvider.decreasedItems.indexWhere(
            (element) =>
                element['varianceName'] == salesOrder.varianceName[index]);
        if (decreasedIndex != -1) {
          var duplicates = customerProvider.decreasedItems
              .where((element) =>
                  element['varianceName'] == salesOrder.varianceName[index])
              .length;
          if (duplicates > 1) {
            print(
                "⚠️ Warning: Multiple decreasedItems entries for ${salesOrder.varianceName[index]}");
          }
          modifiedItem = customerProvider.decreasedItems[decreasedIndex];
          hasDecrease = true;
        }
      }
    }

    String newQuantityText = '';
    String newAmountText = '';
    Color modificationColor = Colors.green;

    int currentQty = salesOrder.qty[index];
    double currentWeight = isKg ? salesOrder.weight[index] : 0.0;
    double currentAmount = salesOrder.amount[index];

    if (modifiedItem != null) {
      if (isKg) {
        double modifiedWeight = modifiedItem['weight'] ?? 0.0;
        double newWeight = hasIncrease
            ? currentWeight + modifiedWeight
            : currentWeight - modifiedWeight;
        newQuantityText = '${newWeight.toStringAsFixed(2)}';
        double modifiedAmount = modifiedItem['amount'] ?? 0.0;
        double newAmount = hasIncrease
            ? currentAmount + modifiedAmount
            : currentAmount - modifiedAmount;
        newAmountText = '₹${newAmount.toStringAsFixed(2)}';
        modificationColor = hasIncrease ? Colors.green : Colors.red;
      } else {
        double modifiedQty = modifiedItem['quantity'] ?? 0.0;
        double newQty =
            hasIncrease ? currentQty + modifiedQty : currentQty - modifiedQty;
        newQuantityText = '${newQty.toStringAsFixed(0)}';
        double modifiedAmount = modifiedItem['amount'] ?? 0.0;
        double newAmount = hasIncrease
            ? currentAmount + modifiedAmount
            : currentAmount - modifiedAmount;
        newAmountText = '₹${newAmount.toStringAsFixed(2)}';
        modificationColor = hasIncrease ? Colors.green : Colors.red;
      }
    }

    Map<String, dynamic> _createItemMap() {
      return {
        'varianceName': salesOrder.varianceName[index],
        'itemName':
            salesOrder.itemName != null && salesOrder.itemName!.length > index
                ? salesOrder.itemName![index]
                : salesOrder.varianceName[index],
        'varianceUom': salesOrder.uom[index],
        'variancePrice': salesOrder.price[index],
        'variancetax': salesOrder.tax != null && salesOrder.tax!.length > index
            ? salesOrder.tax![index]
            : 0,
        'varianceitemCode':
            salesOrder.itemCode != null && salesOrder.itemCode!.length > index
                ? salesOrder.itemCode![index]
                : '',
        'existingQuantity': salesOrder.qty[index],
        'existingWeight': isKg ? salesOrder.weight[index] : 0.0,
        'existingAmount': salesOrder.amount[index],
        'originalIndex': index,
      };
    }

    // Show default UI if not in modify mode
    if (!customerProvider.isModifyMode) {
      return Column(
        children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(
              salesOrder.varianceName[index],
              style: TextStyle(
                fontSize: 11,
                color: isBoxItem ? Colors.blue : Colors.grey,
                fontWeight: isBoxItem ? FontWeight.bold : FontWeight.normal,
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  !isKg
                      ? '$quantity ${salesOrder.uom[index]} x ₹${salesOrder.price[index]} RS'
                      : '${salesOrder.weight[index].toStringAsFixed(2)} ${salesOrder.uom[index]} ${salesOrder.qty[index]}qty x ₹${salesOrder.price[index]} RS',
                  style: TextStyle(fontSize: 11, color: Colors.grey),
                ),
              ],
            ),
            trailing: Text(
              '₹${salesOrder.amount[index].toStringAsFixed(2) ?? ''}',
              style: TextStyle(
                fontSize: 11,
                color: isBoxItem ? Colors.blue : Colors.black,
              ),
            ),
          ),
          // Divider(height: 1),
        ],
      );
    }

    // Modify mode UI
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Item Name
              Text(
                salesOrder.varianceName[index],
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: isBoxItem ? Colors.blue : Colors.black,
                ),
              ),
              SizedBox(height: 8),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Existing Quantity Column
                  // Column(
                  //   crossAxisAlignment: CrossAxisAlignment.start,
                  //   children: [
                  //     Text(
                  //       "Ex Qty",
                  //       style: TextStyle(
                  //         fontSize: 10,
                  //         color: Colors.grey,
                  //       ),
                  //     ),
                  //     Text(
                  //       isKg
                  //           ? '${currentWeight.toStringAsFixed(2)} ${salesOrder.uom[index]}'
                  //           : '$currentQty ${salesOrder.uom[index]}',
                  //       style: TextStyle(
                  //         fontSize: 12,
                  //         fontWeight: FontWeight.bold,
                  //       ),
                  //     ),
                  //   ],
                  // ),

                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isKg ? "Ex Weight" : "Ex Qty",
                        style: TextStyle(fontSize: 10, color: Colors.grey),
                      ),
                      isKg
                          ? GestureDetector(
                              onTap: () => _showWeightCalculator(
                                context,
                                _createItemMap(),
                                // customerProvider,
                              ),
                              child: Text(
                                '${currentWeight.toStringAsFixed(2)} ${salesOrder.uom[index]}',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )
                          : Text(
                              '$currentQty ${salesOrder.uom[index]}',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ],
                  ),
                  // New Quantity Controls
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "New Qty",
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 4),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Decrease Button
                            GestureDetector(
                              onTap: () {
                                print('1.................................');
                                double decrementValue = 1;
                                customerProvider.updateItemInOrder(
                                    _createItemMap(), -decrementValue, index);
                              },
                              child: Container(
                                padding: EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.red.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Icon(Icons.remove,
                                    size: 18, color: Colors.red),
                              ),
                            ),

                            // Quantity Display
                            GestureDetector(
                              onTap: () => _showQuantityEditDialog(
                                context,
                                item: _createItemMap(),
                                // currentQty: isKg
                                //     ? currentWeight
                                //     : currentQty.toDouble(),
                                isKg: isKg,
                                customerProvider: customerProvider,
                                index: index,
                              ),
                              child: Container(
                                margin: EdgeInsets.symmetric(horizontal: 8),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.blue),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  isKg
                                      ? (modifiedItem != null
                                          ? '${(hasIncrease ? currentWeight + modifiedItem['weight'] : currentWeight - modifiedItem['weight']).toStringAsFixed(2)}'
                                          : currentWeight.toStringAsFixed(2))
                                      : (modifiedItem != null
                                          ? '${(hasIncrease ? currentQty + modifiedItem['quantity'] : currentQty - modifiedItem['quantity']).toInt()}'
                                          : currentQty.toString()),
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: modificationColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),

                            // Increase Button
                            GestureDetector(
                              onTap: () {
                                double incrementValue = 1.0;
                                customerProvider.updateItemInOrder(
                                    _createItemMap(), incrementValue, index);
                              },
                              child: Container(
                                padding: EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.green.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Icon(Icons.add,
                                    size: 18, color: Colors.green),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 8),

              // Amount Row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Ex Amount
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Amt",
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        '₹${currentAmount.toStringAsFixed(2)}',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),

                  // New Amount
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "New Amt",
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        modifiedItem != null ? newAmountText : '-',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: modificationColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        Divider(height: 1),
      ],
    );
  }

// Helper widgets for table cells

  Widget _buildOrderItemsList(
    SalesOrderDisplay salesOrder,
    EditCustomerScreenProvider customerprovider,
  ) {
    List<int> boxItemIndices = [];
    List<int> regularItemIndices = [];
    print('saleordermodification${salesOrder.isBoxItem}');
    for (int i = 0; i < salesOrder.varianceName.length; i++) {
      print('saleorderisboxitem${salesOrder.isBoxItem}');
      if (salesOrder.isBoxItem != null &&
          salesOrder.isBoxItem!.length > i &&
          salesOrder.isBoxItem![i].toLowerCase() == "yes") {
        boxItemIndices.add(i);
        print('boxitems$boxItemIndices');
      } else {
        regularItemIndices.add(i);
      }
    }

    final newItemsOnly = customerprovider.increasedItems
        .where(
            (item) => !salesOrder.varianceName.contains(item['varianceName']))
        .toList();
    return Expanded(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Order',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            // ListView.separated(
            //   shrinkWrap: true,
            //   physics: NeverScrollableScrollPhysics(),
            //   itemCount: salesOrder.varianceName.isNotEmpty
            //       ? salesOrder.varianceName.length
            //       : 0,
            //   itemBuilder: (context, index) {
            //     return _buildOrderItemTile(salesOrder, index, customerprovider);
            //   },
            //   separatorBuilder: (context, index) => SizedBox(height: 10),
            // ),

            if (boxItemIndices.isNotEmpty)
              Card(
                margin: EdgeInsets.symmetric(vertical: 8),
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Box Items",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                      Divider(),
                      Column(
                        children: boxItemIndices
                            .map((index) => _buildOrderItemTile(
                                salesOrder, index, customerprovider))
                            .toList(),
                      ),
                    ],
                  ),
                ),
              ),

            // Display regular items
            Column(
              children: regularItemIndices
                  .map((index) =>
                      _buildOrderItemTile(salesOrder, index, customerprovider))
                  .toList(),
            ),

            //  if (customerprovider.isModifyMode && customerprovider.increasedItems.isNotEmpty)
            // Column(
            //   crossAxisAlignment: CrossAxisAlignment.start,
            //   children: [
            //     SizedBox(height: 20),
            //     Text(
            //       'Added Items',
            //       style: TextStyle(
            //         fontSize: 11,
            //         fontWeight: FontWeight.bold,
            //         color: Colors.green,
            //       ),
            //     ),
            //     Divider(),
            //     ...customerprovider.increasedItems.map((item) => _buildAddedItemTile(item)).toList(),
            //   ],
            // ),
            // Divider(thickness: 1.5),

            if (customerprovider.isModifyMode && newItemsOnly.isNotEmpty)
              Card(
                margin: EdgeInsets.symmetric(vertical: 8),
                elevation: 2,
                color: Colors.green[50],
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            "Newly Added Items",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                          SizedBox(width: 8),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              'Additions',
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.green,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Divider(),
                      ...newItemsOnly.map((item) {
                        final uom = item['varianceUom']?.toString() ?? '';
                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(
                            item['varianceName']?.toString() ?? 'New Item',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                          subtitle: Text(
                            '${item['quantity']?.toStringAsFixed(0) ?? '1'} $uom x ₹${item['variancePrice']?.toStringAsFixed(2) ?? '0.00'}',
                            style: TextStyle(fontSize: 11),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '₹${item['amount']?.toStringAsFixed(2) ?? '0.00'}',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.delete,
                                    size: 20, color: Colors.red),
                                onPressed: () =>
                                    customerprovider.removeAddedItem(item),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ],
                  ),
                ),
              ),

            if (salesOrder.toApprove != null &&
                salesOrder.toApprove!.isNotEmpty) ...[
              Text(
                'toapprove Items',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: salesOrder.toApprove!.length,
                itemBuilder: (context, modifyIndex) {
                  final toApproveOrder = salesOrder.toApprove![modifyIndex];

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.0),
                        child: Row(
                          children: [
                            // Icon(Icons.edit, size: 14, color: Colors.grey),
                            SizedBox(width: 8),
                          ],
                        ),
                      ),
                      ListView.separated(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: toApproveOrder.varianceName.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text(
                              toApproveOrder.varianceName[index],
                              style: TextStyle(fontSize: 11),
                            ),
                            subtitle: Text(
                              '${toApproveOrder.qty[index]} ${toApproveOrder.uom[index]} x ₹${toApproveOrder.price[index].toStringAsFixed(2)}',
                              style: TextStyle(fontSize: 10),
                            ),
                            trailing: Text(
                              '₹${toApproveOrder.amount[index].toStringAsFixed(2)}',
                              style: TextStyle(fontSize: 11),
                            ),
                          );
                        },
                        separatorBuilder: (context, index) =>
                            SizedBox(height: 5),
                      ),
                      Divider(),
                    ],
                  );
                },
              ),
              // Divider(thickness: 1.5),
              SizedBox(height: 20),
            ],
            Divider(thickness: 1.5),
            // if (salesOrder.modifiedOrders == null)

            if (salesOrder.modifiedOrders != null &&
                salesOrder.modifiedOrders!.isNotEmpty) ...[
              Text(
                'Existing Orders',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: salesOrder.modifiedOrders!.length,
                itemBuilder: (context, modifyIndex) {
                  final modifiedOrder = salesOrder.modifiedOrders![modifyIndex];
                  print('modifiedOrder$modifiedOrder');
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.0),
                        child: Row(
                          children: [
                            // Icon(Icons.edit, size: 14, color: Colors.grey),
                            SizedBox(width: 8),
                          ],
                        ),
                      ),
                      ListView.separated(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: modifiedOrder.varianceName.length,
                        itemBuilder: (context, index) {
                          print('modifyodrerfromallorders');
                          print(modifiedOrder.varianceName[index]);
                          return ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text(
                              modifiedOrder.varianceName[index],
                              style: TextStyle(fontSize: 11),
                            ),
                            // subtitle: Text(
                            //   '${modifiedOrder.qty[index]} ${modifiedOrder.uom[index]} x ₹${modifiedOrder.price[index].toStringAsFixed(2)}',
                            //   style: TextStyle(fontSize: 10),
                            // ),
                            subtitle: modifiedOrder.uom[index] == 'Kgs'
                                ? Text(
                                    'Weight: ${modifiedOrder.weight![index]}  x ₹${modifiedOrder.price[index].toStringAsFixed(2)}',
                                    style: TextStyle(fontSize: 10),
                                  )
                                : Text(
                                    '${modifiedOrder.qty[index]} ${modifiedOrder.uom[index]} x ₹${modifiedOrder.price[index].toStringAsFixed(2)}/-',
                                    style: const TextStyle(
                                      fontSize: 11,
                                      color: Colors.grey,
                                    ),
                                  ),
                            trailing: Text(
                              '₹${modifiedOrder.amount[index].toStringAsFixed(2)}',
                              style: TextStyle(fontSize: 11),
                            ),
                          );
                        },
                        separatorBuilder: (context, index) =>
                            SizedBox(height: 5),
                      ),
                      Divider(),
                    ],
                  );
                },
              ),
              // Divider(thickness: 1.5),
              SizedBox(height: 20),
            ],

            // Current Modifications Section (if in modify mode)

            // Original Order Section
          ],
        ),
      ),
    );
  }

  Future<void> _showWeightCalculator(
    BuildContext context,
    Map<String, dynamic> item,
  ) async {
    showDialog(
      context: context,
      builder: (context) {
        return NumericCalculator(
          onValueSelected: (double newWeight) {
            Provider.of<EditCustomerScreenProvider>(
              context,
              listen: false,
            ).updateWeight(item, newWeight);
          },
        );
      },
    );
  }

  //   // Future<void> _showWeightEditDialog(BuildContext context, Map<String, dynamic> item) async {
  //   // double? newWeight = await showDialog<double>(
  //   //   context: context,
  //   //   builder: (context) {
  //   //     return NumericCalculator(
  //   //       onValueSelected: (double selectedWeight) {
  //   //         Navigator.pop(context, selectedWeight); // Return the selected weight
  //   //       },
  //   //     );
  //   //   },
  //   // );

  //   if (newWeight != null && newWeight > 0) {
  //     setState(() {
  //       item['weight'] = newWeight; // Update the weight
  //     });
  //   }
  // }

  Widget _buildOrderSummary(
    SalesOrderDisplay salesOrder,
    EditCustomerScreenProvider customerprovider,
  ) {
    double totalAdvanceAmount = salesOrder.advanceAmount!.fold(
      0.0,
      (sum, value) => sum + value,
    );

    double modifiedTotal = customerprovider.isModifyMode
        ? customerprovider.calculateModifiedTotal(salesOrder)
        : salesOrder.totalAmount;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (salesOrder.discount > 0)
            Text(
              'Discount: ${salesOrder.discountAmount.toStringAsFixed(0)}%',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
            ),
          if (salesOrder.customCharge > 0)
            Text(
              'Custom Charge: ₹${salesOrder.customCharge.toStringAsFixed(0)}',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
            ),
          if (customerprovider.isModifyMode &&
              (customerprovider.increasedItems.isNotEmpty ||
                  customerprovider.decreasedItems.isNotEmpty))
            Text(
              'Original Total: ₹${salesOrder.totalAmount.toStringAsFixed(2)}',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                decoration: TextDecoration.lineThrough,
                color: Colors.grey,
              ),
            ),
          if (customerprovider.isModifyMode &&
              customerprovider.increasedItems.isNotEmpty)
            Text(
              'Added Items: +₹${customerprovider.increasedItems.fold(0.0, (sum, item) => sum + (item['"amount"'] ?? 0.0)).toStringAsFixed(2)}',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
          if (customerprovider.isModifyMode &&
              customerprovider.decreasedItems.isNotEmpty)
            Text(
              'Removed Items: -₹${customerprovider.decreasedItems.fold(0.0, (sum, item) => sum + (item['"amount"'] ?? 0.0)).toStringAsFixed(2)}',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          Text(
            'Total Amount: ₹${modifiedTotal.toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: customerprovider.isModifyMode ? Colors.blue : Colors.black,
            ),
          ),
          ...List.generate(salesOrder.advanceAmount!.length, (index) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 4.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    DateFormat(
                      'dd-MM-yyyy',
                    ).format(DateTime.parse(salesOrder.advanceDateTime[index])),
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                  ),
                  Text(
                    'Amount : ₹${salesOrder.advanceAmount![index].toStringAsFixed(2)}',
                    style: TextStyle(
                      fontSize: 11,
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            );
          }),
          Text(
            'Balance: ₹${(modifiedTotal - totalAdvanceAmount).toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: Colors.blue,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderActions(
    BuildContext context,
    SalesOrderDisplay salesOrder,
    ApiServiceSalesOrderProvider apiService,
    CartProvider cartProvider,
    EditCustomerScreenProvider customerscreenprovider,
  ) {
    double totalAdvanceAmount = salesOrder.advanceAmount!.fold(
      0.0,
      (sum, value) => sum + value,
    );
    final total = salesOrder.totalAmount - totalAdvanceAmount;
    double modifiedTotal = customerscreenprovider.isModifyMode
        ? customerscreenprovider.calculateModifiedTotal(salesOrder)
        : salesOrder.totalAmount;
    return Column(
      children: [
        SizedBox(height: 20),
        Row(
          mainAxisAlignment:
              MainAxisAlignment.center, // Center buttons horizontally
          children: [
            // Show "Send to Approval" button if there are decreased items
            if (customerscreenprovider.decreasedItems.isNotEmpty)
              CustomButton(
                text: 'Send to Approval',
                onPressed: () async {
                  customerscreenprovider.sendToApproval(
                    salesOrder,
                    customerscreenprovider.increasedItems,
                    customerscreenprovider.decreasedItems,
                    customerscreenprovider.recordedFilePath.isNotEmpty
                        ? customerscreenprovider.recordedFilePath
                        : null,
                    _pickedImage1,
                    _pickedImage1,
                    modifiedTotal,
                    total,
                    totalAdvanceAmount,
                    context,
                  );
                  if (context.mounted) {
                    customerscreenprovider.setModifyMode(false);
                  }
                },
                backgroundColor: Colors.orange, // Change button color as needed
                textColor: CustomColors.whiteColor,
                padding: EdgeInsets.symmetric(horizontal: 25, vertical: 11),
              ),

            if (customerscreenprovider.isModifyMode &&
                customerscreenprovider.decreasedItems.isEmpty) ...[
              CustomButton(
                text: 'Save Changes',
                onPressed: () async {
                  print('save changes pressed');
                  // No need to capture the result, just call the method
                  customerscreenprovider.showAdvancePaymentPopup(
                    context,
                    salesOrder,
                    customerscreenprovider.increasedItems,
                    customerscreenprovider.decreasedItems,
                    customerscreenprovider.recordedFilePath.isNotEmpty
                        ? customerscreenprovider.recordedFilePath
                        : null,
                    apiService,
                    _pickedImage1,
                    _pickedImage2,
                    modifiedTotal,
                  );
                  customerscreenprovider.isModifyMode == false;
                  // After this, you can perform any subsequent logic or update UI accordingly
                },
                backgroundColor: Colors.green,
                textColor: CustomColors.whiteColor,
                padding: EdgeInsets.symmetric(horizontal: 25, vertical: 11),
              ),
            ],

            if (customerscreenprovider.decreasedItems.isEmpty &&
                customerscreenprovider.isModifyMode == false) ...[
              // Add Advance Button
              CustomButton(
                text: 'Add Advance',
                onPressed: () => showPaymentDialog(context, salesOrder),
                backgroundColor: CustomColors.blueColor,
                textColor: CustomColors.whiteColor,
                padding: EdgeInsets.symmetric(horizontal: 25, vertical: 11),
              ),
              SizedBox(width: 20), // Space between the buttons
              // Pay Button (only visible if the order status is 'Confirm Order')
              if (salesOrder.status == 'Confirm Order')
                CustomButton(
                  text: 'Pay ₹ ${total.toStringAsFixed(2)}',
                  onPressed: salesOrder.status != "SalesOrder Completed"
                      ? () => _showPaymentDialog(context, salesOrder)
                      : () {},
                  backgroundColor: salesOrder.status != "SalesOrder Completed"
                      ? CustomColors.primaryColor
                      : Colors.grey,
                  textColor: CustomColors.whiteColor,
                  padding: EdgeInsets.symmetric(horizontal: 25, vertical: 11),
                ),
            ],
          ],
        ),
      ],
    );
  }

  void _showConfirmationDialog(
    BuildContext context, {
    required String title,
    required String message,
    required VoidCallback onConfirm,
  }) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text("No"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                onConfirm();
              },
              child: Text("Yes"),
            ),
          ],
        );
      },
    );
  }

  void _showPaymentDialog(BuildContext context, SalesOrderDisplay salesOrder) {
    double totalAmount = salesOrder.balanceAmount;
    if (totalAmount != 0) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: CustomSizedBox(
              width: MediaQuery.of(context).size.width * 0.6,
              child: OrderManagementPayandPrint(
                totalAmount: totalAmount,
                holdBillId: '',
                orderId: salesOrder.salesOrderId,
                employee: salesOrder.employeeName,
                discount: salesOrder.discount,
                customerNumber: salesOrder.customerNumber,
                salesOrder: salesOrder,
              ),
            ),
          );
        },
      );
    }
  }

  void _showQuantityUpdateDialog(
    SalesOrderDisplay salesOrder,
    int index,
    EditCustomerScreenProvider customerProvider,
  ) {
    TextEditingController quantityController = TextEditingController();
    bool isKgUnit = salesOrder.uom[index].toLowerCase() == 'kg' ||
        salesOrder.uom[index].toLowerCase() == 'kgs';

    // Initial value for the quantity
    double currentQty = salesOrder.qty[index].toDouble();
    quantityController.text = currentQty.toString();
    debugPrint('current QTY ${currentQty.toString()}');
    if (isKgUnit) {
      // Show numeric calculator for kg/kgs units
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return NumericCalculator(
            onValueSelected: (double value) {
              customerProvider.updateQuantityWithWeight(
                salesOrder,
                index,
                value,
              );
            },
          );
        },
      );
    } else {
      // Show regular quantity update dialog for non-kg units
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Update Quantity'),
            backgroundColor: Colors.white,
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(salesOrder.varianceName[index]),
                SizedBox(height: 10),
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.remove),
                      color: Colors.blue,
                      onPressed: () {
                        currentQty = (currentQty - 1).clamp(
                          0.0,
                          double.infinity,
                        );
                        quantityController.text = currentQty.toString();
                      },
                    ),
                    Expanded(
                      child: TextField(
                        controller: quantityController,
                        keyboardType: TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: InputDecoration(
                          labelText: 'New Quantity',
                          hintText: 'Current: ${salesOrder.qty[index]}',
                          border: OutlineInputBorder(),
                        ),
                        style: TextStyle(fontSize: 20),
                        onChanged: (value) {
                          double? newQty = double.tryParse(value);
                          if (newQty != null) {
                            currentQty = newQty;
                          }
                        },
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.add),
                      color: Colors.blue,
                      onPressed: () {
                        currentQty += 1;
                        quantityController.text = currentQty.toString();
                      },
                    ),
                  ],
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
              TextButton(
                onPressed: () {
                  double? newQty = double.tryParse(quantityController.text);
                  if (newQty != null) {
                    customerProvider.updateQuantity(salesOrder, index, newQty);
                  }
                  Navigator.pop(context);
                },
                child: Text('Update'),
              ),
            ],
          );
        },
      );
    }
  }

  Widget _buildOrderHeader(SalesOrderDisplay salesOrder) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Item Name',
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              'Amount',
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ],
    );
  }

  void _showAddItemDialog(
    BuildContext parentContext,
    EditCustomerScreenProvider customerScreenProvider,
  ) {
    final searchController = TextEditingController();
    List<Map<String, dynamic>> searchResults = [];
    Timer? _debounceTimer;

    final regularModeProvider = Provider.of<RegularModeProvider>(
      parentContext,
      listen: false,
    );

    void performSearch(String query) {
      if (query.isEmpty) {
        searchResults = [];
        return;
      }

      final queryLower = query.toLowerCase();

      searchResults = regularModeProvider.originalItems
          .expand((item) => item['variances'] as List<dynamic>)
          .where((variance) {
            final name =
                variance['varianceName']?.toString().toLowerCase() ?? '';
            final code =
                variance['varianceitemCode']?.toString().toLowerCase() ?? '';
            final uom = variance['varianceUOM']?.toString().toLowerCase() ?? '';

            return name.contains(queryLower) ||
                code.contains(queryLower) ||
                uom.contains(queryLower);
          })
          .map((variance) => {
                'varianceName': variance['varianceName'],
                'varianceUom': variance['varianceUOM'],
                'variancePrice': variance['varianceDefaultPrice'],
                'varianceTax': variance['tax'] ?? 0.0,
                'weight': variance['weight'] ?? 0.0,
                'varianceitemCode': variance['varianceitemCode'],
                'itemName': _getItemNameForVariance(
                    regularModeProvider.originalItems,
                    variance['varianceName']),
              })
          .toList();
    }

    void _clearSearch() {
      searchController.clear();
      searchResults = [];
      if (_debounceTimer != null && _debounceTimer!.isActive) {
        _debounceTimer!.cancel();
      }
    }

    @override
    void dispose() {
      searchController.dispose();
      _debounceTimer?.cancel();
      super.dispose();
    }

    showDialog(
      context: parentContext,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Add Item'),
              content: Container(
                width: MediaQuery.of(context).size.width * 0.8,
                constraints: const BoxConstraints(maxWidth: 400),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: searchController,
                      decoration: InputDecoration(
                        hintText: 'Search by name, code or UOM',
                        prefixIcon: const Icon(Icons.search),
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () {
                            _clearSearch();
                            setState(() {});
                          },
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      autofocus: true,
                      onChanged: (query) {
                        if (_debounceTimer != null &&
                            _debounceTimer!.isActive) {
                          _debounceTimer!.cancel();
                        }

                        _debounceTimer =
                            Timer(const Duration(milliseconds: 300), () {
                          setState(() {
                            performSearch(query);
                          });
                        });
                      },
                    ),
                    const SizedBox(height: 16),
                    if (searchController.text.isNotEmpty &&
                        searchResults.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text('No items found'),
                      )
                    else if (searchResults.isNotEmpty)
                      SizedBox(
                        height: 300,
                        child: ListView.separated(
                          itemCount: searchResults.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, index) {
                            final item = searchResults[index];
                            return ListTile(
                              title: Text(item['varianceName'] ?? ''),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('${item['itemName'] ?? ''}'),
                                  const SizedBox(height: 4),
                                  Text(
                                    '${item['varianceUom'] ?? ''} • '
                                    '₹${item['variancePrice']?.toStringAsFixed(2) ?? '0.00'} • '
                                    'Code: ${item['varianceitemCode'] ?? ''}',
                                    style:
                                        Theme.of(context).textTheme.bodySmall,
                                  ),
                                ],
                              ),
                              onTap: () {
                                _showQuantityDialog(
                                  context,
                                  item,
                                  customerScreenProvider,
                                );
                              },
                            );
                          },
                        ),
                      ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Close'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  String _getItemNameForVariance(
      List<Map<String, dynamic>> items, String varianceName) {
    for (final item in items) {
      for (final variance in item['variances']) {
        if (variance['varianceName'] == varianceName) {
          return item['name'] ?? '';
        }
      }
    }
    return '';
  }

  void _showQuantityDialog(
    BuildContext context,
    Map<String, dynamic> item,
    EditCustomerScreenProvider customerScreenProvider,
  ) {
    final quantityController = TextEditingController(text: '1');

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add ${item['varianceName']}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: quantityController,
                decoration: const InputDecoration(
                  labelText: 'Quantity',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 16),
              Text(
                'Price: ₹${item['variancePrice']?.toStringAsFixed(2) ?? '0.00'}',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                // final quantity = int.tryParse(quantityController.text) ?? 1;
                // customerScreenProvider.addItemToOrder(
                //   item: item,
                //   quantity: quantity,
                // );
                double quantity = double.tryParse(quantityController.text) ?? 1;
                customerScreenProvider.addItemToOrder(
                  item,
                  quantity,
                );
                Navigator.pop(context); // Close quantity dialog
                Navigator.pop(context); // Close search dialog
              },
              child: const Text('Add to Order'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildAddedItemTile(
      Map<String, dynamic> item, EditCustomerScreenProvider customerProvider) {
    final isKg = item['varianceUom'].toLowerCase() == 'kg' ||
        item['varianceUom'].toLowerCase() == 'kgs';

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Item Name with "Added" tag
              Row(
                children: [
                  Text(
                    item['varianceName'],
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                  SizedBox(width: 8),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      'Added',
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),

              // Quantity Row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Quantity
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Quantity",
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        isKg
                            ? '${item['weight']?.toStringAsFixed(2) ?? '0.00'} ${item['varianceUom']}'
                            : '${item['quantity']?.toStringAsFixed(0) ?? '0'} ${item['varianceUom']}',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),

                  // Price
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "Price",
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        '₹${item['variancePrice']?.toStringAsFixed(2) ?? '0.00'}',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 8),

              // Amount Row with remove button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Amount
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Amount",
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        '₹${item['amount']?.toStringAsFixed(2) ?? '0.00'}',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),

                  // Remove button
                  IconButton(
                    icon: Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      // customerProvider.    (item);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
        Divider(height: 1),
      ],
    );
  }

  void _showQuantityEditDialog(
    BuildContext context, {
    required Map<String, dynamic> item,
    required bool isKg,
    required EditCustomerScreenProvider customerProvider,
    required int index,
  }) {
    // Get original values from the item
    final originalQty = item['existingQuantity'];
    final originalWeight = item['existingWeight'];

    // Calculate current displayed value based on existing modifications
    final currentDelta = customerProvider.quantityChanges[index] ?? 0;
    final currentValue =
        isKg ? (originalWeight + currentDelta) : (originalQty + currentDelta);

    TextEditingController controller = TextEditingController(
      text: currentValue.toStringAsFixed(isKg ? 2 : 0),
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Update Quantity'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isKg)
              NumericCalculator(
                // initialValue: currentValue,
                onValueSelected: (newValue) {
                  // Calculate delta from original value
                  final delta = newValue - originalWeight;
                  customerProvider.updateItemInOrder(item, delta, index);
                },
              )
            else
              TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'New Quantity',
                  border: OutlineInputBorder(),
                  suffixText: item['varianceUom'],
                ),
                onSubmitted: (value) {
                  final newQty = double.tryParse(value) ?? originalQty;
                  // Calculate delta from original value
                  final delta = newQty - originalQty;
                  customerProvider.updateItemInOrder(item, delta, index);
                  Navigator.pop(context);
                },
              ),
            SizedBox(height: 10),
            Text(
              'Original: ${isKg ? originalWeight.toStringAsFixed(2) : originalQty.toString()} ${item['varianceUom']}',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
        actions: isKg
            ? null
            : [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Cancel'),
                ),
                TextButton(
                  onPressed: () {
                    final newQty =
                        double.tryParse(controller.text) ?? originalQty;
                    // Calculate delta from original value
                    final delta = newQty - originalQty;
                    customerProvider.updateItemInOrder(item, delta, index);
                    Navigator.pop(context);
                  },
                  child: Text('Update'),
                ),
              ],
      ),
    );
  }
}
