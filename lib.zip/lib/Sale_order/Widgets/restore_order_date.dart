import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:yenpos/Global/Audio%20Player/audio_provider.dart';
import 'package:yenpos/Global/Widget/scaffold_global.dart';
import 'package:yenpos/Global/globals_data.dart' as globals;
import 'package:yenpos/Sale_order/Models/held_order_model.dart';
import 'package:yenpos/Sale_order/Provider/cartProvider.dart';
import 'package:yenpos/Sale_order/Provider/customerScreen_provider.dart';
import 'package:yenpos/Sale_order/Provider/detailsProvider.dart';
import 'package:yenpos/Sale_order/Provider/photoProvider.dart';

bool _isRestoringHeldOrder = false;

Future<void> restoreHeldOrderData(BuildContext context, HeldOrder order) async {
  if (_isRestoringHeldOrder) return;
  _isRestoringHeldOrder = true;

  // 🔥 Copy the context safely; do not use context of a closing modal
  final safeContext = Navigator.of(context).context;

  // 🔥 Always delay provider/messenger access until the current frame finishes
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    try {
      final customerScreenProvider = Provider.of<CustomerScreenProvider>(
        safeContext,
        listen: false,
      );

      final cartProvider = Provider.of<CartProvider>(
        safeContext,
        listen: false,
      );

      final detailsProvider = Provider.of<DetailsProvider>(
        safeContext,
        listen: false,
      );

      // -------------------------------
      // RESTORE CUSTOMER DETAILS
      // -------------------------------
      customerScreenProvider.dateController.text = order.deliveryDate ?? '';
      customerScreenProvider.timeController.text = order.deliveryTime ?? '';
      customerScreenProvider.setSelectedEvent(order.event);
      customerScreenProvider.setSelectedDeliveryType(order.deliveryType);

      customerScreenProvider.landmarkController.text = order.landmark ?? '';
      customerScreenProvider.addressController.text = order.address ?? '';
      customerScreenProvider.birthdaydateController.text =
          order.eventDate ?? '';
      customerScreenProvider.remarkController.text = order.remark ?? '';

      customerScreenProvider.patchHoldOrderId = order.holdOrderId ?? '';
      customerScreenProvider.setSelectedHoldOrderId(order.holdOrderId);

      customerScreenProvider.customerNameController.text =
          order.customerName ?? '';
      customerScreenProvider.mobileNoController.text =
          order.customerNumber ?? '';

      // Update combined field
      final mobile = customerScreenProvider.mobileNoController.text.trim();
      final name = customerScreenProvider.customerNameController.text.trim();
      customerScreenProvider.combinedController.text =
          (mobile.isNotEmpty && name.isNotEmpty)
          ? '$mobile - $name'
          : mobile.isNotEmpty
          ? mobile
          : name.isNotEmpty
          ? name
          : '';

      // Employees
      customerScreenProvider.searchController.text = order.employeeName ?? '';
      detailsProvider.filteredEmployeeFirstNames.clear();

      // -------------------------------
      // RESTORE CART ITEMS
      // -------------------------------
      if (order.itemName.isNotEmpty) {
        for (int i = 0; i < order.itemName.length; i++) {
          cartProvider.addItemToCart(
            CartItem(
              itemName: order.itemName[i],
              varianceName: order.varianceName[i],
              itemCode: order.itemCode[i],
              uom: order.uom[i],
              quantity: order.qty[i],
              weight: order.weight[i],
              pricePerKg: order.price[i],
              tax: order.tax[i],
              itemWiseDiscount: order.itemWiseDiscount?[i] ?? 0,
              itemWiseDiscountAmount: order.itemWiseDiscountAmount?[i] ?? 0,
              boxQuantity: order.boxQty,
            ),
          );
        }
      }

      // ---------------------------------
      // SUCCESS MESSAGE
      // ---------------------------------
      GlobalScaffold.showMessage(
        message: 'Held order restored successfully',
        backgroundColor: Colors.green,
        textColor: Colors.white,
      );

      // Close the bottom sheet AFTER restoring — safely
      if (Navigator.of(safeContext).canPop()) {
        Navigator.of(safeContext).pop();
      }
    } catch (e, stack) {
      print("❌ Error restoring data: $e\n$stack");

      GlobalScaffold.showMessage(
        message: 'Failed to restore held order',
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    } finally {
      _isRestoringHeldOrder = false;
    }
  });
}
