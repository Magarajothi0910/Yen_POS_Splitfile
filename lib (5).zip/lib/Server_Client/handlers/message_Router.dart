import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:yen_pos/Global/global_data_manager.dart';
import 'package:yen_pos/Sale_order/Print_Receipt/invoicePrint.dart';
import 'package:yen_pos/Sale_order/Provider/customerScreen_provider.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handleHandShake.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_ModifyOrder.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_holdorder_websocket.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_invoice.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_invoiceNo.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_opsaleorder_generated.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_patch_approval_order.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_patchsaleorder.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_salesReturn.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_salesapproval.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_shift.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/handle_sync_invoice.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/invoice_patch_saleorder.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/message_handler_websocket_saleorder.dart';
import 'package:yen_pos/Server_Client/handlers/Webscoekt_handler/websocket_patch_saleorder.dart';

import 'package:yen_pos/Server_Client/websocketService.dart';
import 'package:yen_pos/kotpreinvoice/handlers/updateTopPriorityHandlers.dart';

class MessageRouter {
  static Future<void> handle(
    String rawMessage,
    CustomerScreenProvider provider,
    SalesInvoiceReceiptPrinter printer,
    WebSocketService ws,
  ) async {
    debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    debugPrint('[WS] RAW MESSAGE RECEIVED');
    debugPrint(rawMessage);
    debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    final data = jsonDecode(rawMessage);
    final action = data['action'];

    debugPrint('[WS] ACTION ROUTED → $action');

    switch (action) {
      case 'salesOrderGenerated':
        debugPrint('[WS] Handling SALES ORDER');
        await handleSalesOrder(data, provider);
        break;

      case 'OpSalesOrderGenerated':
        debugPrint('[WS] Handling OP SALES ORDER');
        await handleOpSalesOrder(data, provider);
        break;

      case 'holdOrderGenerated':
        debugPrint('[WS] Handling HOLD ORDER (NO PRINT)');
        debugPrint(
          '[WS] HoldOrderId → ${data['holdOrder']?['data']?['holdOrderId']}',
        );
        await handleHoldOrder(data);
        break;

      case 'invoiceGenerated':
        debugPrint('[WS] Handling INVOICE GENERATION');
        await handleInvoice(data, printer);
        break;

      case 'patchsaleorderGenerated':
        debugPrint('[WS] Handling PATCH SALES ORDER');
        await handlePatchSalesOrder(data, provider);
        break;

      case 'modifyOrderGenerated':
        debugPrint('[WS] Handling MODIFY ORDER');
        await handleModifyOrder(data, provider);
        break;

      case 'salesApprovalOrderGenerated':
        debugPrint('[WS] Handling SALES APPROVAL');
        await handleApprovalOrder(data);
        break;

      case 'salesOrder_updated':
        debugPrint('[WS] Handling SALES ORDER UPDATE');
        await handleWebsocketPatchSalesOrder(data, provider);
        break;

      case 'approval_updated':
        debugPrint('[WS] Handling APPROVAL UPDATE');
        await handlePatchSalesApprovalOrder(data, provider);
        break;

      case 'patchInvoicesaleorderGenerated':
        debugPrint('[WS] Handling PATCH INVOICE SALES ORDER');
        await handleInvoicePatchSalesOrder(data, provider);
        break;

      case 'ApprovedsalesOrderGenerated':
        debugPrint('[WS] Handling APPROVED SALES ORDER');
        await handleWebsocketPatchSalesOrder(data, provider);
        break;

      case 'soStockDecreaseUpdate':
        debugPrint('[WS] STOCK DECREASE (SO)');
        debugPrint('Location → ${data['locationId']}');
        debugPrint('Variance → ${data['varianceName']}');
        debugPrint('UpdatedStock → ${data['updatedStock']}');
        break;

      case 'stockDecreaseUpdate':
      case 'stockIncreaseUpdate':
      case 'stock':
        debugPrint('[WS] LIVE STOCK UPDATE');
        _handleLiveStockUpdate(data);
        break;

      case 'salesReturnProcessed':
        debugPrint('[WS] Handling SALES RETURN');
        handleSalesReturn(data);
        break;

      case 'handshake':
        debugPrint('[WS] HANDSHAKE RECEIVED');
        handleHandShake(data);
        break;

      case 'syncInvoice':
        debugPrint('[WS] SYNC INVOICE');
        await handleSyncInvoice(data);
        break;

      case 'invoiceNoGenerated':
        debugPrint('[WS] INVOICE NUMBER GENERATED');
        handleInvoiceNo(data);
        break;

      case 'DineInStatus':
        debugPrint('[WS] DINE-IN STATUS UPDATE');
        handleKOT(data);
        break;

      case 'allDataResponse':
        debugPrint('[WS] ALL DATA RESPONSE');
        handleInvoices(data, printer);
        break;

      case 'subnetIpChanged':
        debugPrint('[WS] SUBNET IP CHANGED');
        handleIp(data);
        break;

      case 'priorityUpdate':
        debugPrint('[WS] PRIORITY UPDATE');
        handlePriorityUpdate(data);
        break;

      default:
        debugPrint('❌ [WS] UNKNOWN ACTION → $action');
        debugPrint('Payload → $data');
        break;
    }

    debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  }
}

void _handleLiveStockUpdate(Map<String, dynamic> data) {
  try {
    final String? action = data['action']?.toString();
    final String? locationId = data['locationId']?.toString();
    final String? varianceName = data['varianceName']?.toString();

    if (locationId == null || varianceName == null) {
      debugPrint("Invalid stock payload (missing branch/varianceName): $data");
      return;
    }

    double newStock = 0.0;
    double newStockSO = 0.0;

    // Handle different message formats gracefully
    if (action == 'stockIncreaseUpdate' || action == 'stockDecreaseUpdate') {
      final dynamic raw = data['updatedStock'];
      newStock = _parseToDouble(raw);
      newStockSO = 0.0; // older format didn't send SO
    } else if (action == 'stock') {
      newStock = _parseToDouble(data['systemStock']);
      newStockSO = _parseToDouble(data['systemstockSo']);
    } else {
      debugPrint("Unknown stock action: $action");
      return;
    }

    // Clean precision
    newStock = double.parse(newStock.toStringAsFixed(3));
    newStockSO = double.parse(newStockSO.toStringAsFixed(3));

    debugPrint(
      "LIVE STOCK RECEIVED → $locationId | $varianceName = $newStock (SO: $newStockSO)",
    );

    // 1. Update UI immediately
    GlobalDataManager().updateStockLive(
      locationId: locationId,
      varianceName: varianceName,
      systemStock: newStock,
      soStock: newStockSO,
    );

    // 2. Also sync to local Hive (only on client!)
    _applyRemoteStockUpdateToLocalHive(
      action: action,
      locationId: locationId,
      varianceName: varianceName,
      systemStock: newStock,
      systemstockSo: newStockSO,
    );
  } catch (e, st) {
    debugPrint("Stock update error: $e\n$st");
  }
}

// double _parseToDouble(dynamic value) {
//   if (value is num) return value.toDouble();
//   if (value is String) return double.tryParse(value) ?? 0.0;
//   return 0.0;
// }

// void _handleLiveStockUpdates(Map<String, dynamic> data) {
//   try {
//     final String? branchAlias = data['branchAlias']?.toString();
//     final String? varianceName = data['varianceName']?.toString();

//     final dynamic rawSystem = data['systemStock'];
//     final dynamic rawSystemSO = data['systemstockSo'];

//     if (branchAlias == null || varianceName == null) {
//       debugPrint("Invalid stock update payload: $data");
//       return;
//     }

//     double newSystem = _parseToDouble(rawSystem);
//     double newSystemSO = _parseToDouble(rawSystemSO);

//     // Clean precision
//     newSystem = double.parse(newSystem.toStringAsFixed(3));
//     newSystemSO = double.parse(newSystemSO.toStringAsFixed(3));

//     debugPrint("LIVE STOCK → $branchAlias | $varianceName = $newSystem (SO: $newSystemSO)");

//     GlobalDataManager().updateStockLive(
//       branchAlias: branchAlias,
//       varianceName: varianceName,
//       newStock: newSystem,
//       //newStockSO: newSystemSO, // if you have this param
//     );

//   } catch (e, st) {
//     debugPrint("Stock update error: $e\n$st");
//   }
// }

double _parseToDouble(dynamic value) {
  if (value is num) return value.toDouble();
  if (value is String) return double.tryParse(value) ?? 0.0;
  return 0.0;
}

/// Called from WebSocket listener on client only
Future<void> _applyRemoteStockUpdateToLocalHive({
  required String? action,
  required String locationId,
  required String varianceName,
  required double systemStock,
  required double systemstockSo,
}) async {
  // ──────── ONLY RUN ON CLIENT DEVICES (NOT ON SERVER) ────────
  if (const String.fromEnvironment('APP_TYPE', defaultValue: 'client') ==
      'server') {
    debugPrint("Skipping Hive update: Running in server mode");
    return;
  }

  debugPrint(
    "CLIENT: Applying remote stock update → $varianceName = $systemStock (SO: $systemstockSo)",
  );

  try {
    final box = await Hive.openBox('items');
    final hiveKey = 'branchwiseItems_$locationId';

    final dynamic boxedData = await box.get(hiveKey);
    if (boxedData == null) {
      debugPrint(
        "No local branch data for $locationId – cannot apply remote update",
      );
      return;
    }

    final globalData = Map<String, dynamic>.from(boxedData as Map);
    if (globalData['data'] == null) return;

    final branchwiseData = Map<String, dynamic>.from(globalData['data']);
    bool foundAndUpdated = false;

    for (final itemEntry in branchwiseData.entries) {
      final itemVal = Map<String, dynamic>.from(itemEntry.value);
      if (!itemVal.containsKey('variance')) continue;

      final varianceMap = Map<String, dynamic>.from(itemVal['variance']);
      if (!varianceMap.containsKey(varianceName)) continue;

      final variance = Map<String, dynamic>.from(varianceMap[varianceName]);
      if (!variance.containsKey('branchwise')) continue;

      final branchwiseMap = Map<String, dynamic>.from(variance['branchwise']);
      if (!branchwiseMap.containsKey(locationId)) continue;

      final branchData = Map<String, dynamic>.from(branchwiseMap[locationId]);

      final sysKey = 'systemStock';
      final soKey = 'systemstockSo';

      // Clean values
      final double newStock = double.parse(systemStock.toStringAsFixed(3));
      final double newSO = double.parse(systemstockSo.toStringAsFixed(3));

      branchData[sysKey] = newStock;
      branchData[soKey] = newSO;

      // Rebuild nested structure
      branchwiseMap[locationId] = branchData;
      variance['branchwise'] = branchwiseMap;
      varianceMap[varianceName] = variance;
      itemVal['variance'] = varianceMap;
      branchwiseData[itemEntry.key] = itemVal;

      foundAndUpdated = true;
      break;
    }

    if (foundAndUpdated) {
      globalData['data'] = branchwiseData;
      await box.put(hiveKey, globalData);
      debugPrint(
        "CLIENT: Hive updated successfully for $varianceName @ $locationId",
      );

      // Also notify UI via GlobalDataManager (your existing live update)
      GlobalDataManager().updateStockLive(
        locationId: locationId,
        varianceName: varianceName,
        systemStock: systemStock,
        soStock: systemstockSo,
        // newStockSO: systemstockSo,
      );
    } else {
      debugPrint("CLIENT: Variance '$varianceName' not found in local Hive");
    }
  } catch (e, st) {
    debugPrint("Failed to apply remote stock to local Hive: $e\n$st");
  }
}
