enum AppType { client, server }
