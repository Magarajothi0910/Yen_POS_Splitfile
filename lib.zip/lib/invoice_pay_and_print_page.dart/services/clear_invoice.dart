import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:yenpos/Global/globals_data.dart';

import 'package:intl/intl.dart';

DateTime getServerDateTime() {
  final date = currentDate.value; // e.g. "13-01-2026"
  final time = currentTime.value; // e.g. "10:33 AM"

  final formatter = DateFormat('dd-MM-yyyy hh:mm a');
   debugPrint(
      'Deleted ${date} ${time} invoices older than 2 days (Server Time)',
    );
  
  return formatter.parse('$date $time');
}


Future<void> cleanOldInvoices(Box box) async {
  final serverNow = getServerDateTime();
  const expiry = Duration(days: 2);

  final keysToDelete = <dynamic>[];

  for (final key in box.keys) {
    final value = box.get(key);

    if (value is Map && value['invoiceDateTime'] != null) {
      final invoiceDate =
          DateTime.parse(value['invoiceDateTime']); // ISO → OK

      if (serverNow.difference(invoiceDate) > expiry) {
        keysToDelete.add(key);
      }
    }
  }

  await box.deleteAll(keysToDelete);
}


