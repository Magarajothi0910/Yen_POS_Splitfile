import 'dart:typed_data';

import 'package:esc_pos_printer/esc_pos_printer.dart';
import 'package:flutter/material.dart';

import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:yenposapp/Global/customposcolumn.dart';
import 'package:yenposapp/screens/sales_order/screens/model/sales_order_model.dart';
// import 'package:yenposapp/Global/customposcolumn.dart' show createPosColumn, createPosStyles;
import '../../../Global/scaffold_global.dart';
import '../../printer_screen/provider/printer_config_provider.dart';

// class PrintUtility {
//   static final BlueThermalPrinter printer = BlueThermalPrinter.instance;

//   static Future<void> printSalesOrders(List<dynamic> salesOrders) async {
//     // Check if printer is connected
//     bool isConnected = await printer.isConnected ?? false;
//     if (!isConnected) {
//       // Show a message if not connected
//       GlobalScaffold.showMessage(
//         message: "Printer not connected",
//         backgroundColor: Colors.red,
//       );
//       return;
//     }

//     // Start printing
//     printer.printCustom("      Sales Orders      ", 2, 1);
//     printer.printCustom("-------------------------------", 1, 1);
//     printer.printCustom("S.No | OrdNo | Qty | Amount | Number", 1, 1);
//     printer.printCustom("-------------------------------", 1, 1);

//     int index = 1;
//     for (var order in salesOrders) {
//       String orderNo = order.orderNo ?? "N/A";
//       String qty = order.qty.toString();
//       String totalAmount = order.totalAmount.toStringAsFixed(2);
//       String customerNumber = order.customerNumber ?? "N/A";

//       printer.printCustom(
//         "${index.toString().padRight(4)}| ${orderNo.padRight(6)}| ${qty.padRight(3)}| ${totalAmount.padRight(6)}| ${customerNumber.padRight(10)}",
//         1,
//         0,
//       );
//       index++;
//     }

//     // Footer
//     printer.printCustom("-------------------------------", 1, 1);
//     printer.printCustom("Thank you for your purchase!", 1, 1);
//     printer.printNewLine();
//     printer.printNewLine();
//   }
// }

// class PrintUtility {
//   static Future<void> printSalesOrders(
//       BuildContext context, List<dynamic> salesOrders) async {
//     // Get printer IP from provider
//     print('salesOrders: ${salesOrders.length}');
//     final printerProvider =
//         Provider.of<PrinterProvider>(context, listen: false);
//     String? printerIp = printerProvider.getOverallPrinterIp();
//     print("Printer IP: $printerIp");

//     // Load the printer profile
//     final profile = await CapabilityProfile.load();
//     final printer = NetworkPrinter(PaperSize.mm80, profile);

//     // Try connecting to the printer
//     // final PosPrintResult res = await printer.connect(printerIp!, port: 9100);
//     final PosPrintResult res = await printer.connect(printerIp!, port: 9100);
//     print("Connection result: $res");
//     if (res != PosPrintResult.success) {
//       GlobalScaffold.showMessage(
//         message: "Unable to connect to printer at $printerIp. Error: $res",
//         backgroundColor: Colors.red,
//       );
//       printer.disconnect();
//       return;
//     }

//     if (res != PosPrintResult.success) {
//       GlobalScaffold.showMessage(
//         message: "Printer not connected: $res",
//         backgroundColor: Colors.red,
//       );
//       return;
//     }

//     // Start printing
//     printer.setStyles(PosStyles(
//       align: PosAlign.center,
//       height: PosTextSize.size2,
//       width: PosTextSize.size2,
//       bold: true,
//     ));
//     printer.text("Sales Orders");
//     printer.hr();

//     // Table Header
//     printer.setStyles(PosStyles(bold: true));
//     printer.text("S.No  | OrdNo  | Qty  | Amount  | Number");
//     printer.hr();

//     // Table Rows
//     int index = 1;
//     for (var order in salesOrders) {
//       // String orderNo = order.saleOrderNO ?? "N/A";
//       String orderNo = 'SOAR250021';
//       String qty = order.qty.toString();
//       String totalAmount = order.totalAmount.toStringAsFixed(2);
//       String customerNumber = order.customerNumber ?? "N/A";

//       printer.text(
//         "${index.toString().padRight(4)}| ${orderNo.padRight(6)}| ${qty.padRight(3)}| ${totalAmount.padRight(6)}| ${customerNumber.padRight(10)}",
//       );
//       index++;
//     }

//     // Footer
//     printer.hr();
//     printer.text("Thank you for your purchase!");
//     printer.feed(2);
//     printer.cut();
//     printer.disconnect();
//   }
// }

class PrintUtility {
  static Future<void> printSalesOrders(
      BuildContext context, List<dynamic> salesOrders) async {
    // Get printer IP from provider
    print('salesOrders: \${salesOrders.length}');
    final printerProvider =
        Provider.of<PrinterProvider>(context, listen: false);
    String? printerIp = printerProvider.getOverallPrinterIp();
    print("Printer IP: $printerIp");

    // Load the printer profile
    final profile = await CapabilityProfile.load();
    final printer = NetworkPrinter(PaperSize.mm80, profile);

    // Try connecting to the printer
    final PosPrintResult res = await printer.connect(printerIp!, port: 9100);
    print("Connection result: \$res");

    if (res != PosPrintResult.success) {
      GlobalScaffold.showMessage(
        message: "Unable to connect to printer at \$printerIp. Error: \$res",
        backgroundColor: Colors.red,
      );
      printer.disconnect();
      return;
    }

    // Start printing
    DateTime now = DateTime.now();
    String formattedDate = "${now.day}/${now.month}/${now.year}";

    // Title
    printer.setStyles(PosStyles(
      align: PosAlign.center,
      height: PosTextSize.size2,
      width: PosTextSize.size2,
      bold: true,
    ));
    printer.text("Sales Orders");
    printer.hr();

    // Dynamic Table Header
    printer.setStyles(PosStyles(bold: true, align: PosAlign.left));
    printer.text("S.No  Order No        Amount    Number");
    printer.hr();

    // Dynamic Table Rows
    int index = 1;
    for (var order in salesOrders) {
      String orderNo = "N/A";
      String totalAmount = order.totalAmount.toStringAsFixed(2);
      String customerNumber = order.customerNumber ?? "N/A";
      String line =
          "${index.toString().padRight(5)} ${orderNo.padRight(15)} ${totalAmount.padRight(10)} ${customerNumber}";
      printer.text(line);
      index++;
    }

    // Summary and QR
    printer.hr();
    printer.setStyles(PosStyles(align: PosAlign.center));
    printer.qrcode(
        "Orders: ${salesOrders.length}, Total: ${_calculateTotal(salesOrders)}",
        size: QRSize.Size8,
        cor: QRCorrection.H);
    printer.text("Order Summary");
    printer.text("Total Orders: ${salesOrders.length}");
    printer.text("Total Amount: ${_calculateTotal(salesOrders)}");
    printer.text("Date: $formattedDate");

    // Footer
    printer.hr();
    printer.text("Thank you for your purchase!");
    printer.feed(2);
    printer.cut();
    printer.disconnect();
  }

  // Helper to calculate total
  static String _calculateTotal(List<dynamic> salesOrders) {
    double total = 0;
    for (var order in salesOrders) {
      total += order.totalAmount;
    }
    return total.toStringAsFixed(2);
  }

// List<dynamic> todaySalesOrders = getTodaySalesOrders(); // Fetch today's orders
// PrintUtility.printSalesOrders(context, todaySalesOrders);
  List<dynamic> getTodaySalesOrders(dynamic allSalesOrders) {
    DateTime today = DateTime.now();
    return allSalesOrders.where((order) {
      DateTime orderDate =
          DateTime.parse(order.date); // Ensure date format matches
      return orderDate.year == today.year &&
          orderDate.month == today.month &&
          orderDate.day == today.day;
    }).toList();
  }

//  static  Future<void> printReceiptDetails(BuildContext context, List<dynamic> salesOrder,) async {
//    print('salesOrder$salesOrder');
//     DateTime now = DateTime.now();
//     String formattedDate = DateFormat('dd-MM-yyyy').format(now);
//     String formattedTime =
//         DateFormat('hh:mm a').format(now); // 12-hour format with AM/PM
//     final printerProvider =
//         Provider.of<PrinterProvider>(context, listen: false);
//     String printerIp = printerProvider.getOverallPrinterIp().toString();

//     print(printerIp);
//     final profile = await CapabilityProfile.load();
//     final printer = NetworkPrinter(PaperSize.mm80, profile);

//     final PosPrintResult res = await printer.connect(printerIp, port: 9100);

//     if (res == PosPrintResult.success) {
//       List<int> bytes;
//       final generator = Generator(PaperSize.mm80, profile);

//       // for (int copy = 0; copy < 2; copy++) {
//       bytes = []; // Reset bytes for each copy

//       bytes += generator.row([
//         createPosColumn(
//             width: 12,
//             text: '',
//             styles: createPosStyles(
//               align: PosAlign.center,
//               height: PosTextSize.size6,
//               width: PosTextSize.size6,
//               codeTable: 'CP1252',
//             )),
//       ]);
//       bytes += generator.row([
//         createPosColumn(
//             width: 12,
//             text: 'BestMummy',
//             styles: createPosStyles(
//               align: PosAlign.center,
//               height: PosTextSize.size1,
//               width: PosTextSize.size1,
//               codeTable: 'CP1252',
//             )),
//       ]);
//       bytes += generator.row([
//         createPosColumn(
//             width: 12,
//             text: 'Sweets & Cakes',
//             styles: createPosStyles(
//               align: PosAlign.center,
//               height: PosTextSize.size1,
//               width: PosTextSize.size1,
//               codeTable: 'CP1252',
//             )),
//       ]);
//       bytes += generator.feed(1);
//       bytes += generator.feed(1);
//       bytes += generator.row([
//         createPosColumn(
//             width: 12,
//             text: 'sales Order',
//             styles: createPosStyles(
//               align: PosAlign.center,
//               codeTable: 'CP1252',
//               height: PosTextSize.size1,
//               width: PosTextSize.size1,
//             )),
//       ]);
//       bytes += generator.feed(1);

//       // Add formatted date and time
//       bytes += generator.row([
//          createPosColumn(
//             width: 6,
//             text: 'Branch : Aranmanai',
//             styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//         createPosColumn(
//             width: 6,
//             text: 'Date: $formattedDate',
//             styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//         // createPosColumn(
//         //     width: 6,
//         //     text: 'Time: $formattedTime',
//         //     styles:
//         //         createPosStyles(align: PosAlign.right, codeTable: 'CP1252')),
//       ]);

//       bytes += generator.feed(1);

//       // bytes += generator.row([
//       //   createPosColumn(
//       //       width: 6,
//       //       text: 'Branch : Aranmanai',
//       //       styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//       //   createPosColumn(
//       //       width: 6,
//       //       text:  'SalesOrder',

//       //       styles:
//       //           createPosStyles(align: PosAlign.right, codeTable: 'CP1252')),
//       // ]);

//       bytes += generator.feed(1);

// // Print Sales Person and Customer Number on the same line
//       // bytes += generator.row([
//       //   createPosColumn(
//       //       width: 6,
//       //       text: 'SalesPerson : $employeeNameController',
//       //       styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//       //   createPosColumn(
//       //       width: 6,
//       //       text: 'C No: $customerNumberController',
//       //       styles:
//       //           createPosStyles(align: PosAlign.right, codeTable: 'CP1252')),
//       // ]);

//       bytes += generator.feed(1);

//       // Add headers for S.No, Item, Price, Qty, and Amount
//       // bytes += generator.row([
//       //   createPosColumn(
//       //       width: 1,
//       //       text: 'S.No',
//       //       styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//       //   createPosColumn(
//       //       width: 5,
//       //       text: 'Item',
//       //       styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//       //   createPosColumn(
//       //       width: 2,
//       //       text: '',
//       //       styles:
//       //           createPosStyles(align: PosAlign.right, codeTable: 'CP1252')),
//       //   createPosColumn(
//       //       width: 1,
//       //       text: '',
//       //       styles:
//       //           createPosStyles(align: PosAlign.right, codeTable: 'CP1252')),
//       //   createPosColumn(
//       //       width: 3,
//       //       text: 'Amount',
//       //       styles:
//       //           createPosStyles(align: PosAlign.right, codeTable: 'CP1252')),
//       // ]);

//       bytes += generator.feed(1);
//       double totalSGST = 0.0;
//       double totalCGST = 0.0;
//       double taxVaule = 0.0;
//       Map<double, double> sgstMap = {};
//       Map<double, double> cgstMap = {};

//       // Process each item
//       // for (var item in salesOrder.items) {
//       //   // Assuming tax is fetched as dynamic or int, ensure it's treated as double
//       //   double taxRate =
//       //       (item.tax as num).toDouble(); // num can be both int and double
//       //   double itemTotal = cartProvider.calculateSubtotal();
//       //   //     .toDouble(); // Ensure itemTotal is a double

//       //   double itemTax = itemTotal * (taxRate / 100);
//       //   double itemSGST = itemTax / 2;
//       //   double itemCGST = itemSGST;

//       //   // Update the maps with doubles
//       //   sgstMap[taxRate / 2] = (sgstMap[taxRate / 2] ?? 0.0) + itemSGST;
//       //   cgstMap[taxRate / 2] = (cgstMap[taxRate / 2] ?? 0.0) + itemCGST;
//       // }

//       // Adding cart items with item name, quantity, and price in the desired format
//       for (int i = 0; i < salesOrder.length; i++) {
//         // final item = cartItems[i];
//          for (int j = 0; j < salesOrder[i].varianceName.length; j++) { // Iterate through list
//     String varianceName = salesOrder[i].varianceName[j]; // Access element properly
//     int quantity = salesOrder[i].qty[j];
//     double price = salesOrder[i].price[j];

//     print("Variance: $varianceName, Quantity: $quantity, Price: $price");
//   }

//         double totalTax =100;
//         //  totalAmount * (taxRate / 100); // Total tax amount
//         double sgstAmount = totalTax / 2; // SGST amount
//         double cgstAmount = totalTax / 2;
//         // Calculate item amount
//         sgstMap[2 / 2] = (sgstMap[2 / 2] ?? 0.0) + sgstAmount;
//         cgstMap[2 / 2] = (cgstMap[2 / 2] ?? 0.0) + cgstAmount;
//         double amount = 2 * 2;
// //    void main() {
// //   List<String> yourList = ["Apple", "Banana", "Orange"];  // Sample data

// //   print("List content: $yourList");
// //   print("List length: ${yourList.length}");

// //   if (yourList.isNotEmpty) {  // ✅ Check before accessing
// //       print(yourList[0]);  // ✅ Safe indexing
// //   } else {
// //       print("Error: List is empty!");
// //   }
// // }

//         final String itemName = salesOrder.toString() ?? 'N/A';
//         print('item from for loop');
//         print('itemName$itemName');
//         final String varianceName = itemName?? 'N/A';
//         print('item from for loop');
//         print('itemName$varianceName');
// //         final double price = item.price.toDouble() ?? 0.0;
// //         final double weight = (item.weight ?? 0.0).toDouble();
// //         final double qty = (item.qty as num).toDouble() ?? 0.0;
// //         // final double amount = item.uom == 'Kgs'
// //         //     ? 'Rs.${(item.weight * item.quantity * item.pricePerKg).toDouble()}/-'
// //         //     : 'Rs.${(item.quantity * item.pricePerKg).toDouble()}/-';

//         // final double amount = uoms == 'Kgs'
//         //       ? (weights! * quantities! * prices).toDouble()
//         //       : (quantities! * prices.toDouble();

// Now, if you want to display the value with 'Rs.' and '/-', you can do this seRparately
  // final String amountString = 'Rs.${amount.toStringAsFixed(0)}/-';
  // final double tax = (item.tax as num).toDouble();
  // final String uom = item.uom ?? 'N/A';

  // double taxPercentage = (item.tax as num).toDouble();

  // taxVaule = taxPercentage;

//         // List<String> varianceNameLines = splitText("varianceName" ?? '', 15);
//         List<String> varianceNameLines = splitText(varianceName, 15);

//         // Main item name
//         bytes += generator.row([
//           createPosColumn(
//               width: 1,
//               text: (i + 1).toString(), // S.No
//               styles:
//                   createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//           createPosColumn(
//               width: 8,
//               text: varianceNameLines[0], // First line of item name

//               styles:
//                   createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//           createPosColumn(
//               width: 3,
//               text:
//                   // "Rs ${cartProvider.calculateSubtotal().toStringAsFixed(0)}", // Price
//                   "Rs $amount",
//               styles:
//                   createPosStyles(align: PosAlign.right, codeTable: 'CP1252')),
//         ]);

//         // If there are additional lines for the item name, print them below
//         if (varianceNameLines.length > 1) {
//           for (int j = 1; j < varianceNameLines.length; j++) {
//             bytes += generator.row([
//               createPosColumn(
//                   width: 1,
//                   text: '',
//                   styles: createPosStyles(align: PosAlign.left)),
//               createPosColumn(
//                   width: 8,
//                   text: varianceNameLines[j], // Additional line of item name
//                   // text: 'hii',
//                   styles: createPosStyles(
//                       align: PosAlign.left, codeTable: 'CP1252')),
//               createPosColumn(
//                   width: 3,
//                   text: '',
//                   styles: createPosStyles(align: PosAlign.right)),
//             ]);
//           }
//         }

//         // Quantity and unit price (for kg, pcs, etc.)
//         bytes += generator.row([
//           createPosColumn(
//               width: 1,
//               text: '',
//               styles: createPosStyles(align: PosAlign.left)),
//           createPosColumn(
//               width: 8,
//               text:
//                   "()", // Quantity and unit price

//               styles:
//                   createPosStyles(align: PosAlign.left, codeTable: 'CP1252')),
//           createPosColumn(
//               width: 3,
//               text: "", // Total amount
//               styles:
//                   createPosStyles(align: PosAlign.right, codeTable: 'CP1252')),
//         ]);

//         // Add an empty row for spacing between items
//         bytes += generator.row([
//           createPosColumn(
//               width: 12,
//               text: '',
//               styles: createPosStyles(align: PosAlign.center)),
//         ]);
//       }

//       // Adding totals and other details
//       bytes += generator.row([
//         createPosColumn(
//             width: 12,
//             text: '----------------------------------------------',
//             styles:
//                 createPosStyles(align: PosAlign.center, codeTable: 'CP1252')),
//       ]);

//       printer
//           .rawBytes(Uint8List.fromList(bytes)); // Send the bytes to the printer

//       printer.cut(); // Cut the paper after each copy

//       // Add a slight delay between prints

//       // }

//       printer.disconnect();
//     } else {
//       print('Could not connect to printer: ${res.msg}');
//     }

  // Navigator.of(context).pop();
  // cartProvider.clearCart();
  // }
  static Future<void> printReceiptDetails(
    BuildContext context,
    List<SalesOrderDisplay>
        salesOrder, // Ensure it's a list of SalesOrderDisplay
  ) async {
    print('Sales Order Details: $salesOrder');

    DateTime now = DateTime.now();
    String formattedDate = DateFormat('dd-MM-yyyy').format(now);
    String formattedTime =
        DateFormat('hh:mm a').format(now); // 12-hour format with AM/PM
    final printerProvider =
        Provider.of<PrinterProvider>(context, listen: false);
    String printerIp = printerProvider.getOverallPrinterIp().toString();

    print('Printer IP: $printerIp');

    final profile = await CapabilityProfile.load();
    final printer = NetworkPrinter(PaperSize.mm80, profile);

    final PosPrintResult res = await printer.connect(printerIp, port: 9100);

    if (res == PosPrintResult.success) {
      List<int> bytes;
      final generator = Generator(PaperSize.mm80, profile);
      bytes = []; // Reset bytes for each copy

      // Header
      bytes += generator.row([
        createPosColumn(
            width: 12,
            text: '                  BestMummy',
            styles: createPosStyles(
              align: PosAlign.center,
              height: PosTextSize.size1,
              width: PosTextSize.size1,
              codeTable: 'CP1252',
              bold: true,
            )),
      ]);
      //  bytes += generator.feed(1);

      bytes += generator.row([
        createPosColumn(
            width: 12,
            text: '                  Sweets & Cakes',
            styles: createPosStyles(
              align: PosAlign.center,
              height: PosTextSize.size1,
              width: PosTextSize.size1,
              codeTable: 'CP1252',
              bold: true,
            )),
      ]);
      bytes += generator.feed(1);
      bytes += generator.feed(1);
      bytes += generator.feed(1);

      // Print Branch and Date
      bytes += generator.row([
        createPosColumn(
            width: 6,
            text: 'Branch: Aranmanai',
            styles: createPosStyles(
                align: PosAlign.left, codeTable: 'CP1252', bold: false)),
        createPosColumn(
            width: 6,
            text: '       Date: $formattedDate',
            styles: createPosStyles(
                align: PosAlign.left, codeTable: 'CP1252', bold: false)),
      ]);

      bytes += generator.feed(1);

      // Loop through each Sales Order
      // for (var order in salesOrder) {
      //   String salesOrderNo = order.saleOrderNo ?? 'N/A'; // Get Order No
      //   print('Sales Order No: $salesOrderNo');

      //   bytes += generator.row([
      //     createPosColumn(
      //         width: 12,
      //         text: 'Sales Order No: $salesOrderNo',
      //         styles: createPosStyles(
      //           align: PosAlign.center,
      //           codeTable: 'CP1252',
      //           height: PosTextSize.size1,
      //           width: PosTextSize.size1, bold: false,
      //         )),
      //   ]);
      //     bytes += generator.feed(1);
      //     bytes += generator.row([
      //   createPosColumn(
      //       width: 3,
      //       text: 'Date: $formattedDate ',
      //       styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1255', bold:false)),
      //       createPosColumn(
      //       width: 3,
      //       text: 'ITEM',
      //       styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1255', bold: false)),
      //   createPosColumn(
      //       width: 6,
      //       text: '                 AMOUNT',
      //       styles: createPosStyles(align: PosAlign.left, codeTable: 'CP1255', bold:false)),
      // ]);

      //   bytes += generator.feed(1);

      //   // Print Variance Names, Quantities, and Prices
      //   List<String> varianceNames = order.varianceName;
      //   List<int> quantities = order.qty;
      //   List<double> prices = order.price;

      //   for (int j = 0; j < varianceNames.length; j++) {
      //     String varianceName = varianceNames[j];
      //     int quantity = quantities[j];
      //     double price = prices[j];

      //     print(
      //         "Variance Name: $varianceName, Quantity: $quantity, Price: $price");

      //     bytes += generator.row([
      //       createPosColumn(
      //           width: 6,
      //           text: varianceName,
      //           styles: createPosStyles(
      //               align: PosAlign.left, codeTable: 'CP1252', bold: false)),
      //       createPosColumn(
      //           width: 4,
      //           text: quantity.toString(),

      //           styles: createPosStyles(
      //               align: PosAlign.left, codeTable: 'CP1252', bold:false)),
      //       createPosColumn(
      //           width: 2,
      //           text: ' ${price.toStringAsFixed(2)}',
      //           styles: createPosStyles(
      //               align: PosAlign.right, codeTable: 'CP1252', bold: false)),
      //     ]);

      //     bytes += generator.feed(1);
      //   }

      //   bytes += generator.feed(1);
      // }

      for (int i = 0; i < salesOrder.length; i++) {
        SalesOrderDisplay orderItem =
            salesOrder[i]; // Access each object in the list

        bytes += generator.row([
          createPosColumn(
              width: 12,
              text: 'Sales Order No: ${orderItem.saleOrderNo}',
              styles: createPosStyles(
                align: PosAlign.center,
                codeTable: 'CP1252',
                height: PosTextSize.size2,
                width: PosTextSize.size1,
                bold: true,
              )),
        ]);

        bytes += generator.feed(1);

        // bytes += generator.feed(1);
        bytes += generator.row([
          createPosColumn(
              width: 3,
              text: 'S.NO ',
              styles: createPosStyles(
                  align: PosAlign.left, codeTable: 'CP1255', bold: false)),
          createPosColumn(
              width: 3,
              text: 'ITEM',
              styles: createPosStyles(
                  align: PosAlign.left, codeTable: 'CP1255', bold: false)),
          createPosColumn(
              width: 6,
              text: '                 AMOUNT',
              styles: createPosStyles(
                  align: PosAlign.left, codeTable: 'CP1255', bold: false)),
        ]);
        bytes += generator.feed(1);
        for (int j = 0; j < orderItem.varianceName.length; j++) {
          String varianceName = orderItem.varianceName[j]; // Get item name
          int quantity = orderItem.qty[j]; // Get quantity
          double price = orderItem.price[j]; // Get price per unit
          String uom = orderItem.uom[j]; // Get unit of measure
          int taxRate = orderItem.tax[j]; // Get tax rate
          double amount = orderItem.amount[j];
          // double  totalAmount=orderItem.totalAmount[j];

          bytes += generator.feed(1);

          bytes += generator.row([
            createPosColumn(
                width: 2,
                text: (j + 1).toString(), // Serial Number
                styles: createPosStyles(
                    align: PosAlign.left, codeTable: 'CP1252', bold: false)),
            createPosColumn(
                width: 6,
                text: varianceName, // Item Name
                styles: createPosStyles(
                    align: PosAlign.left, codeTable: 'CP1252', bold: false)),
            createPosColumn(
                width: 4,
                text: ' ${amount.toStringAsFixed(2)}', // Amount
                styles: createPosStyles(
                    align: PosAlign.right, codeTable: 'CP1252', bold: false)),
          ]);
          String formatPrice(double value) {
            return value % 1 == 0
                ? value.toInt().toString()
                : value.toStringAsFixed(2);
          }

// String priceText = price > 0 ? formatPrice(price) : '';
// String taxText = taxRate > 0 ? 'tax $taxRate%' : '';

// String details = '($quantity $uom';
// if (price > 0) details += ' x $priceText';
// if (taxRate > 0) details += ' $taxText';
// details += ')';

          bytes += generator.row([
            createPosColumn(
                width: 8,
                text: '($quantity $uom x $price tax $taxRate%)',
                styles: createPosStyles(
                    align: PosAlign.left, codeTable: 'CP1252', bold: false)),

            // Print UOM, Quantity, and Tax

            createPosColumn(
                width: 2,
                text: '',
                styles: createPosStyles(
                    align: PosAlign.left, codeTable: 'CP1252', bold: false)),

            createPosColumn(
                width: 2,
                text: '',
                styles: createPosStyles(
                    align: PosAlign.right, codeTable: 'CP1252', bold: false)),
          ]);

          bytes += generator.feed(1);
        }
        bytes += generator.row([
          createPosColumn(
              width: 12,
              text:
                  '                  Total Amount  =     ${orderItem.totalAmount}',
              styles: createPosStyles(
                align: PosAlign.center,
                codeTable: 'CP1252',
                height: PosTextSize.size2,
                width: PosTextSize.size1,
                bold: true,
              )),
        ]);

        bytes += generator.feed(1);
      }

// Divider
      bytes += generator.row([
        createPosColumn(
            width: 12,
            text: '----------------------------------------------',
            styles: createPosStyles(
                align: PosAlign.center, codeTable: 'CP1252', bold: false)),
      ]);

// Discount (if applicable)
// if (discountController != 0) {
//   bytes += generator.row([
//     createPosColumn(
//         width: 12,
//         text: "Discount: Rs ${discountController.toStringAsFixed(2)}",
//         styles: createPosStyles(align: PosAlign.right, codeTable: 'CP1252', bold: false)),
//   ]);
// }

      printer
          .rawBytes(Uint8List.fromList(bytes)); // Send the bytes to the printer
      printer.cut(); // Cut the paper after printing
      printer.disconnect();
    } else {
      print('Could not connect to printer: ${res.msg}');
    }
  }

  static List<String> splitAddress(String address) {
    const int maxLineWidth = 18;
    List<String> lines = [];
    String remainingAddress = address ?? '';

    while (remainingAddress.length > maxLineWidth) {
      int lastIndex = remainingAddress.lastIndexOf(' ', maxLineWidth);
      if (lastIndex == -1) {
        lastIndex = maxLineWidth;
      }
      lines.add(remainingAddress.substring(0, lastIndex).trimRight());
      remainingAddress = remainingAddress.substring(lastIndex).trimLeft();
    }

    lines.add(remainingAddress);

    return lines;
  }

  static List<String> splitText(String text, int maxLineWidth) {
    List<String> lines = [];
    String remainingText = text ?? '';

    while (remainingText.length > maxLineWidth) {
      int lastIndex = remainingText.lastIndexOf(' ', maxLineWidth);
      if (lastIndex == -1) {
        // If no space is found, break at maxLineWidth
        lastIndex = maxLineWidth;
      }
      lines.add(remainingText.substring(0, lastIndex).trimRight());
      remainingText = remainingText.substring(lastIndex).trimLeft();
    }

    lines.add(remainingText);

    return lines;
  }
}

Future<void> printReceiptDetails(List<SalesOrderDisplay> salesOrders) async {
  final profile = await CapabilityProfile.load();
  final printer = NetworkPrinter(PaperSize.mm80, profile);

  const String printerIp =
      "192.168.1.87"; // Replace with your printer's actual IP
  final PosPrintResult connectResult =
      await printer.connect(printerIp, port: 9100);

  if (connectResult != PosPrintResult.success) {
    print("Failed to connect to printer: $connectResult");
    return;
  }

  printer.text('SALES RECEIPT',
      styles: PosStyles(
          align: PosAlign.center, height: PosTextSize.size2, bold: true));
  printer.text('  Date: ${DateTime.now().toString().split(' ')[0]}');
  printer.hr(); // Prints a horizontal line

  double grandTotal = 0;

  for (var order in salesOrders) {
    printer.text('Order ID: ${order.orderInvoiceNo}',
        styles: PosStyles(bold: true));
    printer.text('Customer: ${order.customerName}');
    printer.hr();

    printer.text('Item           Qty   Price   Total',
        styles: PosStyles(bold: true));
    double orderTotal = 0;

    // for (var item in order.items) {
    //   double itemTotal = item.  item.price;
    //   orderTotal += itemTotal;
    //   printer.text(
    //     '${item.name.padRight(12)} ${item.quantity.toString().padLeft(2)}  ${item.price.toStringAsFixed(2).padLeft(6)}  ${itemTotal.toStringAsFixed(2).padLeft(7)}',
    //   );
    // }

    grandTotal += orderTotal;
    printer.hr();
    printer.text('Order Total: \$${orderTotal.toStringAsFixed(2)}',
        styles: PosStyles(align: PosAlign.right, bold: true));
    printer.feed(1);
  }

  printer.hr();
  printer.text('Grand Total: \$${grandTotal.toStringAsFixed(2)}',
      styles: PosStyles(
          align: PosAlign.right, height: PosTextSize.size2, bold: true));

  printer.feed(2);
  printer.cut();
  printer.disconnect();
}
