import 'dart:convert';
import 'package:yenpos/Global/global_data_manager.dart';
import 'package:yenpos/Sale_order/Print_Receipt/invoicePrint.dart';
import 'package:yenpos/Sale_order/Provider/customerScreen_provider.dart';
import 'package:yenpos/Server_Client/handlers/Webscoekt_handler/handle_holdorder_websocket.dart';
import 'package:yenpos/Server_Client/handlers/Webscoekt_handler/handle_invoice.dart';
import 'package:yenpos/Server_Client/handlers/Webscoekt_handler/handle_patch_approval_order.dart';
import 'package:yenpos/Server_Client/handlers/Webscoekt_handler/handle_patchsaleorder.dart';
import 'package:yenpos/Server_Client/handlers/Webscoekt_handler/handle_salesapproval.dart';
import 'package:yenpos/Server_Client/handlers/Webscoekt_handler/invoice_patch_saleorder.dart';
import 'package:yenpos/Server_Client/handlers/Webscoekt_handler/message_handler_websocket_saleorder.dart';

import 'package:yenpos/Server_Client/websocketService.dart';

class MessageRouter {
  static Future<void> handle(
    String rawMessage,
    CustomerScreenProvider provider,
    SalesInvoiceReceiptPrinter printer,
    WebSocketService ws,
  ) async {
    final data = jsonDecode(rawMessage);
    final action = data['action'];

    switch (action) {
      case 'salesOrderGenerated':
        await handleSalesOrder(data, provider);
        break;

      case 'holdOrderGenerated':
        await handleHoldOrder(data);
        break;
      case 'invoiceGenerated':
        await handleInvoice(data, printer);
        break;
      case 'patchsaleorderGenerated':
        await handlePatchSalesOrder(data, provider);
        break;
      case 'salesApprovalOrderGenerated':
        await handleApprovalOrder(data);
        break;
      case 'salesOrder_updated':
        await handlePatchSalesOrder(data, provider);
        break;
      case 'approval_updated':
        await handlePatchSalesApprovalOrder(data, provider);
        break;
      case 'patchInvoicesaleorderGenerated':
        await handleInvoicePatchSalesOrder(data, provider);
        break;

      // ADD THESE 3 LINES NOW
      case 'stockDecreaseUpdate':
        _handleLiveStockUpdate(data);
        break;
      case 'stockIncreaseUpdate':
        _handleLiveStockUpdate(data);
        break;

      default:
        print('[WS] Unknown action: $action');
        break;
    }
  }
}

void _handleLiveStockUpdate(Map<String, dynamic> data) {
  try {
    final branchAlias = data['branchAlias']?.toString();
    final varianceName = data['varianceName']?.toString();
    final dynamic rawStock = data['updatedStock'];

    // Validate required fields
    if (branchAlias == null || varianceName == null || rawStock == null) {
      print("Invalid stock update payload: $data");
      return;
    }

    // SUPPORT BOTH int (Pcs) AND double (Kgs) – NO TRUNCATION!
    double updatedStock = 0.0;

    if (rawStock is num) {
      updatedStock = rawStock.toDouble();
    } else if (rawStock is String) {
      updatedStock = double.tryParse(rawStock) ?? 0.0;
    } else {
      print("Unknown stock type: ${rawStock.runtimeType}");
      return;
    }

    // Clean floating-point noise (e.g. 9985.5000000009 → 9985.5)
    updatedStock = double.parse(updatedStock.toStringAsFixed(3));

    print("LIVE STOCK → $branchAlias | $varianceName = $updatedStock");

    // Pass DOUBLE to GlobalDataManager
    GlobalDataManager().updateStockLive(
      branchAlias: branchAlias,
      varianceName: varianceName,
      newStock: updatedStock, // ← double, not int!
    );
  } catch (e, st) {
    print("Stock update error: $e\n$st");
  }
}
