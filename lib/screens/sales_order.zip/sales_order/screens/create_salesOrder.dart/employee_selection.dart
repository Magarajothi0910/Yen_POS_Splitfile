import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../Global/camera_qr_screen.dart';
import '../../../../Global/pos_detector.dart';
import '../../sales_order_providers/customerScreen_provider.dart';
import '../../sales_order_providers/detailsProvider.dart';
import 'dart:convert';

// class EmployeeSearchDropdown extends StatefulWidget {
//   const EmployeeSearchDropdown({Key? key}) : super(key: key);

//   @override
//   _EmployeeSearchDropdownState createState() => _EmployeeSearchDropdownState();
// }

// class _EmployeeSearchDropdownState extends State<EmployeeSearchDropdown> {
//   final LayerLink _layerLink = LayerLink();
//   OverlayEntry? _overlayEntry;
//   final FocusNode _focusNode = FocusNode();
//   final TextEditingController _textController = TextEditingController();
//   bool _isQrMode = false; // QR mode toggle
//   bool _isProcessing = false; // To prevent overlapping processing

//   @override
//   void initState() {
//     super.initState();
//     final customerScreenProvider =
//         Provider.of<CustomerScreenProvider>(context, listen: false);
//     customerScreenProvider.searchController.addListener(_updateOverlay);
//     _focusNode.requestFocus(); // Focus on the text field immediately
//   }

//   @override
//   void dispose() {
//     final customerScreenProvider =
//         Provider.of<CustomerScreenProvider>(context, listen: false);
//     customerScreenProvider.searchController.removeListener(_updateOverlay);
//     customerScreenProvider.searchController.dispose();
//     _overlayEntry?.remove();
//     _focusNode.dispose();
//     _textController.dispose();
//     super.dispose();
//   }

//   void _updateOverlay() {
//     final detailsProvider =
//         Provider.of<DetailsProvider>(context, listen: false);
//     final customerScreenProvider =
//         Provider.of<CustomerScreenProvider>(context, listen: false);
//     detailsProvider.searchQuery = customerScreenProvider.searchController.text;
//     print("Search Query: ${detailsProvider.searchQuery}");
//     if (detailsProvider.searchQuery.isNotEmpty && _overlayEntry == null) {
//       print("Creating and inserting overlay");
//       _overlayEntry = _createOverlayEntry();
//       Overlay.of(context).insert(_overlayEntry!);
//     } else if (detailsProvider.searchQuery.isEmpty) {
//       print("Removing overlay because search query is empty");
//       _removeOverlay();
//     } else {
//       print("Updating overlay");
//       _overlayEntry?.markNeedsBuild();
//     }
//   }

//   OverlayEntry _createOverlayEntry() {
//     RenderBox renderBox = context.findRenderObject() as RenderBox;
//     var size = renderBox.size;
//     return OverlayEntry(
//       builder: (context) => Positioned(
//         width: size.width,
//         child: CompositedTransformFollower(
//           link: _layerLink,
//           showWhenUnlinked: false,
//           offset: Offset(0, size.height + 5),
//           child: Material(
//             elevation: 4.0,
//             borderRadius: BorderRadius.circular(8),
//             color: Colors.white,
//             child: Consumer<DetailsProvider>(
//                 builder: (context, detailsProvider, _) {
//               // final filteredEmployees =
//               //     detailsProvider.filteredEmployeeFirstNames;
//               final filteredEmployees =
//                   detailsProvider.filteredEmployeeFirstNames ?? [];

//               return filteredEmployees.isNotEmpty
//                   ? ListView.builder(
//                       padding: EdgeInsets.zero,
//                       shrinkWrap: true,
//                       itemCount: filteredEmployees.length,
//                       itemBuilder: (context, index) {
//                         if (filteredEmployees.isEmpty ||
//                             index >= filteredEmployees.length) {
//                           return const SizedBox.shrink();
//                         }
//                         final employeeName = filteredEmployees[index];
//                         return ListTile(
//                           title: Text(
//                             employeeName,
//                             style: TextStyle(color: Colors.black),
//                           ),
//                           hoverColor: Colors.blue.shade50,
//                           onTap: () {
//                             _handleEmployeeSelection(employeeName);
//                           },
//                         );
//                       },
//                     )
//                   : const Padding(
//                       padding: EdgeInsets.all(8.0),
//                       child: Text(
//                         'No matches found',
//                         style: TextStyle(color: Colors.grey),
//                       ),
//                     );
//             }),
//           ),
//         ),
//       ),
//     );
//   }

//   void _handleEmployeeSelection(String employeeName) {
//     print("Employee Selected: $employeeName");
//     final customerScreenProvider =
//         Provider.of<CustomerScreenProvider>(context, listen: false);
//     customerScreenProvider.searchController.text = employeeName;
//     print(
//         "Updated search field with: ${customerScreenProvider.searchController.text}");
//     // Dismiss keyboard
//     FocusScope.of(context).unfocus();
//     print("Keyboard dismissed");
//     final detailsProvider =
//         Provider.of<DetailsProvider>(context, listen: false);
//     detailsProvider.filteredEmployeeFirstNames.clear();
//     detailsProvider.searchQuery = '';
//     print("Cleared filteredEmployeeFirstNames and searchQuery");
//     print("searchQuery${detailsProvider.searchQuery}");
//     detailsProvider.notifyListeners();
//     print("Notified listeners about the changes");
//     _removeOverlay();
//   }

//   void _removeOverlay() {
//     if (_overlayEntry != null) {
//       print("Removing overlay...");
//       _overlayEntry?.remove();
//       _overlayEntry = null;
//     } else {
//       print("Overlay was already null");
//     }
//   }

//   void _toggleQrMode() async {
//     bool isPOS = await POSDetector.isPOSDevice;

//     if (isPOS) {
//       _startHardwareScanner(); // Use hardware scanner for POS devices
//     } else {
//       _startCameraScan(); // Use camera for non-POS devices
//     }
//   }

//   void _startHardwareScanner() {
//     setState(() {
//       _isQrMode = true;
//       _focusNode.requestFocus(); // Focus on the hidden field
//     });
//     print("Hardware scanner mode activated");
//   }

//   void _startCameraScan() async {
//     Navigator.push(
//       context,
//       MaterialPageRoute(builder: (context) => const QRCodeScannerScreen()),
//     ).then((scannedData) {
//       print('scannedData: $scannedData');
//       if (scannedData != null && scannedData is String) {
//         _handleInput(scannedData);
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(
//             content: Text("No QR code detected or scanning canceled."),
//             duration: Duration(seconds: 1),
//           ),
//         );
//       }
//     });
//   }

//   Future<String> _scanWithCamera() async {
//     // Simulate camera scan (you can integrate any camera QR scanner library here)
//     await Future.delayed(const Duration(seconds: 1)); // Simulated delay
//     return '{"Name": "John Doe"}'; // Simulated scanned data
//   }

//   void _handleInput(String value) async {
//     if (_isProcessing || !_isQrMode || value.isEmpty) return;
//     setState(() {
//       _isProcessing = true;
//     });

//     try {
//       final Map<String, dynamic> scannedData = _parseScannedData(value);
//       if (scannedData.containsKey('Name')) {
//         final employeeName = scannedData['Name'];
//         _handleEmployeeSelection(employeeName);
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(
//             content: Text("Invalid QR data. 'EmployeeName' not found."),
//             duration: Duration(milliseconds: 500),
//           ),
//         );
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text("Error: ${e.toString()}"),
//           duration: const Duration(milliseconds: 500),
//         ),
//       );
//     } finally {
//       _textController.clear();
//       _focusNode.unfocus(); // Make sure to unfocus
//       setState(() {
//         _isProcessing = false;
//       });
//     }
//   }

//   Map<String, dynamic> _parseScannedData(String value) {
//     if (value.trim().isEmpty) {
//       throw FormatException("Scanned data is empty");
//     }
//     try {
//       return json.decode(value); // Try parsing JSON
//     } catch (_) {
//       // Fallback to key-value pair parsing
//       final Map<String, dynamic> parsedData = {};
//       value.replaceAll('{', '').replaceAll('}', '').split(',').forEach((pair) {
//         final keyValue = pair.split(':');
//         if (keyValue.length == 2) {
//           parsedData[keyValue[0].trim()] = keyValue[1].trim();
//         }
//       });
//       if (parsedData.isEmpty) {
//         throw FormatException("Scanned data is not in a recognizable format");
//       }
//       return parsedData;
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final customerScreenProvider =
//         Provider.of<CustomerScreenProvider>(context, listen: false);
//     return CompositedTransformTarget(
//       link: _layerLink,
//       child: Column(
//         children: [
//           TextField(
//             controller: customerScreenProvider.searchController,
//             decoration: InputDecoration(
//               labelText: 'Search SalesMan',
//               border: OutlineInputBorder(),
//               isDense: false,
//               suffixIcon: IconButton(
//                 icon: Icon(Icons.qr_code_scanner),
//                 onPressed: _toggleQrMode,
//               ),
//             ),
//             style: TextStyle(fontSize: 14, color: Colors.black),
//             cursorColor: Colors.blue,
//           ),
//           if (_isQrMode)
//             Offstage(
//               offstage: true, // Hides the widget from UI but keeps it active
//               child: TextField(
//                 focusNode: _focusNode,
//                 controller: _textController,
//                 keyboardType: TextInputType.none, // Prevent system keyboard
//                 onSubmitted: _handleInput,
//                 decoration: const InputDecoration(
//                   border: InputBorder.none,
//                 ),
//                 style: const TextStyle(fontSize: 0), // Invisible text
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }

class EmployeeSearchDropdown extends StatefulWidget {
  const EmployeeSearchDropdown({Key? key}) : super(key: key);

  @override
  _EmployeeSearchDropdownState createState() => _EmployeeSearchDropdownState();
}

class _EmployeeSearchDropdownState extends State<EmployeeSearchDropdown> {
  bool _isProgrammaticUpdate = false;
  @override
  Widget build(BuildContext context) {
    final customerScreenProvider =
        Provider.of<CustomerScreenProvider>(context, listen: false);

    return CompositedTransformTarget(
      link: _layerLink,
      child: Column(
        children: [
          TextField(
            controller: customerScreenProvider.searchController,
            decoration: InputDecoration(
              labelText: 'Search SalesMan',
              border: const OutlineInputBorder(),
              isDense: false,
              suffixIcon: IconButton(
                icon: const Icon(Icons.qr_code_scanner),
                onPressed: _toggleQrMode,
              ),
            ),
            style: const TextStyle(fontSize: 14, color: Colors.black),
            cursorColor: Colors.blue,
          ),
          if (_isQrMode)
            Offstage(
              offstage: true,
              child: TextField(
                focusNode: _focusNode,
                controller: _textController,
                keyboardType: TextInputType.none,
                onSubmitted: _handleInput,
                decoration: const InputDecoration(
                  border: InputBorder.none,
                ),
                style: const TextStyle(fontSize: 0),
              ),
            ),
        ],
      ),
    );
  }

  final LayerLink _layerLink = LayerLink();
  OverlayEntry? _overlayEntry;
  final FocusNode _focusNode = FocusNode();
  final TextEditingController _textController = TextEditingController();
  bool _isQrMode = false;
  bool _isProcessing = false;
  Timer? _debounceTimer; // Added debounce timer
  List<String> _lastFilteredList = []; // Cache last filtered list

  @override
  void initState() {
    super.initState();
    final customerScreenProvider =
        Provider.of<CustomerScreenProvider>(context, listen: false);
    customerScreenProvider.searchController
        .addListener(_debouncedUpdateOverlay);
    _focusNode.requestFocus();
  }

  void _debouncedUpdateOverlay() {
    if (_isProgrammaticUpdate) return; // Skip if programmatic update
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 300), _updateOverlay);
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    _removeOverlay();
    final customerScreenProvider =
        Provider.of<CustomerScreenProvider>(context, listen: false);
    customerScreenProvider.searchController
        .removeListener(_debouncedUpdateOverlay);
    _focusNode.dispose();
    _textController.dispose();
    super.dispose();
  }
  // Keep existing dispose method unchanged

  void _updateOverlay() {
    if (_isProgrammaticUpdate) return;

    final detailsProvider =
        Provider.of<DetailsProvider>(context, listen: false);
    final customerScreenProvider =
        Provider.of<CustomerScreenProvider>(context, listen: false);

    detailsProvider.searchQuery = customerScreenProvider.searchController.text;

    // If there's a search query and no overlay, create one
    if (detailsProvider.searchQuery.isNotEmpty && _overlayEntry == null) {
      _overlayEntry = _createOverlayEntry();
      Overlay.of(context)!.insert(_overlayEntry!);
    }
    // If search query is empty, remove overlay
    else if (detailsProvider.searchQuery.isEmpty && _overlayEntry != null) {
      _removeOverlay();
    }
    // Otherwise, rebuild the existing overlay
    else if (_overlayEntry != null) {
      _overlayEntry!.markNeedsBuild();
    }
  }

  void _toggleQrMode() async {
    bool isPOS = await POSDetector.isPOSDevice;

    if (isPOS) {
      _startHardwareScanner(); // Use hardware scanner for POS devices
    } else {
      _startCameraScan(); // Use camera for non-POS devices
    }
  }

  void _startHardwareScanner() {
    setState(() {
      _isQrMode = true;
      _focusNode.requestFocus(); // Focus on the hidden field
    });
    print("Hardware scanner mode activated");
  }

  void _startCameraScan() async {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const QRCodeScannerScreen()),
    ).then((scannedData) {
      print('scannedData: $scannedData');
      if (scannedData != null && scannedData is String) {
        _handleInput(scannedData);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("No QR code detected or scanning canceled."),
            duration: Duration(seconds: 1),
          ),
        );
      }
    });
  }

  Future<String> _scanWithCamera() async {
    // Simulate camera scan (you can integrate any camera QR scanner library here)
    await Future.delayed(const Duration(seconds: 1)); // Simulated delay
    return '{"Name": "John Doe"}'; // Simulated scanned data
  }

  void _handleInput(String value) async {
    if (_isProcessing || !_isQrMode || value.isEmpty) return;
    setState(() {
      _isProcessing = true;
    });

    try {
      final Map<String, dynamic> scannedData = _parseScannedData(value);
      if (scannedData.containsKey('Name')) {
        final employeeName = scannedData['Name'];
        _handleEmployeeSelection(employeeName);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Invalid QR data. 'EmployeeName' not found."),
            duration: Duration(milliseconds: 500),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error: ${e.toString()}"),
          duration: const Duration(milliseconds: 500),
        ),
      );
    } finally {
      _textController.clear();
      _focusNode.unfocus(); // Make sure to unfocus
      setState(() {
        _isProcessing = false;
      });
    }
  }

  Map<String, dynamic> _parseScannedData(String value) {
    if (value.trim().isEmpty) {
      throw FormatException("Scanned data is empty");
    }
    try {
      return json.decode(value); // Try parsing JSON
    } catch (_) {
      // Fallback to key-value pair parsing
      final Map<String, dynamic> parsedData = {};
      value.replaceAll('{', '').replaceAll('}', '').split(',').forEach((pair) {
        final keyValue = pair.split(':');
        if (keyValue.length == 2) {
          parsedData[keyValue[0].trim()] = keyValue[1].trim();
        }
      });
      if (parsedData.isEmpty) {
        throw FormatException("Scanned data is not in a recognizable format");
      }
      return parsedData;
    }
  }

  OverlayEntry _createOverlayEntry() {
    final renderBox = context.findRenderObject() as RenderBox;
    final size = renderBox.size;
    return OverlayEntry(
      builder: (context) => Positioned(
        width: size.width,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(0, size.height + 5),
          child: Material(
            elevation: 4.0,
            borderRadius: BorderRadius.circular(8),
            color: Colors.white,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: 200, // Constrain maximum height
                minWidth: size.width,
              ),
              child: Selector<DetailsProvider, List<String>>(
                selector: (_, provider) =>
                    provider.filteredEmployeeFirstNames ?? [],
                shouldRebuild: (prev, next) => !listEquals(prev, next),
                builder: (context, filteredEmployees, _) {
                  if (listEquals(filteredEmployees, _lastFilteredList)) {
                    return const SizedBox.shrink();
                  }
                  _lastFilteredList = filteredEmployees;

                  return filteredEmployees.isNotEmpty
                      ? ListView.builder(
                          shrinkWrap: true, // Add shrinkWrap
                          padding: EdgeInsets.zero,
                          itemCount: filteredEmployees.length,
                          itemBuilder: (context, index) => _ListItem(
                            employeeName: filteredEmployees[index],
                            onSelect: _handleEmployeeSelection,
                          ),
                        )
                      : const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('No matches found'),
                        );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _removeOverlay() {
    if (_overlayEntry != null) {
      print("Removing overlay...");
      _overlayEntry?.remove();
      _overlayEntry = null;
    } else {
      print("Overlay was already null");
    }
  }

  void _handleEmployeeSelection(String employeeName) {
    final customerScreenProvider =
        Provider.of<CustomerScreenProvider>(context, listen: false);
    final detailsProvider =
        Provider.of<DetailsProvider>(context, listen: false);

    // Set flag to avoid triggering the debounced update
    setState(() => _isProgrammaticUpdate = true);

    // Update the text field
    customerScreenProvider.searchController.text = employeeName;

    // Clear the search query in the provider
    detailsProvider.searchQuery = '';

    // Remove focus from the text field
    FocusScope.of(context).unfocus();

    // Remove overlay first
    _removeOverlay();

    // Reset the programmatic update flag after a small delay
    // to ensure the listener doesn't trigger immediately
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) {
        setState(() => _isProgrammaticUpdate = false);
      }
    });
  }
  // Keep rest of the methods unchanged
}

class _ListItem extends StatelessWidget {
  final String employeeName;
  final Function(String) onSelect;

  const _ListItem({
    required this.employeeName,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      key: ValueKey(employeeName),
      title: Text(
        employeeName,
        style: const TextStyle(color: Colors.black),
      ),
      hoverColor: Colors.blue.shade50,
      onTap: () => onSelect(employeeName),
    );
  }
}
