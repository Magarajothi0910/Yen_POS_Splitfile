import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/utils.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../Service/Token_service.dart';
import '../Service/hive_service.dart';
import '../Service/sendDataToClients.dart';
import '../Service/sync_service.dart';
import 'package:intl/intl.dart'; // For date formatting
import 'package:network_info_plus/network_info_plus.dart';

class ServerScreen extends ChangeNotifier {
  final List<Map<String, dynamic>> _receivedData = [];
  Set<WebSocketChannel> clients = {};
  List<Map<String, dynamic>> orders = [];
  final SyncService _syncService = SyncService();
  Timer? _syncTimer;
  Timer? _patchCheckTimer;
  late Box saleOrderBox;
  Timer? _approvalCheckTimer;
  Map<String, dynamic>? paymentDetails;
  int _sendDataToClientsCount = 0;
  final TextEditingController _advanceController = TextEditingController();
  bool placeOrderCliked = false;
  bool showPaymentScreen = false;
  final Set<String> _processedMessageIds = {};

  // Initialize the state
  Future<void> init() async {
    await Hive.openBox('invoices');
    await Hive.openBox('posInvoiceBox');
    await Hive.openBox('salesOrders');
    saleOrderBox = await Hive.openBox('saleOrderBox');
    await Hive.openBox('holdOrders');
    await Hive.openBox('salesApprovalOrder');
    await Hive.openBox('saleOrderModifyOrders');

    _approvalCheckTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      print('fetching pending approvals');
      checkPendingApprovals(saleOrderBox);
    });
    _syncTimer = Timer.periodic(const Duration(minutes: 10), (timer) {
      _syncService.syncUnsyncedOrders();
      _syncService.syncUnsyncedInvoices();
      _syncService.patchEditedOrders();
      _syncService.syncPendingPatches();
    });

    loadOrdersFromHive().then((orders) {
      _receivedData.addAll(orders);
      notifyListeners();
    });

    startServer(clients, onDataReceived);
  }

  @override
  void dispose() {
    // Cancel the timer when the screen is disposed
    Hive.close();

    _syncTimer?.cancel();
    super.dispose();
  }

  void startServer(Set<WebSocketChannel> clients,
      Function(Map<String, dynamic>) onDataReceived) async {
    try {
      final server = await HttpServer.bind(InternetAddress.anyIPv4, 8383);
      print('Server running on ${server.address}:${server.port}');

      tokenCounter = await getTokenCounterFromHive();

      server.transform(WebSocketTransformer()).listen((WebSocket socket) {
        handleWebSocket(socket, clients, onDataReceived);
      });
    } catch (e) {
      print('Failed to start server: $e');
    }
  }

  Map<String, String> seathiveOrderIds = {};

  void handleInvoice(Map<String, dynamic> data) async {
    // Define branchName, defaulting to "BM" if not provided

    sendDataToClients({
      'action': 'invoiceGenerated',
      'invoice': data,
    }, clients);
    if (data['type'] == 'posInvoice') {
      // Save POS invoice in `posInvoiceBox`
      print("savePosInvoiceToHive 1");
      await savePosInvoiceToHive(data);
      print("savePosInvoiceToHive 2");
    }
    // Save regular invoice in `invoices` box
    await saveInvoiceToHive(data);

    await _syncService.saveInvoiceToHive(data);
  }

  String generateSalesOrderId(String branchCode, int sequenceNumber) {
    final yearSuffix = DateFormat('yy').format(DateTime.now());
    final sequenceStr = sequenceNumber.toString().padLeft(4, '0');
    return 'SO$branchCode$yearSuffix$sequenceStr';
  }

  Future<String?> fetchNextSalesOrderNumberFromHive(String prefix) async {
    // Open the Hive box for sales orders
    final salesOrderBox = await Hive.openBox('salesOrders');

    // Get the current count for the prefix or initialize it to 250000
    final currentCount = salesOrderBox.get(prefix) ?? 0000;

    // Increment to get the next count
    final nextCount = currentCount + 1;

    // Save the updated count back to Hive
    await salesOrderBox.put(prefix, nextCount);

    // Format the numeric part with leading zeros to ensure it is always six digits
    final formattedNumber = nextCount.toString().padLeft(4, '0');

    // Return the new sales order number in the format "prefix + formattedNumber"
    return '$prefix$formattedNumber';
  }

  int sendDataToClientsCallCount =
      0; // Declare this at an appropriate global or class level if needed

  Future<void> handlePatchSaleOrder(Map<String, dynamic> data) async {
    final salesOrderId = data['salesOrderId'];
    final patchData = data['data'];
    final deviceName = data['deviceName'];
    final type = data['type'];
    final sync = data['sync'];
    final edit = data['edit'];
    final waitingForApprovalResult = data['waitingForApprovalResult'];
    print('waitingForApprovalResult: $waitingForApprovalResult');
    final soNo = data['saleOrderNo'];
    debugPrint('🔧 Starting handlePatchSaleOrder');

    String? targetKey;

    for (final entry in saleOrderBox.toMap().entries) {
      final orderData = entry.value['data'];
      if (orderData is Map && orderData['saleOrderNo'] == salesOrderId) {
        targetKey = entry.key.toString();
        break;
      }
    }

    if (targetKey == null) {
      debugPrint("❌ Order $salesOrderId not found in Hive");
      return;
    }

    final existingOrder = saleOrderBox.get(targetKey);
    final updatedOrder = Map<String, dynamic>.from(existingOrder);

    if (updatedOrder['data'] is Map) {
      updatedOrder['data'] = Map.from(updatedOrder['data'])..addAll(patchData);
    }

    updatedOrder.addAll({
      'deviceName': deviceName,
      'type': type,
      'sync': sync,
      'edit': edit,
      'waitingForApprovalResult': 'Yes',
      "saleOrderNo": soNo,
    });

    await saleOrderBox.put(targetKey, updatedOrder);
    debugPrint('✅ Successfully updated Hive entry $targetKey');

    sendDataToClients({
      'action': 'patchsaleorderGenerated',
      'saleOrderNo': salesOrderId,
      'patchSaleOrder': data,
    }, clients);

    sendDataToClientsCallCount++;
    debugPrint(
        '📨 sendDataToClients called $sendDataToClientsCallCount time(s)');
  }

  Future<void> handleSaleOrder(Map<String, dynamic> data) async {
    debugPrint("handleSaleOrder: $data");

    // Save the sales order locally with original data.

    // Extract the sales order data (nested or top-level)
    final salesOrder = data['data'] ?? data;

    // Determine prefix for sales order number
    String prefix = salesOrder['saleOrderNo']?.toString().trim() ??
        salesOrder['branchAlias']?.toString().trim() ??
        "SOSB";

    // Get new sales order number from API
    final newSalesOrderNo = await fetchNextSalesOrderNumberFromHive(prefix);
    if (newSalesOrderNo == null) {
      debugPrint("Failed to fetch a new sales order number");
      return;
    }

    // Clean and update the sales order number
    final cleanSalesOrderNo = newSalesOrderNo.replaceAll('"', '');
    salesOrder['saleOrderNo'] = cleanSalesOrderNo;
    debugPrint("Updated sales order with new number: $cleanSalesOrderNo");
    await savePosSaleOrderToHive(data, saleOrderBox);
    debugPrint("Saved sale order locally: $data");
    // Notify clients WITH THE UPDATED SALES ORDER NUMBER
    sendDataToClients({
      'action': 'salesOrderGenerated',
      'salesOrder': data, // Now contains the updated salesOrderNo
    }, clients);
    _sendDataToClientsCount++;
    debugPrint("Sent data to clients $_sendDataToClientsCount times");
    // Post to API
    bool success = await _syncService.postSalesOrder({
      "data": [salesOrder]
    });

    if (success) {
      debugPrint("Sales order posted successfully.");
    } else {
      debugPrint("Failed to post sales order.");
    }
  }

  void handleModifyOrder(Map<String, dynamic> data) async {
    // Notify connected clients about the new sales order.
    sendDataToClients({
      'action': 'modifyOrderGenerated',
      'modifyOrder': data,
    }, clients);

    print("handleSaleOrder: $data");

    // Save the sales order locally.
    await saveModifyOrderToHive(data);
    print("Saved sale order locally: $data");

    // If the sales order data contains a nested "data" key,
    // extract it. Otherwise, fallback to the original data.
    final modifyOrder = data['data'] ?? data;

    // Post the flattened sales order to the FastAPI endpoint.
    bool success = await _syncService.postModifyOrder({
      "data": [modifyOrder]
    });

    if (success) {
      print("Sales order posted successfully.");
    } else {
      print("Failed to post sales order.");
    }
  }

  Future<void> saveToApproveOrderToHive(Map<String, dynamic> data) async {
    // Save the sales approval order to the Hive database
    var modifyOrdersBox = await Hive.openBox('salesOrderToApprove');
    await modifyOrdersBox.add(data);
    print('Sales approval order saved to Hive: $data');
  }

// Define a method to handle adding a customer to a sales order.
  Future<void> saveSalesOrderAddCustomerToHive(
      Map<String, dynamic> data) async {
    // Save the sales order customer addition to the Hive database
    var salesOrderAddCustomerBox = await Hive.openBox('salesOrderAddCustomer');
    await salesOrderAddCustomerBox.add(data);
    debugPrint('Sales order customer addition saved to Hive: $data');
  }

  void handleSalesOrderAddCustomer(Map<String, dynamic> data) async {
    debugPrint('handleSalesOrderAddCustomer: $data');

    // ── broadcast to clients & local Hive ─────────────────────────
    sendDataToClients({
      'action': 'salesOrderAddCustomerGenerated',
      'salesOrderAddCustomer': data,
    }, clients);

    saveSalesOrderAddCustomerToHive(data);

    // ── extract fields for the sync call ──────────────────────────
    final String? name = data['name'] as String?;
    final String? mobile = data['mobile'] as String?;
    final String? branch = data['branchId'] as String?;

    if (name == null || mobile == null) {
      debugPrint('❌ Missing name or mobile – sync aborted');
      return;
    }

    final success = await _syncService.postAddNewCustomerOrder(
      name: name,
      mobile: mobile,
      branchId: branch,
    );

    if (success) {
      debugPrint('✅ Sales‑order customer posted successfully.');
    } else {
      debugPrint('❌ Failed to post sales‑order customer.');
    }
  }

  void handleToApproveOrder(Map<String, dynamic> data) async {
    // Notify connected clients about the new sales order.

    debugPrint("toApproveOrderGenerated: $data");

    // Save the sales order locally.
    await saveToApproveOrderToHive(data);
    debugPrint("Saved sale order locally: $data");

    // If the sales order data contains a nested "data" key,
    // extract it. Otherwise, fallback to the original data.
    final modifyOrder = data['data'] ?? data;

    sendDataToClients({
      'action': 'toApproveOrderGenerated',
      'toApproveOrder': data,
    }, clients);

    // Post the flattened sales order to the FastAPI endpoint.
    bool success = await _syncService.postToApproveOrder({
      "data": [modifyOrder]
    });

    if (success) {
      // _syncService.patchSaleOrder();
      debugPrint("Modify order api posted successfully.");
    } else {
      debugPrint("Failed to post sales order.");
    }
  }

  void handleHoldOrder(Map<String, dynamic> data) async {
    sendDataToClients({
      'action': 'holdOrderGenerated',
      'holdOrder': data,
    }, clients);
    print("handleHoldOrder $data");

    print("savePosInvoiceToHive 1");
    await saveHoldOrderToHive(data);
    print("savePosInvoiceToHive 2 $data");
  }

  void handleSalesApprovalOrder(Map<String, dynamic> data) async {
    print("handleSalesApprovalOrder $data");
    final salesOrder = data['data'] ?? data;
    print("savePosInvoiceToHive 1");
    await saveSalesApprovalOrderToHive(data);
    sendDataToClients({
      'action': 'salesApprovalOrderGenerated',
      'salesApprovalOrder': data,
    }, clients);
    bool success = await _syncService.postDiscountOrder({
      "data": [salesOrder]
    });

    if (success) {
      // _syncService.patchSaleOrder();
      debugPrint("Modify order api posted successfully.");
    } else {
      debugPrint("Failed to post sales order.");
    }
    print("savePosInvoiceToHive 2 $data");
  }

  Future<void> saveSalesApprovalOrderToHive(Map<String, dynamic> data) async {
    var box = await Hive.openBox('salesApprovalOrder');
    await box.add(data);
    print("Sales approval order saved to Hive: $data");
  }

  Map<String, WebSocketChannel> ipChannelMap = {};
  Future<void> handleWebSocket(WebSocket socket, Set<WebSocketChannel> clients,
      Function(Map<String, dynamic>) onDataReceived) async {
    final channel = IOWebSocketChannel(socket);
    print('channel: $channel');

    clients.add(channel);
    print('New client connected. Total clients: ${clients.length}');

    final Map<String, Future<void> Function(Map<String, dynamic>)>
        actionHandlers = {
      'removePrinter': (data) async {
        handleRemovePrinter(data, clients);
      },
      'printerDetails': (data) async {
        await savePrinterDetailsToHive(data);
        sendDataToClients(data, clients);
      },
      'transferSeat': (data) async {
        await saveTransferToHive(data);
        sendDataToClients(data, clients);
      },
      'deleteOrder': (data) async {
        await deleteOrderFromHive(data['hiveOrderId']);
        sendDataToClients(data, clients);
      },
    };

    // Map for handling messages triggered by the 'type' field.
    final Map<String, Future<void> Function(Map<String, dynamic>)>
        typeHandlers = {
      'invoice': (data) async {
        handleInvoice(data);
      },
      'posInvoice': (data) async {
        handleInvoice(data);
      },
      'salesOrder': (data) async {
        await handleSaleOrder(data);
      },
      'patchSaleOrder': (data) async {
        handlePatchSaleOrder(data);
      },
      'postToApprove': (data) async {
        handleToApproveOrder(data);
      },
      'modifySaleOrder': (data) async {
        handleModifyOrder(data);
      },
      'holdOrder': (data) async {
        sendDataToClients({
          'action': 'holdOrderGenerated',
          'holdOrder': data,
        }, clients);
        print("saveHoldOrderToHive123 $data");
        await saveHoldOrderToHive(data);
      },
      'salesApprovalOrder': (data) async {
        handleSalesApprovalOrder(data);
      },
      'newCustomer': (data) async {
        print("newCustomer :  $data");
        handleSalesOrderAddCustomer(data);
      },
      'paymentDetails': (data) async {
        print("PaymentDetails $data");
        paymentDetails = data;
        _advanceController.text = data['advance'].toString();
        notifyListeners(); // Notify listeners about the state change
      },
      'placeOrderCliked': (data) async {
        print("placeOrderCliked $data");
        showPaymentScreen = true;
        notifyListeners(); // Notify listeners about the state change
      },
      'sentIp': (data) async {
        print("sentIp received: $data");

        // Retrieve the current device's WiFi IP using network_info_plus.
        final info = NetworkInfo();
        final myIp = await info.getWifiIP();
        print("Current device IP: $myIp");

        // Compare the received IP with the current device IP.
        bool isSame = (data['ip'] == myIp);

        // Optionally, show a dialog with the details.

        // Send the current device IP, the received data, and the match result to the clients.
        sendDataToClients({
          'action': 'deviceIpGenerated',
          'data': data,
          'deviceIp': myIp,
          'isSame': isSame,
        }, clients);
      },
    };

    channel.stream.listen((message) async {
      try {
        var data = jsonDecode(message);
        // print('Received message: $data');
        onDataReceived(data);

        // Special handling for heartbeat
        if (data.containsKey('action') && data['action'] == 'heartbeat') {
          channel.sink.add(jsonEncode({'action': 'heartbeatAck'}));
          return;
        }

        // Process actions if present
        if (data.containsKey('action') &&
            actionHandlers.containsKey(data['action'])) {
          await actionHandlers[data['action']]!(data);
          return;
        }

        // Process types if present
        if (data.containsKey('type') &&
            typeHandlers.containsKey(data['type'])) {
          await typeHandlers[data['type']]!(data);
          return;
        }

        print('Unhandled message type: $data');
      } catch (e) {
        print('Error decoding message: $e');
      }
    }, onDone: () {
      clients.remove(channel);
      channel.sink.close();
      print('Client disconnected. Total clients: ${clients.length}');
    }, onError: (error) {
      print('Error in WebSocket stream: $error');
      clients.remove(channel);
      print('Client disconnected. Total clients: ${clients.length}');
    });
  }

  Future<void> onDataReceived(Map<String, dynamic> data) async {
    //for (var order in _receivedData) {}
    if (data['action'] == 'seat_tapped') {
      sendDataToClients(data, clients);
    }
  }

  // Future<void> checkPendingApprovals(salesOrdersBox) async {
  //   debugPrint('🔍 Checking for pending approval orders');
  //   // final salesOrdersBox = await Hive.openBox('saleOrderBox');

  //   // Print all entries in the box
  //   debugPrint('📦 Current contents of saleOrderBox:');
  //   debugPrint(
  //       '🔎 Verifying presence of "waitingForApprovalResult" in each entry:');
  //   salesOrdersBox.toMap().forEach((key, value) {
  //     if (value is Map && value.containsKey('waitingForApprovalResult')) {
  //       debugPrint(
  //           '✅ Key: $key → "waitingForApprovalResult" exists with value: ${value['waitingForApprovalResult']}');
  //     } else {
  //       debugPrint('❌ Key: $key → "waitingForApprovalResult" is MISSING');
  //     }
  //   });

  //   for (final entry in salesOrdersBox.toMap().entries) {
  //     final order = entry.value;
  //     final orderData = order['data'];
  //     print('orderData: $orderData');
  //     if (order['waitingForApprovalResult'] == 'No' &&
  //         orderData is Map &&
  //         orderData.containsKey('saleOrderNo')) {
  //       final saleOrderNo = orderData['saleOrderNo'];

  //       // Check approvalDetails conditions
  //       // final approvalDetails = orderData['approvalDetails'];
  //       // print('approvaldetails: $approvalDetails');
  //       // if (approvalDetails is! List || approvalDetails.isEmpty) {
  //       //   debugPrint(
  //       //       '⏩ Skipping $saleOrderNo: approvalDetails is not a list or is empty.');
  //       //   continue;
  //       // }

  //       // final lastApproval = approvalDetails.last;
  //       // if (lastApproval is! Map ||
  //       //     lastApproval.containsKey('approvalStatus')) {
  //       //   debugPrint(
  //       //       '⏩ Skipping $saleOrderNo: last approval has approvalStatus or is invalid.');
  //       //   continue;
  //       // }

  //       // debugPrint(
  //       //     '📡 Found pending approval for $saleOrderNo with no status in last approval');

  //       final approvalStatus = orderData['approvalStatus'];
  //       debugPrint('approvalStatus for $saleOrderNo: $approvalStatus');

  //       if (approvalStatus != null) {
  //         debugPrint(
  //             '⏩ Skipping $saleOrderNo: approvalStatus is not null ($approvalStatus)');
  //         continue;
  //       }

  //       debugPrint(
  //           '📡 Found pending approval for $saleOrderNo with null approvalStatus');
  //       try {
  //         final apiResponse =
  //             await _syncService.fetchSalesOrderFromApi(saleOrderNo);
  //         dynamic apiSalesOrder = apiResponse;

  //         // Handle API response whether it's List or Map
  //         if (apiSalesOrder is List) {
  //           debugPrint(
  //               '🔄 API returned List with ${apiSalesOrder.length} items');
  //           apiSalesOrder =
  //               apiSalesOrder.isNotEmpty ? apiSalesOrder.first : null;
  //         }

  //         if (apiSalesOrder != null && apiSalesOrder is Map<String, dynamic>) {
  //           final updatedOrder = Map<String, dynamic>.from(order);

  //           // Merge API data into existing 'data' field
  //           if (updatedOrder['data'] is Map) {
  //             updatedOrder['data'] =
  //                 Map<String, dynamic>.from(updatedOrder['data'])
  //                   ..addAll(apiSalesOrder);
  //           } else {
  //             updatedOrder['data'] = apiSalesOrder;
  //           }

  //           updatedOrder['waitingForApprovalResult'] = 'No';

  //           await salesOrdersBox.put(entry.key, updatedOrder);
  //           debugPrint('✅ Updated Hive entry ${entry.key} with API data');

  //           sendDataToClients({
  //             'action': 'patchsaleorderGenerated',
  //             'saleOrderNo': saleOrderNo,
  //             'patchSaleOrder': updatedOrder,
  //           }, clients);
  //         } else {
  //           debugPrint(
  //               '⚠️ No valid data found in API response for $saleOrderNo');
  //         }
  //       } catch (e) {
  //         debugPrint('🚨 Error processing $saleOrderNo: ${e.toString()}');
  //       }
  //     }
  //   }

  //   debugPrint('📦 Contents of saleOrderBox after processing:');
  //   salesOrdersBox.toMap().forEach((key, value) {
  //     debugPrint('🗝️ Key: $key, 📝 Value: $value');
  //   });
  // }

  Future<void> checkPendingApprovals(salesOrdersBox) async {
    debugPrint('🔍 Checking for pending approval orders');

    // Print all entries in the box
    debugPrint('📦 Current contents of saleOrderBox:');
    salesOrdersBox.toMap().forEach((key, value) {
      debugPrint(
          '🗝️ Key: $key, 📝 Value: ${jsonEncode(value)}'); // Print full entry
    });

    debugPrint(
        '🔎 Verifying presence of "waitingForApprovalResult" in each entry:');
    salesOrdersBox.toMap().forEach((key, value) {
      if (value is Map && value.containsKey('waitingForApprovalResult')) {
        debugPrint(
            '✅ Key: $key → "waitingForApprovalResult" exists with value: ${value['waitingForApprovalResult']}');
      } else {
        debugPrint('❌ Key: $key → "waitingForApprovalResult" is MISSING');
      }
    });

    for (final entry in salesOrdersBox.toMap().entries) {
      final order = entry.value;
      final orderData = order['data'];
      debugPrint('📋 orderData for key ${entry.key}: ${jsonEncode(orderData)}');

      if (order['waitingForApprovalResult'] == 'Yes' &&
          orderData is Map &&
          orderData.containsKey('saleOrderNo')) {
        final saleOrderNo = orderData['saleOrderNo'];
        debugPrint('📄 Processing saleOrderNo: $saleOrderNo');

        final approvalStatus = orderData['approvalStatus'];
        debugPrint('📊 approvalStatus for $saleOrderNo: $approvalStatus');

        if (approvalStatus != null) {
          debugPrint(
              '⏩ Skipping $saleOrderNo: approvalStatus is not null ($approvalStatus)');
          continue;
        }

        debugPrint(
            '📡 Found pending approval for $saleOrderNo with null approvalStatus');
        try {
          debugPrint('🌐 Fetching API data for $saleOrderNo');
          final apiResponse =
              await _syncService.fetchSalesOrderFromApi(saleOrderNo);
          debugPrint(
              '📥 API response for $saleOrderNo: ${jsonEncode(apiResponse)}');

          dynamic apiSalesOrder = apiResponse;

          // Handle API response whether it's List or Map
          if (apiSalesOrder is List) {
            debugPrint(
                '🔄 API returned List with ${apiSalesOrder.length} items');
            debugPrint('📋 API List content: ${jsonEncode(apiSalesOrder)}');
            apiSalesOrder =
                apiSalesOrder.isNotEmpty ? apiSalesOrder.first : null;
            debugPrint('📋 Selected first item: ${jsonEncode(apiSalesOrder)}');
          }

          if (apiSalesOrder != null && apiSalesOrder is Map<String, dynamic>) {
            debugPrint('✅ Valid API data received for $saleOrderNo');
            final updatedOrder = Map<String, dynamic>.from(order);
            debugPrint('📝 Original order: ${jsonEncode(order)}');

            // Merge API data into existing 'data' field
            if (updatedOrder['data'] is Map) {
              updatedOrder['data'] =
                  Map<String, dynamic>.from(updatedOrder['data'])
                    ..addAll(apiSalesOrder);
            } else {
              updatedOrder['data'] = apiSalesOrder;
            }
            debugPrint(
                '🔄 Merged order data: ${jsonEncode(updatedOrder['data'])}');

            updatedOrder['waitingForApprovalResult'] = 'No';
            debugPrint(
                '📝 Updated order with waitingForApprovalResult: ${jsonEncode(updatedOrder)}');

            await salesOrdersBox.put(entry.key, updatedOrder);
            debugPrint('✅ Updated Hive entry ${entry.key} with API data');

            debugPrint('📤 Sending data to clients for $saleOrderNo');
            sendDataToClients({
              'action': 'patchsaleorderGenerated',
              'saleOrderNo': saleOrderNo,
              'patchSaleOrder': updatedOrder,
            }, clients);
            debugPrint('📦 Client data sent: ${jsonEncode({
                  'action': 'patchsaleorderGenerated',
                  'saleOrderNo': saleOrderNo,
                  'patchSaleOrder': updatedOrder,
                })}');
          } else {
            debugPrint(
                '⚠️ No valid data found in API response for $saleOrderNo');
          }
        } catch (e) {
          debugPrint('🚨 Error processing $saleOrderNo: ${e.toString()}');
        }
      } else {
        debugPrint(
            '⏩ Skipping entry ${entry.key}: Does not meet processing conditions');
      }
    }

    debugPrint('📦 Contents of saleOrderBox after processing:');
    salesOrdersBox.toMap().forEach((key, value) {
      debugPrint('🗝️ Key: $key, 📝 Value: ${jsonEncode(value)}');
    });
  }
}
