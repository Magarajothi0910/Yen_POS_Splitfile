import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:uuid/uuid.dart';

final List<Map<String, dynamic>> _receivedData = [];

Future<void> handleNewClientConnected(
    Map<String, dynamic> data, WebSocketChannel channel) async {
  final deviceCode = data['deviceCode'];

  print('New client connected with device code: $deviceCode');

  // Store the device information in Hive
  var deviceBox = await Hive.openBox('deviceData');
  await deviceBox.put(deviceCode, {
    'connectedAt': DateTime.now().toIso8601String(),
    'status': 'active',
  });

  print('Stored device code $deviceCode in Hive with status active.');

  await sendReceivedDataToNewClient(channel);

  // Optionally send an acknowledgment back to the client
  var response = jsonEncode({
    'action': 'deviceCodeStored',
    'status': 'success',
    'message': 'Device code $deviceCode stored successfully.',
  });
  channel.sink.add(response);
}

Future<void> sendReceivedDataToNewClient(WebSocketChannel channel) async {
  print('Sending received data to the new client...');
  final currentDate = DateFormat('dd-MM-yyyy').format(DateTime.now());

  // Iterate through _receivedData and send relevant items to the new client
  for (var data in _receivedData) {
    // Check if the item is an order with a matching date and status
    if (data['action'] == 'transfer_seat' ||
        (data.containsKey('date') &&
            data['date'] == currentDate &&
            (data['status'] == "active" ||
                data['status'] == "confirm" ||
                data['status'] == "invoiced" ||
                data['status'] == "cancelled"))) {
      // Prepare the message for order data
      final receivedDataMessage = jsonEncode({
        'action': 'receivedData',
        'data': data,
      });

      channel.sink.add(receivedDataMessage);
      print('Sent order data to new client: ${data['tokenNo'] ?? 'N/A'}');
      print(receivedDataMessage);
    } else if (data['action'] == 'printerDetails') {
      // If the item is printer details, send it separately
      final printerDetailsMessage = jsonEncode({
        'action': 'printerDetails',
        'name': data['name'],
        'ipAddress': data['ipAddress'],
        'type': data['type'],
        'items': data['items'],
        'orderSource': data['orderSource'],
      });

      channel.sink.add(printerDetailsMessage);
      print('Sent printer details to new client: ${data['name']}');
    } else {
      // If data doesn't match, print a message for debugging
      print(
          'Data with token ${data['tokenNo'] ?? 'N/A'} does not match the current date: ${data['date'] ?? 'N/A'}');
    }
  }

  print('All relevant received data sent to the new client.');
}

// void sendDataToClients(
//     Map<String, dynamic> data, Set<WebSocketChannel> clients) {
//   final jsonData = jsonEncode(data);

//   print("sendDataToClients33");
//   print(jsonData);
//   for (var client in clients) {
//     bool success = false;
//     int retryCount = 0;

//     while (!success && retryCount < 3) {
//       try {
//         client.sink.add(jsonData);
//         success = true;
//       } catch (e) {
//         retryCount++;
//       }
//     }

//     if (!success) {
//       clients.remove(client);
//     }
//   }
// }

void sendDataToClients(
    Map<String, dynamic> data, Set<WebSocketChannel> clients) {
  print("sendDataToClients started5....");
  print('clients: $clients');
  // final jsonData = jsonEncode(data);
  final jsonData = jsonEncode({
    ...data,
    'messageId': Uuid().v4(), // Add unique message ID
  });
  print("Data to send: $jsonData");

  final failedClients = <WebSocketChannel>{};
  int totalSuccessfulSends = 0;

  for (var client in clients) {
    bool success = false;
    int retryCount = 0;

    print("Sending data to client: $client");

    while (!success && retryCount < 3) {
      try {
        client.sink.add(jsonData);
        success = true;
        totalSuccessfulSends++;
        print(
            "Data sent successfully to $client after ${retryCount + 1} attempt(s)");
      } catch (e) {
        retryCount++;
        print("Failed to send to $client on attempt $retryCount: $e");
      }
    }

    if (!success) {
      print("Removing client after 3 failed attempts: $client");
      failedClients.add(client);
    }
  }

  clients.removeAll(failedClients);
  print(
      "sendDataToClients finished. Total clients attempted: ${clients.length + failedClients.length}");
  print("Sent data to clients $totalSuccessfulSends times");
}

void handleRemovePrinter(
    Map<String, dynamic> data, Set<WebSocketChannel> clients) async {
  final printerName = data['printerName'];

  if (printerName != null) {
    // Update the local _receivedData by removing the printer with the matching name
    _receivedData.removeWhere((entry) =>
        entry['action'] == 'printerDetails' && entry['name'] == printerName);

    // Save the updated printer list to Hive
    var printerBox = await Hive.openBox('printerData');
    await printerBox.delete(printerName);
    print('Removed printer from Hive: $printerName');

    // Broadcast the removal to all clients
    sendDataToClients({
      'action': 'removePrinter',
      'printerName': printerName,
    }, clients);

    // Optionally, broadcast the updated list of printers to all clients
    final updatedPrinters = printerBox.values.toList();
    sendDataToClients({
      'action': 'allPrinterDetails',
      'printers': updatedPrinters,
    }, clients);

    print('Broadcasted updated printers to all clients after removal.');
  } else {
    print('Error: Printer name is null for removePrinter action.');
  }
}
