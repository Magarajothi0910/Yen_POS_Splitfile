// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:hive/hive.dart';
// import 'package:provider/provider.dart';
// import '../../../Global/allorderprint.dart';
// import '../../../Global/custom_sized_box.dart';
// import '../../../Global/custom_textWidgets.dart';
// import '../../../services/websocketService.dart';
// import '../../regular_mode_page/provider/cart_page_provider.dart';
// import '../../regular_mode_page/widget/custom_reusable_widget/letter_keyborard.dart';
// import '../screens/all_orders_page/services/get_sales_order_service.dart';
// import '../screens/create_salesOrder.dart/bank_search_dropdown.dart';
// import '../screens/model/sales_order_model.dart';

// class OrderManagementPayandPrint extends StatefulWidget {
//   final double totalAmount;
//   final String holdBillId; // Added holdBillId to identify the bill
//   final String orderId;
//   final String employee;
//   final int discount;
//   final String customerNumber;
//   final SalesOrderDisplay salesOrder;

//   const OrderManagementPayandPrint({
//     super.key,
//     required this.totalAmount,
//     required this.holdBillId, // Receive the holdBillId
//     required this.orderId,
//     required this.employee,
//     required this.discount,
//     required this.customerNumber,
//     required this.salesOrder,
//   });

//   @override
//   State<OrderManagementPayandPrint> createState() =>
//       _OrderManagementPayandPrintState();
// }

// class _OrderManagementPayandPrintState
//     extends State<OrderManagementPayandPrint> {
//   // final InvoiceService _invoiceService = InvoiceService();
//   final List<String> cashOptions = [];
//   final TextEditingController _customAmountController = TextEditingController();
//   final TextEditingController _employeeNumberController =
//       TextEditingController();
//   List<Map<String, dynamic>> _employeeSuggestions =
//       []; // Store employee suggestions
//   bool _showEmployeeSuggestions = false; // Show or hide suggestions dropdown
//   final TextEditingController _customerNumberController =
//       TextEditingController();
//   String _selectedPaymentOption = '';
//   String _selectedPaymentOptionVaule = '';
//   final TextEditingController _discountController =
//       TextEditingController(); // New controller for discount
//   final TextEditingController _customChargeController =
//       TextEditingController(); // New controller for discount
//   double _balanceAmount = 0.0; // New variable for balance
//   int _cashAmount = 0;
//   int _cardAmount = 0;
//   int _upiAmount = 0;
//   double _originalAmount = 0.0;
//   double _upiandcashAmount = 0.0;
//   String salesOrderId = '';
//   String? _selectedEmployeeFirstName;
//   bool _isPrintButtonEnabled = false;
//   late salesInvoiceReceiptPrinter receiptPrinter;
//   final TextEditingController _customCashController = TextEditingController();
//   final TextEditingController _customUpiController = TextEditingController();
//   final TextEditingController _customCardController = TextEditingController();
//   String selectedPaymentMethod = 'Cash'; // Default payment method

//   OverlayEntry? _overlayEntry;

//   // Method to show the overlay with employee suggestions
//   void _showEmployeeSuggestionsOverlay(BuildContext context) {
//     final overlay = Overlay.of(context);
//     _overlayEntry = OverlayEntry(
//       builder: (context) => Positioned(
//         top: 210.0, // Adjust this as needed to position the dropdown
//         left: 340.0,
//         right: 650.0,
//         child: Material(
//           color: Colors.transparent,
//           child: Container(
//             width: 100, // Reduced width
//             height: 150, // Reduced height
//             decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.circular(12),
//               border: Border.all(color: Colors.grey),
//             ),
//             child: ListView.builder(
//               shrinkWrap: true,
//               itemCount: _employeeSuggestions.length,
//               itemBuilder: (context, index) {
//                 final employee = _employeeSuggestions[index];
//                 return ListTile(
//                   leading: Icon(Icons.person),
//                   title: Text(
//                     '${employee['employeeNumber']} - ${employee['firstName']}',
//                     style: TextStyle(fontWeight: FontWeight.w600),
//                   ),
//                   onTap: () => _selectEmployee(employee),
//                 );
//               },
//             ),
//           ),
//         ),
//       ),
//     );
//     overlay.insert(_overlayEntry!);
//   }

//   void initializeReceiptPrinter({
//     required String employeeNameController,
//     required String customerNumberController,
//     required double discountController,
//     required double customChargeController,
//     required String selectedPaymentOptionValue,
//     required double totalAmount,
//     // required BuildContext context,
//     required double advanceAmount,
//     required String deliverydateprint,
//     required String deliveryTime,
//     required String customAmountController,
//     required String selectedPaymentOption,
//     required double balanceAmount,
//     required String customerType,
//     required SalesOrderDisplay salesOrder,
//     // required Function saveInvoiceToHiveAndPrint,
//   }) {
//     receiptPrinter = salesInvoiceReceiptPrinter(
//       employeeNameController: widget.salesOrder.employeeName,
//       customerNumberController: widget.salesOrder.customerNumber,
//       discountController: widget.salesOrder.discountAmount,
//       customChargeController: widget.salesOrder.customCharge,
//       selectedPaymentOptionValue: widget.salesOrder.paymentType,
//       totalAmount: widget.salesOrder.totalAmount,
//       advanceAmount: advanceAmount,
//       balanceAmount: balanceAmount,
//       customerType: customerType,
//       // context: context,
//       deliveryDateprint: '12-10-2024',
//       deliveryTimeprint: '10:10 AM',
//       customAmountController: 'Cash',
//       selectedPaymentOption: widget.salesOrder.paymentType,
//       salesOrder: widget.salesOrder,
//       // saveInvoiceToHiveAndPrint: saveInvoiceToHiveAndPrint,
//     );
//   }

//   Widget _buildPaymentMethodTile(
//     BuildContext context,
//     String method,
//     IconData icon,
//     String selectedMethod,
//     ValueChanged<String?> onChanged,
//   ) {
//     return GestureDetector(
//       onTap: () => onChanged(method),
//       child: Container(
//         padding: EdgeInsets.symmetric(vertical: 2, horizontal: 40),
//         decoration: BoxDecoration(
//           color: selectedMethod == method ? Colors.grey.shade200 : Colors.white,
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(
//             color: selectedMethod == method
//                 ? Colors.grey.shade600
//                 : Colors.grey.shade300,
//             width: 2,
//           ),
//           boxShadow: selectedMethod == method
//               ? [
//                   BoxShadow(
//                     color: Colors.black.withOpacity(0.1),
//                     blurRadius: 4,
//                     offset: Offset(0, 2),
//                   ),
//                 ]
//               : [],
//         ),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Icon(icon, color: Colors.grey.shade700, size: 28),
//             const SizedBox(height: 8),
//             Text(
//               method,
//               style: TextStyle(
//                 color: Colors.black87,
//                 fontWeight: FontWeight.w600,
//                 fontSize: 14,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   @override
//   void initState() {
//     super.initState();
//     cashOptions.addAll(_generateCashOptions(widget.totalAmount));
//     _originalAmount = widget.totalAmount;
//     _upiandcashAmount = widget.totalAmount;
//     salesOrderId = widget.orderId;
//     _balanceAmount =
//         widget.totalAmount; // Initially, balance equals the total amount
//     _employeeNumberController.addListener(_onEmployeeInputChanged);
//   }

//   Future<void> _onEmployeeInputChanged() async {
//     String query = _employeeNumberController.text;
//     if (query.isNotEmpty) {
//       final suggestions = await _fetchEmployeeSuggestions(query);
//       print('Filtered Suggestions: $suggestions'); // Debug suggestions
//       setState(() {
//         _employeeSuggestions = suggestions;
//         _showEmployeeSuggestions = suggestions.isNotEmpty;
//       });
//     } else {
//       setState(() {
//         _showEmployeeSuggestions = false;
//         _employeeSuggestions = [];
//       });
//     }
//   }

//   Widget _buildStyledFormField({
//     required TextEditingController controller,
//     required String labelText,
//     required IconData icon,
//     String? hintText,
//     TextInputType keyboardType = TextInputType.text,
//     String? prefixText,
//     bool readOnly = false,
//   }) {
//     return TextFormField(
//       controller: controller,
//       readOnly: readOnly,
//       keyboardType: keyboardType,
//       style: TextStyle(fontSize: 16, color: Colors.black87),
//       decoration: InputDecoration(
//         prefixText: prefixText,
//         labelText: labelText,
//         hintText: hintText,
//         hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 14),
//         filled: true,
//         fillColor: Colors.grey.shade100,
//         prefixIcon: Icon(icon, color: Colors.blueAccent),
//         border: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(12),
//           borderSide: BorderSide(color: Colors.blueAccent, width: 1.5),
//         ),
//         enabledBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(12),
//           borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
//         ),
//         focusedBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(12),
//           borderSide: BorderSide(color: Colors.blueAccent, width: 2),
//         ),
//         contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
//       ),
//     );
//   }

//   void _selectPaymentOption(String method, String amount) {
//     setState(() {
//       _selectedPaymentOption = '$method: $amount';
//       _selectedPaymentOptionVaule = method;

//       int selectedAmount = int.tryParse(amount.replaceAll('', '')) ?? 0;
//       double remainingAmount = (widget.totalAmount - selectedAmount).abs();

//       switch (method) {
//         case "Cash":
//           _cashAmount = selectedAmount;
//           _customCashController.text = selectedAmount.toString();
//           break;
//         case "Upi":
//           _upiAmount = selectedAmount;
//           _customUpiController.text = selectedAmount.toString();
//           break;
//         case "Card":
//           _cardAmount = selectedAmount;
//           _customCardController.text = selectedAmount.toString();
//           break;
//       }

//       _updateBalance(); // Update balance dynamically based on the selection
//     });
//   }

//   // Cheque-specific controllers
//   TextEditingController chequeNumberController = TextEditingController();
//   TextEditingController chequeAmountController = TextEditingController();
//   TextEditingController chequeNameController = TextEditingController();
//   TextEditingController chequeBankController = TextEditingController();
//   TextEditingController chequeDateController = TextEditingController();
//   Widget _buildPaymentOption(String amount, String method) {
//     bool isSelected = _selectedPaymentOption == '$method: $amount';
//     TextEditingController controller;

//     // Special case for Cheque - directly return the cheque details form
//     if (method == 'Cheque') {
//       return _buildChequeDetails(); // Return the cheque form
//     }

//     switch (method) {
//       case 'Cash':
//         controller = _customCashController;
//         break;
//       case 'Upi':
//         controller = _customUpiController;
//         break;
//       case 'Card':
//         controller = _customCardController;
//         break;
//       default:
//         controller = _customAmountController;
//     }

//     if (amount == 'Custom') {
//       return Padding(
//         padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 10.0),
//         child: CustomSizedBox(
//           width: 320,
//           child: TextField(
//             controller: controller,
//             keyboardType: TextInputType.numberWithOptions(decimal: true),
//             decoration: InputDecoration(
//               border: OutlineInputBorder(
//                 borderRadius: BorderRadius.circular(15),
//               ),
//               labelText: 'Enter Custom $method Amount',
//               labelStyle: TextStyle(
//                 color: isSelected ? Colors.blue.shade700 : Colors.black87,
//                 fontWeight: FontWeight.w500,
//               ),
//               filled: true,
//               fillColor:
//                   isSelected ? Colors.blue.shade50 : Colors.grey.shade200,
//               contentPadding: EdgeInsets.symmetric(
//                 vertical: 18,
//                 horizontal: 22,
//               ),
//             ),
//             style: TextStyle(fontSize: 16),
//             onChanged: (value) {
//               _selectPaymentOption(method, value);
//             },
//           ),
//         ),
//       );
//     } else {
//       return Padding(
//         padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 10.0),
//         child: ElevatedButton(
//           onPressed: () {
//             _selectPaymentOption(method, amount);
//           },
//           style: ElevatedButton.styleFrom(
//             backgroundColor: isSelected ? Colors.blue.shade600 : Colors.white,
//             foregroundColor: isSelected ? Colors.white : Colors.blue.shade600,
//             padding: EdgeInsets.symmetric(vertical: 14, horizontal: 25),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(15),
//               side: BorderSide(
//                 color: isSelected ? Colors.blue.shade800 : Colors.blue.shade300,
//                 width: isSelected ? 2 : 1,
//               ),
//             ),
//             elevation: isSelected ? 8 : 3,
//             shadowColor: Colors.grey.shade400,
//           ),
//           child: Text(
//             amount,
//             style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
//           ),
//         ),
//       );
//     }
//   }

//   void _validateForm() {
//     setState(() {
//       bool isEmployeeSelected =
//           _selectedEmployeeFirstName != null; // Check if employee is selected
//       bool isCustomerNumberValid = _customerNumberController.text.length == 10;
//       bool isPaymentOptionSelected = _selectedPaymentOption.isNotEmpty;

//       // Enable the print button only if all conditions are met
//       _isPrintButtonEnabled = isEmployeeSelected &&
//           isCustomerNumberValid &&
//           isPaymentOptionSelected;
//     });
//   }

//   // Method to select an employee from suggestions
//   void _selectEmployee(Map<String, dynamic> employee) {
//     _employeeNumberController.text =
//         '${employee['employeeNumber']} - ${employee['firstName']}';

//     // Save the first name in a separate String
//     _selectedEmployeeFirstName = employee['firstName'];

//     setState(() {
//       _showEmployeeSuggestions = false; // Hide dropdown after selection
//       _validateForm(); // Re-validate form upon selection
//     });
//     _overlayEntry?.remove();
//   }

//   // Method to get employee suggestions from Hive based on the query
//   Future<List<Map<String, dynamic>>> _fetchEmployeeSuggestions(
//     String query,
//   ) async {
//     var box = await Hive.openBox('employeeBox');
//     final List<Map<String, dynamic>> employees =
//         List<Map<String, dynamic>>.from(box.get('employees', defaultValue: []));

//     // Filter employee data based on the query (either by employee number or name)
//     return employees.where((employee) {
//       final employeeNumber = employee['employeeNumber']?.toString() ?? '';
//       final firstName = employee['firstName']?.toString().toLowerCase() ?? '';
//       return employeeNumber.contains(query) ||
//           firstName.contains(query.toLowerCase());
//     }).toList();
//   }

//   void _updateBalance() {
//     final saleProvider = Provider.of<CurrentSaleProvider>(
//       context,
//       listen: false,
//     );

//     // Get the total payments (Cash + Card + UPI)
//     double totalPayments =
//         _cashAmount.toDouble() + _cardAmount.toDouble() + _upiAmount.toDouble();

//     // Get the custom charge (if any)
//     double totalCharges = double.tryParse(_customChargeController.text) ?? 0.0;

//     // Get the discount value (as a percentage)
//     double discountValue =
//         (double.tryParse(_discountController.text) ?? 0.0) / 100;

//     setState(() {
//       // Apply discount first, then add any custom charges
//       double totalWithDiscount =
//           (widget.totalAmount * (1 - discountValue)) + totalCharges;

//       // Calculate balance
//       _balanceAmount = totalWithDiscount - totalPayments;

//       // Debugging - Print payment method selection
//       print("Selected Payment Option: $_selectedPaymentOptionVaule");

//       // Update cash options based on the updated balance
//       cashOptions.clear();
//       cashOptions.addAll(_generateCashOptions(totalWithDiscount));

//       // Ensure balance updates reflect user input
//       if (_selectedPaymentOptionVaule == "Cash") {
//         _customCashController.text = _cashAmount.toString();
//       } else if (_selectedPaymentOptionVaule == "Card") {
//         _customCardController.text = _cardAmount.toString();
//       } else if (_selectedPaymentOptionVaule == "Upi") {
//         _customUpiController.text = _upiAmount.toString();
//       }

//       // Enable the Print button if balance is zero or negative, and all fields are filled
//       _isPrintButtonEnabled = _balanceAmount <= 0 &&
//           _employeeNumberController.text.isNotEmpty &&
//           _customerNumberController.text.length == 10;
//     });
//   }

//   List<String> _generateCashOptions(double amount) {
//     List<String> options = [];
//     int exactAmount =
//         amount.ceil(); // Ensure it covers the total even if it's a fraction
//     options.add(exactAmount.toString()); // Add exact amount

//     // Determine the next immediate round figure close to the exact amount
//     int nextImmediateRound = (exactAmount % 50 == 0)
//         ? exactAmount + 50
//         : ((exactAmount / 50).ceil() * 50);
//     options.add(nextImmediateRound.toString());

//     // Determine a higher typical round figure
//     int higherRoundFigure;
//     if (nextImmediateRound % 100 == 0) {
//       higherRoundFigure = nextImmediateRound + 100;
//     } else {
//       higherRoundFigure = ((nextImmediateRound / 100).ceil() * 100);
//     }
//     options.add(higherRoundFigure.toString());

//     // Ensure we have exactly three distinct options (this is to handle edge cases where amounts could overlap)
//     return options.toSet().toList();
//   }

//   void _showCustomKeyboard(TextEditingController controller) {
//     showModalBottomSheet(
//       barrierColor: Colors.transparent,
//       context: context,
//       builder: (context) {
//         return CustomKeyboard(
//           onTextInput: (value) {
//             setState(() {
//               controller.text += value;
//             });
//           },
//           onBackspace: () {
//             setState(() {
//               if (controller.text.isNotEmpty) {
//                 controller.text = controller.text.substring(
//                   0,
//                   controller.text.length - 1,
//                 );
//               }
//             });
//           },
//           onClose: () {
//             Navigator.pop(context);
//           },
//         );
//       },
//     );
//   }

//   Widget _buildChequeDetails() {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 15),
//       child: Card(
//         color: Colors.white,
//         elevation: 3,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//         child: Padding(
//           padding: const EdgeInsets.all(15),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Expanded(
//                     child: _buildStyledFormField(
//                       controller: chequeNumberController,
//                       labelText: 'Cheque Number',
//                       icon: Icons.numbers,
//                       hintText: 'Enter cheque number',
//                       keyboardType: TextInputType.number,
//                     ),
//                   ),
//                   SizedBox(
//                     width: 10,
//                   ),
//                   Expanded(
//                     child: _buildStyledFormField(
//                       controller: chequeAmountController,
//                       labelText: 'Cheque Amount',
//                       icon: Icons.currency_rupee,
//                       hintText: 'Enter amount',
//                       keyboardType: TextInputType.number,
//                       prefixText: '₹ ',
//                     ),
//                   ),
//                   SizedBox(
//                     width: 10,
//                   ),
//                   Expanded(
//                     child: GestureDetector(
//                       onTap: () async {
//                         final DateTime? picked = await showDatePicker(
//                           context: context,
//                           initialDate: DateTime.now(),
//                           firstDate: DateTime(2000),
//                           lastDate: DateTime(2100),
//                           builder: (context, child) {
//                             return Theme(
//                               data: Theme.of(context).copyWith(
//                                 colorScheme: const ColorScheme.light(
//                                   primary: Colors.blueAccent,
//                                   onPrimary: Colors.white,
//                                   onSurface: Colors.black,
//                                 ),
//                               ),
//                               child: child!,
//                             );
//                           },
//                         );
//                         if (picked != null) {
//                           setState(() {
//                             chequeDateController.text =
//                                 "${picked.day}/${picked.month}/${picked.year}";
//                           });
//                         }
//                       },
//                       child: _buildStyledFormField(
//                         controller: chequeDateController,
//                         labelText: 'Cheque Date',
//                         icon: Icons.calendar_today,
//                         hintText: 'Select date',
//                         readOnly: true,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 10),
//               Row(
//                 children: [
//                   Expanded(
//                     child: _buildStyledFormField(
//                       controller: chequeNameController,
//                       labelText: 'Cheque Holder Name',
//                       icon: Icons.person,
//                       hintText: 'Enter name on cheque',
//                     ),
//                   ),
//                   const SizedBox(width: 15),
//                   Expanded(child: BankSearchDropdown()), // Dummy dropdown
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildPaymentSection(String method) {
//     final saleProvider = Provider.of<CurrentSaleProvider>(context);
//     List<String> options = cashOptions;
//     if (method != 'Cash') {
//       // Use the calculated total amount for UPI and Card
//       // options = [(saleProvider.calculateTotal().toStringAsFixed(0))];
//       options = [(_originalAmount.toStringAsFixed(0))];
//     }

//     return Row(
//       mainAxisAlignment: MainAxisAlignment.start,
//       children: [
//         Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: _buildPaymentOption('Custom', method),
//         ),
//         for (var option in options) _buildPaymentOption(option, method),
//         const Divider(),
//       ],
//     );
//   }

//   List<String> splitText(String text, int maxLineWidth) {
//     List<String> lines = [];
//     String remainingText = text ?? '';

//     while (remainingText.length > maxLineWidth) {
//       int lastIndex = remainingText.lastIndexOf(' ', maxLineWidth);
//       if (lastIndex == -1) {
//         // If no space is found, break at maxLineWidth
//         lastIndex = maxLineWidth;
//       }
//       lines.add(remainingText.substring(0, lastIndex).trimRight());
//       remainingText = remainingText.substring(lastIndex).trimLeft();
//     }

//     lines.add(remainingText);

//     return lines;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         automaticallyImplyLeading: false,
//         backgroundColor: Colors.blueAccent,
//         elevation: 4,
//         shadowColor: Colors.black26,
//         title: Text(
//           "Sales Order",
//           style: TextStyle(
//             color: Colors.white,
//             fontSize: 22,
//             fontWeight: FontWeight.bold,
//             letterSpacing: 1.2,
//           ),
//         ),
//         centerTitle: true,
//       ),
//       body: RepaintBoundary(
//         child: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: SingleChildScrollView(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 CustomText(
//                   text: '₹${_originalAmount.toStringAsFixed(0)}',
//                   style: const TextStyle(
//                     fontSize: 32,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.black,
//                   ),
//                 ),
//                 const CustomSizedBox(height: 10),
//                 Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       // Sales Person Input Field
//                       Row(
//                         children: [
//                           Expanded(
//                             child: TextFormField(
//                               controller: _employeeNumberController,
//                               decoration: InputDecoration(
//                                 labelText: "Sales Person",
//                                 hintText: "Enter Sales Person",
//                                 prefixIcon: Icon(Icons.person),
//                                 border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(
//                                     color: Colors.blueAccent,
//                                   ),
//                                 ),
//                                 contentPadding: EdgeInsets.symmetric(
//                                   vertical: 16,
//                                   horizontal: 12,
//                                 ),
//                               ),
//                               onChanged: (value) {
//                                 setState(() {
//                                   _showEmployeeSuggestions = value.isNotEmpty;
//                                 });

//                                 if (value.isNotEmpty) {
//                                   // Simulate fetching employee suggestions
//                                   _employeeSuggestions = [];
//                                   _showEmployeeSuggestionsOverlay(context);
//                                 } else {
//                                   _overlayEntry?.remove();
//                                 }
//                               },
//                             ),
//                           ),
//                           SizedBox(width: 16),
//                           Expanded(
//                             child: TextFormField(
//                               controller: TextEditingController(
//                                 text: widget.customerNumber,
//                               ),
//                               readOnly: true,
//                               decoration: InputDecoration(
//                                 labelText: "Customer Mobile Number",
//                                 prefixIcon: Icon(Icons.phone),
//                                 border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                 ),
//                                 contentPadding: EdgeInsets.symmetric(
//                                   vertical: 16,
//                                   horizontal: 12,
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),

//                       SizedBox(height: 5),

//                       // Discount Input Field (Read-Only)
//                       Row(
//                         children: [
//                           Expanded(
//                             child: TextFormField(
//                               readOnly: true,
//                               controller: TextEditingController(
//                                 text:
//                                     widget.salesOrder.discountAmount.toString(),
//                               ),
//                               decoration: InputDecoration(
//                                 labelText: "Discount",
//                                 prefixIcon: Icon(Icons.discount),
//                                 border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                 ),
//                                 contentPadding: EdgeInsets.symmetric(
//                                   vertical: 16,
//                                   horizontal: 12,
//                                 ),
//                               ),
//                             ),
//                           ),
//                           SizedBox(width: 16),

//                           // Custom Charge Input Field (Read-Only)
//                           Expanded(
//                             child: TextFormField(
//                               readOnly: true,
//                               controller: TextEditingController(
//                                 text: widget.salesOrder.customCharge.toString(),
//                               ),
//                               decoration: InputDecoration(
//                                 labelText: "Custom Charge",
//                                 prefixIcon: Icon(Icons.attach_money),
//                                 border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                 ),
//                                 contentPadding: EdgeInsets.symmetric(
//                                   vertical: 16,
//                                   horizontal: 12,
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),

//                 Row(
//                   children: [
//                     Text(
//                       'Payment Method',
//                       style: TextStyle(
//                         fontSize: 18,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.black87,
//                       ),
//                     ),
//                   ],
//                 ), // Payment Methods Container
//                 Row(
//                   children: [
//                     Expanded(
//                       child: Container(
//                         padding: const EdgeInsets.all(
//                           10,
//                         ), // Increased padding for better spacing
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(15),
//                           border: Border.all(color: Colors.grey.shade300),
//                           boxShadow: [
//                             BoxShadow(
//                               color: Colors.grey.withOpacity(0.1),
//                               blurRadius: 8,
//                               offset: const Offset(0, 3),
//                             ),
//                           ],
//                         ),
//                         child: Wrap(
//                           alignment: WrapAlignment
//                               .start, // Ensure tiles are aligned at the start
//                           spacing: 25, // Spacing between tiles
//                           runSpacing: 15, // Spacing between rows of tiles
//                           children: [
//                             _buildPaymentMethodTile(
//                               context,
//                               'Cash',
//                               Icons.money,
//                               selectedPaymentMethod,
//                               (value) {
//                                 setState(() {
//                                   selectedPaymentMethod = value!;
//                                 });
//                               },
//                             ),
//                             _buildPaymentMethodTile(
//                               context,
//                               'Card',
//                               Icons.credit_card,
//                               selectedPaymentMethod,
//                               (value) {
//                                 setState(() {
//                                   selectedPaymentMethod = value!;
//                                 });
//                               },
//                             ),
//                             _buildPaymentMethodTile(
//                               context,
//                               'UPI',
//                               Icons.phone_android,
//                               selectedPaymentMethod,
//                               (value) {
//                                 setState(() {
//                                   selectedPaymentMethod = value!;
//                                 });
//                               },
//                             ),
//                             _buildPaymentMethodTile(
//                               context,
//                               'Cheque',
//                               Icons.account_balance_wallet,
//                               selectedPaymentMethod,
//                               (value) {
//                                 setState(() {
//                                   selectedPaymentMethod = value!;
//                                 });
//                               },
//                             ),
//                             _buildPaymentMethodTile(
//                               context,
//                               'Others',
//                               Icons.more_horiz,
//                               selectedPaymentMethod,
//                               (value) {
//                                 setState(() {
//                                   selectedPaymentMethod = value!;
//                                 });
//                               },
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 if (selectedPaymentMethod == 'Cash')
//                   _buildPaymentSection(selectedPaymentMethod),

//                 // Cheque Details Section (Visible only when Cheque is selected)
//                 if (selectedPaymentMethod == 'Cheque') _buildChequeDetails(),

//                 if (selectedPaymentMethod == 'UPI')
//                   _buildPaymentSection(selectedPaymentMethod),
//                 if (selectedPaymentMethod == 'Card')
//                   _buildPaymentSection(selectedPaymentMethod),
//                 if (selectedPaymentMethod == 'Others')
//                   _buildPaymentSection(selectedPaymentMethod),
//                 const CustomSizedBox(height: 10),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     // Balance Amount Section
//                     Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         const CustomText(
//                           text: "Balance Amount",
//                           style: TextStyle(
//                             fontSize: 16,
//                             fontWeight: FontWeight.w500,
//                             color: Colors.black54,
//                           ),
//                         ),
//                         SizedBox(height: 5),
//                         CustomText(
//                           text: _balanceAmount.abs().toStringAsFixed(0),
//                           style: const TextStyle(
//                             fontSize: 28,
//                             fontWeight: FontWeight.bold,
//                             color: Colors.black,
//                           ),
//                         ),
//                       ],
//                     ),

//                     // Print Receipt Button
//                     ElevatedButton(
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: (_selectedEmployeeFirstName != null)
//                             ? Colors.blue
//                             : Colors
//                                 .grey, // Enable or disable based on condition
//                         foregroundColor: Colors.white, // Text color
//                         padding: const EdgeInsets.symmetric(
//                           horizontal: 30.0,
//                           vertical: 18.0,
//                         ),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(
//                             8.0,
//                           ), // Rounded corners
//                         ),
//                         elevation: 5.0,
//                       ),
//                       onPressed: (_selectedEmployeeFirstName != null)
//                           ? () => markOrderAsCompleted(salesOrderId)
//                           : null,
//                       child: const CustomText(
//                         text: "Print Receipt",
//                         style: TextStyle(
//                           fontSize: 16, // Font size
//                           fontWeight: FontWeight.bold, // Font weight
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Future<void> printReceipt(BuildContext context) async {
//     print('print clicked');
//     try {
//       // if (!context.mounted) {
//       //   return;
//       // }
//       await receiptPrinter.printReceiptDetails(context);
//       print("Receipt printed successfully.");
//     } catch (e) {
//       print("Error printing receipt: $e");
//     }
//   }

//   void markOrderAsCompleted(salesOrderId) async {
//     ApiServiceSalesOrderProvider apiService = ApiServiceSalesOrderProvider(
//       webSocketService: WebSocketService(), // Provide the required argument
//     );
//     double totalAdvanceAmount = widget.salesOrder.advanceAmount!.fold(
//       0.0,
//       (sum, value) => sum + value,
//     );

//     try {
//       // Replace with the actual sales order ID
//       initializeReceiptPrinter(
//         deliveryTime: widget.salesOrder.deliveryTime,
//         deliverydateprint: widget.salesOrder.deliveryDate,
//         employeeNameController: _employeeNumberController.text,
//         customerNumberController: _customerNumberController.text,
//         discountController: widget.salesOrder.discountAmount,
//         customChargeController: widget.salesOrder.customCharge,
//         selectedPaymentOptionValue: widget.salesOrder.paymentType,
//         totalAmount: widget.salesOrder.totalAmount,
//         // advanceAmount: widget.salesOrder.advanceAmount,
//         advanceAmount: totalAdvanceAmount,
//         balanceAmount: widget.salesOrder.balanceAmount,
//         customerType: 'SalesOrder',
//         // context: context,
//         customAmountController: _customAmountController.text,
//         selectedPaymentOption: _selectedPaymentOption,
//         salesOrder: widget.salesOrder,
//         // saveInvoiceToHiveAndPrint: () {}
//       );
//       print('paymenttype$_selectedPaymentOption');
//       debugPrint('cash$_cashAmount');
//       debugPrint('_cardAmount$_cardAmount');
//       debugPrint('_upiAmount$_upiAmount');
//       bool success = await apiService.updateOrderStatus(
//         salesOrderId,
//         _selectedPaymentOptionVaule,
//         _cashAmount,
//         _cardAmount,
//         _upiAmount,
//         "SalesOrder Completed",
//       );
//       // print(invoice.toJson());
//       if (success) {
//         // await apiService.postSalesInvoice();
//         if (context.mounted) {
//           await printReceipt(context);
//           Navigator.pop(context);
//         }
//         await apiService.fetchAllOrders();
//         print("Order status updated to Completed!");
//       } else {
//         print("Failed to update order status.");
//       }
//     } catch (e) {
//       print("Error: $e");
//     }
//   }
// }

// class CustomNumberInputFormatter extends TextInputFormatter {
//   @override
//   TextEditingValue formatEditUpdate(
//     TextEditingValue oldValue,
//     TextEditingValue newValue,
//   ) {
//     final regExp = RegExp(
//       r'^[6-9][0-9]{0,9}$',
//     ); // Starts with 6-9, up to 10 digits

//     // Check if the new value is empty to allow clearing the input
//     if (newValue.text.isEmpty) {
//       return newValue;
//     }

//     if (regExp.hasMatch(newValue.text)) {
//       // Valid input
//       return newValue;
//     } else if (newValue.text.length > 10) {
//       // If the input exceeds 10 digits, return old value
//       return oldValue;
//     }

//     // Revert to the old value if invalid input
//     return oldValue;
//   }
// }

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:provider/provider.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../../../Global/allorderprint.dart';
import '../../../Global/custom_sized_box.dart';
import '../../../Global/custom_textWidgets.dart';
import '../../../services/websocketService.dart';
import '../../kot_screen/global/globals.dart';
import '../../regular_mode_page/provider/cart_page_provider.dart';
import '../../regular_mode_page/widget/custom_reusable_widget/letter_keyborard.dart';
import '../sales_order_providers/customerScreen_provider.dart';
import '../screens/all_orders_page/services/get_sales_order_service.dart';
import '../screens/create_salesOrder.dart/bank_search_dropdown.dart';
import '../screens/model/sales_order_model.dart';

class OrderManagementPayandPrint extends StatefulWidget {
  final double totalAmount;
  final String holdBillId; // Added holdBillId to identify the bill
  final String orderId;
  final String employee;
  final int discount;
  final String customerNumber;
  final SalesOrderDisplay salesOrder;

  const OrderManagementPayandPrint({
    super.key,
    required this.totalAmount,
    required this.holdBillId, // Receive the holdBillId
    required this.orderId,
    required this.employee,
    required this.discount,
    required this.customerNumber,
    required this.salesOrder,
  });

  @override
  State<OrderManagementPayandPrint> createState() =>
      _OrderManagementPayandPrintState();
}

class _OrderManagementPayandPrintState
    extends State<OrderManagementPayandPrint> {
  // final InvoiceService _invoiceService = InvoiceService();
  final List<String> cashOptions = [];
  TextEditingController _customAmountController = TextEditingController();
  TextEditingController _employeeNumberController = TextEditingController();
  List<Map<String, dynamic>> _employeeSuggestions =
      []; // Store employee suggestions
  bool _showEmployeeSuggestions = false; // Show or hide suggestions dropdown
  final TextEditingController _customerNumberController =
      TextEditingController();
  String _selectedPaymentOption = '';
  String _selectedPaymentOptionVaule = '';
  final TextEditingController _discountController =
      TextEditingController(); // New controller for discount
  final TextEditingController _customChargeController =
      TextEditingController(); // New controller for discount
  double _balanceAmount = 0.0; // New variable for balance
  int _cashAmount = 0;
  int _cardAmount = 0;
  int _upiAmount = 0;
  double _originalAmount = 0.0;
  double _upiandcashAmount = 0.0;
  String salesOrderId = '';
  String? _selectedEmployeeFirstName;
  bool _isPrintButtonEnabled = false;
  late salesInvoiceReceiptPrinter receiptPrinter;
  final TextEditingController _customCashController = TextEditingController();
  final TextEditingController _customUpiController = TextEditingController();
  final TextEditingController _customCardController = TextEditingController();
  String selectedPaymentMethod = 'Cash'; // Default payment method
  late WebSocketChannel _channel;
  OverlayEntry? _overlayEntry;

  // Method to show the overlay with employee suggestions
  void _showEmployeeSuggestionsOverlay(BuildContext context) {
    final overlay = Overlay.of(context);
    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        top: 210.0, // Adjust this as needed to position the dropdown
        left: 340.0,
        right: 650.0,
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: 100, // Reduced width
            height: 150, // Reduced height
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey),
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _employeeSuggestions.length,
              itemBuilder: (context, index) {
                final employee = _employeeSuggestions[index];
                return ListTile(
                  leading: Icon(Icons.person),
                  title: Text(
                    '${employee['employeeNumber']} - ${employee['firstName']}',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  onTap: () => _selectEmployee(employee),
                );
              },
            ),
          ),
        ),
      ),
    );
    overlay.insert(_overlayEntry!);
  }

  void initializeReceiptPrinter({
    required TextEditingController employeeNameController,
    required TextEditingController customerNumberController,
    required double discountController,
    required double customChargeController,
    required String selectedPaymentOptionValue,
    required double totalAmount,
    // required BuildContext context,
    required double advanceAmount,
    required String deliverydateprint,
    required String deliveryTime,
    required TextEditingController customAmountController,
    required String selectedPaymentOption,
    required double balanceAmount,
    required String customerType,
    required SalesOrderDisplay salesOrder,
    // required Function saveInvoiceToHiveAndPrint,
  }) {
    receiptPrinter = salesInvoiceReceiptPrinter(
      employeeNameController: employeeNameController,
      customerNumberController: customerNumberController,
      discountController: widget.salesOrder.discountAmount,
      customChargeController: widget.salesOrder.customCharge,
      selectedPaymentOptionValue: widget.salesOrder.paymentType,
      totalAmount: widget.salesOrder.totalAmount,
      advanceAmount: advanceAmount,
      balanceAmount: balanceAmount,
      customerType: customerType,
      // context: context,
      deliveryDateprint: '12-10-2024',
      deliveryTimeprint: '10:10 AM',

      selectedPaymentOption: widget.salesOrder.paymentType,

      customAmountController: customAmountController,
      // saveInvoiceToHiveAndPrint: saveInvoiceToHiveAndPrint,
    );
  }

  Widget _buildPaymentMethodTile(
    BuildContext context,
    String method,
    IconData icon,
    String selectedMethod,
    ValueChanged<String?> onChanged,
  ) {
    return GestureDetector(
      onTap: () => onChanged(method),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 2, horizontal: 40),
        decoration: BoxDecoration(
          color: selectedMethod == method ? Colors.grey.shade200 : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selectedMethod == method
                ? Colors.grey.shade600
                : Colors.grey.shade300,
            width: 2,
          ),
          boxShadow: selectedMethod == method
              ? [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ]
              : [],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.grey.shade700, size: 28),
            const SizedBox(height: 8),
            Text(
              method,
              style: TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    cashOptions.addAll(_generateCashOptions(widget.totalAmount));
    _originalAmount = widget.totalAmount;
    _upiandcashAmount = widget.totalAmount;
    salesOrderId = widget.orderId;
    _balanceAmount =
        widget.totalAmount; // Initially, balance equals the total amount
    _employeeNumberController.addListener(_onEmployeeInputChanged);
    _channel = WebSocketChannel.connect(
      Uri.parse(
        'ws://$serverip:$port',
      ), // Replace `port` with your WebSocket server's port
    );

    // Add a listener for WebSocket messages if needed
    _channel.stream.listen(
      (data) {
        print('Received data : $data');
      },
      onError: (error) {
        print('WebSocket error: $error');
      },
    );
    cashOptions.addAll(_generateCashOptions(widget.totalAmount));
    _balanceAmount =
        widget.totalAmount; // Initially, balance equals the total amount
    _employeeNumberController.addListener(_validateForm);
    _customerNumberController.addListener(_validateForm);
    _customAmountController.addListener(_validateForm);
    _employeeNumberController.addListener(_onEmployeeInputChanged);
  }

  Future<void> _onEmployeeInputChanged() async {
    String query = _employeeNumberController.text;
    if (query.isNotEmpty) {
      final suggestions = await _fetchEmployeeSuggestions(query);
      print('Filtered Suggestions: $suggestions'); // Debug suggestions
      setState(() {
        _employeeSuggestions = suggestions;
        _showEmployeeSuggestions = suggestions.isNotEmpty;
      });
    } else {
      setState(() {
        _showEmployeeSuggestions = false;
        _employeeSuggestions = [];
      });
    }
  }

  Widget _buildStyledFormField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    String? hintText,
    TextInputType keyboardType = TextInputType.text,
    String? prefixText,
    bool readOnly = false,
  }) {
    return TextFormField(
      controller: controller,
      readOnly: readOnly,
      keyboardType: keyboardType,
      style: TextStyle(fontSize: 16, color: Colors.black87),
      decoration: InputDecoration(
        prefixText: prefixText,
        labelText: labelText,
        hintText: hintText,
        hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 14),
        filled: true,
        fillColor: Colors.grey.shade100,
        prefixIcon: Icon(icon, color: Colors.blueAccent),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blueAccent, width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blueAccent, width: 2),
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      ),
    );
  }

  void _selectPaymentOption(String method, String amount) {
    setState(() {
      _selectedPaymentOption = '$method: $amount';
      _selectedPaymentOptionVaule = method;

      int selectedAmount = int.tryParse(amount.replaceAll('', '')) ?? 0;
      double remainingAmount = (widget.totalAmount - selectedAmount).abs();

      switch (method) {
        case "Cash":
          _cashAmount = selectedAmount;
          _customCashController.text = selectedAmount.toString();
          break;
        case "Upi":
          _upiAmount = selectedAmount;
          _customUpiController.text = selectedAmount.toString();
          break;
        case "Card":
          _cardAmount = selectedAmount;
          _customCardController.text = selectedAmount.toString();
          break;
      }

      _updateBalance(); // Update balance dynamically based on the selection
    });
  }

  // Cheque-specific controllers
  TextEditingController chequeNumberController = TextEditingController();
  TextEditingController chequeAmountController = TextEditingController();
  TextEditingController chequeNameController = TextEditingController();
  TextEditingController chequeBankController = TextEditingController();
  TextEditingController chequeDateController = TextEditingController();
  Widget _buildPaymentOption(String amount, String method) {
    bool isSelected = _selectedPaymentOption == '$method: $amount';
    TextEditingController controller;

    // Special case for Cheque - directly return the cheque details form
    if (method == 'Cheque') {
      return _buildChequeDetails(); // Return the cheque form
    }

    switch (method) {
      case 'Cash':
        controller = _customCashController;
        break;
      case 'Upi':
        controller = _customUpiController;
        break;
      case 'Card':
        controller = _customCardController;
        break;
      default:
        controller = _customAmountController;
    }

    if (amount == 'Custom') {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 10.0),
        child: CustomSizedBox(
          width: 160,
          child: TextField(
            controller: controller,
            keyboardType: TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              labelText: 'Enter Custom $method Amount',
              labelStyle: TextStyle(
                color: isSelected ? Colors.blue.shade700 : Colors.black87,
                fontWeight: FontWeight.w500,
              ),
              filled: true,
              fillColor:
                  isSelected ? Colors.blue.shade50 : Colors.grey.shade200,
              contentPadding: EdgeInsets.symmetric(
                vertical: 18,
                horizontal: 22,
              ),
            ),
            style: TextStyle(fontSize: 16),
            onChanged: (value) {
              _selectPaymentOption(method, value);
            },
          ),
        ),
      );
    } else {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 10.0),
        child: ElevatedButton(
          onPressed: () {
            _selectPaymentOption(method, amount);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: isSelected ? Colors.blue.shade600 : Colors.white,
            foregroundColor: isSelected ? Colors.white : Colors.blue.shade600,
            padding: EdgeInsets.symmetric(vertical: 14, horizontal: 25),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
              side: BorderSide(
                color: isSelected ? Colors.blue.shade800 : Colors.blue.shade300,
                width: isSelected ? 2 : 1,
              ),
            ),
            elevation: isSelected ? 8 : 3,
            shadowColor: Colors.grey.shade400,
          ),
          child: Text(
            amount,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),
      );
    }
  }

  void _validateForm() {
    setState(() {
      bool isEmployeeSelected =
          _selectedEmployeeFirstName != null; // Check if employee is selected
      bool isCustomerNumberValid = _customerNumberController.text.length == 10;
      bool isPaymentOptionSelected = _selectedPaymentOption.isNotEmpty;

      // Enable the print button only if all conditions are met
      _isPrintButtonEnabled = isEmployeeSelected &&
          isCustomerNumberValid &&
          isPaymentOptionSelected;
    });
  }

  // Method to select an employee from suggestions
  void _selectEmployee(Map<String, dynamic> employee) {
    _employeeNumberController.text =
        '${employee['employeeNumber']} - ${employee['firstName']}';

    // Save the first name in a separate String
    _selectedEmployeeFirstName = employee['firstName'];

    setState(() {
      _showEmployeeSuggestions = false; // Hide dropdown after selection
      _validateForm(); // Re-validate form upon selection
    });
    _overlayEntry?.remove();
  }

  Future<void> sendInvoiceDataToServer(Map<String, dynamic> invoiceData) async {
    try {
      final jsonData = jsonEncode(invoiceData);
      _channel.sink.add(jsonData);
      print('Invoice data sent to server: $jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  Future<void> sendpatchInvoiceDataToServer(
    Map<String, dynamic> invoiceData,
  ) async {
    try {
      final jsonData = jsonEncode(invoiceData);
      _channel.sink.add(jsonData);
      print('Invoice data sent to server: $jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  // Method to get employee suggestions from Hive based on the query
  Future<List<Map<String, dynamic>>> _fetchEmployeeSuggestions(
    String query,
  ) async {
    var box = await Hive.openBox('employeeBox');
    final List<Map<String, dynamic>> employees =
        List<Map<String, dynamic>>.from(box.get('employees', defaultValue: []));

    // Filter employee data based on the query (either by employee number or name)
    return employees.where((employee) {
      final employeeNumber = employee['employeeNumber']?.toString() ?? '';
      final firstName = employee['firstName']?.toString().toLowerCase() ?? '';
      return employeeNumber.contains(query) ||
          firstName.contains(query.toLowerCase());
    }).toList();
  }

  void _updateBalance() {
    final saleProvider = Provider.of<CurrentSaleProvider>(
      context,
      listen: false,
    );

    // Get the total payments (Cash + Card + UPI)
    double totalPayments =
        _cashAmount.toDouble() + _cardAmount.toDouble() + _upiAmount.toDouble();

    // Get the custom charge (if any)
    double totalCharges = double.tryParse(_customChargeController.text) ?? 0.0;

    // Get the discount value (as a percentage)
    double discountValue =
        (double.tryParse(_discountController.text) ?? 0.0) / 100;

    setState(() {
      // Apply discount first, then add any custom charges
      double totalWithDiscount =
          (widget.totalAmount * (1 - discountValue)) + totalCharges;

      // Calculate balance
      _balanceAmount = totalWithDiscount - totalPayments;

      // Debugging - Print payment method selection
      print("Selected Payment Option: $_selectedPaymentOptionVaule");

      // Update cash options based on the updated balance
      cashOptions.clear();
      cashOptions.addAll(_generateCashOptions(totalWithDiscount));

      // Ensure balance updates reflect user input
      if (_selectedPaymentOptionVaule == "Cash") {
        _customCashController.text = _cashAmount.toString();
      } else if (_selectedPaymentOptionVaule == "Card") {
        _customCardController.text = _cardAmount.toString();
      } else if (_selectedPaymentOptionVaule == "Upi") {
        _customUpiController.text = _upiAmount.toString();
      }

      // Enable the Print button if balance is zero or negative, and all fields are filled
      _isPrintButtonEnabled = _balanceAmount <= 0 &&
          _employeeNumberController.text.isNotEmpty &&
          _customerNumberController.text.length == 10;
    });
  }

  List<String> _generateCashOptions(double amount) {
    List<String> options = [];
    int exactAmount =
        amount.ceil(); // Ensure it covers the total even if it's a fraction
    options.add(exactAmount.toString()); // Add exact amount

    // Determine the next immediate round figure close to the exact amount
    int nextImmediateRound = (exactAmount % 50 == 0)
        ? exactAmount + 50
        : ((exactAmount / 50).ceil() * 50);
    options.add(nextImmediateRound.toString());

    // Determine a higher typical round figure
    int higherRoundFigure;
    if (nextImmediateRound % 100 == 0) {
      higherRoundFigure = nextImmediateRound + 100;
    } else {
      higherRoundFigure = ((nextImmediateRound / 100).ceil() * 100);
    }
    options.add(higherRoundFigure.toString());

    // Ensure we have exactly three distinct options (this is to handle edge cases where amounts could overlap)
    return options.toSet().toList();
  }

  void _showCustomKeyboard(TextEditingController controller) {
    showModalBottomSheet(
      barrierColor: Colors.transparent,
      context: context,
      builder: (context) {
        return CustomKeyboard(
          onTextInput: (value) {
            setState(() {
              controller.text += value;
            });
          },
          onBackspace: () {
            setState(() {
              if (controller.text.isNotEmpty) {
                controller.text = controller.text.substring(
                  0,
                  controller.text.length - 1,
                );
              }
            });
          },
          onClose: () {
            Navigator.pop(context);
          },
        );
      },
    );
  }

  Widget _buildChequeDetails() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 15),
      child: Card(
        color: Colors.white,
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: _buildStyledFormField(
                      controller: chequeNumberController,
                      labelText: 'Cheque Number',
                      icon: Icons.numbers,
                      hintText: 'Enter cheque number',
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: _buildStyledFormField(
                      controller: chequeAmountController,
                      labelText: 'Cheque Amount',
                      icon: Icons.currency_rupee,
                      hintText: 'Enter amount',
                      keyboardType: TextInputType.number,
                      prefixText: '₹ ',
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        final DateTime? picked = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                          builder: (context, child) {
                            return Theme(
                              data: Theme.of(context).copyWith(
                                colorScheme: const ColorScheme.light(
                                  primary: Colors.blueAccent,
                                  onPrimary: Colors.white,
                                  onSurface: Colors.black,
                                ),
                              ),
                              child: child!,
                            );
                          },
                        );
                        if (picked != null) {
                          setState(() {
                            chequeDateController.text =
                                "${picked.day}/${picked.month}/${picked.year}";
                          });
                        }
                      },
                      child: _buildStyledFormField(
                        controller: chequeDateController,
                        labelText: 'Cheque Date',
                        icon: Icons.calendar_today,
                        hintText: 'Select date',
                        readOnly: true,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: _buildStyledFormField(
                      controller: chequeNameController,
                      labelText: 'Cheque Holder Name',
                      icon: Icons.person,
                      hintText: 'Enter name on cheque',
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(child: BankSearchDropdown()), // Dummy dropdown
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPaymentSection(String method) {
    final saleProvider = Provider.of<CurrentSaleProvider>(context);
    List<String> options = cashOptions;
    if (method != 'Cash') {
      // Use the calculated total amount for UPI and Card
      // options = [(saleProvider.calculateTotal().toStringAsFixed(0))];
      options = [(_originalAmount.toStringAsFixed(0))];
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: _buildPaymentOption('Custom', method),
        ),
        for (var option in options) _buildPaymentOption(option, method),
        const Divider(),
      ],
    );
  }

  List<String> splitText(String text, int maxLineWidth) {
    List<String> lines = [];
    String remainingText = text ?? '';

    while (remainingText.length > maxLineWidth) {
      int lastIndex = remainingText.lastIndexOf(' ', maxLineWidth);
      if (lastIndex == -1) {
        // If no space is found, break at maxLineWidth
        lastIndex = maxLineWidth;
      }
      lines.add(remainingText.substring(0, lastIndex).trimRight());
      remainingText = remainingText.substring(lastIndex).trimLeft();
    }

    lines.add(remainingText);

    return lines;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.blueAccent,
        elevation: 4,
        shadowColor: Colors.black26,
        title: Text(
          "Sales Order",
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
      ),
      body: RepaintBoundary(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomText(
                  text: '₹${_originalAmount.toStringAsFixed(0)}',
                  style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const CustomSizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Sales Person Input Field
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _employeeNumberController,
                              decoration: InputDecoration(
                                labelText: "Sales Person",
                                hintText: "Enter Sales Person",
                                prefixIcon: Icon(Icons.person),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(
                                    color: Colors.blueAccent,
                                  ),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 16,
                                  horizontal: 12,
                                ),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _showEmployeeSuggestions = value.isNotEmpty;
                                });

                                if (value.isNotEmpty) {
                                  // Simulate fetching employee suggestions
                                  _employeeSuggestions = [];
                                  _showEmployeeSuggestionsOverlay(context);
                                } else {
                                  _overlayEntry?.remove();
                                }
                              },
                            ),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: TextFormField(
                              controller: TextEditingController(
                                text: widget.customerNumber,
                              ),
                              readOnly: true,
                              decoration: InputDecoration(
                                labelText: "Customer Mobile Number",
                                prefixIcon: Icon(Icons.phone),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 16,
                                  horizontal: 12,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 5),

                      // Discount Input Field (Read-Only)
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              readOnly: true,
                              controller: TextEditingController(
                                text:
                                    widget.salesOrder.discountAmount.toString(),
                              ),
                              decoration: InputDecoration(
                                labelText: "Discount",
                                prefixIcon: Icon(Icons.discount),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 16,
                                  horizontal: 12,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 16),

                          // Custom Charge Input Field (Read-Only)
                          Expanded(
                            child: TextFormField(
                              readOnly: true,
                              controller: TextEditingController(
                                text: widget.salesOrder.customCharge.toString(),
                              ),
                              decoration: InputDecoration(
                                labelText: "Custom Charge",
                                prefixIcon: Icon(Icons.attach_money),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 16,
                                  horizontal: 12,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                Row(
                  children: [
                    Text(
                      'Payment Method',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ],
                ), // Payment Methods Container
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(
                          10,
                        ), // Increased padding for better spacing
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: Colors.grey.shade300),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.1),
                              blurRadius: 8,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Wrap(
                          alignment: WrapAlignment
                              .start, // Ensure tiles are aligned at the start
                          spacing: 25, // Spacing between tiles
                          runSpacing: 15, // Spacing between rows of tiles
                          children: [
                            _buildPaymentMethodTile(
                              context,
                              'Cash',
                              Icons.money,
                              selectedPaymentMethod,
                              (value) {
                                setState(() {
                                  selectedPaymentMethod = value!;
                                });
                              },
                            ),
                            _buildPaymentMethodTile(
                              context,
                              'Card',
                              Icons.credit_card,
                              selectedPaymentMethod,
                              (value) {
                                setState(() {
                                  selectedPaymentMethod = value!;
                                });
                              },
                            ),
                            _buildPaymentMethodTile(
                              context,
                              'UPI',
                              Icons.phone_android,
                              selectedPaymentMethod,
                              (value) {
                                setState(() {
                                  selectedPaymentMethod = value!;
                                });
                              },
                            ),
                            _buildPaymentMethodTile(
                              context,
                              'Cheque',
                              Icons.account_balance_wallet,
                              selectedPaymentMethod,
                              (value) {
                                setState(() {
                                  selectedPaymentMethod = value!;
                                });
                              },
                            ),
                            _buildPaymentMethodTile(
                              context,
                              'Others',
                              Icons.more_horiz,
                              selectedPaymentMethod,
                              (value) {
                                setState(() {
                                  selectedPaymentMethod = value!;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                if (selectedPaymentMethod == 'Cash')
                  _buildPaymentSection(selectedPaymentMethod),

                // Cheque Details Section (Visible only when Cheque is selected)
                if (selectedPaymentMethod == 'Cheque') _buildChequeDetails(),

                if (selectedPaymentMethod == 'UPI')
                  _buildPaymentSection(selectedPaymentMethod),
                if (selectedPaymentMethod == 'Card')
                  _buildPaymentSection(selectedPaymentMethod),
                if (selectedPaymentMethod == 'Others')
                  _buildPaymentSection(selectedPaymentMethod),
                const CustomSizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Balance Amount Section
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const CustomText(
                          text: "Balance Amount",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                            color: Colors.black54,
                          ),
                        ),
                        SizedBox(height: 5),
                        CustomText(
                          text: _balanceAmount.abs().toStringAsFixed(0),
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),

                    // Print Receipt Button
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: (_selectedEmployeeFirstName != null)
                            ? Colors.blue
                            : Colors
                                .grey, // Enable or disable based on condition
                        foregroundColor: Colors.white, // Text color
                        padding: const EdgeInsets.symmetric(
                          horizontal: 30.0,
                          vertical: 18.0,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            8.0,
                          ), // Rounded corners
                        ),
                        elevation: 5.0,
                      ),
                      onPressed: (_selectedEmployeeFirstName != null)
                          ? () => markOrderAsCompleted(salesOrderId)
                          : null,
                      child: const CustomText(
                        text: "Print Receipt",
                        style: TextStyle(
                          fontSize: 16, // Font size
                          fontWeight: FontWeight.bold, // Font weight
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void markOrderAsCompleted(salesOrderId) async {
    print("🧾 Marking order as completed...123");
    // Initialize the API service with WebSocket
    // ApiServiceSalesOrderProvider apiService = ApiServiceSalesOrderProvider(
    //   webSocketService: WebSocketService(
    //     CustomerScreenProvider(),
    //     SalesInvoiceReceiptPrinter(),
    //   ),
    // );

    // Calculate total advance amount from list
    double totalAdvanceAmount = widget.salesOrder.advanceAmount!.fold(
      0.0,
      (sum, value) => sum + value,
    );

    print("🧾 Starting order completion process...");
    print("🧮 Calculated totalAdvanceAmount: $totalAdvanceAmount");
    print("🆔 Sales Order ID: $salesOrderId");

    try {
      // Prepare the JSON object to send
      String jsoninvoiceSalesOrder = jsonEncode({
        "salesOrderId": widget.salesOrder,
        "type": "posInvoice",
        "sync": "No",
        "edit": "No",
      });

      print(
        '📝 Invoice order invoiceJSON data to send: $jsoninvoiceSalesOrder',
      );

      // Initialize receipt printer
      initializeReceiptPrinter(
        deliveryTime: widget.salesOrder.deliveryTime,
        deliverydateprint: widget.salesOrder.deliveryDate,
        employeeNameController: _employeeNumberController,
        customerNumberController: _customerNumberController,
        discountController: widget.salesOrder.discountAmount,
        customChargeController: widget.salesOrder.customCharge,
        selectedPaymentOptionValue: widget.salesOrder.paymentType,
        totalAmount: widget.salesOrder.totalAmount,
        advanceAmount: totalAdvanceAmount,
        balanceAmount: widget.salesOrder.balanceAmount,
        customerType: 'SalesOrder',
        customAmountController: _customAmountController,
        selectedPaymentOption: _selectedPaymentOption,
        salesOrder: widget.salesOrder,
      );

      print(
        "🖨️ Initialized receipt printer with current sales order details.",
      );
      print("📡 Sending invoice data via WebSocket...");
      await sendInvoiceDataToServer(jsonDecode(jsoninvoiceSalesOrder));

      print("💳 Payment Details:");
      print("  🔘 Selected Payment Option: $_selectedPaymentOption");
      debugPrint("  💵 Cash Amount: $_cashAmount");
      debugPrint("  💳 Card Amount: $_cardAmount");
      debugPrint("  📱 UPI Amount: $_upiAmount");
    } catch (e) {
      print("❗ Error occurred while completing the order: $e");
    }
    Navigator.pop(context);
  }
}

class CustomNumberInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final regExp = RegExp(
      r'^[6-9][0-9]{0,9}$',
    ); // Starts with 6-9, up to 10 digits

    // Check if the new value is empty to allow clearing the input
    if (newValue.text.isEmpty) {
      return newValue;
    }

    if (regExp.hasMatch(newValue.text)) {
      // Valid input
      return newValue;
    } else if (newValue.text.length > 10) {
      // If the input exceeds 10 digits, return old value
      return oldValue;
    }

    // Revert to the old value if invalid input
    return oldValue;
  }
}
