import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:yen_pos/Sale_order/Widgets/Send_data_to_server.dart';
import 'package:yen_pos/Server_Client/sendDataToClients.dart';

handleHandShake(Map<String, dynamic> data) async {
  final d = {'type': 'handshake', 'message': 'From Client'};
  //sendDataToClients(d, clients);
  // sendataToServer(d);
}
