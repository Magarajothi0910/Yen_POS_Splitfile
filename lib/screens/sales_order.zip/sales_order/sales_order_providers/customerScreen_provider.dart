import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:yenposapp/screens/sales_order/sales_order_providers/cart_selection_provider.dart';
// import 'package:yenposapp/screens/take_away_orders/screens/create_salesOrder.dart/create_sales_order.dart';
import '../../../Global/branchSelection.dart';
import '../../../Global/salesOrder_print.dart';
import '../../../data/global_data_manager.dart';
import '../../../services/branchwise_item_fetch.dart';
import '../../../services/websocketService.dart';
import '../sales_order_print/invoicePrint.dart';
import '../screens/all_orders_page/discount_service.dart' as globaldiscount;
import '../screens/all_orders_page/services/get_sales_order_service.dart';
import '../screens/create_salesOrder.dart/bank_search_dropdown.dart';
import '../screens/create_salesOrder.dart/create_sales_order.dart';
import '../screens/create_salesOrder.dart/models/approval_order_model.dart';
import '../screens/create_salesOrder.dart/models/held_order_model.dart';
import '../screens/create_salesOrder.dart/models/sale_order_model.dart';
import '../screens/model/sales_order_model.dart';
import 'cartProvider.dart';

import 'package:http_parser/http_parser.dart';
import '../globals.dart' as globals;

import 'package:http/http.dart' as http;
import 'package:mime/mime.dart';

import '../../../Global/globals_data.dart' as globalbranch;
import 'modifyOrderProvider.dart';
import '../../kot_screen/global/globals.dart' as globals;
import 'package:path_provider/path_provider.dart';
import 'dart:io';

import 'saveAudioandImageFile.dart';

class CustomerScreenProvider with ChangeNotifier {
  CustomerScreenProvider() {
    receiptPrinter = salesOrderReceiptPrinter(
      employeeNameController: TextEditingController(),
      customerNumberController: TextEditingController(),
      discountController: 0.0,
      customChargeController: 0.0,
      selectedPaymentOptionValue: '',
      totalAmount: 0.0,
      advanceAmount: 0.0,
      balanceAmount: 0.0,
      customerType: '',
      deliveryDateprint: '',
      deliveryTimeprint: '',
      customAmountController: TextEditingController(),
      selectedPaymentOption: '',
    );
    storedBranch = branchProvider.getStoredBranch(globalbranch.branchName);
    print('storesBranch$storedBranch');
    // globaldiscount.DiscountService();
    _initWebSocket();
  }

  late WebSocketChannel _channel;

  void _initWebSocket() {
    // Replace these with your actual server IP and port defined in globals.
    _channel = WebSocketChannel.connect(
      Uri.parse('ws://${globals.serverip}:${globals.port}'),
    );
    // Listen for messages from the server.
    _channel.stream.listen(
      (data) {
        print('Received dataCustomerProvider: $data');
        // WebSocketService();
        WebSocketService(
          CustomerScreenProvider(),
          SalesInvoiceReceiptPrinter(),
        ).handleMessage(data);
      },
      onError: (error) {
        print('WebSocket error: $error');
      },
    );
  }

  String _selectedStoreType = 'Warehouse';
  bool _isStoreTypeSelected = false;
  String _lastPrintedOrderNo = '';
  String get selectedStoreType => _selectedStoreType;
  bool get isStoreTypeSelected => _isStoreTypeSelected;

  List<Map<String, dynamic>> _hiveholdSalesOrders = [];
  List<Map<String, dynamic>> get hiveholdSalesOrders => _hiveholdSalesOrders;
  List<Map<String, dynamic>> _rawOrders = [];
  List<Map<String, dynamic>> get rawOrders => _rawOrders;
  Future<void> saveStoreType(String type) async {
    final prefs = await SharedPreferences.getInstance();
    final currentTimestamp = DateTime.now().millisecondsSinceEpoch;

    await prefs.setString('storeType', type);
    await prefs.setInt('lastShownTimestamp', currentTimestamp);

    _selectedStoreType = type;
    _isStoreTypeSelected = true;
    notifyListeners();
  }

  Future<void> sendPaymentDataToServer(Map<String, dynamic> paymentData) async {
    try {
      final jsonData = jsonEncode(paymentData);
      _channel.sink.add(jsonData);
      print('Payment data sent to server: $jsonData');
    } catch (e) {
      print('Error sending payment data to server: $e');
    }
  }

  void clikedThePaymentButton() {
    Map<String, dynamic> paymentData = {
      "type": "placeOrderCliked",
      "cliked ": "Yes",
    };

    // Call your API service method here
    sendClikedThePaymentButtonServer(paymentData);
  }

  /// Sends the brand‑new customer to the back‑end so every device sees it.
  Future<void> sendNewCustomer(String mobile, String name) async {
    print('sendNewCustomer called with mobile: $mobile, name: $name');
    final Map<String, dynamic> cutomerPayload = {
      "type": "newCustomer",
      "mobile": mobile,
      "name": name,
      "branchId": storedBranch?.branchId, // optional – remove if not needed
      "timestamp": DateTime.now().toIso8601String(),
    };

    try {
      sendSoAddNewCustomerServer(cutomerPayload);
      print('[WS]  New‑customer packet sent ➜ $cutomerPayload');
    } catch (e) {
      print('[WS]  ❌ Failed to send new‑customer packet – $e');
    }
  }

  Future<void> sendClikedThePaymentButtonServer(
      Map<String, dynamic> paymentData) async {
    try {
      final jsonData = jsonEncode(paymentData);
      _channel.sink.add(jsonData);
      print('Payment data sent to server: $jsonData');
    } catch (e) {
      print('Error sending payment data to server: $e');
    }
  }

  Future<void> sendSoAddNewCustomerServer(
      Map<String, dynamic> customerdata) async {
    try {
      final jsonData = jsonEncode(customerdata);
      _channel.sink.add(jsonData);
      print('Payment data sent to server: $jsonData');
    } catch (e) {
      print('Error sending payment data to server: $e');
    }
  }

  Future<List<Map<String, dynamic>>> fetchHolderFromHive() async {
    print("Step 1: Entering _fetchOrdersFromHive...");
    try {
      WebSocketService webSocketService = WebSocketService(
        CustomerScreenProvider(),
        SalesInvoiceReceiptPrinter(),
      );
      print("Step 2: Calling webSocketService.getSavedHoldOrder()");
      List<Map<String, dynamic>> hiveOrders =
          await webSocketService.getSavedHoldOrder();

      print("Step 3: Hive orders fetched: ${hiveOrders.length}");
      for (int i = 0; i < hiveOrders.length; i++) {
        print("Step 4: Hive order $i: ${hiveOrders[i]}");
      }

      print(
          "Step 5: Storing raw hive orders into _rawOrders and _hiveholdSalesOrders.");
      _rawOrders = hiveOrders;
      _hiveholdSalesOrders = List.from(_rawOrders);
      print("Step 6: Total orders stored: ${_rawOrders.length}");

      print("Step 7: Notifying listeners about the new data.");
      notifyListeners();
      print("Step 8: _fetchOrdersFromHive completed successfully.");

      return _hiveholdSalesOrders;
    } catch (e) {
      print("Error fetching orders from Hive: $e");
      return [];
    }
  }

  void updateReceiptData(Map<String, dynamic> orderData) {
    print("print123");
    print(orderData);

    final data = orderData; // Access the nested map safely
    print('data in the updateReceiptData: $data');
    // String saleOrderNo = data['saleOrderNo'] ?? '';
    // if (saleOrderNo.isEmpty || saleOrderNo == _lastPrintedOrderNo) {
    //   print("🔄 Order $saleOrderNo already printed or invalid");
    //   return;
    // }
    // _lastPrintedOrderNo = saleOrderNo;
    receiptPrinter.employeeNameController.text = data['employeeName'] ?? '';
    receiptPrinter.customerNumberController.text = data['customerNumber'] ?? '';

    receiptPrinter.discountController = (data['discount'] ?? 0.0).toDouble();
    receiptPrinter.customChargeController =
        (data['customCharge'] ?? 0.0).toDouble();
    receiptPrinter.selectedPaymentOptionValue = data['paymentOption'] ?? '';
    receiptPrinter.totalAmount = (data['totalAmount'] ?? 0.0).toDouble();

    receiptPrinter.advanceAmount =
        (data['advanceAmount'] is List && data['advanceAmount'].isNotEmpty)
            ? (data['advanceAmount'][0] ?? 0.0).toDouble()
            : 0.0;

    receiptPrinter.balanceAmount = (data['balanceAmount'] ?? 0.0).toDouble();
    receiptPrinter.customerType = data['customerType'] ?? '';
    receiptPrinter.deliveryDateprint = data['deliveryDate'] ?? '';
    receiptPrinter.deliveryTimeprint = data['deliveryTime'] ?? '';
    receiptPrinter.customAmountController.text =
        data['customAmount']?.toString() ?? '';

    receiptPrinter.selectedPaymentOption =
        (data['advancePaymentType'] is List &&
                data['advancePaymentType'].isNotEmpty)
            ? data['advancePaymentType'][0] ?? ''
            : '';

    String advanceDateTime =
        (data['advanceDateTime'] is List && data['advanceDateTime'].isNotEmpty)
            ? data['advanceDateTime'][0].toString()
            : '';
    print("Advance Date Time: $advanceDateTime");

    // Update cart items
    globals.cartItems = [];
    if (data.containsKey('varianceName') && data['varianceName'] is List) {
      for (int i = 0; i < data['varianceName'].length; i++) {
        print("Item Name: ${data['varianceName'][i]}");
        globals.cartItems.add(
          CartItem(
            itemName: (data['itemName'].length > i ? data['itemName'][i] : ''),
            varianceName: data['varianceName'][i] ?? '',
            itemCode: (data['itemCode'].length > i ? data['itemCode'][i] : ''),
            quantity: (data['qty'].length > i ? data['qty'][i] : 0).toInt(),
            tax: (data['tax'].length > i ? data['tax'][i] : 0).toInt(),
            uom: (data['uom'].length > i ? data['uom'][i] : ''),
            pricePerKg:
                (data['price'].length > i ? data['price'][i] : 0).toInt(),
            weight: (data['weight'].length > i ? data['weight'][i] : 0.0)
                .toDouble(),
          ),
        );
      }
    }

    print("Updated cart items: ${globals.cartItems}");

    printReceipt();
    notifyListeners();
  }

  Future<void> checkAndShowStoreTypeDialog(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final lastShownTimestamp = prefs.getInt('lastShownTimestamp') ?? 0;
    final storedStoreType = prefs.getString('storeType') ?? '';

    final lastShownDate =
        DateTime.fromMillisecondsSinceEpoch(lastShownTimestamp);
    final currentDate = DateTime.now();

    final isSameDay = lastShownDate.year == currentDate.year &&
        lastShownDate.month == currentDate.month &&
        lastShownDate.day == currentDate.day;

    if (storedStoreType.isNotEmpty) {
      _selectedStoreType = storedStoreType;
      notifyListeners();
    }

    if (!isSameDay || storedStoreType.isEmpty) {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => StoreTypeSelectionDialog(
          onStoreTypeSelected: saveStoreType,
        ),
      );
    } else {
      _isStoreTypeSelected = true;
      notifyListeners();
    }
  }

  void updateDate(String newDate) {
    dateController.text = newDate;
    notifyListeners(); // Trigger UI rebuild
  }

  // Future<void> sendInvoiceDataToServer(Map<String, dynamic> invoiceData) async {
  //   try {
  //     final jsonData = jsonEncode(invoiceData);
  //     _channel.sink.add(jsonData);
  //     print('sendInvoiceDataToServer$jsonData');
  //     print('Invoice data sent to server: $jsonData');
  //   } catch (e) {
  //     print('Error sending invoice data to server: $e');
  //   }
  // }

  int _sendInvoiceCallCount = 0;

  Future<void> sendInvoiceDataToServer(Map<String, dynamic> invoiceData) async {
    _sendInvoiceCallCount++;
    print('sendInvoiceDataToServer called $_sendInvoiceCallCount times');

    try {
      final jsonData = jsonEncode(invoiceData);
      _channel.sink.add(jsonData);
      print('sendInvoiceDataToServer$jsonData');
      print('Invoice data sent to server: $jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  Future<Directory> _createOrderDir(String saleOrderNo) async {
    final base = await getApplicationDocumentsDirectory();
    final orderDir = Directory('${base.path}/orders/$saleOrderNo');
    if (!await orderDir.exists()) {
      await orderDir.create(recursive: true);
    }
    return orderDir;
  }

  Future<void> sendApprovalDataToServer(
      Map<String, dynamic> approvalData) async {
    try {
      final jsonData = jsonEncode(approvalData);
      _channel.sink.add(jsonData);
      print('Approval data sent to server: $jsonData');
    } catch (e) {
      print('Error sending Approval data to server: $e');
    }
  }
  // String? photoScreenId;
  // String? audioPlayerId;

  // // Add these methods
  // void clearAudioAndPhotoIds() {
  //   audioPlayerId = null;
  //   photoScreenId = null;
  //   notifyListeners();
  // }

  // late ReceiptPrinter _receiptPrinter;
  // void setReceiptPrinter(ReceiptPrinter printer) {
  //   _receiptPrinter = printer;
  // }
  bool isSubmitting = false;
  late salesOrderReceiptPrinter receiptPrinter;
  List<String>? advanceDateTime;
  List<String>? advancePaymentType;
  Timer? _debounce;
  bool showAudioandImage = true;
  String selectedOrderOption = 'Inhouse';
  void initializeReceiptPrinter({
    required TextEditingController employeeNameController,
    required TextEditingController customerNumberController,
    required double discountController,
    required double customChargeController,
    required String selectedPaymentOptionValue,
    required double totalAmount,
    // required BuildContext context,
    required double advanceAmount,
    required String deliverydateprint,
    required String deliveryTime,
    required TextEditingController customAmountController,
    required String selectedPaymentOption,
    required double balanceAmount,
    required String customerType,
    // required Function saveInvoiceToHiveAndPrint,
  }) {
    receiptPrinter = salesOrderReceiptPrinter(
      employeeNameController: employeeNameController,
      customerNumberController: customerNumberController,
      discountController: discountController,
      customChargeController: customChargeController,
      selectedPaymentOptionValue: selectedPaymentOptionValue,
      totalAmount: totalAmount,
      advanceAmount: advanceAmount,
      balanceAmount: balanceAmount,
      customerType: customerType,
      // context: context,
      deliveryDateprint: dateController.text,
      deliveryTimeprint: timeController.text,
      customAmountController: customAmountController,
      selectedPaymentOption: selectedPaymentOption,
      // saveInvoiceToHiveAndPrint: saveInvoiceToHiveAndPrint,
    );
  }

  void onSuggestionSelected(Map<String, String> suggestion) {
    mobileNoController.text = suggestion['mobileNo']!;
    customerNameController.text = suggestion['name']!;
    suggestions = []; // Clear suggestions after selection
    notifyListeners();
  }

  Future<void> cancelOrder(
      String salesOrderId, Map<String, dynamic> payload) async {
    try {
      // Add the salesOrderId to the payload if needed
      final cancelOrderData = {
        'action': 'cancelOrder', // Add an action identifier for the server
        'salesOrderId': salesOrderId,
        'payload': payload,
      };

      final jsonData = jsonEncode(cancelOrderData);
      _channel.sink.add(jsonData);
      print('Cancel order request sent to server: $jsonData');
    } catch (e) {
      print('Failed to send cancel order request: $e');
      // You might want to show an error to the user here
    }
  }

  Future<void> cancelOrderAccounts(
      String salesOrderId, Map<String, dynamic> payload) async {
    try {
      // Add the salesOrderId to the payload if needed
      final cancelOrderData = {
        'action': 'cancelOrder', // Add an action identifier for the server
        'salesOrderId': salesOrderId,
        'payload': payload,
      };

      final jsonData = jsonEncode(cancelOrderData);
      _channel.sink.add(jsonData);
      print('Cancel order request sent to server: $jsonData');
    } catch (e) {
      print('Failed to send cancel order request: $e');
      // You might want to show an error to the user here
    }
  }

  Future<List<HeldOrder>> fetchOrderStatus() async {
    String url =
        "http://$ipAddress/heldorders/?status=Waiting%20for%20Approval"; // API endpoint

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
        },
      );
      print('response result${response.statusCode}');
      if (response.statusCode == 200) {
        List<dynamic> jsonData = jsonDecode(response.body);
        print('jsondata$jsonData');
        // Filter only orders with status == "holdorder"
        List<HeldOrder> heldOrders = jsonData
            .map((order) => HeldOrder.fromJson(order))
            .where((order) => order.status == "Waiting for Approval")
            .toList();

        print('Filtered Held Orders: $heldOrders');
        return heldOrders;
      } else {
        print('Failed to fetch held orders: ${response.statusCode}');
        print('Server Error: ${response.body}');
        return [];
      }
    } catch (e) {
      print('Error while fetching held orders: $e');
      return [];
    }
  }

  Future<void> fetchSuggestions(String query) async {
    print('query');
    print(query);
    if (query.isEmpty) {
      suggestions = [];
      notifyListeners();
      return;
    }

    final url = Uri.parse('http://192.168.29.246:8881/customer/');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final List customers = json.decode(response.body);
        print('customers:$customers');
        suggestions = customers
            .where((customer) => customer['customerPhoneNumber']
                .toString()
                .startsWith(query)) // Filter by mobile number prefix
            .map((customer) => {
                  'mobileNo': customer['customerPhoneNumber'].toString(),
                  'name': customer['customerName'].toString(),
                })
            .toList();
        notifyListeners();
      } else {
        throw Exception('Failed to load customers');
      }
    } catch (e) {
      print(e);
      suggestions = [];
      notifyListeners();
    }
  }
  // Handle suggestion selection
  // void onSuggestionSelected(Map<String, String> suggestion) {
  //   mobileNoController.text = suggestion['mobileNo']!;
  //   customerNameController.text = suggestion['name']!;
  // }

  void fetchCompanySuggestionsDebounced(String query) {
    if (_debounce?.isActive ?? false) _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      fetchCompanySuggestions(query);
    });
  }

  Future<bool> addCompany(String name, String address, String gst) async {
    try {
      final response = await http.post(
        Uri.parse('http://192.168.29.246:8881/companies/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'companyName': name,
          'companyAddress': address,
          'companyGST': gst,
          'status': '1',
        }),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        return true;
      } else {
        debugPrint(
            'Failed to add customer. Status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      debugPrint('Error adding customer: $e');
      return false;
    }
  }

  Future<void> fetchCompanySuggestions(String query) async {
    if (query.isEmpty) {
      suggestions = [];
      notifyListeners();
      return;
    }

    final url = Uri.parse('http://192.168.29.246:8881/companies/');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final List customers = json.decode(response.body);

        suggestions = customers
            .where((customer) => customer['companyName']
                .toString()
                .startsWith(query)) // Filter by company name prefix
            .map((customer) => {
                  'name': customer['companyName'].toString(),
                  'address': customer['companyAddress'].toString(),
                  'gst': customer['companyGST'].toString(),
                })
            .toList();
        notifyListeners();
      } else {
        throw Exception('Failed to load companies');
      }
    } catch (e) {
      print(e);
      suggestions = [];
      notifyListeners();
    }
  }

  final String baseUrl = "http://192.168.29.246:8881/CurrentOrder";

  // Future<void> cancelOrder(
  //     String salesOrderId, Map<String, dynamic> payload) async {
  //   try {
  //     final url = Uri.parse('$baseUrl/$salesOrderId'); // Append ID to URL
  //     final response = await http.patch(
  //       url,
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(payload), // Serialize the payload
  //     );

  //     if (response.statusCode == 200 || response.statusCode == 204) {
  //       print('Order canceled successfully'); // Success message
  //     } else {
  //       print('Failed to cancel order. Status code: ${response.statusCode}');
  //     }
  //   } catch (e) {
  //     print('Failed to cancel order: $e');
  //   }
  // }

  // Future<void> printReceipt(BuildContext context) async {
  //   print('print clicked');
  //   try {
  //     if (!context.mounted) {
  //       return;
  //     }
  //     await receiptPrinter.printReceiptDetails(context);
  //     print("Receipt printed successfully.");
  //   } catch (e) {
  //     print("Error printing receipt: $e");
  //   }
  // }

  bool isPaymentDone = false;
  double totalAdvance = 0;
  List<String> filteredItems = [];
  List<Map<String, dynamic>> submittedOrders = [];
  List<SalesOrder> orders = [];
  TextEditingController advanceAmountController = TextEditingController();
  BranchProvider branchProvider = BranchProvider();
  Branch? storedBranch;
  ItemProvider getbranchaliasname = ItemProvider();
  TextEditingController customersearchController = TextEditingController();
  List<Map<String, String>> filteredCustomers = [];
  String customersearchQuery = '';

  TextEditingController customerNameController = TextEditingController();
  TextEditingController customChargeController = TextEditingController();
  TextEditingController dateController = TextEditingController();
  TextEditingController birthdaydateController = TextEditingController();
  TextEditingController timeController = TextEditingController();
  TextEditingController mobileNoController = TextEditingController();
  TextEditingController searchController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController landmarkController = TextEditingController();
  TextEditingController remarkController = TextEditingController();
  TextEditingController companyNameController = TextEditingController();
  TextEditingController companyAddressController = TextEditingController();
  TextEditingController companygstNumberController = TextEditingController();
  String? _selectedEvent;
  String? get selectedEvent => _selectedEvent;
  // Member variable for payment method
  String selectedPaymentMethod = 'Cash'; // Initialized with a default value
  String searchQuery = '';
  String? selectedDeliveryType;
  void setSelectedEvent(String? event) {
    _selectedEvent = event;
    notifyListeners();
  }

  void setSelectedDeliveryType(String? newValue) {
    selectedDeliveryType = newValue;
    notifyListeners();
  }

  void selectEmployee(String employee) {
    searchController.text = employee;
    filteredItems = [];
    notifyListeners();
  }

  void holdOrers(cartProvider, path, apiProvider, img1, img2) {
    _heldOrder(cartProvider, path, apiProvider, img1, img2);
  }

  Future<void> printReceipt() async {
    try {
      print("Starting receipt print...");
      await receiptPrinter.printReceiptDetails();
      print("Receipt printed successfully.");
    } catch (e) {
      print("Error printing receipt: $e");
    }
  }

  Future<void> updateCustomId(String curentCustomId, String CustomId) async {
    final String currentCustomId =
        curentCustomId; // Replace with actual custom ID
    final String newCustomId = CustomId; // New custom ID

    final url = Uri.parse(
        'http://192.168.29.246:8881/audioOrder/media/$currentCustomId/audio');

    final response = await http.patch(
      url,
      body: {
        'new_custom_id': newCustomId,
      },
    );

    if (response.statusCode == 200) {
      print('Custom ID updated successfully');
    } else {
      print('Failed to update Custom ID: ${response.statusCode}');
    }
  }

  Future<void> updateImageId(String currentCustomId, String newCustomId) async {
    final url =
        Uri.parse("http://192.168.29.246:8881/imageOrder/media/batch_update");

    try {
      // Prepare the request body
      final body = {
        'current_custom_id': currentCustomId,
        'new_custom_id': newCustomId,
      };

      // Send the PATCH request
      final response = await http.patch(
        url,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: body,
      );

      if (response.statusCode == 200) {
        // Parse the response if needed
        final data = json.decode(response.body);
        print("Batch update successful: $data");
      } else {
        print("Failed to update: ${response.statusCode}");
        print("Error: ${response.body}");
      }
    } catch (e) {
      print("An error occurred: $e");
    }
  }

  void clearControllers() {
    dateController.clear();
    timeController.clear();
    landmarkController.clear();
    addressController.clear();
    customerNameController.clear();
    mobileNoController.clear();
    searchController.clear();
    companyAddressController.clear();
    birthdaydateController.clear();
    companyNameController.clear();
    companygstNumberController.clear();
    remarkController.clear();
    // Reset dropdown selections
    _selectedEvent = null;
    selectedDeliveryType = null;

    notifyListeners(); // Optional, if you're using ChangeNotifier
  }

  @override
  void dispose() {
    dateController.dispose();
    timeController.dispose();
    mobileNoController.dispose();
    customerNameController.dispose();
    addressController.dispose();
    landmarkController.dispose();
    searchController.dispose();
    advanceAmountController.dispose(); // Dispose all controllers
    super.dispose();
  }

  Future<bool> addCustomer(String mobile, String name) async {
    try {
      final response = await http.post(
        Uri.parse('http://192.168.29.246:8881/customer/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'customerPhoneNumber': mobile,
          'customerName': name,
          'status': '1'
        }),
      );
      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      debugPrint('Error adding customer: $e');
      return false;
    }
  }

  bool isFormValid = true;
  List<Map<String, String>> suggestions = [];

  Future<List<Map<String, String>>> fetchCustomerList() async {
    try {
      final response = await http.get(
        // Uri.parse('http://192.168.1.103:8888/fastapi/customer/'),
        Uri.parse('http://192.168.29.246:8881/customer/'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> customerData = json.decode(response.body);
        return customerData.map((data) {
          return {
            'customerName': data['customerName'] as String,
            'customerPhoneNumber': data['customerPhoneNumber'] as String,
          };
        }).toList();
      } else {
        throw Exception('Failed to load customer');
      }
    } catch (e) {
      throw Exception('Error fetching customer: $e');
    }
  }

  // void showAdvancePaymentPopup(
  //     BuildContext context,
  //     CartProvider cartProvider,
  //     String? path,
  //     ApiServiceSalesOrderProvider apiprovider,
  //     File? img1,
  //     File? img2,
  //     String customerType,
  //     String? audioOrderId,
  //     String? holdId) {
  //   double orderAmount = cartProvider.getTotalAmount();
  //   double discount = 0;
  //   double customCharge = 0;
  //   double totalAdvance = 0;
  //   double deductedAmount = 0;
  //   double totalAmount = orderAmount + customCharge - deductedAmount;

  //   TextEditingController discountController = TextEditingController();
  //   TextEditingController customChargeController = TextEditingController();
  //   TextEditingController advanceController = TextEditingController();
  //   TextEditingController remarkController = TextEditingController();

  //   String selectedPaymentMethod = 'Cash'; // Default payment method

  //   advanceController.clear();

  //   showDialog(
  //     barrierDismissible: false,
  //     context: context,
  //     builder: (context) {
  //       return StatefulBuilder(builder: (context, setState) {
  //         return AlertDialog(
  //           shape:
  //               RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
  //           title: const Text(
  //             'Payment Details',
  //             style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
  //           ),
  //           content: SizedBox(
  //             width: MediaQuery.of(context).size.width * 0.5,
  //             child: SingleChildScrollView(
  //               child: Padding(
  //                 padding: const EdgeInsets.all(16.0),
  //                 child: Column(
  //                   crossAxisAlignment: CrossAxisAlignment.start,
  //                   children: [
  //                     Text(
  //                       'Order Amount: ₹$orderAmount',
  //                       style: const TextStyle(fontSize: 16),
  //                     ),
  //                     const SizedBox(height: 10),
  //                     Row(
  //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                       children: [
  //                         Flexible(
  //                           child: TextFormField(
  //                             controller: discountController,
  //                             keyboardType: TextInputType.number,
  //                             inputFormatters: [
  //                               FilteringTextInputFormatter.digitsOnly,
  //                               LengthLimitingTextInputFormatter(2),
  //                             ],
  //                             decoration: const InputDecoration(
  //                               labelText: 'Discount (%)',
  //                               border: OutlineInputBorder(),
  //                               isDense: false,
  //                               hintText: 'Enter discount percentage',
  //                             ),
  //                             // onChanged: (value) {
  //                             //   setState(() {
  //                             //     discount = double.tryParse(value) ?? 0;
  //                             //     deductedAmount = (discount / 100) * orderAmount;
  //                             //     totalAmount =
  //                             //         orderAmount + customCharge - deductedAmount;
  //                             //   });

  //                             onChanged: (value) {
  //                               setState(() {
  //                                 discount = double.tryParse(value) ?? 0;
  //                                 deductedAmount =
  //                                     (discount / 100) * orderAmount;
  //                                 totalAmount = orderAmount +
  //                                     customCharge -
  //                                     deductedAmount;

  //                                 if (discount >
  //                                     globaldiscount.globalDiscountPercentage) {
  //                                   WidgetsBinding.instance
  //                                       .addPostFrameCallback((_) {
  //                                     showDialog(
  //                                       context: context,
  //                                       builder: (context) {
  //                                         return AlertDialog(
  //                                           title:
  //                                               const Text('Approval Required'),
  //                                           content: const Text(
  //                                             'Discount exceeds the allowed limit of 6%. Please send for approval.',
  //                                           ),
  //                                           actions: [
  //                                             TextButton(
  //                                               onPressed: () {
  //                                                 Navigator.pop(context);
  //                                               },
  //                                               child: const Text('OK'),
  //                                             ),
  //                                           ],
  //                                         );
  //                                       },
  //                                     );
  //                                   });
  //                                 }
  //                               });
  //                             },

  //                             // },
  //                           ),
  //                         ),
  //                         const SizedBox(width: 10),
  //                         Text(
  //                           '-₹${deductedAmount.toStringAsFixed(2)}',
  //                           style: const TextStyle(
  //                               fontWeight: FontWeight.bold, fontSize: 16),
  //                         ),
  //                       ],
  //                     ),

  //                     const SizedBox(height: 10),

  //                     // Hide Payment and Advance Section if Discount > 6%
  //                     if (discount <=
  //                         globaldiscount.globalDiscountPercentage) ...[
  //                       TextFormField(
  //                         controller: customChargeController,
  //                         keyboardType: TextInputType.number,
  //                         inputFormatters: [
  //                           FilteringTextInputFormatter.digitsOnly,
  //                           LengthLimitingTextInputFormatter(5),
  //                         ],
  //                         decoration: const InputDecoration(
  //                           labelText: 'Custom Charge',
  //                           border: OutlineInputBorder(),
  //                           hintText: 'Enter custom charge',
  //                         ),
  //                         onChanged: (value) {
  //                           setState(() {
  //                             customCharge = double.tryParse(value) ?? 0;
  //                             totalAmount =
  //                                 orderAmount + customCharge - deductedAmount;
  //                           });
  //                         },
  //                       ),
  //                       const SizedBox(height: 10),
  //                       const Text(
  //                         'Payment Method:',
  //                         style: TextStyle(fontSize: 16),
  //                       ),
  //                       Row(
  //                         mainAxisAlignment: MainAxisAlignment.start,
  //                         children: [
  //                           Radio<String>(
  //                             value: 'Cash',
  //                             groupValue: selectedPaymentMethod,
  //                             onChanged: (value) {
  //                               setState(() {
  //                                 selectedPaymentMethod = value!;
  //                               });
  //                             },
  //                           ),
  //                           const Text('Cash'),
  //                           Radio<String>(
  //                             value: 'Card',
  //                             groupValue: selectedPaymentMethod,
  //                             onChanged: (value) {
  //                               setState(() {
  //                                 selectedPaymentMethod = value!;
  //                               });
  //                             },
  //                           ),
  //                           const Text('Card'),
  //                           Radio<String>(
  //                             value: 'UPI',
  //                             groupValue: selectedPaymentMethod,
  //                             onChanged: (value) {
  //                               setState(() {
  //                                 selectedPaymentMethod = value!;
  //                               });
  //                             },
  //                           ),
  //                           const Text('UPI'),
  //                           Radio<String>(
  //                             value: 'Others',
  //                             groupValue: selectedPaymentMethod,
  //                             onChanged: (value) {
  //                               setState(() {
  //                                 selectedPaymentMethod = value!;
  //                               });
  //                             },
  //                           ),
  //                           const Text('Others'),
  //                         ],
  //                       ),
  //                       TextFormField(
  //                         controller: advanceController,
  //                         keyboardType: TextInputType.number,
  //                         decoration: const InputDecoration(
  //                           labelText: 'Advance',
  //                           border: OutlineInputBorder(),
  //                           hintText: 'Enter advance amount',
  //                         ),
  //                         onChanged: (value) {
  //                           setState(() {
  //                             double enteredValue = double.tryParse(value) ?? 0;
  //                             if (enteredValue > totalAmount) {
  //                               advanceController.text =
  //                                   totalAmount.toStringAsFixed(0);
  //                               advanceController.selection =
  //                                   TextSelection.fromPosition(
  //                                 TextPosition(
  //                                     offset: advanceController.text.length),
  //                               );
  //                               totalAdvance = totalAmount;
  //                             } else {
  //                               totalAdvance = enteredValue;
  //                             }
  //                           });
  //                         },
  //                       ),
  //                       const SizedBox(height: 10),
  //                       Text(
  //                         'Total Advance: ₹$totalAdvance',
  //                         style: const TextStyle(
  //                             fontSize: 16, fontWeight: FontWeight.bold),
  //                       ),
  //                     ],
  //                     const SizedBox(height: 10),
  //                     Text(
  //                       'Total Amount: ₹$totalAmount',
  //                       style: const TextStyle(
  //                           fontSize: 16, fontWeight: FontWeight.bold),
  //                     ),
  //                     const SizedBox(height: 10),
  //                     Text(
  //                       'Balance Amount: ₹${totalAmount - totalAdvance}',
  //                       style: const TextStyle(
  //                           fontWeight: FontWeight.bold, fontSize: 16),
  //                     ),
  //                   ],
  //                 ),
  //               ),
  //             ),
  //           ),
  //           actions: [
  //             if (discount > 6)
  //               ElevatedButton(
  //                 onPressed: () {
  //                   // Logic to send for approval
  //                   Navigator.pop(context);
  //                   String selectedOrderOption = 'Warehouse';
  //                   // Call the approval function
  //                   sendForApproval(
  //                       cartProvider,
  //                       totalAdvance,
  //                       orderAmount,
  //                       discount,
  //                       deductedAmount,
  //                       customCharge,
  //                       totalAmount,
  //                       remarkController.text,
  //                       path,
  //                       apiprovider,
  //                       img1,
  //                       img2,
  //                       audioOrderId,
  //                       holdId,
  //                       selectedOrderOption,
  //                       context);
  //                 },
  //                 style:
  //                     ElevatedButton.styleFrom(backgroundColor: Colors.orange),
  //                 child: const Text(
  //                   'Send for Approval',
  //                   style: TextStyle(color: Colors.white),
  //                 ),
  //               ),
  //             ElevatedButton(onPressed: () {}, child: Text('Cancel')),
  //             if (discount <= globaldiscount.globalDiscountPercentage)
  //               ElevatedButton(
  //                 onPressed: () async {
  //                   Navigator.pop(context);
  //                   String selectedOrderOption =
  //                       'Warehouse'; // Default selection

  //                   showDialog(
  //                     context: context,
  //                     builder: (BuildContext context) {
  //                       return StatefulBuilder(
  //                         builder: (context, setState) {
  //                           return AlertDialog(
  //                             title: const Text('Confirm Order'),
  //                             content: Column(
  //                               mainAxisSize: MainAxisSize.min,
  //                               children: [
  //                                 const Text(
  //                                     'Are you sure you want to complete the order?'),
  //                                 const SizedBox(height: 20),
  //                                 // Radio buttons for selecting the order type
  //                                 ListTile(
  //                                   title: const Text('In-shop'),
  //                                   leading: Radio<String>(
  //                                     value: 'In-shop',
  //                                     groupValue: selectedOrderOption,
  //                                     onChanged: (String? value) {
  //                                       setState(() {
  //                                         selectedOrderOption = value!;
  //                                       });
  //                                     },
  //                                   ),
  //                                 ),
  //                                 ListTile(
  //                                   title: const Text('Warehouse'),
  //                                   leading: Radio<String>(
  //                                     value: 'Warehouse',
  //                                     groupValue: selectedOrderOption,
  //                                     onChanged: (String? value) {
  //                                       setState(() {
  //                                         selectedOrderOption = value!;
  //                                       });
  //                                     },
  //                                   ),
  //                                 ),
  //                               ],
  //                             ),
  //                             actions: [
  //                               // If discount is greater than 6, show Send for Approval button
  //                               if (discount > 6)
  //                                 ElevatedButton(
  //                                   onPressed: () {
  //                                     Navigator.pop(
  //                                         context); // Close the dialog
  //                                     // Call the approval function
  //                                     sendForApproval(
  //                                       cartProvider,
  //                                       totalAdvance,
  //                                       orderAmount,
  //                                       discount,
  //                                       deductedAmount,
  //                                       customCharge,
  //                                       totalAmount,
  //                                       remarkController.text,
  //                                       path,
  //                                       apiprovider,
  //                                       img1,
  //                                       img2,
  //                                       audioOrderId,
  //                                       holdId,
  //                                       selectedOrderOption,
  //                                       context,
  //                                     );
  //                                   },
  //                                   style: ElevatedButton.styleFrom(
  //                                       backgroundColor: Colors.orange),
  //                                   child: const Text(
  //                                     'Send for Approval',
  //                                     style: TextStyle(color: Colors.white),
  //                                   ),
  //                                 ),
  //                               // If discount is 6 or lower, show Complete Order button
  //                               if (discount <= 6)
  //                                 ElevatedButton(
  //                                   onPressed: () async {
  //                                     Navigator.pop(
  //                                         context); // Close the dialog
  //                                     if (customerType == 'Normal' ||
  //                                         customerType == 'Company') {
  //                                       // Execute action for In-shop order
  //                                       await _saveOrder(
  //                                         cartProvider,
  //                                         totalAdvance,
  //                                         orderAmount,
  //                                         discount,
  //                                         deductedAmount,
  //                                         customCharge,
  //                                         totalAmount,
  //                                         remarkController.text,
  //                                         path,
  //                                         apiprovider,
  //                                         img1,
  //                                         img2,
  //                                         audioOrderId,
  //                                         holdId,
  //                                         selectedOrderOption,
  //                                         context,
  //                                       );
  //                                     } else {
  //                                       // Execute action for Warehouse order
  //                                       await postCreditCustomer(
  //                                         cartProvider,
  //                                         totalAdvance,
  //                                         orderAmount,
  //                                         discount,
  //                                         deductedAmount,
  //                                         customCharge,
  //                                         totalAmount,
  //                                         remarkController.text,
  //                                         path,
  //                                         img1,
  //                                         img2,
  //                                         context,
  //                                       );
  //                                     }
  //                                   },
  //                                   style: ElevatedButton.styleFrom(
  //                                       backgroundColor: Colors.green),
  //                                   child: const Text(
  //                                     'Complete Order',
  //                                     style: TextStyle(color: Colors.white),
  //                                   ),
  //                                 ),
  //                             ],
  //                           );
  //                         },
  //                       );
  //                     },
  //                   );
  //                 },
  //                 style:
  //                     ElevatedButton.styleFrom(backgroundColor: Colors.green),
  //                 child: const Text(
  //                   'Complete Order',
  //                   style: TextStyle(color: Colors.white),
  //                 ),
  //               ),
  //           ],
  //         );
  //       });
  //     },
  //   );
  // }

  void showAdvancePaymentPopup(
    BuildContext context,
    CartSelectionProvider cartSelectionProvider,
    CartProvider cartProvider,
    String? path,
    ApiServiceSalesOrderProvider apiprovider,
    File? img1,
    File? img2,
    String customerType,
    String? audioOrderId,
    String? holdId,
  ) {
    double orderAmount = cartProvider.getTotalAmount();
    double discount = 0;
    double customCharge = 0;
    double totalAdvance = 0;
    double deductedAmount = 0;
    double totalAmount = orderAmount + customCharge - deductedAmount;

    TextEditingController discountController = TextEditingController();
    TextEditingController customChargeController = TextEditingController();
    TextEditingController advanceController = TextEditingController();
    TextEditingController remarkController = TextEditingController();

    // Cheque-specific controllers
    TextEditingController chequeNumberController = TextEditingController();
    TextEditingController chequeAmountController = TextEditingController();
    TextEditingController chequeNameController = TextEditingController();
    TextEditingController chequeBankController = TextEditingController();
    TextEditingController chequeDateController = TextEditingController();

    String selectedPaymentMethod = 'Cash'; // Default payment method

    advanceController.clear();

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            void updatePaymentData() {
              Map<String, dynamic> paymentData = {
                "type": "paymentDetails",
                "orderAmount": orderAmount,
                "discountPercentage": discount,
                "discountAmount": deductedAmount,
                "customCharge": customCharge,
                "total": totalAmount,
                "advance": totalAdvance,
                "paymentMethod": selectedPaymentMethod,
                "remark": remarkController.text,
                "sync": "No",
                "edit": "No"
              };
              print('paymentData');
              print(paymentData);
              // Call your API service method here
              sendPaymentDataToServer(paymentData);
            }

            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              elevation: 10,
              child: Container(
                width: MediaQuery.of(context).size.width * 0.6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Colors.white, Colors.white],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blue.withOpacity(0.2),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Header
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.blue.shade200, Colors.blue.shade600],
                        ),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.payment_rounded,
                              color: Colors.white,
                              size: 28,
                            ),
                            const SizedBox(width: 10),
                            const Text(
                              'Payment Details',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Content
                    Flexible(
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Order Amount
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '₹${orderAmount.toStringAsFixed(2)}',
                                    style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.blue.shade900,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Discount Input Field
                                  Expanded(
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 4,
                                      ),
                                      margin: const EdgeInsets.symmetric(
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.black.withOpacity(
                                              0.1,
                                            ),
                                            blurRadius: 6,
                                            offset: const Offset(0, 2),
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          const Text(
                                            'Discount (%)',
                                            style: TextStyle(
                                              color: Colors.black87,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          TextFormField(
                                            controller: discountController,
                                            keyboardType: TextInputType.number,
                                            inputFormatters: [
                                              FilteringTextInputFormatter
                                                  .digitsOnly,
                                              LengthLimitingTextInputFormatter(
                                                2,
                                              ),
                                            ],
                                            style: const TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.black87,
                                            ),
                                            decoration: InputDecoration(
                                              prefixIcon: const Icon(
                                                Icons.percent,
                                                color: Colors.grey,
                                              ),
                                              border: InputBorder.none,
                                              hintText: 'Enter discount %',
                                              hintStyle: TextStyle(
                                                color: Colors.grey.shade600,
                                                fontSize: 14,
                                              ),
                                            ),
                                            onChanged: (value) {
                                              setState(() {
                                                discount =
                                                    double.tryParse(value) ?? 0;
                                                deductedAmount =
                                                    (discount / 100) *
                                                        orderAmount;
                                                totalAmount = orderAmount +
                                                    customCharge -
                                                    deductedAmount;

                                                if (discount >
                                                    globaldiscount
                                                        .globalDiscountPercentage) {
                                                  WidgetsBinding.instance
                                                      .addPostFrameCallback((
                                                    _,
                                                  ) {
                                                    showDialog(
                                                      context: context,
                                                      builder: (context) {
                                                        return AlertDialog(
                                                          shape:
                                                              RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                              15,
                                                            ),
                                                          ),
                                                          title: Row(
                                                            children: const [
                                                              Icon(
                                                                Icons
                                                                    .warning_amber_rounded,
                                                                color: Colors
                                                                    .orange,
                                                              ),
                                                              SizedBox(
                                                                width: 10,
                                                              ),
                                                              Text(
                                                                'Approval Required',
                                                              ),
                                                            ],
                                                          ),
                                                          content: const Text(
                                                            'Discount exceeds the allowed limit of 6%. Please send for approval.',
                                                          ),
                                                          actions: [
                                                            TextButton(
                                                              onPressed: () =>
                                                                  Navigator.pop(
                                                                context,
                                                              ),
                                                              child: const Text(
                                                                'OK',
                                                              ),
                                                            ),
                                                          ],
                                                        );
                                                      },
                                                    );
                                                  });
                                                }
                                              });
                                              updatePaymentData();
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),

                                  const SizedBox(
                                    width: 10,
                                  ), // Space between fields
                                  // Custom Charge Input Field
                                ],
                              ),

                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Section Title
                                  Text(
                                    'Payment Method',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black87,
                                    ),
                                  ),
                                  const SizedBox(height: 10),

                                  // Payment Methods Container
                                  Container(
                                    padding: const EdgeInsets.all(15),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(15),
                                      border: Border.all(
                                        color: Colors.grey.shade300,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey.withOpacity(0.1),
                                          blurRadius: 8,
                                          offset: const Offset(0, 3),
                                        ),
                                      ],
                                    ),
                                    child: Wrap(
                                      spacing: 15,
                                      runSpacing: 15,
                                      children: [
                                        _buildPaymentMethodTile(
                                          context,
                                          'Cash',
                                          Icons.money,
                                          selectedPaymentMethod,
                                          (value) {
                                            setState(() {
                                              selectedPaymentMethod = value!;
                                              updatePaymentData();
                                            }
                                                // () =>

                                                );
                                          },
                                        ),
                                        _buildPaymentMethodTile(
                                          context,
                                          'Card',
                                          Icons.credit_card,
                                          selectedPaymentMethod,
                                          (value) {
                                            setState(() {
                                              selectedPaymentMethod = value!;
                                              updatePaymentData();
                                            });
                                          },
                                        ),
                                        _buildPaymentMethodTile(
                                          context,
                                          'UPI',
                                          Icons.phone_android,
                                          selectedPaymentMethod,
                                          (value) {
                                            setState(() {
                                              selectedPaymentMethod = value!;
                                              updatePaymentData();
                                            });
                                          },
                                        ),
                                        _buildPaymentMethodTile(
                                          context,
                                          'Cheque',
                                          Icons.account_balance_wallet,
                                          selectedPaymentMethod,
                                          (value) {
                                            setState(() {
                                              selectedPaymentMethod = value!;
                                              if (value == 'Cheque' &&
                                                  advanceController
                                                      .text.isNotEmpty) {
                                                chequeAmountController.text =
                                                    advanceController.text;
                                              }
                                            });
                                          },
                                        ),
                                        _buildPaymentMethodTile(
                                          context,
                                          'Others',
                                          Icons.more_horiz,
                                          selectedPaymentMethod,
                                          (value) {
                                            setState(() {
                                              selectedPaymentMethod = value!;
                                              updatePaymentData();
                                            });
                                          },
                                        ),
                                      ],
                                    ),
                                  ),

                                  // Advance Amount Input (Visible only for Cash Payment)
                                  if (selectedPaymentMethod == 'Cash')
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: TextFormField(
                                        controller: advanceController,
                                        keyboardType: TextInputType.number,
                                        decoration: InputDecoration(
                                          labelText: 'Advance Amount',
                                          labelStyle: TextStyle(
                                            color: Colors.black87,
                                          ),
                                          filled: true,
                                          fillColor: Colors.white,
                                          prefixIcon: Icon(
                                            Icons.payment,
                                            color: Colors.grey.shade600,
                                          ),
                                          prefixText: '₹ ',
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                            borderSide: BorderSide(
                                              color: Colors.grey.shade300,
                                            ),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                            borderSide: BorderSide(
                                              color: Colors.black87,
                                              width: 2,
                                            ),
                                          ),
                                          hintText: 'Enter advance amount',
                                        ),
                                        onChanged: (value) {
                                          setState(() {
                                            double enteredValue =
                                                double.tryParse(value) ?? 0;
                                            if (enteredValue > totalAmount) {
                                              advanceController.text =
                                                  totalAmount
                                                      .toStringAsFixed(0);
                                              advanceController.selection =
                                                  TextSelection.fromPosition(
                                                TextPosition(
                                                  offset: advanceController
                                                      .text.length,
                                                ),
                                              );
                                              totalAdvance = totalAmount;
                                            } else {
                                              totalAdvance = enteredValue;
                                            }
                                            updatePaymentData();
                                            if (selectedPaymentMethod ==
                                                'Cheque') {
                                              chequeAmountController.text =
                                                  advanceController.text;
                                            }
                                          });
                                        },
                                      ),
                                    ),

                                  // Cheque Details Section (Visible only when Cheque is selected)
                                  if (selectedPaymentMethod == 'Cheque')
                                    if (selectedPaymentMethod == 'Cash')
                                      Padding(
                                        padding: const EdgeInsets.only(top: 20),
                                        child: Card(
                                          elevation: 3,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 15,
                                              vertical: 10,
                                            ),
                                            child: TextFormField(
                                              controller: advanceController,
                                              keyboardType:
                                                  TextInputType.number,
                                              decoration: InputDecoration(
                                                labelText: 'Advance Amount',
                                                labelStyle: TextStyle(
                                                  color: Colors.black87,
                                                  fontSize: 16,
                                                ),
                                                filled: true,
                                                fillColor: Colors.white,
                                                prefixIcon: Icon(
                                                  Icons.payment,
                                                  color: Colors.black54,
                                                ),
                                                prefixText: '₹ ',
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                    12,
                                                  ),
                                                  borderSide: BorderSide(
                                                    color: Colors.grey.shade300,
                                                  ),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                    12,
                                                  ),
                                                  borderSide: BorderSide(
                                                    color: Colors.black87,
                                                    width: 2,
                                                  ),
                                                ),
                                                hintText:
                                                    'Enter advance amount',
                                              ),
                                              onChanged: (value) {
                                                setState(() {
                                                  double enteredValue =
                                                      double.tryParse(value) ??
                                                          0;
                                                  if (enteredValue >
                                                      totalAmount) {
                                                    advanceController.text =
                                                        totalAmount
                                                            .toStringAsFixed(0);
                                                    advanceController
                                                            .selection =
                                                        TextSelection
                                                            .fromPosition(
                                                      TextPosition(
                                                        offset:
                                                            advanceController
                                                                .text.length,
                                                      ),
                                                    );
                                                    totalAdvance = totalAmount;
                                                  } else {
                                                    totalAdvance = enteredValue;
                                                  }

                                                  if (selectedPaymentMethod ==
                                                      'Cheque') {
                                                    chequeAmountController
                                                            .text =
                                                        advanceController.text;
                                                  }
                                                });
                                              },
                                            ),
                                          ),
                                        ),
                                      ),

                                  if (selectedPaymentMethod == 'Cheque')
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 3,
                                        horizontal: 15,
                                      ),
                                      child: Card(
                                        color: Colors.white,
                                        elevation: 3,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(15),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              // Section Header
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.description,
                                                    color: Colors.blueAccent,
                                                    size: 26,
                                                  ),
                                                  const SizedBox(width: 10),
                                                  Text(
                                                    'Cheque Details',
                                                    style: TextStyle(
                                                      color: Colors.black87,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontSize: 20,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const Divider(
                                                thickness: 1.5,
                                                height: 20,
                                              ),

                                              // Row 1: Cheque Number, Cheque Amount, Holder Name
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child:
                                                        _buildStyledFormField(
                                                      controller:
                                                          chequeNumberController,
                                                      labelText:
                                                          'Cheque Number',
                                                      icon: Icons.numbers,
                                                      hintText:
                                                          'Enter cheque number',
                                                      keyboardType:
                                                          TextInputType.number,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 15),
                                                  Expanded(
                                                    child:
                                                        _buildStyledFormField(
                                                      controller:
                                                          chequeAmountController,
                                                      labelText:
                                                          'Cheque Amount',
                                                      icon:
                                                          Icons.currency_rupee,
                                                      hintText: 'Enter amount',
                                                      keyboardType:
                                                          TextInputType.number,
                                                      prefixText: '₹ ',
                                                    ),
                                                  ),
                                                  const SizedBox(width: 15),
                                                  Expanded(
                                                    child: GestureDetector(
                                                      onTap: () async {
                                                        final DateTime? picked =
                                                            await showDatePicker(
                                                          context: context,
                                                          initialDate:
                                                              DateTime.now(),
                                                          firstDate: DateTime(
                                                            2000,
                                                          ),
                                                          lastDate: DateTime(
                                                            2100,
                                                          ),
                                                          builder: (
                                                            context,
                                                            child,
                                                          ) {
                                                            return Theme(
                                                              data: Theme.of(
                                                                context,
                                                              ).copyWith(
                                                                colorScheme:
                                                                    ColorScheme
                                                                        .light(
                                                                  primary: Colors
                                                                      .blueAccent,
                                                                  onPrimary:
                                                                      Colors
                                                                          .white,
                                                                  onSurface:
                                                                      Colors
                                                                          .black,
                                                                ),
                                                              ),
                                                              child: child!,
                                                            );
                                                          },
                                                        );
                                                        if (picked != null) {
                                                          setState(() {
                                                            chequeDateController
                                                                    .text =
                                                                "${picked.day}/${picked.month}/${picked.year}";
                                                          });
                                                        }
                                                      },
                                                      child:
                                                          _buildStyledFormField(
                                                        controller:
                                                            chequeDateController,
                                                        labelText:
                                                            'Cheque Date',
                                                        icon: Icons
                                                            .calendar_today,
                                                        hintText: 'Select date',
                                                        readOnly: true,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 10),

                                              // Row 2: Cheque Date, Bank Name
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child:
                                                        _buildStyledFormField(
                                                      controller:
                                                          chequeNameController,
                                                      labelText:
                                                          'Cheque Holder Name',
                                                      icon: Icons.person,
                                                      hintText:
                                                          'Enter name on cheque',
                                                    ),
                                                  ),
                                                  const SizedBox(width: 15),
                                                  Expanded(
                                                    child:
                                                        BankSearchDropdown(), // Dropdown for bank selection
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),

                              SizedBox(height: 25),

                              Container(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 20,
                                  horizontal: 16,
                                ),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.blue.shade600,
                                      Colors.blue.shade800,
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(15),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.blue.withOpacity(0.3),
                                      blurRadius: 10,
                                      offset: const Offset(0, 5),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    _buildAmountInfo('Advance', totalAdvance),
                                    _buildSeparator(),
                                    _buildAmountInfo('Total', totalAmount),
                                    _buildSeparator(),
                                    _buildAmountInfo(
                                      'Balance',
                                      totalAmount - totalAdvance,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // Footer Actions
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: const BorderRadius.only(
                          bottomLeft: Radius.circular(20),
                          bottomRight: Radius.circular(20),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.blue.withOpacity(0.1),
                            blurRadius: 10,
                            offset: const Offset(0, -3),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          // Cancel Button
                          OutlinedButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 12,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              side: BorderSide(color: Colors.blue.shade400),
                            ),
                            child: Text(
                              'Cancel',
                              style: TextStyle(color: Colors.blue.shade700),
                            ),
                          ),
                          const SizedBox(width: 15),

                          // Complete/Approve Order Button
                          ElevatedButton(
                            onPressed: () async {
                              Navigator.pop(context);
                              // Validate cheque details if Cheque is selected
                              if (selectedPaymentMethod == 'Cheque') {
                                // Call the sendToApproval function if payment type is Cheque
                                await sendForApproval(
                                  cartProvider,
                                  totalAdvance,
                                  orderAmount,
                                  discount,
                                  deductedAmount,
                                  customCharge,
                                  totalAmount,
                                  remarkController.text,
                                  path,
                                  apiprovider,
                                  img1,
                                  img2,
                                  audioOrderId,
                                  holdId,
                                  "Cheque",
                                  context,
                                );
                                return;
                              }

                              // Process the order normally
                              // Navigator.pop(context);

                              // // Clear values after successful submission
                              // cartProvider.clearCart(); // If applicable
                              // remarkController.clear();
                              // img1 = null;
                              // img2 = null;
                              // audioOrderId = '';
                              // holdId = '';
                              // path = '';
                              showDialog(
                                barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return StatefulBuilder(
                                    builder: (context, setState) {
                                      return AlertDialog(
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            15,
                                          ),
                                        ),
                                        title: Row(
                                          children: [
                                            const Icon(
                                              Icons.check_circle,
                                              color: Colors.green,
                                            ),
                                            const SizedBox(width: 10),
                                            const Text('Confirm Order'),
                                          ],
                                        ),
                                        content: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Text(
                                              'Are you sure you want to complete the order?',
                                            ),
                                            const SizedBox(height: 20),
                                            // Radio buttons for order option
                                          ],
                                        ),
                                        actions: [
                                          TextButton(
                                            onPressed: () {
                                              Navigator.pop(context);
                                            },
                                            child: const Text('Cancel'),
                                          ),
                                          ElevatedButton(
                                            onPressed: () async {
                                              await _saveOrder(
                                                cartProvider,
                                                cartSelectionProvider,
                                                totalAdvance,
                                                orderAmount,
                                                discount,
                                                deductedAmount,
                                                // customCharge,
                                                totalAmount,
                                                remarkController.text,
                                                path,
                                                apiprovider,
                                                img1,
                                                img2,
                                                audioOrderId,
                                                holdId,
                                                selectedStoreType,
                                                context,
                                                // selectedOrderOption,
                                              );

                                              // _clearCartAndResetState(cartProvider);
                                              // _bulkDiscountController.clear();
                                              //  Clear values after successful submission
                                              cartProvider.clearCart();
                                              // _allBoxQtyController.clear();
                                              // Provider.of<CartSelectionProvider>(context, listen: false)
                                              //     .clearSelections();
                                              // for (final controller in _boxQtyControllers.values) {
                                              //   controller.clear();
                                              // }
                                              // for (final controller in _discountControllers.values) {
                                              //   controller.clear();
                                              // }
                                              //                                            remarkController.clear();
                                              SalesOrderScreenState()
                                                  .clearCartAndResetState;
                                              img1 = null;
                                              img2 = null;
                                              audioOrderId = '';
                                              holdId = '';
                                              path = '';
                                            },
                                            child: const Text('Confirm'),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                },
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 12,
                              ),
                              backgroundColor: Colors.blue.shade700,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text(
                              selectedPaymentMethod == 'Cheque'
                                  ? 'Send to Approval'
                                  : 'Complete Order',
                              style: const TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSeparator() {
    return Container(
      height: 50,
      width: 1.5,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.4),
        borderRadius: BorderRadius.circular(1),
      ),
    );
  }

  Widget _buildAmountInfo(String title, double amount) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 14,
              color: Colors.blue.shade50,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '₹${amount.toStringAsFixed(2)}',
            style: const TextStyle(
              fontSize: 18,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStyledFormField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    String? hintText,
    TextInputType keyboardType = TextInputType.text,
    String? prefixText,
    bool readOnly = false,
  }) {
    return TextFormField(
      controller: controller,
      readOnly: readOnly,
      keyboardType: keyboardType,
      style: TextStyle(fontSize: 16, color: Colors.black87),
      decoration: InputDecoration(
        prefixText: prefixText,
        labelText: labelText,
        hintText: hintText,
        hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 14),
        filled: true,
        fillColor: Colors.grey.shade100,
        prefixIcon: Icon(icon, color: Colors.blueAccent),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blueAccent, width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blueAccent, width: 2),
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      ),
    );
  }

  Widget _buildPaymentMethodTile(
    BuildContext context,
    String method,
    IconData icon,
    String selectedMethod,
    ValueChanged<String?> onChanged,
  ) {
    return GestureDetector(
      onTap: () {
        onChanged(method);
      },
      child: Container(
        // padding: const EdgeInsets.all(10),
        padding: EdgeInsets.symmetric(horizontal: 40),
        decoration: BoxDecoration(
          color: selectedMethod == method ? Colors.blue.shade100 : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selectedMethod == method
                ? Colors.blue.shade700
                : Colors.blue.shade200,
            width: 2,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.blue.shade700),
            const SizedBox(height: 5),
            Text(
              method,
              style: TextStyle(
                color: Colors.blue.shade800,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    String? hintText,
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
    String? prefixText,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      readOnly: readOnly,
      decoration: InputDecoration(
        labelText: labelText,
        labelStyle: TextStyle(color: Colors.blue.shade800),
        filled: true,
        fillColor: Colors.white,
        prefixIcon: Icon(icon, color: Colors.blue.shade600),
        prefixText: prefixText,
        hintText: hintText,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blue.shade200),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blue.shade600, width: 2),
        ),
      ),
    );
  }

  final Map<String, int> branchOrderCount = HashMap();

  // String generateSaleOrderNo() {
  //   // Get today's date in dd/MM/yy format
  //   String formattedDate = DateFormat('dd/MM/yy').format(DateTime.now());

  //   // Fetch the stored branch data from Hive
  //   // BranchProvider branchProvider = BranchProvider();
  //   Branch? storedBranch =
  //       branchProvider.getStoredBranch(globalbranch.branchName);

  //   // Check if branch data is found
  //   if (storedBranch == null) {
  //     return 'Error: Branch data not found';
  //   }

  //   // Get the aliasName from the stored branch
  //   String aliasName = storedBranch.aliasName;

  //   // Create a unique key for counting sales orders for today
  //   String branchDateKey = '${storedBranch.branchName}-$formattedDate';

  //   // Increment the order count for the current branch and date
  //   if (!branchOrderCount.containsKey(branchDateKey)) {
  //     branchOrderCount[branchDateKey] = 1; // Start with 1 for the first order
  //   } else {
  //     branchOrderCount[branchDateKey] = branchOrderCount[branchDateKey]! + 1;
  //   }

  //   // Get the current count and format it to 2 digits
  //   int currentOrderCount = branchOrderCount[branchDateKey]!;
  //   String formattedOrderCount = currentOrderCount.toString().padLeft(2, '0');

  //   // Generate the sales order number
  //   return 'SO$formattedDate$formattedOrderCount$aliasName';
  // }

  String generateSaleOrderNo() {
    // Get the current year in YY format (last two digits of the year)
    String currentYear = DateFormat('yy').format(DateTime.now());

    // Fetch the stored branch data from Hive
    Branch? storedBranch =
        branchProvider.getStoredBranch(globalbranch.branchName);

    // Check if branch data is found
    if (storedBranch == null) {
      return 'Error: Branch data not found';
    }

    // Get the aliasName from the stored branch
    String aliasName = storedBranch.aliasName;

    // Generate the sales order number in the desired format
    return 'SO$aliasName$currentYear';
  }

  Future<void> _saveOrder(
      CartProvider cartProvider,
      CartSelectionProvider cartSelectionProvider,
      double totalAdvance,
      double orderAmount,
      double discount,
      double deductedAmount,
      // double customCharge,
      double totalAmount,
      String remark,
      String? path,
      ApiServiceSalesOrderProvider apiProvider,
      File? img1,
      File? img2,
      String? audioOrderId,
      String? holdId,
      String? selectedOrderOption,
      BuildContext context) async {
    // if (isSubmitting) return; // Prevent double submission
    // isSubmitting = true;
    double balanceAmount = totalAmount - totalAdvance;
    List<double> advanceAmountList = [totalAdvance];
    List<double> cashAdvance = [0.0];
    List<double> cardAdvance = [0.0];
    List<double> upiAdvance = [0.0];

    if (selectedPaymentMethod == 'Cash') {
      cashAdvance[0] = totalAdvance; // Update the first element of cashAdvance
    } else if (selectedPaymentMethod == 'Card') {
      cardAdvance[0] = totalAdvance; // Update the first element of cardAdvance
    } else if (selectedPaymentMethod == 'UPI') {
      upiAdvance[0] = totalAdvance; // Update the first element of upiAdvance
    }
    String currentDateTime = DateTime.now().toIso8601String();
    advanceDateTime ??= [];
    advancePaymentType ??= [];

    // Add datetime and payment type
    advanceDateTime!.add(currentDateTime);
    advancePaymentType!.add(selectedPaymentMethod);

    List<String> itemNames =
        globals.cartItems.map((item) => item.itemName).toList();
    List<String> varianceNames =
        globals.cartItems.map((item) => item.varianceName).toList();
    List<int> quantities =
        globals.cartItems.map((item) => item.quantity).toList();
    List<String> itemCodes =
        globals.cartItems.map((item) => item.itemCode.toString()).toList();
    List<String> uoms =
        globals.cartItems.map((item) => item.uom.toString()).toList();
    List<int> taxs = globals.cartItems.map((item) => item.tax).toList();
    List<double> weights =
        globals.cartItems.map((item) => item.weight).toList();
    List<int> prices =
        globals.cartItems.map((item) => item.pricePerKg).toList();
    List<int>? boxQuantities = globals.cartItems
        .map((item) => item.boxQuantity)
        .whereType<int>()
        .toList();
    List<String>? isBoxItem = globals.cartItems
        .map((item) => item.isBoxItem)
        .whereType<String>()
        .toList();

    List<double> itemWiseDiscounts =
        globals.cartItems.map((item) => item.itemWiseDiscount ?? 0.0).toList();
    List<double> itemWiseDiscountAmounts = globals.cartItems
        .map((item) => item.itemWiseDiscountAmount ?? 0.0)
        .toList();
    final customCharge =
        double.tryParse(cartProvider.customChargeController.text) ?? 0;
    List<double> amounts = globals.cartItems.map((item) {
      double calculatedAmount;
      if (item.uom == 'Pcs' || item.uom == 'Pkt') {
        calculatedAmount = (item.pricePerKg * item.quantity.toDouble()) -
            (item.itemWiseDiscountAmount ?? 0.0);
      } else {
        calculatedAmount = (item.weight * item.quantity * item.pricePerKg) -
            (item.itemWiseDiscountAmount ?? 0.0);
      }
      return calculatedAmount;
    }).toList();

    String saleOrderNo = generateSaleOrderNo();
    String formattedDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
    String formattedTime = DateFormat('hh:mm a').format(DateTime.now());

    // 1️⃣  Create /orders/<SALE_ORDER_NO>  -----------------------------
    final orderDir = await createOrderDir(saleOrderNo);
    if (orderDir == null) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content:
                Text('Please allow storage permission to save images/audio.'),
          ),
        );
      }
      return; // stop the save‑order flow
    }
    print('[ORDER‑DIR]  Created or found directory: ${orderDir.path}');

    String? imagePath1, imagePath2, audioPath;

// 2️⃣  Save first image  ------------------------------------------
    if (img1 != null) {
      print('[IMG‑1]  Starting save for ${img1.path}');
      imagePath1 = await saveFile(img1, orderDir, '${saleOrderNo}_img1');

      if (imagePath1 != null && await verifyFile(imagePath1)) {
        print('[IMG‑1]  ✅ Saved & verified at $imagePath1');
      } else {
        print('[IMG‑1]  ❌ Save or verification failed');
        imagePath1 = null;
      }
    } else {
      print('[IMG‑1]  ⚠️  img1 is null – nothing to save');
    }

// 3️⃣  Save second image  -----------------------------------------
    if (img2 != null) {
      print('[IMG‑2]  Starting save for ${img2.path}');
      imagePath2 = await saveFile(img2, orderDir, '${saleOrderNo}_img2');

      if (imagePath2 != null && await verifyFile(imagePath2)) {
        print('[IMG‑2]  ✅ Saved & verified at $imagePath2');
      } else {
        print('[IMG‑2]  ❌ Save or verification failed');
        imagePath2 = null;
      }
    } else {
      print('[IMG‑2]  ⚠️  img2 is null – nothing to save');
    }

// 4️⃣  Save audio file  -------------------------------------------
    if (path != null) {
      final recorded = File(path);
      if (await recorded.exists()) {
        print('[AUDIO]  Starting save for ${recorded.path}');
        audioPath = await saveFile(recorded, orderDir, '${saleOrderNo}_audio');

        if (audioPath != null && await verifyFile(audioPath)) {
          print('[AUDIO]  ✅ Saved & verified at $audioPath');
        } else {
          print('[AUDIO]  ❌ Save or verification failed');
          audioPath = null;
        }
      } else {
        print('[AUDIO]  ⚠️  Source audio file does not exist');
      }
    } else {
      print('[AUDIO]  ⚠️  path is null – no audio to save');
    }

// 5️⃣  Summary  ----------------------------------------------------
    print(
        '[SUMMARY] imagePath1=$imagePath1 | imagePath2=$imagePath2 | audioPath=$audioPath');

    SalesOrder salesOrder = SalesOrder(
      itemName: itemNames,
      varianceName: varianceNames,
      qty: quantities,
      uom: uoms,
      isBoxItem: isBoxItem,
      weight: weights,
      amount: amounts,
      boxQty: boxQuantities,
      totalAmount2: totalAmount,
      branchId: storedBranch!.branchId,
      branchName: storedBranch!.branchName,
      totalAmount: totalAmount,
      itemCode: itemCodes,
      tax: taxs,
      price: prices,
      deliveryDate: dateController.text,
      deliveryTime: timeController.text,
      event: selectedEvent.toString(),
      customerNumber: mobileNoController.text,
      customerName: customerNameController.text,
      deliveryType: selectedDeliveryType.toString(),
      address: addressController.text,
      landmark: landmarkController.text,
      discount: discount,
      discountAmount: deductedAmount,
      remark: remark,
      customCharge: customCharge,
      advanceAmount: advanceAmountList,
      advancePaymentType: advancePaymentType,
      finalPrice: orderAmount,
      balanceAmount: balanceAmount,
      saleOrderNo: saleOrderNo,
      orderDate: DateTime.now().toIso8601String(),
      orderTime: formattedTime,
      employeeName: searchController.text,
      status: 'Confirm Order',
      advanceDateTime: advanceDateTime,
      companyName: companyNameController.text,
      companyAddress: companyAddressController.text,
      companyGST: companygstNumberController.text,
      orderType: selectedOrderOption,
      eventDate: birthdaydateController.text,
      itemWiseDiscount: itemWiseDiscounts, // Add item-wise discounts
      itemWiseDiscountAmount: itemWiseDiscountAmounts,

      // cash: cashAdvance,
      // card: cardAdvance,
      // upi: upiAdvance,
    );
    print('saleosrderabovethe jsonencode${salesOrder.isBoxItem}');
    // String jsonSalesOrder = jsonEncode(salesOrder.toJson());

    // print('Sales order JSON data: $jsonSalesOrder');
    try {
      String jsonSalesOrder = jsonEncode({
        "data": salesOrder.toJson(),
        "type": "salesOrder",
        "deviceName": "POS1",
        "sync": "No",
        "edit": "No",
        "image1Path": imagePath1,
        "image2Path": imagePath2,
        "audioPath": audioPath,
      });
      print('Sales order JSON data: $jsonSalesOrder');
      initializeReceiptPrinter(
        deliveryTime: timeController.text,
        deliverydateprint: dateController.text,
        employeeNameController: searchController,
        customerNumberController: mobileNoController,
        discountController: deductedAmount,
        customChargeController: customCharge,
        selectedPaymentOptionValue: selectedPaymentMethod,
        totalAmount: totalAmount,
        advanceAmount: totalAdvance,
        balanceAmount: balanceAmount,
        customerType: 'SalesOrder',
        // context: context,
        customAmountController: mobileNoController,
        selectedPaymentOption: selectedPaymentMethod,
        // saveInvoiceToHiveAndPrint: () {}
      );

      print("Sending HTTP request..."); // Check if it reaches here

      await sendInvoiceDataToServer(jsonDecode(jsonSalesOrder));

      // if (context.mounted) {
      //   await printReceipt();
      // }
      Navigator.pop(context);
      print("Invoice data sent via WebSocket");
    } catch (e) {
      print(
          'Error while posting order: $e'); // Catches any errors during the request
    } finally {
      clearControllers();
      cartProvider.clearCart();
      cartSelectionProvider.clearSelections();
      SalesOrderScreenState().clearCartAndResetState;
      isSubmitting = false;
      showAudioandImage = false;
      advanceDateTime!.clear();
      advancePaymentType!.clear();
      clearFile(path!);
      if (img1 != null) {
        clearFile(img1.path);
      }

      if (img2 != null) {
        clearFile(img2.path);
      }
      if (audioOrderId != null) {
        clearFile(audioOrderId!);
      }
      notifyListeners();
    }
  }

  // Future<void> sendWhatsAppMessage({
  //   required String customerNumber,
  //   required String billNumber,
  //   required double totalAmount,
  // }) async {
  //   String whatsappApiUrl =
  //       'https://backend.askeva.io/v1/message/send-message?token=226b3bc6338f9de4107cc93016924fb2868113776165b8d4b9a76914930e2fa2e47ff2906d87e0281121e425dccf62d84a6a82303c99beb2c24d0f9da7a46c1e32af25b2e74b7e42a7d17ce834c474aeb9b4abecdf454ade5fcd7519b8dd2e3893e0ac008bf50aa0d2ddc59737e381d4166d7d1e45af5cb285d388959efdc897c43af27799a56ea571830eca7cb8d5f08cf4284b28dff365fb85a2ad9d645ee0aaf8a86e8d6103150f29361e0f4556ba02cbf0149bacd06ad35fbe51d0ba630533cf73a51476c02eccc3845d13506638';

  //   Map<String, dynamic> whatsappMessage = {
  //     "to": "91${customerNumber}",
  //     "type": "template",
  //     "template": {
  //       "language": {"policy": "deterministic", "code": "en"},
  //       "name": "whatsapp_test",
  //       "components": [
  //         {
  //           "type": "header",
  //           "parameters": [
  //             {
  //               "type": "image",
  //               "image": {"link": "https://yenerp.com/share/offer.jpg"}
  //             }
  //           ]
  //         },
  //         {
  //           "type": "body",
  //           "parameters": [
  //             {"type": "text", "text": "Customer"},
  //             {"type": "text", "text": "Bill No: $billNumber"},
  //             {"type": "text", "text": "Amount: $totalAmount"}
  //           ]
  //         }
  //       ]
  //     }
  //   };

  //   try {
  //     var whatsappResponse = await http.post(
  //       Uri.parse(whatsappApiUrl),
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: json.encode(whatsappMessage),
  //     );

  //     if (whatsappResponse.statusCode == 200) {
  //       print('WhatsApp message sent successfully to $customerNumber');
  //     } else {
  //       print('Failed to send WhatsApp message: ${whatsappResponse.body}');
  //     }
  //   } catch (e) {
  //     print('Error sending WhatsApp message: $e');
  //   }
  // }
  void submitForApproval(
    BuildContext context,
    CartSelectionProvider cartSelectionProvider,
    CartProvider cartProvider,
    String recordedFilePath,
    ApiServiceSalesOrderProvider apiService,
    File? pickedImage1,
    File? pickedImage2,
    String customerType,
    // String audioPlayerId,
    // String holdId,
  ) async {
    try {
      // Initialize advance-related fields with default values
      print('1.........................');
      double totalAdvance = 0.0;
      double balanceAmount = cartProvider.getTotalAmount();
      List<double> advanceAmountList = [0.0];
      // List<String> advancePaymentType = ['Pending Approval'];
      List<String> advanceDateTime = [DateTime.now().toIso8601String()];

      // Collect order items data
      List<String> itemNames =
          globals.cartItems.map((item) => item.itemName).toList();
      List<String> varianceNames =
          globals.cartItems.map((item) => item.varianceName).toList();
      List<int> quantities =
          globals.cartItems.map((item) => item.quantity).toList();
      List<String> itemCodes =
          globals.cartItems.map((item) => item.itemCode.toString()).toList();
      List<String> uoms =
          globals.cartItems.map((item) => item.uom.toString()).toList();
      List<int> taxs = globals.cartItems.map((item) => item.tax).toList();
      List<double> weights =
          globals.cartItems.map((item) => item.weight).toList();
      List<int> prices =
          globals.cartItems.map((item) => item.pricePerKg).toList();

      // Calculate amounts
      List<double> amounts = globals.cartItems.map((item) {
        return (item.uom == 'Pcs' || item.uom == 'Pkt')
            ? item.pricePerKg * item.quantity.toDouble()
            : item.weight * item.quantity * item.pricePerKg;
      }).toList();

      // Create sales order object with approval-specific fields
      SalesOrder approvalOrder = SalesOrder(
        itemName: itemNames,
        varianceName: varianceNames,
        qty: quantities,
        uom: uoms,
        weight: weights,
        amount: amounts,
        totalAmount2: cartProvider.getTotalAmount(),
        branchId: storedBranch!.branchId,
        branchName: storedBranch!.branchName,
        totalAmount: cartProvider.getTotalAmount(),
        itemCode: itemCodes,
        tax: taxs,
        price: prices,
        deliveryDate: dateController.text,
        deliveryTime: timeController.text,
        event: selectedEvent.toString(),
        customerNumber: mobileNoController.text,
        customerName: customerNameController.text,
        deliveryType: selectedDeliveryType.toString(),
        address: addressController.text,
        landmark: landmarkController.text,
        discount: 0.0,
        discountAmount: 0.0,
        remark: remarkController.text,
        // customCharge: cartProvider.getCustomCharge(),
        advanceAmount: advanceAmountList,
        advancePaymentType: advancePaymentType,
        finalPrice: cartProvider.getTotalAmount(),
        balanceAmount: balanceAmount,
        saleOrderNo: generateSaleOrderNo(),
        orderDate: DateTime.now().toIso8601String(),
        orderTime: DateFormat('hh:mm a').format(DateTime.now()),
        employeeName: searchController.text,
        status: 'Waiting for Approval',
        advanceDateTime: advanceDateTime,
        companyName: companyNameController.text,
        companyAddress: companyAddressController.text,
        companyGST: companygstNumberController.text,
        orderType: selectedOrderOption,
        approvalDetails: [
          ApprovalOrderDetail(
            approvalType: "Discount",
            approvalStatus: 'Sending to Approval',
            approvalDate: DateTime.now().toIso8601String(),
            summary: 'No',
          ),
        ],
        // approvalStatus: 'Pending',
      );

      // Prepare JSON data
      String jsonApprovalOrder = jsonEncode({
        "data": [
          approvalOrder.toJson(),
        ],
        "type": "salesApprovalOrder",
        'sync': "No",
        'edit': 'No',
        'approvalStatusChanged': 'No'
      });

      // Send approval request
      sendApproveDataToServer(jsonDecode(jsonApprovalOrder));
    } catch (e) {
      // Handle general errors
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error submitting approval: $e')),
      );
    } finally {
      // Reset submission state
      isSubmitting = false;
      notifyListeners();
    }
  }

  // Future<void> sendForApproval(
  //     CartProvider cartProvider,
  //     double totalAdvance,
  //     double orderAmount,
  //     double discount,
  //     double deductedAmount,
  //     double customCharge,
  //     double totalAmount,
  //     String remark,
  //     String? path,
  //     ApiServiceSalesOrderProvider apiProvider,
  //     File? img1,
  //     File? img2,
  //     String? audioOrderId,
  //     String? holdId,
  //     String? selectedOrderOption,
  //     BuildContext context) async {
  //   // if (isSubmitting) return; // Prevent double submission
  //   // isSubmitting = true;
  //   double balanceAmount = totalAmount - totalAdvance;
  //   List<double> advanceAmountList = [totalAdvance];
  //   List<double> cashAdvance = [0.0];
  //   List<double> cardAdvance = [0.0];
  //   List<double> upiAdvance = [0.0];

  //   if (selectedPaymentMethod == 'Cash') {
  //     cashAdvance[0] = totalAdvance; // Update the first element of cashAdvance
  //   } else if (selectedPaymentMethod == 'Card') {
  //     cardAdvance[0] = totalAdvance; // Update the first element of cardAdvance
  //   } else if (selectedPaymentMethod == 'UPI') {
  //     upiAdvance[0] = totalAdvance; // Update the first element of upiAdvance
  //   }
  //   String currentDateTime = DateTime.now().toIso8601String();
  //   advanceDateTime ??= [];
  //   advancePaymentType ??= [];

  //   // Add datetime and payment type
  //   advanceDateTime!.add(currentDateTime);
  //   advancePaymentType!.add(selectedPaymentMethod);

  //   List<String> itemNames =
  //       globals.cartItems.map((item) => item.itemName).toList();
  //   List<String> varianceNames =
  //       globals.cartItems.map((item) => item.varianceName).toList();
  //   List<int> quantities =
  //       globals.cartItems.map((item) => item.quantity).toList();
  //   List<String> itemCodes =
  //       globals.cartItems.map((item) => item.itemCode.toString()).toList();
  //   List<String> uoms =
  //       globals.cartItems.map((item) => item.uom.toString()).toList();
  //   List<int> taxs = globals.cartItems.map((item) => item.tax).toList();
  //   List<double> weights =
  //       globals.cartItems.map((item) => item.weight).toList();
  //   List<int> prices =
  //       globals.cartItems.map((item) => item.pricePerKg).toList();

  //   List<double> amounts = globals.cartItems.map((item) {
  //     double calculatedAmount;
  //     if (item.uom == 'Pcs' || item.uom == 'Pkt') {
  //       calculatedAmount = item.pricePerKg * item.quantity.toDouble();
  //     } else {
  //       calculatedAmount = item.weight * item.quantity * item.pricePerKg;
  //     }
  //     return calculatedAmount;
  //   }).toList();

  //   String saleOrderNo = generateSaleOrderNo();
  //   // String formattedDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
  //   String formattedTime = DateFormat('hh:mm a').format(DateTime.now());

  //   SalesOrder salesOrder = SalesOrder(
  //       itemName: itemNames,
  //       varianceName: varianceNames,
  //       qty: quantities,
  //       uom: uoms,
  //       weight: weights,
  //       amount: amounts,
  //       totalAmount2: totalAmount,
  //       branchId: storedBranch!.branchId,
  //       branchName: storedBranch!.branchName,
  //       totalAmount: totalAmount,
  //       itemCode: itemCodes,
  //       tax: taxs,
  //       price: prices,
  //       deliveryDate: dateController.text,
  //       deliveryTime: timeController.text,
  //       event: selectedEvent.toString(),
  //       customerNumber: mobileNoController.text,
  //       customerName: customerNameController.text,
  //       deliveryType: selectedDeliveryType.toString(),
  //       address: addressController.text,
  //       landmark: landmarkController.text,
  //       discount: discount,
  //       discountAmount: deductedAmount,
  //       remark: remark,
  //       customCharge: customCharge,
  //       advanceAmount: advanceAmountList,
  //       advancePaymentType: advancePaymentType,
  //       finalPrice: orderAmount,
  //       balanceAmount: balanceAmount,
  //       saleOrderNo: saleOrderNo,
  //       orderDate: DateTime.now().toIso8601String(),
  //       orderTime: formattedTime,
  //       employeeName: searchController.text,
  //       status: 'Waiting for Approval',
  //       advanceDateTime: advanceDateTime,
  //       companyName: companyNameController.text,
  //       companyAddress: companyAddressController.text,
  //       companyGST: companygstNumberController.text,
  //       orderType: selectedOrderOption,
  //       approvalStatus: 'Sending to Approval',
  //       approvalType: 'Discount'
  //       // cash: cashAdvance,
  //       // card: cardAdvance,
  //       // upi: upiAdvance,
  //       );

  //   // String jsonSalesOrder = jsonEncode(salesOrder.toJson());

  //   try {
  //     String jsonSalesOrder = jsonEncode({
  //       "data": [salesOrder.toJson()]
  //     });
  //     print('Sales order JSON data: $jsonSalesOrder');
  //     initializeReceiptPrinter(
  //       deliveryTime: timeController.text,
  //       deliverydateprint: dateController.text,
  //       employeeNameController: searchController,
  //       customerNumberController: mobileNoController,
  //       discountController: deductedAmount,
  //       customChargeController: customCharge,
  //       selectedPaymentOptionValue: selectedPaymentMethod,
  //       totalAmount: totalAmount,
  //       advanceAmount: totalAdvance,
  //       balanceAmount: balanceAmount,
  //       customerType: 'SalesOrder',
  //       // context: context,
  //       customAmountController: mobileNoController,
  //       selectedPaymentOption: selectedPaymentMethod,
  //       // saveInvoiceToHiveAndPrint: () {}
  //     );

  //     print("Sending HTTP request..."); // Check if it reaches here
  //     // final response = await http.post(
  //     //   Uri.parse('http://192.168.29.246:8881/salesOrders/'),
  //     final response = await http.post(
  //       // Uri.parse("http://192.168.29.246:8881/fastapi/salesorders/"),
  //       Uri.parse("http://192.168.29.246:8881/fastapi/salesorders/"),
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //       body: jsonSalesOrder,
  //     );

  //     print("Status Code: ${response.statusCode}");
  //     print("Response Body: ${response.body}");

  //     if (response.statusCode == 200) {
  //       var responseData = jsonDecode(response.body);
  //       String salesOrderId = responseData;
  //       print(salesOrderId);
  //       await handleAudioOrder(audioOrderId, salesOrderId, path);
  //       await handleImageUpload(salesOrderId, img1, img2);
  //       await handleHoldOrder(holdId);

  //       // if (context.mounted) {
  //       //   await printReceipt(context);
  //       // }

  //       // /  apiProvider.fetchAllOrders();
  //       // apiProvider.fetchAllOrders();
  //       notifyListeners();

  //       print('Order saved successfully!');
  //       // submitted = true;

  //       // print(submittedOrders);
  //     } else {
  //       print('Failed to save order: ${response.statusCode}');
  //       print('Server Error: ${response.body}');
  //     }
  //   } catch (e) {
  //     print(
  //         'Error while posting order: $e'); // Catches any errors during the request
  //   } finally {
  //     clearControllers();
  //     cartProvider.clearCart();
  //     isSubmitting = false;
  //     showAudioandImage = false;
  //     advanceDateTime!.clear();
  //     advancePaymentType!.clear();
  //     // audioOrderId = null;
  //     // clearAudioAndPhotoIds();
  //     notifyListeners();
  //   }
  // }
  Future<void> sendApproveDataToServer(Map<String, dynamic> approveData) async {
    try {
      final jsonData = jsonEncode(approveData);
      _channel.sink.add(jsonData);
      print('Invoice data sent to server: $jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  Future<void> sendHoldDataToServer(Map<String, dynamic> holdData) async {
    try {
      final jsonData = jsonEncode(holdData);
      _channel.sink.add(jsonData);
      print('Invoice data sent to server: $jsonData');
    } catch (e) {
      print('Error sending invoice data to server: $e');
    }
  }

  Future<void> sendForApproval(
    CartProvider cartProvider,
    double totalAdvance,
    double orderAmount,
    double discount,
    double deductedAmount,
    double customCharge,
    double totalAmount,
    String remark,
    String? path,
    ApiServiceSalesOrderProvider apiProvider,
    File? img1,
    File? img2,
    String? audioOrderId,
    String? holdId,
    String? selectedOrderOption,
    BuildContext context,
  ) async {
    // if (isSubmitting) return; // Prevent double submission
    // isSubmitting = true;

    double balanceAmount = totalAmount - totalAdvance;
    List<double> advanceAmountList = [totalAdvance];
    List<double> cashAdvance = [0.0];
    List<double> cardAdvance = [0.0];
    List<double> upiAdvance = [0.0];

    if (selectedPaymentMethod == 'Cash') {
      cashAdvance[0] = totalAdvance; // Update the first element of cashAdvance
    } else if (selectedPaymentMethod == 'Card') {
      cardAdvance[0] = totalAdvance; // Update the first element of cardAdvance
    } else if (selectedPaymentMethod == 'UPI') {
      upiAdvance[0] = totalAdvance; // Update the first element of upiAdvance
    }
    String currentDateTime = DateTime.now().toIso8601String();
    advanceDateTime ??= [];
    advancePaymentType ??= [];

    // Add datetime and payment type
    advanceDateTime!.add(currentDateTime);
    advancePaymentType!.add(selectedPaymentMethod);

    List<String> itemNames =
        globals.cartItems.map((item) => item.itemName).toList();
    List<String> varianceNames =
        globals.cartItems.map((item) => item.varianceName).toList();
    List<int> quantities =
        globals.cartItems.map((item) => item.quantity).toList();
    List<String> itemCodes =
        globals.cartItems.map((item) => item.itemCode.toString()).toList();
    List<String> uoms =
        globals.cartItems.map((item) => item.uom.toString()).toList();
    List<int> taxs = globals.cartItems.map((item) => item.tax).toList();
    List<double> weights =
        globals.cartItems.map((item) => item.weight).toList();
    List<int> prices =
        globals.cartItems.map((item) => item.pricePerKg).toList();

    List<double> amounts = globals.cartItems.map((item) {
      double calculatedAmount;
      if (item.uom == 'Pcs' || item.uom == 'Pkt') {
        calculatedAmount = item.pricePerKg * item.quantity.toDouble();
      } else {
        calculatedAmount = item.weight * item.quantity * item.pricePerKg;
      }
      return calculatedAmount;
    }).toList();

    String saleOrderNo = generateSaleOrderNo();
    // String formattedDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
    String formattedTime = DateFormat('hh:mm a').format(DateTime.now());
    String approvalType;
    String approvalStatus;
    if (selectedOrderOption == 'Cheque') {
      approvalType = 'Cheque';
      approvalStatus = 'Pending Cheque Payment';
    } else {
      approvalType = 'Discount';
      approvalStatus = 'Sending to Approval';
    }
    SalesOrder salesOrder = SalesOrder(
      itemName: itemNames,
      varianceName: varianceNames,
      qty: quantities,
      uom: uoms,
      weight: weights,
      amount: amounts,
      totalAmount2: totalAmount,
      branchId: storedBranch!.branchId,
      branchName: storedBranch!.branchName,
      totalAmount: totalAmount,
      itemCode: itemCodes,
      tax: taxs,
      price: prices,
      deliveryDate: dateController.text,
      deliveryTime: timeController.text,
      event: selectedEvent.toString(),
      customerNumber: mobileNoController.text,
      customerName: customerNameController.text,
      deliveryType: selectedDeliveryType.toString(),
      address: addressController.text,
      landmark: landmarkController.text,
      discount: discount,
      discountAmount: deductedAmount,
      remark: remark,
      customCharge: customCharge,
      advanceAmount: advanceAmountList,
      advancePaymentType: advancePaymentType,
      finalPrice: orderAmount,
      balanceAmount: balanceAmount,
      saleOrderNo: saleOrderNo,
      orderDate: DateTime.now().toIso8601String(),
      orderTime: formattedTime,
      employeeName: searchController.text,
      status: 'Waiting for Approval',
      advanceDateTime: advanceDateTime,
      companyName: companyNameController.text,
      companyAddress: companyAddressController.text,
      companyGST: companygstNumberController.text,
      orderType: selectedOrderOption,

      approvalDetails: [
        ApprovalOrderDetail(
          approvalType: approvalType,
          approvalStatus: approvalStatus,
          approvalDate: DateTime.now().toIso8601String(),
          summary: 'No',
        ),
      ],
      // cash: cashAdvance,
      // card: cardAdvance,
      // upi: upiAdvance,
    );

    // String jsonSalesOrder = jsonEncode(salesOrder.toJson());

    try {
      String jsonSalesOrder = jsonEncode({
        "data": [salesOrder.toJson()],
        "type": "salesApprovalOrder",
        'sync': "No",
        'edit': 'No',
        'waitingForApprovalResult': 'Yes',
        "saleOrderNo": salesOrder.saleOrderNo,
      });
      print('Sales order JSON data: $jsonSalesOrder');
      initializeReceiptPrinter(
        deliveryTime: timeController.text,
        deliverydateprint: dateController.text,
        employeeNameController: searchController,
        customerNumberController: mobileNoController,
        discountController: deductedAmount,
        customChargeController: customCharge,
        selectedPaymentOptionValue: selectedPaymentMethod,
        totalAmount: totalAmount,
        advanceAmount: totalAdvance,
        balanceAmount: balanceAmount,
        customerType: 'SalesOrder',
        // context: context,
        customAmountController: mobileNoController,
        selectedPaymentOption: selectedPaymentMethod,
        // saveInvoiceToHiveAndPrint: () {}
      );
      await sendApproveDataToServer(jsonDecode(jsonSalesOrder));
      print("Sending HTTP request..."); // Check if it reaches here
      // final response = await http.post(
      //   Uri.parse('http://192.168.29.246:8881/salesOrders/'),
      // final response = await http.post(
      //   // Uri.parse("http://192.168.29.246:8881/fastapi/salesorders/"),
      //   Uri.parse("http://192.168.29.246:8881/fastapi/salesorders/"),
      //   headers: {'Content-Type': 'application/json'},
      //   body: jsonSalesOrder,
      // );

      // print("Status Code: ${response.statusCode}");
      // print("Response Body: ${response.body}");

      // if (response.statusCode == 200) {
      //   var responseData = jsonDecode(response.body);
      //   String salesOrderId = responseData;
      //   print(salesOrderId);
      //   await handleAudioOrder(audioOrderId, salesOrderId, path);
      //   await handleImageUpload(salesOrderId, img1, img2);
      //   await handleHoldOrder(holdId);

      //   // if (context.mounted) {
      //   //   await printReceipt(context);
      //   // }

      //   // /  apiProvider.fetchAllOrders();
      //   // apiProvider.fetchAllOrders();
      //   notifyListeners();

      //   print('Order saved successfully!');
      //   // submitted = true;

      //   // print(submittedOrders);
      // } else {
      //   print('Failed to save order: ${response.statusCode}');
      //   print('Server Error: ${response.body}');
      // }
    } catch (e) {
      print(
        'Error while posting order: $e',
      ); // Catches any errors during the request
    } finally {
      clearControllers();
      cartProvider.clearCart();
      isSubmitting = false;
      showAudioandImage = false;
      advanceDateTime!.clear();
      advancePaymentType!.clear();
      // audioOrderId = null;
      // clearAudioAndPhotoIds();
      notifyListeners();
    }
  }

  Future<void> saveNewOrder(ModifyCartProvider cartProvider,
      SalesOrderDisplay saleorderdisplay, BuildContext context) async {
    // if (isSubmitting) return; // Prevent double submission
    // isSubmitting = true;

    double cashAdvance = 0.0;
    double cardAdvance = 0.0;
    double upiAdvance = 0.0;
    List<double> totalAdvance = saleorderdisplay.advanceAmount!;

    List<String> itemNames =
        globals.modifyItems.map((item) => item.itemName).toList();
    List<String> varianceNames =
        globals.modifyItems.map((item) => item.variancename).toList();
    List<int> quantities =
        globals.modifyItems.map((item) => item.quantity).toList();
    List<String> itemCodes =
        globals.modifyItems.map((item) => item.itemCode.toString()).toList();
    List<String> uoms =
        globals.modifyItems.map((item) => item.uom.toString()).toList();
    List<int> taxs = globals.cartItems.map((item) => item.tax).toList();
    List<double> weights =
        globals.modifyItems.map((item) => item.weight).toList();
    List<int> prices =
        globals.modifyItems.map((item) => item.pricePerKg).toList();

    List<double> amounts = globals.modifyItems.map((item) {
      double calculatedAmount;
      if (item.uom == 'Pcs' || item.uom == 'Pkt') {
        calculatedAmount = item.pricePerKg * item.quantity.toDouble();
      } else {
        calculatedAmount = item.weight * item.quantity * item.pricePerKg;
      }
      return calculatedAmount;
    }).toList();

    // String saleOrderNo = generateSaleOrderNo();
    String formattedDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
    String formattedTime = DateFormat('hh:mm a').format(DateTime.now());

    SalesOrder salesOrder = SalesOrder(
      itemName: itemNames,
      varianceName: varianceNames,
      qty: quantities,
      uom: uoms,
      weight: weights,
      amount: amounts,
      // totalAmount2: totalAmount,
      branchId: storedBranch!.branchId,
      branchName: storedBranch!.branchName,
      totalAmount: 0,
      itemCode: itemCodes,
      tax: taxs,
      price: prices,
      deliveryDate: saleorderdisplay.deliveryDate,
      deliveryTime: saleorderdisplay.deliveryTime,
      event: saleorderdisplay.event,
      customerNumber: saleorderdisplay.customerNumber,
      customerName: saleorderdisplay.customerName,
      deliveryType: saleorderdisplay.deliveryType,
      address: saleorderdisplay.address,
      landmark: saleorderdisplay.landmark,
      discount: 0,
      discountAmount: saleorderdisplay.discountAmount,
      remark: saleorderdisplay.remark,
      customCharge: 0,
      advanceAmount: totalAdvance,
      // advancePaymentType: selectedPaymentMethod,
      finalPrice: 0,
      balanceAmount: 0,
      saleOrderNo: saleorderdisplay.saleOrderNo,
      orderDate: formattedDate,
      orderTime: formattedTime,
      employeeName: searchController.text,
      status: 'Modify request',
      cash: cashAdvance,
      card: cardAdvance,
      upi: upiAdvance,
    );

    String jsonSalesOrder = jsonEncode(salesOrder.toJson());

    print('Sales order JSON data: $jsonSalesOrder');
    try {
      print("Sending HTTP request..."); // Check if it reaches here
      // final response = await http.post(
      //   Uri.parse('http://192.168.29.246:8881/salesOrders/'),
      final response = await http.post(
        // Uri.parse("http://192.168.29.246:8881/fastapi/salesorders/"),
        Uri.parse("https://yenerp.com/fastapi/salesorders/"),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonSalesOrder,
      );

      print("Status Code: ${response.statusCode}");
      print("Response Body: ${response.body}");

      if (response.statusCode == 200) {
        var responseData = jsonDecode(response.body);
        // String salesOrderId = responseData['salesOrderId'];

        String salesOrderId = responseData;

        print(salesOrderId);

        print('Order saved successfully!');
        notifyListeners();
        // print(submittedOrders);
      } else {
        print('Failed to save order: ${response.statusCode}');
        print('Server Error: ${response.body}');
      }
    } catch (e) {
      print(
          'Error while posting order: $e'); // Catches any errors during the request
    } finally {
      // clearControllers();
      // cartProvider.clearCart();
      // isSubmitting = false;
      // audioOrderId = null;
      notifyListeners();
    }
  }

  Future<void> deleteSalesOrder(String salesOrderId) async {
    try {
      final url =
          Uri.parse("http://192.168.29.246:8881/heldorders/$salesOrderId");

      final response = await http.delete(
        url,
        headers: {
          'Content-Type': 'application/json', // Set content type as JSON
        },
      );

      if (response.statusCode == 200) {
        // Successfully deleted
        print("Sales Order Deleted Successfully!");
        print("Response: ${response.body}");
        notifyListeners();
      } else {
        // Handle failure response
        print(
            "Failed to delete sales order. Status code: ${response.statusCode}");
        print("Response: ${response.body}");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  Future<void> _postImages(
      String salesOrderId, File? pickedImage1, File? pickedImage2) async {
    try {
      print("Sending HTTP request for images...");

      var uri = Uri.parse(
          "http://192.168.29.246:8881/imageOrder/upload_photo"); // Change to your FastAPI endpoint
      var request = http.MultipartRequest('POST', uri);

      // Attach the salesOrderId to the request
      request.fields['custom_id'] = salesOrderId;

      // Check and add image1 if it's picked
      if (pickedImage1 != null) {
        var image1Bytes = await pickedImage1.readAsBytes();
        var image1MimeType = lookupMimeType(pickedImage1.path) ??
            'image/jpeg'; // Default to 'image/jpeg' if MIME type is not found

        // Add image1 as a multipart file
        request.files.add(http.MultipartFile.fromBytes(
          'files', // The field name expected by FastAPI
          image1Bytes,
          filename: pickedImage1.path
              .split('/')
              .last, // Extract the filename from the path
          contentType:
              MediaType.parse(image1MimeType), // Use the correct MIME type
        ));
      }

      // Check and add image2 if it's picked
      if (pickedImage2 != null) {
        var image2Bytes = await pickedImage2.readAsBytes();
        var image2MimeType = lookupMimeType(pickedImage2.path) ??
            'image/jpeg'; // Default to 'image/jpeg' if MIME type is not found

        // Add image2 as a multipart file
        request.files.add(http.MultipartFile.fromBytes(
          'files', // The field name expected by FastAPI
          image2Bytes,
          filename: pickedImage2.path
              .split('/')
              .last, // Extract the filename from the path
          contentType:
              MediaType.parse(image2MimeType), // Use the correct MIME type
        ));
      }

      // Send the request and await the response
      var response = await request.send();
      print("Status Code: ${response.statusCode}");

      if (response.statusCode == 200) {
        var responseBody = await response.stream.bytesToString();
        var responseData = jsonDecode(responseBody);
        print('Response Data: $responseData');

        // Process the response to get the uploaded image URLs
        var uploadedPhotos = responseData['uploaded_photos'];
        for (var photo in uploadedPhotos) {
          print('Uploaded Photo URL: ${photo['photo_url']}');
        }
      } else {
        print('Failed to upload images: ${response.statusCode}');
        print('Server Error: ${response.headers}');
      }
    } catch (e) {
      print('Error while posting images: $e');
    }
  }

  Future<void> handleAudioOrder(
      String? audioOrderId, String salesOrderId, String? path) async {
    print('path');
    print(path);
    if (path == null || path.isEmpty) {
      return;
    }
    if (audioOrderId != null) {
      await updateCustomId(audioOrderId, salesOrderId);
    } else {
      await _postAudioFile(salesOrderId, path);
    }
  }

  Future<void> handleImageUpload(
      String salesOrderId, File? img1, File? img2) async {
    if (img1 != null || img2 != null) {
      await _postImages(salesOrderId, img1, img2);
    }
  }

  Future<void> handleHoldOrder(String? holdId) async {
    if (holdId != null) {
      await _patchHoldOrderStatus(holdId);
    }
  }

  Future<void> _patchHoldOrderStatus(String? holdOrderId) async {
    if (holdOrderId == null || holdOrderId.isEmpty) {
      print("No hold order ID provided. Exiting the function.");
      return; // Return early if there's no valid holdOrderId
    }

    try {
      print("Sending PATCH request to update hold order status...");

      // Create the request body with the new status
      final Map<String, dynamic> requestBody = {
        'status': 'completed order', // Update the status to 'completed order'
      };

      final response = await http.patch(
        Uri.parse(
            "http://192.168.29.246:8881/heldorders/$holdOrderId"), // Use holdOrderId in the URL
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestBody), // Convert request body to JSON
      );

      print("Status Code: ${response.statusCode}");
      print("Response Body: ${response.body}");

      if (response.statusCode == 200) {
        print("Hold order status updated to 'completed order'.");
      } else {
        print(
            "Failed to update hold order status. Status code: ${response.statusCode}");
      }
    } catch (e) {
      print("Error occurred while sending the PATCH request: $e");
    }
  }
//  Future<void> printReceiptBack(String orderId, Map<String, dynamic> salesOrder) async {
//     final String endpoint = "http://192.168.29.246:8881/fastapi/salesorders/print-receipt/$orderId";

//     try {
//       // Make a POST request to the /print-receipt endpoint
//       final response = await http.post(
//         Uri.parse(endpoint),
//         headers: {
//           "Content-Type": "application/json", // Set headers
//         },
//         body: jsonEncode(salesOrder), // Encode salesOrder as JSON
//       );

//       // Handle response
//       if (response.statusCode == 200) {
//         final responseData = jsonDecode(response.body);
//         print("Receipt printed successfully: ${responseData['message']}");
//       } else {
//         print("Failed to print receipt: ${response.body}");
//       }
//     } catch (error) {
//       // Handle errors
//       print("Error calling /print-receipt: $error");
//     }
//   }
// }

  Future<void> _postAudioFile(String customId, String filePath) async {
    print('Posting audio with customId: $customId');
    // final uri = Uri.parse('https://yenerp.com/fastapi/audios/upload_audio');
    final uri = Uri.parse('http://192.168.29.246:8881/audioOrder/upload_audio');

    try {
      // Determine the content type based on the file extension (simplified example)
      String fileExtension = filePath.split('.').last.toLowerCase();
      String contentType = 'audio/$fileExtension';

      // Create a new MultipartRequest
      final request = http.MultipartRequest('POST', uri);

      // Add the audio file with dynamic content type
      var file = await http.MultipartFile.fromPath(
        'file',
        filePath,
        contentType: MediaType.parse(contentType),
      );
      request.files.add(file);

      // Debug: Check what is being added to the request
      print('Adding custom_id to form: $customId');

      // Pass customId in the form fields
      if (customId.isNotEmpty) {
        request.fields['custom_id'] = customId;
      }

      // Debug: Check the request before sending it
      print('Request fields: ${request.fields}');

      // Send the request
      final response = await request.send();
      final responseBody =
          await response.stream.bytesToString(); // Read response body

      // Debug: Check the server's response
      if (response.statusCode == 200) {
        print('Audio uploaded successfully');
        print('Server response: $responseBody');
      } else {
        print('Failed to upload audio: ${response.statusCode}');
        print('Server response: $responseBody');
      }
    } catch (e) {
      print('Error uploading audio: $e');
      // Optionally, handle error more gracefully (e.g., display a user-friendly message)
    }
  }

  Future<void> _heldOrder(CartProvider cartProvider, String path,
      ApiServiceSalesOrderProvider apiProvider, File? img1, File? img2) async {
    print("hold orders 1");
    List<String> itemNames =
        globals.cartItems.map((item) => item.itemName).toList();
    List<String> varianceNames =
        globals.cartItems.map((item) => item.varianceName).toList();
    print("variance heldorder $varianceNames");
    List<int> quantities =
        globals.cartItems.map((item) => item.quantity).toList();
    List<String> itemCodes =
        globals.cartItems.map((item) => item.itemCode.toString()).toList();
    List<String> uoms =
        globals.cartItems.map((item) => item.uom.toString()).toList();
    List<int> taxs = globals.cartItems.map((item) => item.tax).toList();
    List<double> weights =
        globals.cartItems.map((item) => item.weight).toList();
    List<int> prices =
        globals.cartItems.map((item) => item.pricePerKg).toList();

    List<double> amounts = globals.cartItems.map((item) {
      double calculatedAmount;
      if (item.uom == 'Pcs' || item.uom == 'Pkt') {
        calculatedAmount = item.pricePerKg * item.quantity.toDouble();
      } else {
        calculatedAmount = item.weight * item.quantity * item.pricePerKg;
      }
      return calculatedAmount;
    }).toList();

    String saleOrderNo = generateSaleOrderNo();
    String formattedDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
    String formattedTime = DateFormat('hh:mm a').format(DateTime.now());

    HeldOrder holdsalesOrder = HeldOrder(
      salesOrderId: '',
      itemName: itemNames,
      varianceName: varianceNames,
      qty: quantities,
      uom: uoms,
      weight: weights,
      amount: amounts,
      itemCode: itemCodes,
      tax: taxs,
      price: prices,
      deliveryDate: dateController.text,
      deliveryTime: timeController.text,
      event: selectedEvent.toString(),
      customerNumber: mobileNoController.text,
      customerName: customerNameController.text,
      deliveryType: selectedDeliveryType.toString(),
      address: addressController.text,
      landmark: landmarkController.text,
      saleOrderNo: saleOrderNo,
      orderDate: formattedDate,
      orderTime: formattedTime,
      employeeName: searchController.text,
      status: 'Hold Order',
    );

    String jsonHoldSalesOrder = jsonEncode({
      "data": [
        holdsalesOrder.toJson(),
      ],
      "type": "holdOrder",
      'sync': "No",
      'edit': 'No'
    });

    print('Sales order JSON data1235 : $jsonHoldSalesOrder');
    try {
      await sendHoldDataToServer(jsonDecode(jsonHoldSalesOrder));
      print("Hold data sent via WebSocket $jsonHoldSalesOrder");
    } catch (e) {
      print(
          'Error while posting order: $e'); // Catches any errors during the request
    } finally {
      clearControllers();
      clearControllers();
      cartProvider.clearCart();
      isSubmitting = false;
      showAudioandImage = false;
      advanceDateTime!.clear();
      advancePaymentType!.clear();
    }
  }
  // Future<void> _heldOrder(CartProvider cartProvider, String path,
  //     ApiServiceSalesOrderProvider apiProvider, File? img1, File? img2) async {
  //   List<String> itemNames =
  //       globals.cartItems.map((item) => item.itemName).toList();
  //   List<String> varianceNames =
  //       globals.cartItems.map((item) => item.varianceName).toList();
  //   List<int> quantities =
  //       globals.cartItems.map((item) => item.quantity).toList();
  //   List<String> itemCodes =
  //       globals.cartItems.map((item) => item.itemCode.toString()).toList();
  //   List<String> uoms =
  //       globals.cartItems.map((item) => item.uom.toString()).toList();
  //   List<int> taxs = globals.cartItems.map((item) => item.tax).toList();
  //   List<double> weights =
  //       globals.cartItems.map((item) => item.weight).toList();
  //   List<int> prices =
  //       globals.cartItems.map((item) => item.pricePerKg).toList();

  //   List<double> amounts = globals.cartItems.map((item) {
  //     double calculatedAmount;
  //     if (item.uom == 'Pcs' || item.uom == 'Pkt') {
  //       calculatedAmount = item.pricePerKg * item.quantity.toDouble();
  //     } else {
  //       calculatedAmount = item.weight * item.quantity * item.pricePerKg;
  //     }
  //     return calculatedAmount;
  //   }).toList();

  //   String saleOrderNo = generateSaleOrderNo();
  //   String formattedDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
  //   String formattedTime = DateFormat('hh:mm a').format(DateTime.now());

  //   HeldOrder salesOrder = HeldOrder(
  //     salesOrderId: '',
  //     itemName: itemNames,
  //     varianceName: varianceNames,
  //     qty: quantities,
  //     uom: uoms,
  //     weight: weights,
  //     amount: amounts,
  //     itemCode: itemCodes,
  //     tax: taxs,
  //     price: prices,
  //     deliveryDate: dateController.text,
  //     deliveryTime: timeController.text,
  //     event: selectedEvent.toString(),
  //     customerNumber: mobileNoController.text,
  //     customerName: customerNameController.text,
  //     deliveryType: selectedDeliveryType.toString(),
  //     address: addressController.text,
  //     landmark: landmarkController.text,
  //     saleOrderNo: saleOrderNo,
  //     orderDate: formattedDate,
  //     orderTime: formattedTime,
  //     employeeName: searchController.text,
  //     status: 'Hold Order',
  //   );

  //   String jsonSalesOrder = jsonEncode(salesOrder.toJson());
  //   print('Sales order JSON data: $jsonSalesOrder');
  //   try {
  //     print("Sending HTTP request..."); // Check if it reaches here
  //     // final response = await http.post(
  //     //   Uri.parse('http://192.168.29.246:8881/salesOrders/'),
  //     final response = await http.post(
  //       Uri.parse("http://192.168.29.246:8881/heldorders/"),
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //       body: jsonSalesOrder,
  //     );

  //     print("Status Code: ${response.statusCode}");
  //     print("Response Body: ${response.body}");

  //     if (response.statusCode == 200) {
  //       var responseData = jsonDecode(response.body);
  //       // String salesOrderId = responseData['salesOrderId'];
  //       String salesOrderId = responseData;
  //       // orders.add(salesOrder);
  //       print(salesOrderId);
  //       await _postAudioFile(salesOrderId, path);
  //       if (img1 != null) {
  //         _postImages(salesOrderId, img1, img2);
  //       }
  //       await apiProvider.fetchOrders();
  //       notifyListeners();
  //       print('Order saved successfully!');
  //       notifyListeners();
  //       //print(submittedOrders);
  //     } else {
  //       print('Failed to save order: ${response.statusCode}');
  //       print('Server Error: ${response.body}');
  //     }
  //   } catch (e) {
  //     print(
  //         'Error while posting order: $e'); // Catches any errors during the request
  //   } finally {
  //     clearControllers();
  //   }
  // }

  Future<List<HeldOrder>> fetchHeldOrders() async {
    const String url = "http://192.168.29.246:8881/heldorders/"; // API endpoint

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        List<dynamic> jsonData = jsonDecode(response.body);

        // Filter only orders with status == "holdorder"
        List<HeldOrder> heldOrders = jsonData
            .map((order) => HeldOrder.fromJson(order))
            .where((order) => order.status == "Hold Order")
            .toList();

        print('Filtered Held Orders: $heldOrders');
        return heldOrders;
      } else {
        print('Failed to fetch held orders: ${response.statusCode}');
        print('Server Error: ${response.body}');
        return [];
      }
    } catch (e) {
      print('Error while fetching held orders: $e');
      return [];
    }
  }

  Future<void> postCreditCustomer(
    CartProvider cartProvider,
    double totalAdvance,
    double orderAmount,
    double discount,
    double deductedAmount,
    double customCharge,
    double totalAmount,
    String remark,
    String? path,
    File? img1,
    File? img2,
    BuildContext context, // Pass the context to the function
  ) async {
    double balanceAmount = totalAmount - totalAdvance;
    double cashAdvance = 0.0;
    double cardAdvance = 0.0;
    double upiAdvance = 0.0;

    if (selectedPaymentMethod == 'Cash') {
      cashAdvance = totalAdvance;
    } else if (selectedPaymentMethod == 'Card') {
      cardAdvance = totalAdvance;
    } else if (selectedPaymentMethod == 'UPI') {
      upiAdvance = totalAdvance;
    }

    List<String> itemNames =
        globals.cartItems.map((item) => item.itemName).toList();

    List<String> varianceNames =
        globals.cartItems.map((item) => item.varianceName).toList();
    List<double> quantities =
        globals.cartItems.map((item) => item.quantity.toDouble()).toList();
    List<String> itemCodes =
        globals.cartItems.map((item) => item.itemCode.toString()).toList();
    List<String> uoms =
        globals.cartItems.map((item) => item.uom.toString()).toList();
    List<double> taxs =
        globals.cartItems.map((item) => item.tax.toDouble()).toList();
    List<double> weights =
        globals.cartItems.map((item) => item.weight).toList();
    List<double> prices =
        globals.cartItems.map((item) => item.pricePerKg.toDouble()).toList();

    List<double> amounts = globals.cartItems.map((item) {
      double calculatedAmount;
      if (item.uom == 'Pcs' || item.uom == 'Pkt') {
        calculatedAmount = item.pricePerKg * item.quantity.toDouble();
      } else {
        calculatedAmount = item.weight * item.quantity * item.pricePerKg;
      }
      return calculatedAmount;
    }).toList();

    // String saleOrderNo = generateSaleOrderNo();
    // String formattedDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
    // String formattedTime = DateFormat('hh:mm a').format(DateTime.now());

    CreditOrder creditOrder = CreditOrder(
      creditBillId: '', // You can provide a valid ID if available
      itemName: itemNames, // List of item names
      price: prices, // List of prices
      weight: weights, // List of weights
      qty: quantities, // List of quantities
      amount: amounts, // List of amounts
      tax: taxs, // List of taxes
      branch: storedBranch!.branchName,
      totalAmount: totalAmount,
      branchId: storedBranch!.branchId,
      balanceAmount: balanceAmount,
      uom: uoms, // List of units of measure
      employeeName: searchController.text, // Employee name from controller
      phoneNumber: mobileNoController.text
          .toString(), // Customer phone number from controller
      deliveryDate: dateController.text.toString(), // Date from controller
      deliveryTime: timeController.text.toString(), // Time from controller
      deliveryType: selectedDeliveryType.toString(), // Delivery type selected
      discountAmount: deductedAmount,
      customCharge: customCharge,
      paymentType: selectedPaymentMethod,
      customerName:
          customerNameController.text, // Customer name from controller
      customerAddress: addressController.text, // Address from controller
    );

    String jsonSalesOrder = jsonEncode(creditOrder.toJson());
    print('Sales order JSON data: $jsonSalesOrder');

    try {
      // Attempt to post the data

      initializeReceiptPrinter(
        deliveryTime: timeController.text,
        deliverydateprint: dateController.text,
        employeeNameController: searchController,
        customerNumberController: mobileNoController,
        discountController: deductedAmount,
        customChargeController: customCharge,
        selectedPaymentOptionValue: selectedPaymentMethod,
        totalAmount: totalAmount,
        advanceAmount: totalAdvance,
        balanceAmount: balanceAmount,
        customerType: 'CreditOrder',
        // context: context,
        customAmountController: mobileNoController,
        selectedPaymentOption: selectedPaymentMethod,
      );
      print("Sending HTTP request...");
      final response = await http.post(
        Uri.parse("http://:8888/creditbills/"),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonSalesOrder,
      );

      if (response.statusCode == 201) {
        var responseData = jsonDecode(response.body);
        print('Response Data: $responseData');

        String salesOrderId = responseData['creditBillId'];
        print('Sales Order ID: $salesOrderId');

        // Proceed only if the sales order was successfully created
        if (img1 != null || img2 != null) {
          await _postImages(salesOrderId, img1, img2);
        }
        if (path != null || path!.isNotEmpty) {
          await _postAudioFile(salesOrderId, path);
        }

        // Ensure widget is still mounted before calling printReceipt
        if (context.mounted) {
          await printReceipt();
        }
        // if (context.mounted) {
        //   Navigator.pop(context);
        // }
      } else {
        // Handle unsuccessful response (e.g., show an error message)
        debugPrint(
            'Failed to create sales order. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error occurred while posting credit customer: $e');
    } finally {
      // Clear controllers after the process is done
      clearControllers();
    }
  }

  Future<void> fetchCreditBills() async {
    try {
      print("Fetching credit bills...");

      // Send GET request to the server to fetch data
      final response = await http.get(
        Uri.parse("http://192.168.29.246:8881/fastapi/creditbills/"),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      // Check if the response status is OK (200)
      if (response.statusCode == 200) {
        var responseData = jsonDecode(response.body);
        print("Fetched data: $responseData");

        // Process the fetched data as required
        // For example, you could map the data to a model or update UI state
        // For now, just print the data
      } else {
        print("Failed to fetch data: ${response.statusCode}");
      }
    } catch (e) {
      print("Error fetching credit bills: $e");
    }
  }

//   Widget buildCustomerInputFields(BuildContext context) {
//     return Column(
//       children: [
//         Row(
//           children: [
//             const Padding(padding: EdgeInsets.all(5)),
//             Expanded(
//               child: TextFormField(
//                 controller: mobileNoController,
//                 // keyboardType: TextInputType.phone,
//                 inputFormatters: [
//                   FilteringTextInputFormatter.digitsOnly,
//                   LengthLimitingTextInputFormatter(10),
//                 ],
//                 decoration: const InputDecoration(
//                   border: OutlineInputBorder(),
//                   labelText: 'Mobile Number',
//                   prefixIcon: Icon(Icons.search),
//                 ),
//                 onChanged: fetchSuggestions,
//                 validator: (value) {
//                   if (isFormValid && (value == null || value.isEmpty)) {
//                     return 'Customer Mobile No is required';
//                   }
//                   return null;
//                 },
//               ),
//             ),
//             const Padding(padding: EdgeInsets.all(5)),
//             // const Padding(padding: EdgeInsets.all(5)),
//             Expanded(
//               child: TextFormField(
//                 enabled: false,
//                 controller: customerNameController,
//                 inputFormatters: [
//                   LengthLimitingTextInputFormatter(24),
//                   FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z0-9 ]*$')),
//                 ],
//                 decoration: const InputDecoration(
//                   border: OutlineInputBorder(),
//                   labelText: 'Customer Name',
//                 ),
//                 validator: (value) {
//                   if (isFormValid && (value == null || value.isEmpty)) {
//                     return 'Customer Name is required';
//                   }
//                   return null;
//                 },
//               ),
//             ),
//           ],
//         ),
//         const SizedBox(height: 8.0),

//         if (suggestions.isNotEmpty || mobileNoController.text.isNotEmpty)
//           Container(
//             height: 100,
//             decoration: BoxDecoration(
//               border: Border.all(color: Colors.white),
//               borderRadius: BorderRadius.circular(8.0),
//             ),
//             child: ListView.builder(
//               itemCount: suggestions.length + 1,
//               itemBuilder: (context, index) {
//                 if (index == suggestions.length) {
//                   return ListTile(
//                     leading: const Icon(Icons.add, color: Colors.green),
//                     title: const Text('Add Customer Details'),
//                     onTap: () async {
//                       await showDialog(
//                         context: context,
//                         builder: (BuildContext context) {
//                           final TextEditingController mobileController =
//                               TextEditingController(
//                                   text: mobileNoController.text);
//                           final TextEditingController nameController =
//                               TextEditingController();
//                           return AlertDialog(
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(16.0),
//                             ),
//                             title: const Row(
//                               children: [
//                                 Icon(Icons.person_add, color: Colors.blue),
//                                 SizedBox(width: 8),
//                                 Text('Add Customer',
//                                     style:
//                                         TextStyle(fontWeight: FontWeight.bold)),
//                               ],
//                             ),
//                             content: SingleChildScrollView(
//                               child: Column(
//                                 mainAxisSize: MainAxisSize.min,
//                                 children: [
//                                   TextFormField(
//                                     controller: mobileController,
//                                     keyboardType: TextInputType.phone,
//                                     inputFormatters: [
//                                       FilteringTextInputFormatter.digitsOnly,
//                                       LengthLimitingTextInputFormatter(10),
//                                     ],
//                                     decoration: InputDecoration(
//                                       labelText: 'Mobile Number',
//                                       prefixText: '+91 ',
//                                       prefixStyle:
//                                           const TextStyle(color: Colors.black),
//                                       border: OutlineInputBorder(
//                                           borderRadius:
//                                               BorderRadius.circular(8.0)),
//                                     ),
//                                   ),
//                                   const SizedBox(height: 16),
//                                   TextFormField(
//                                     controller: nameController,
//                                     inputFormatters: [
//                                       LengthLimitingTextInputFormatter(24),
//                                       FilteringTextInputFormatter.allow(
//                                           RegExp(r'^[a-zA-Z ]*$')),
//                                     ],
//                                     decoration: InputDecoration(
//                                       labelText: 'Customer Name',
//                                       border: OutlineInputBorder(
//                                           borderRadius:
//                                               BorderRadius.circular(8.0)),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                             actions: [
//                               TextButton(
//                                 onPressed: () => Navigator.pop(context),
//                                 child: const Text('Cancel',
//                                     style: TextStyle(
//                                         color: Colors.red,
//                                         fontWeight: FontWeight.bold)),
//                               ),
//                               ElevatedButton(
//                                 onPressed: () async {
//                                   final String mobile =
//                                       mobileController.text.trim();
//                                   final String name =
//                                       nameController.text.trim();

//                                   if (mobile.length == 10 &&
//                                       RegExp(r'^\d+$').hasMatch(mobile) &&
//                                       name.isNotEmpty) {
//                                     final response =
//                                         await addCustomer(mobile, name);
//                                     if (response) {
//                                       ScaffoldMessenger.of(context)
//                                           .showSnackBar(
//                                         SnackBar(
//                                           content: Text(
//                                               'Customer "$name" added successfully!',
//                                               style: const TextStyle(
//                                                   color: Colors.white)),
//                                           backgroundColor: Colors.green,
//                                         ),
//                                       );
//                                       await fetchSuggestions(mobile);
//                                       Navigator.pop(context);
//                                     } else {
//                                       ScaffoldMessenger.of(context)
//                                           .showSnackBar(
//                                         const SnackBar(
//                                           content: Text(
//                                               'Failed to add customer. Please try again.'),
//                                           backgroundColor: Colors.red,
//                                         ),
//                                       );
//                                     }
//                                   } else {
//                                     ScaffoldMessenger.of(context).showSnackBar(
//                                       const SnackBar(
//                                         content: Text(
//                                             'Please enter a valid mobile number and name.'),
//                                         backgroundColor: Colors.orange,
//                                       ),
//                                     );
//                                   }
//                                 },
//                                 child: const Text(
//                                   'Submit',
//                                   style: TextStyle(
//                                       fontWeight: FontWeight.bold,
//                                       color: Colors.white),
//                                 ),
//                               ),
//                             ],
//                           );
//                         },
//                       );
//                     },
//                   );
//                 }
//                 final suggestion = suggestions[index];
//                 print('suggestion$suggestion');
//                 return ListTile(
//                   title: Text(suggestion['mobileNo'] ?? 'Unknown Mobile'),
//                   subtitle: Text(suggestion['name'] ?? 'Unknown Name'),
//                   onTap: () => onSuggestionSelected(suggestion),
//                 );
//               },
//             ),
//           ),
//       ],
//     );

//   }
// }

  Widget buildCompanyInputFields(BuildContext context) {
    return Column(
      children: [
        // Company-specific fields
        Row(
          children: [
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                controller: companyNameController,
                keyboardType: TextInputType.text,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z0-9 ]*$')),
                  LengthLimitingTextInputFormatter(50),
                ],
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Company Name',
                  // prefixIcon: Icon(Icons.search),
                  isDense: true, // Makes the field more compact
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                ),
                onChanged: (value) {
                  fetchCompanySuggestionsDebounced(value);
                },
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Company Name is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
          ],
        ),

        if (companyNameController.text.isNotEmpty &&
            companyAddressController.text.isEmpty)
          Container(
            height: 100,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: ListView.builder(
              itemCount: suggestions.isEmpty ? 1 : suggestions.length + 1,
              itemBuilder: (context, index) {
                // Show suggestions if available
                if (suggestions.isNotEmpty && index < suggestions.length) {
                  final company = suggestions[index];
                  return ListTile(
                    title: Text(company['name'] ?? ""),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(company['address'] ?? ""),
                        Text('GST: ${company['gst']}'),
                      ],
                    ),
                    onTap: () {
                      companyNameController.text = company['name'] ?? "";
                      companyAddressController.text = company['address'] ?? "";
                      companygstNumberController.text = company['gst'] ?? "";
                      suggestions.clear();
                      // FocusScope.of(context).unfocus();
                      notifyListeners();
                    },
                  );
                }
                // Show "Add Customer Details" as the last item
                return ListTile(
                  leading: const Icon(Icons.add, color: Colors.green),
                  title: const Text('Add Company Details'),
                  onTap: () async {
                    await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        final TextEditingController nameController =
                            TextEditingController();
                        final TextEditingController addressController =
                            TextEditingController();
                        final TextEditingController gstController =
                            TextEditingController();

                        return AlertDialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16.0),
                          ),
                          title: const Row(
                            children: [
                              Icon(Icons.business, color: Colors.blue),
                              SizedBox(width: 8),
                              Text('Add Company',
                                  style:
                                      TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                          content: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TextFormField(
                                  controller: nameController,
                                  decoration: const InputDecoration(
                                    labelText: 'Company Name',
                                    border: OutlineInputBorder(),
                                    isDense:
                                        true, // Makes the field more compact
                                    contentPadding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 6),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                TextFormField(
                                  controller: addressController,
                                  decoration: const InputDecoration(
                                    labelText: 'Company Address',
                                    border: OutlineInputBorder(),
                                    isDense:
                                        true, // Makes the field more compact
                                    contentPadding: EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 8),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                TextFormField(
                                  controller: gstController,
                                  decoration: const InputDecoration(
                                    labelText: 'Company GST',
                                    border: OutlineInputBorder(),
                                    isDense:
                                        true, // Makes the field more compact
                                    contentPadding: EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 8),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('Cancel',
                                  style: TextStyle(
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold)),
                            ),
                            ElevatedButton(
                              onPressed: () async {
                                final String name = nameController.text.trim();
                                final String address =
                                    addressController.text.trim();
                                final String gst = gstController.text.trim();

                                if (name.isNotEmpty &&
                                    address.isNotEmpty &&
                                    gst.isNotEmpty) {
                                  final response =
                                      await addCompany(name, address, gst);

                                  if (response) {
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(SnackBar(
                                      content: Text(
                                          'Company "$name" added successfully!',
                                          style: const TextStyle(
                                              color: Colors.white)),
                                      backgroundColor: Colors.green,
                                    ));
                                    fetchCompanySuggestionsDebounced('');
                                    Navigator.pop(context);
                                  } else {
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(const SnackBar(
                                      content: Text(
                                          'Failed to add company. Please try again.'),
                                      backgroundColor: Colors.red,
                                    ));
                                  }
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                          'Please fill in all fields correctly.'),
                                      backgroundColor: Colors.orange,
                                    ),
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: const Text('Submit',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white)),
                            ),
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),

        const SizedBox(height: 10),
        Row(
          children: [
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                enabled: false,
                controller: companyAddressController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Company Address',
                  isDense: true, // Makes the field more compact
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                ),
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Company Address is required';
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(width: 10), // Spacing between the two fields
            Expanded(
              child: TextFormField(
                enabled: false,
                controller: companygstNumberController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Company GST',
                  isDense: true, // Makes the field more compact
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                ),
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Company GST is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
          ],
        ),
      ],
    );
  }

  Widget buildCustomerInputFields(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                controller: mobileNoController,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(10),
                ],
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Search Mobile Number',
                  labelStyle: TextStyle(fontSize: 10),

                  isDense: true, // Makes the field more compact
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 8, vertical: 6), // Same padding as above
                ),
                onChanged: (value) {
                  // Clear customer name when mobile number changes
                  customerNameController.clear();
                  fetchSuggestions(value);
                },
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Customer Mobile No is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                enabled: false,
                controller: customerNameController,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(24),
                  FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z0-9 ]*$')),
                ],
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Customer Name',
                  labelStyle: TextStyle(fontSize: 10),
                  isDense: true, // Makes the field more compact
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 8, vertical: 6), // Same padding as above
                ),
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Customer Name is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
          ],
        ),
        const SizedBox(height: 8.0),

        // Only show suggestions container when mobile number is not empty AND customer name is empty
        if (mobileNoController.text.isNotEmpty &&
            customerNameController.text.isEmpty)
          Container(
            height: 50,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: ListView.builder(
              itemCount: suggestions.isEmpty ? 1 : suggestions.length + 1,
              itemBuilder: (context, index) {
                // Show suggestions if available
                if (suggestions.isNotEmpty && index < suggestions.length) {
                  final suggestion = suggestions[index];
                  return ListTile(
                    title: Text(suggestion['mobileNo'] ?? 'Unknown Mobile'),
                    subtitle: Text(suggestion['name'] ?? 'Unknown Name'),
                    onTap: () {
                      onSuggestionSelected(suggestion);
                      // Set focus to next field or clear focus
                      FocusScope.of(context).unfocus();
                    },
                  );
                }

                // Show "Add Customer Details" as the last item
                return ListTile(
                  leading: const Icon(Icons.add, color: Colors.green),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 8.0, vertical: 4.0), // Reduced padding
                  title: const Text('Add Customer Details'),
                  onTap: () async {
                    await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        final TextEditingController mobileController =
                            TextEditingController(
                                text: mobileNoController.text);
                        final TextEditingController nameController =
                            TextEditingController();
                        return AlertDialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16.0),
                          ),
                          title: const Row(
                            children: [
                              Icon(Icons.person_add, color: Colors.blue),
                              SizedBox(width: 8),
                              Text('Add Customer',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 10)),
                            ],
                          ),
                          content: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TextFormField(
                                  controller: mobileController,
                                  keyboardType: TextInputType.phone,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly,
                                    LengthLimitingTextInputFormatter(10),
                                  ],
                                  decoration: InputDecoration(
                                    labelText: 'Mobile Number',
                                    prefixText: '+91 ',
                                    prefixStyle:
                                        const TextStyle(color: Colors.black),
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(8.0)),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                TextFormField(
                                  controller: nameController,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(24),
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'^[a-zA-Z ]*$')),
                                  ],
                                  decoration: InputDecoration(
                                    labelText: 'Customer Name',
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(8.0)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('Cancel',
                                  style: TextStyle(
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold)),
                            ),
                            ElevatedButton(
                              onPressed: () async {
                                final String mobile =
                                    mobileController.text.trim();
                                final String name = nameController.text.trim();

                                if (mobile.length == 10 &&
                                    RegExp(r'^\d+$').hasMatch(mobile) &&
                                    name.isNotEmpty) {
                                  final response =
                                      await addCustomer(mobile, name);
                                  if (response) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                            'Customer "$name" added successfully!',
                                            style: const TextStyle(
                                                color: Colors.white)),
                                        backgroundColor: Colors.green,
                                      ),
                                    );
                                    await fetchSuggestions(mobile);
                                    Navigator.pop(context);
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            'Failed to add customer. Please try again.'),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                  }
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                          'Please enter a valid mobile number and name.'),
                                      backgroundColor: Colors.orange,
                                    ),
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: const Text(
                                'Submit',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white),
                              ),
                            ),
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
      ],
    );
  }

  Widget buildAddCustomerDialog(BuildContext context) {
    final TextEditingController mobileController =
        TextEditingController(text: mobileNoController.text);
    final TextEditingController nameController = TextEditingController();

    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
      ),
      title: const Row(
        children: [
          Icon(Icons.person_add, color: Colors.blue),
          SizedBox(width: 8),
          Text('Add Customer',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10)),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              controller: mobileController,
              keyboardType: TextInputType.phone,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(10),
              ],
              decoration: InputDecoration(
                labelText: 'Mobile Number',
                prefixText: '+91 ',
                prefixStyle: const TextStyle(color: Colors.black),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0)),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: nameController,
              inputFormatters: [
                LengthLimitingTextInputFormatter(24),
                FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z ]*$')),
              ],
              decoration: InputDecoration(
                labelText: 'Customer Name',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0)),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel',
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
        ),
        ElevatedButton(
          onPressed: () async {
            final String mobile = mobileController.text.trim();
            final String name = nameController.text.trim();

            if (mobile.length == 10 &&
                RegExp(r'^\d+$').hasMatch(mobile) &&
                name.isNotEmpty) {
              final response = await addCustomer(mobile, name);
              if (response) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Customer "$name" added successfully!',
                        style: const TextStyle(color: Colors.white)),
                    backgroundColor: Colors.green,
                  ),
                );
                await fetchSuggestions(mobile);
                Navigator.pop(context);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Failed to add customer. Please try again.'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Please enter a valid mobile number and name.'),
                  backgroundColor: Colors.orange,
                ),
              );
            }
          },
          child: const Text('Submit'),
        ),
      ],
    );
  }

  Widget buildCustomerInputFieldsforcredit(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                controller: mobileNoController,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(10),
                ],
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Search Mobile Number',
                  labelStyle: TextStyle(fontSize: 10),
                  isDense: true, // Makes the field more compact
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 8, vertical: 6), // Same padding as above
                ),
                onChanged: (value) {
                  // Clear customer name when mobile number changes
                  customerNameController.clear();

                  // Fetch suggestions based on the mobile number input
                  fetchSuggestions(value);
                },
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Customer Mobile No is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
            Expanded(
              child: TextFormField(
                enabled: false,
                controller: customerNameController,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(24),
                  FilteringTextInputFormatter.allow(RegExp(r'^[a-zA-Z0-9 ]*$')),
                ],
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Customer Name',
                  labelStyle: TextStyle(fontSize: 10),
                  isDense: true, // Makes the field more compact
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 8, vertical: 6), // Same padding as above
                ),
                validator: (value) {
                  if (isFormValid && (value == null || value.isEmpty)) {
                    return 'Customer Name is required';
                  }
                  return null;
                },
              ),
            ),
            const Padding(padding: EdgeInsets.all(5)),
          ],
        ),
        const SizedBox(height: 8.0),

        // Only show suggestions container when mobile number is not empty AND customer name is empty
        if (mobileNoController.text.isNotEmpty &&
            customerNameController.text.isEmpty)
          Container(
            height: 50,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: ListView.builder(
              itemCount: suggestions.isEmpty ? 1 : suggestions.length,
              itemBuilder: (context, index) {
                // Show suggestions if available
                if (suggestions.isNotEmpty) {
                  final suggestion = suggestions[index];
                  return ListTile(
                    title: Text(suggestion['mobileNo'] ?? 'Unknown Mobile'),
                    subtitle: Text(suggestion['name'] ?? 'Unknown Name'),
                    onTap: () {
                      onSuggestionSelected(suggestion);
                      // Set focus to next field or clear focus
                      FocusScope.of(context).unfocus();
                    },
                  );
                }

                // If no suggestions are found, show an error directly.
                return const ListTile(
                  title: Text('No customer found for this mobile number.',
                      style: TextStyle(color: Colors.red)),
                );
              },
            ),
          ),
      ],
    );
  }
  //         String whatsappApiUrl =
//             'https://backend.askeva.io/v1/message/send-message?token=226b3bc6338f9de4107cc93016924fb2868113776165b8d4b9a76914930e2fa2e47ff2906d87e0281121e425dccf62d84a6a82303c99beb2c24d0f9da7a46c1e32af25b2e74b7e42a7d17ce834c474aeb9b4abecdf454ade5fcd7519b8dd2e3893e0ac008bf50aa0d2ddc59737e381d4166d7d1e45af5cb285d388959efdc897c43af27799a56ea571830eca7cb8d5f08cf4284b28dff365fb85a2ad9d645ee0aaf8a86e8d6103150f29361e0f4556ba02cbf0149bacd06ad35fbe51d0ba630533cf73a51476c02eccc3845d13506638';
//         Map<String, dynamic> whatsappMessage = {
//           "to": "91$customerNumber",
//           "type": "template",
//           "template": {
//             "language": {"policy": "deterministic", "code": "en"},
//             "name": "whatsapp_test",
//             "components": [
//               {
//                 "type": "header",
//                 "parameters": [
//                   {
//                     "type": "image",
//                     "image": {"link": "https://yenerp.com/share/offer.jpg"}
//                   }
//                 ]
//               },
//               {
//                 "type": "body",
//                 "parameters": [
//                   {"type": "text", "text": "Customer"},
//                   {"type": "text", "text": "Bill No: $billNumber"},
//                   {"type": "text", "text": "Amount: $totalAmount"}
//                 ]
//               }
//             ]
//           }
//         };

//         var whatsappResponse = await http.post(
//           Uri.parse(whatsappApiUrl),
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: json.encode(whatsappMessage),
//         );

//         if (whatsappResponse.statusCode == 200) {
//           print('WhatsApp message sent successfully to $customerNumber');
//         } else {
//           print('Failed to send WhatsApp message: ${whatsappResponse.body}');
//         }
//       } else {
//         print('Failed to post invoice: ${response.statusCode}');
//       }
//     } catch (e) {
//       print('Error posting invoice or sending message: $e');
//     }
}
