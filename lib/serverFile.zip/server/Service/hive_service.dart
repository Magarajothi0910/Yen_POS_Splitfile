import 'dart:convert';
import 'dart:math';

import 'package:hive/hive.dart';
import 'package:intl/intl.dart';
import '../../server/Screen/serverScreen.dart' as serverscreen;
// Save Invoice to Hive
// Future<void> saveInvoiceToHive(Map<String, dynamic> jsonData) async {
//   try {
//     var invoiceBox = await Hive.openBox('invoicesBox');
//     await invoiceBox.add(jsonData);
//     print('Invoice saved to Hive: $jsonData');

//     // Print the contents of the box to verify
//     for (int i = 0; i < invoiceBox.length; i++) {
//       print('Saved invoice at $i: ${invoiceBox.getAt(i)}');
//     }
//   } catch (e) {
//     print('Error saving invoice to Hive: $e');
//   }
// }

void saveOrderToHive(Map<String, dynamic> order) async {
  try {
    var orderBox = await Hive.openBox(
        'ordersBox'); // Ensure you use 'ordersBox' consistently

    // Convert date fields to strings before saving if necessary
    if (order.containsKey('date') && order['date'] is DateTime) {
      order['date'] = DateFormat('dd-MM-yyyy').format(order['date']);
    }

    // Save the order as a JSON-encoded string
    await orderBox.add(jsonEncode(order));
    print('Order saved in Hive: ${order['hiveOrderId']}');
  } catch (e) {
    print('Error saving order to Hive: $e');
  }
}

// Save Pre-Invoice to Hive
Future<void> savePreInvoiceToHive(Map<String, dynamic> jsonData) async {
  try {
    var preInvoiceBox = await Hive.openBox('preInvoicesBox');
    await preInvoiceBox.add(jsonData);
    print('Pre-invoice saved to Hive: $jsonData');

    // Print the contents of the box to verify
    for (int i = 0; i < preInvoiceBox.length; i++) {
      print('Saved pre-invoice at $i: ${preInvoiceBox.getAt(i)}');
    }
  } catch (e) {
    print('Error saving pre-invoice to Hive: $e');
  }
}

// Load Invoices from Hive
Future<List<Map<String, dynamic>>> loadInvoicesFromHive() async {
  try {
    var invoiceBox = await Hive.openBox('invoicesBox');
    List<Map<String, dynamic>> invoices = [];
    for (int i = 0; i < invoiceBox.length; i++) {
      invoices.add(Map<String, dynamic>.from(invoiceBox.getAt(i) as Map));
    }
    print('Invoices in Hive: $invoices');
    return invoices;
  } catch (e) {
    print('Error loading invoices from Hive: $e');
    return [];
  }
}

Future<List<Map<String, dynamic>>> loadOrdersFromHive() async {
  try {
    var orderBox = Hive.box('ordersBox');
    List<Map<String, dynamic>> orders = [];
    for (int i = 0; i < orderBox.length; i++) {
      var orderData = orderBox.getAt(i);
      // If stored data is a JSON string, decode it
      if (orderData is String) {
        orderData = jsonDecode(orderData) as Map<String, dynamic>;
      }
      orders.add(Map<String, dynamic>.from(orderData));
    }
    print('Orders in Hive: $orders');
    return orders;
  } catch (e) {
    print('Error loading orders from Hive: $e');
    return [];
  }
}

// Load Pre-Invoices from Hive
Future<List<Map<String, dynamic>>> loadPreInvoicesFromHive() async {
  try {
    var preInvoiceBox = await Hive.openBox('preInvoicesBox');
    List<Map<String, dynamic>> preInvoices = [];
    for (int i = 0; i < preInvoiceBox.length; i++) {
      preInvoices.add(Map<String, dynamic>.from(preInvoiceBox.getAt(i) as Map));
    }
    print('Pre-invoices in Hive: $preInvoices');
    return preInvoices;
  } catch (e) {
    print('Error loading pre-invoices from Hive: $e');
    return [];
  }
}

Future<void> saveTransferToHive(Map<String, dynamic> transferData) async {
  try {
    var transferBox = await Hive.openBox('seatTransfers');
    await transferBox.add(transferData);
    print('Transfer saved to Hive: $transferData');
  } catch (e) {
    print('Error saving transfer to Hive: $e');
  }
}

/// Delete an order from Hive by hiveOrderId
Future<void> deleteOrderFromHive(String hiveOrderId) async {
  var orderBox = Hive.box('ordersBox');
  for (int i = 0; i < orderBox.length; i++) {
    var orderData = orderBox.getAt(i);
    if (orderData is String) {
      orderData = jsonDecode(orderData) as Map<String, dynamic>;
    }
    if (orderData['hiveOrderId'] == hiveOrderId) {
      await orderBox.deleteAt(i);
      print('Deleted order from Hive: $hiveOrderId');
      break;
    }
  }
}

// Save invoice using the 'invoices' box
Future<void> saveInvoiceToHive(Map<String, dynamic> invoice) async {
  var invoiceBox = Hive.box('invoices');
  await invoiceBox.add(invoice);
  print('Invoice stored in Hive with ID: ${invoice['invoiceId']}');
}

/// Save POS invoice using the 'posInvoiceBox'
Future<void> savePosInvoiceToHive(Map<String, dynamic> posInvoice) async {
  var posInvoiceBox = Hive.box('posInvoiceBox');
  await posInvoiceBox.add(posInvoice);
  print("POS Invoice saved: ${posInvoice['hiveInvoiceId']}");
}

/// Save POS sale order using the 'saleOrderBox'
// Future<void> savePosSaleOrderToHive(Map<String, dynamic> saleOrder) async {
//   print("savePosInvoiceToHive 3");
//   var saleOrderBox = await Hive.openBox('saleOrderBox');
//   final String shortId = generateShortHiveInvoiceId();
//   saleOrder['hiveId'] = shortId;
//   await saleOrderBox.put(shortId, saleOrder);
//   print("POS salesOrder saved: $saleOrder");
// }

Future<void> savePosSaleOrderToHive(
    Map<String, dynamic> saleOrder, Box saleOrderBox) async {
  print("savePosSaleOrderToHive");
  final String shortId = generateShortHiveInvoiceId();
  saleOrder['hiveId'] = shortId;
  await saleOrderBox.put(shortId, saleOrder);
  print("POS salesOrder saved: $saleOrder");
}

Future<Map<String, dynamic>?> _getSaleOrderFromHive(String saleOrderNo) async {
  final saleOrderBox = await Hive.openBox('saleOrderBox');
  for (var key in saleOrderBox.keys) {
    final order = saleOrderBox.get(key) as Map<String, dynamic>?;
    if (order?['saleOrderNo'] == saleOrderNo) {
      return order;
    }
  }
  return null;
}

String generateShortHiveInvoiceId() {
  final random = Random();
  final timestamp = DateTime.now()
      .millisecondsSinceEpoch
      .toString()
      .substring(6); // Shortened timestamp
  const characters =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; // Alphanumeric characters
  final randomId =
      List<int>.generate(6, (_) => random.nextInt(characters.length))
          .map((index) => characters[index])
          .join(); // Generate a 6-character random ID
  return '$timestamp-$randomId'; // Combines timestamp and random alphanumeric ID
} // Load Pre-Invoices from Hive

/// Save printer details to Hive using the 'printerData' box
Future<void> savePrinterDetailsToHive(Map<String, dynamic> data) async {
  var printerBox = Hive.box('printerData');
  final printerName = data['name'];
  await printerBox.put(printerName, data);
  print(
      'Printer details stored in Hive for printer: $printerName, data: $data');
}

/// Save hold order using the 'holdOrders' box
Future<void> saveHoldOrderToHive(Map<String, dynamic> data) async {
  var holdOrdersBox = Hive.box('holdOrders');
  await holdOrdersBox.add(data);
  print('Hold order saved to Hive: $data');
}

/// Save sales approval order using the 'salesApprovalOrder' box
Future<void> saveSalesApprovalOrderToHive(Map<String, dynamic> data) async {
  var salesApprovalOrdersBox = Hive.box('salesApprovalOrder');
  await salesApprovalOrdersBox.add(data);
  print('Sales approval order saved to Hive: $data');
}

/// Save modify order using the 'saleOrderModifyOrders' box
Future<void> saveModifyOrderToHive(Map<String, dynamic> data) async {
  var modifyOrdersBox = Hive.box('saleOrderModifyOrders');
  await modifyOrdersBox.add(data);
  print('Modified order saved to Hive: $data');
}
