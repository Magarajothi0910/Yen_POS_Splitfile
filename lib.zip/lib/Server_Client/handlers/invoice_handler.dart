import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:yenpos/Sale_order/Print_Receipt/invoicePrint.dart';
import 'package:yenpos/Server_Client/handlers/Token_service.dart';
import 'package:yenpos/Server_Client/hive_service.dart';
import 'package:yenpos/Server_Client/sendDataToClients.dart';
import 'package:yenpos/Server_Client/stockupdateService.dart';
import 'package:yenpos/Server_Client/sync_service.dart';
import 'package:yenpos/invoice_pay_and_print_page.dart/services/invoice_service.dart';
import 'package:yenpos/invoice_pay_and_print_page.dart/widgets/invoiceNumberGenerator.dart';

final SyncService _syncService = SyncService();
final InvoiceService _invoiceService = InvoiceService();

/// Helper: Returns how much stock to deduct based on UOM
double getStockDeductionAmount({
  required String uom,
  required double weight,
  required double qty,
}) {
  final lower = uom.toLowerCase().trim();
  if (lower == 'kgs' ||
      lower == 'kg' ||
      lower == 'kilogram' ||
      lower == 'kilograms') {
    return weight; // Use actual weight sold
  } else if (lower == 'grams' || lower == 'g') {
    return weight / 1000.0; // Convert grams → kg
  } else {
    return qty; // Pcs, Box, etc.
  }
}

SalesInvoiceReceiptPrinter printer = SalesInvoiceReceiptPrinter();
Future<void> handleInvoice(
  Map<String, dynamic> data,
  Set<WebSocketChannel> clients,
) async {
  try {
    print("handleInvoice called with data: ${jsonEncode(data)}");

    final salesOrderRaw = data['salesOrderId'];
    if (salesOrderRaw is! Map<String, dynamic>) {
      print("Invalid salesOrderId format");
      return;
    }

    print("salesOrderRaw extracted successfully.");

    final branchName = salesOrderRaw['branchName']?.toString();
    final aliasName = salesOrderRaw['aliasName']?.toString() ?? 'AR';
    final status = salesOrderRaw['status'] ?? 'Unknown';

    print(
      "Invoice details — Branch: $branchName | Alias: $aliasName | Status: $status",
    );

    // Generate Hive Invoice ID
    if (branchName != null) {
      final invoiceNumberGenerator = InvoiceNumberGenerator();
      //String hiveInvoiceId = _invoiceService.generateShortHiveInvoiceId();
      final hiveInvoiceId = await invoiceNumberGenerator
          .generateInvoiceNumber();
      salesOrderRaw['invoiceNo'] = hiveInvoiceId;
      print("Generated Hive Invoice ID: $hiveInvoiceId");
    }

    // Save invoice locally
    print("Saving invoice to local Hive...");
    await savePosInvoiceToHive(data);
    print("Invoice saved locally.");

    // STOCK DECREASE — FIXED FOR WEIGHTED ITEMS (Kgs)
    try {
      print("Processing stock decrease...");

      // Extract lists safely
      final List<dynamic> varianceCodesRaw =
          salesOrderRaw['varianceitemCode'] is List
          ? List.from(salesOrderRaw['varianceitemCode'])
          : [salesOrderRaw['varianceitemCode']];

      final List<dynamic> varianceNamesRaw =
          salesOrderRaw['varianceName'] is List
          ? List.from(salesOrderRaw['varianceName'])
          : [salesOrderRaw['varianceName']];

      final List<dynamic> qtyRaw = salesOrderRaw['qty'] is List
          ? List.from(salesOrderRaw['qty'])
          : [salesOrderRaw['qty']];

      final List<dynamic> weightRaw = salesOrderRaw['weight'] is List
          ? List.from(salesOrderRaw['weight'])
          : [salesOrderRaw['weight'] ?? 0.0];

      final List<dynamic> uomRaw = salesOrderRaw['uom'] is List
          ? List.from(salesOrderRaw['uom'])
          : [salesOrderRaw['uom'] ?? 'Pcs'];

      final int maxItems = [
        varianceCodesRaw.length,
        varianceNamesRaw.length,
        qtyRaw.length,
        weightRaw.length,
        uomRaw.length,
      ].reduce((a, b) => a > b ? a : b);

      List<String> varianceCodes = [];
      List<String> varianceNames = [];
      List<double> deductionAmounts = [];

      for (int i = 0; i < maxItems; i++) {
        final code = (i < varianceCodesRaw.length)
            ? varianceCodesRaw[i]?.toString().trim()
            : null;
        final name = (i < varianceNamesRaw.length)
            ? varianceNamesRaw[i]?.toString().trim()
            : null;
        final qtyVal = (i < qtyRaw.length) ? qtyRaw[i] : 1.0;
        final weightVal = (i < weightRaw.length) ? weightRaw[i] : 0.0;
        final uomVal = (i < uomRaw.length)
            ? uomRaw[i]?.toString() ?? 'Pcs'
            : 'Pcs';

        if (code == null || code.isEmpty || name == null || name.isEmpty) {
          print("Skipping invalid item at index $i");
          continue;
        }

        double qty = 0.0;
        if (qtyVal is num)
          qty = qtyVal.toDouble();
        else if (qtyVal is String)
          qty = double.tryParse(qtyVal) ?? 0.0;

        double weight = 0.0;
        if (weightVal is num)
          weight = weightVal.toDouble();
        else if (weightVal is String)
          weight = double.tryParse(weightVal) ?? 0.0;

        final deduction = getStockDeductionAmount(
          uom: uomVal,
          weight: weight,
          qty: qty,
        );

        if (deduction <= 0) {
          print("Zero deduction for $name → skipped");
          continue;
        }

        varianceCodes.add(code);
        varianceNames.add(name);
        deductionAmounts.add(deduction);

        print(
          "Will decrease: $name ($code) by $deduction $uomVal ${weight > 0 ? '(weight: $weight kg)' : '(qty: $qty)'}",
        );
      }

      if (varianceCodes.isNotEmpty) {
        print("Decreasing stock for ${varianceCodes.length} items...");
        await decreaseLocalHiveStock(
          clients: clients,
          branchAlias: aliasName,
          varianceCodes: varianceCodes,
          varianceNames: varianceNames,
          stockDeductionAmounts: deductionAmounts, // Now double!
          uoms: uomRaw.map((e) => e.toString()).toList(),
        );
        print("Stock successfully decreased (weighted items supported)");
      } else {
        print("No valid items to decrease stock");
      }
    } catch (e, st) {
      print("Error in stock decrease: $e\n$st");
    }

    // Notify all clients
    final clientData = {'action': 'invoiceGenerated', 'invoice': data};
    sendDataToClients(clientData, clients);
    print("WebSocket clients notified about invoice generation.");

    // Sync to server
    print("Sending invoice data to API...");
    bool success = await _syncService.postInvoiceOrder({
      "data": [salesOrderRaw],
    });

    if (success) {
      print("Invoice successfully synced with API.");
      printer.updateReceiptData(salesOrderRaw);
      print("Invoice successfully Printed.");
    } else {
      print("Invoice sync failed, will retry later.");
    }
  } catch (e, stacktrace) {
    print("Exception in handleInvoice: $e\n$stacktrace");
  }
}
