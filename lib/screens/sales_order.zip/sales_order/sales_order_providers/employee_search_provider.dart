import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../../hiveGlobal/hiveProvider.dart';

class EmployeeSearchProvider extends ChangeNotifier {
  List<Map<String, dynamic>> suggestions = [];
  final HiveProvider hiveProvider;
  final String boxName;
  TextEditingController bankNameController = TextEditingController();

  EmployeeSearchProvider(this.hiveProvider, {required this.boxName});

  Future<void> fetchSuggestions(String query) async {
    print("Starting fetchSuggestions with query: $query");

    // Early exit if query is empty
    if (query.isEmpty) {
      print("Query is empty. Clearing suggestions.");
      suggestions = [];
      notifyListeners();
      return;
    }

    try {
      // Load cached data from Hive first
      final cachedData = hiveProvider.data[boxName];
      print("Loaded cached data from Hive: $cachedData");

      // Check if cached data contains banks
      final banks = cachedData?['items'];
      if (banks is List) {
        print("Filtering cached banks by name.");
        suggestions = banks
            .where((bank) =>
                bank['bankName']?.toLowerCase().contains(query.toLowerCase()) ??
                false)
            .map((bank) => {
                  'bankName': bank['bankName']?.toString() ?? '',
                })
            .toList();
        print("Filtered suggestions: $suggestions");
      } else {
        print("No cached banks found.");
        suggestions = [];
      }

      notifyListeners();
    } catch (e) {
      print("Error fetching suggestions: $e");
      suggestions = [];
      notifyListeners();
    }
  }

  Future<bool> addBank(String bankName) async {
    try {
      // Add new bank to remote API
      final response = await http.post(
        Uri.parse('https://yenerp.com/masterapi/bankmasters/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'bankName': bankName,
          'status': '1',
        }),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        print('Bank added: ${response.body}');
        final newBank = {
          'bankId': response.body,
          'bankName': bankName,
          'status': '1',
        };

        // Ensure the data structure exists
        hiveProvider.data[boxName] ??= {'banks': []};

        if (hiveProvider.data[boxName]!['banks'] == null) {
          hiveProvider.data[boxName]!['banks'] = [];
        }

        // Add the new bank to the cached list
        (hiveProvider.data[boxName]!['banks'] as List).add(newBank);

        // Persist the updated data to Hive
        await hiveProvider.addData(boxName, newBank);
        print("Bank added to Hive: $newBank");

        // Update suggestions with the new bank
        suggestions.add({
          'bankName': bankName,
        });

        notifyListeners();
        return true;
      } else {
        print("Failed to add bank to server");
        return false;
      }
    } catch (e) {
      print("Error adding bank: $e");
      return false;
    }
  }
}
