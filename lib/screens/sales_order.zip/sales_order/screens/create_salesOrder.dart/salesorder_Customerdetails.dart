import 'dart:io';

import 'package:hive/hive.dart';
import 'package:intl/intl.dart';
// import 'package:yenposapp/screens/sale_order_screen.dart';
import 'package:flutter/material.dart';
// import 'package:outletmanager/widgets/common_layout.dart';
import 'package:provider/provider.dart';

import '../../../../Global/Audio Player/audio_provider.dart';
import '../../../../Global/Audio Player/audio_screen.dart';
import '../../../../Global/custom_button_reuse.dart';

import '../../../../Global/image-picker-widget.dart';
import '../../../../Global/order_model.dart';
import '../../../../Global/photoScreen.dart';
import '../../../../Global/scaffold_global.dart';
import '../../../../Global/voice_recording.dart';
import '../../sales_order_providers/cartProvider.dart';
import '../../sales_order_providers/cart_selection_provider.dart';
import '../../sales_order_providers/customerScreen_provider.dart';
import '../../sales_order_providers/detailsProvider.dart';
import '../../sales_order_providers/photoProvider.dart';
import '../../globals.dart' as globals;
import '../all_orders_page/all_orders.dart';
import '../all_orders_page/services/get_sales_order_service.dart';
import 'credit_customer_dropdown.dart';
import 'employee_selection.dart';
import 'mobilenumber_search.dart';
import 'models/held_order_model.dart';

class CustomerDetails extends StatefulWidget {
  const CustomerDetails({super.key});

  @override
  _CustomerDetailsState createState() => _CustomerDetailsState();
}

class _CustomerDetailsState extends State<CustomerDetails> {
  final _formKey = GlobalKey<FormState>();
  bool _isFormValid = false;
  bool isRequestInProgress = false; // Added variable definition
  List<OrderData> heldOrders = [];
  String recordedFilePath = '';
  File? _pickedImage1;
  File? _pickedImage2;
  String _customerType = 'Normal';
  int? _selectedRadioValue = 0; // The selected radio button value
  // String? audioPlayerId;
  String? audioPlayerId;
  String? photoScreenId;
  String? holdId;
  List<Map<String, String>> suggestions = [];
  bool isSuggestionsVisible = false;
  // This function is triggered when both images are selected

  // void _onImagesSelected(File? image1, File? image2) {
  //   setState(() {
  //     _pickedImage1 = image1;
  //     _pickedImage2 = image2;
  //   });
  // }
  void _loadStoredImages() {
    final box = Hive.box('imagesBox');
    String? imagePath1 = box.get('image1');
    String? imagePath2 = box.get('image2');
    print('img1$imagePath1');
    print('img2$imagePath2');
    setState(() {
      _pickedImage1 = imagePath1 != null ? File(imagePath1) : null;

      _pickedImage2 = imagePath2 != null ? File(imagePath2) : null;
    });
  }

  bool _validateOrderDetails() {
    final customerScreenProvider =
        Provider.of<CustomerScreenProvider>(context, listen: false);
    final detailsProvider =
        Provider.of<DetailsProvider>(context, listen: false);

    String selectedSalesperson =
        customerScreenProvider.searchController.text.trim();
    String enteredMobileNumber =
        customerScreenProvider.mobileNoController.text.trim();

    if (!detailsProvider.employeeNames.contains(selectedSalesperson)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Add a valid salesperson.')),
      );
      return false;
    }

    if (enteredMobileNumber.isEmpty ||
        enteredMobileNumber.length != 10 ||
        !RegExp(r'^\d{10}$').hasMatch(enteredMobileNumber)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Please enter a valid 10-digit mobile number.')),
      );
      return false;
    }

    bool hasInvalidBoxItems = globals.cartItems
        .any((item) => item.isBoxItem == 'yes' && item.quantity <= 0);
    if (hasInvalidBoxItems) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Enter valid box quantity for selected items.')),
      );
      return false;
    }

    return true;
  }

  bool _requiresApproval() {
    return globals.cartItems.any((item) => (item.itemWiseDiscount ?? 0) > 7.0);
  }

  void _onImagesSelected(File? image1, File? image2) async {
    if (image1 != null && image2 != null) {
      final box = Hive.box('imagesBox');
      await box.put('image1', image1.path);
      await box.put('image2', image2.path);
      setState(() {
        _pickedImage1 = image1;
        _pickedImage2 = image2;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _loadStoredImages();
  }

  void handleRecordingComplete(String path) {
    setState(() {
      recordedFilePath = path;
    });
    print('Recording completed. File path: $path');
  }

  // void handleRecordingComplete(String path) {
  //   // Store the audio file path in Hive after recording
  //   saveRecordingToHive(path);
  // }

  // Future<void> saveRecordingToHive(String path) async {
  //   var box = await Hive.openBox('recordings');
  //   await box.add(path); // Store the file path in Hive
  //   print("Recording saved at: $path");
  // }

  void _validateForm() {
    setState(() {
      _isFormValid = _formKey.currentState?.validate() ?? false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);
    final detailsProvider = Provider.of<DetailsProvider>(context);
    final customerScreenProvider = Provider.of<CustomerScreenProvider>(context);
    final apiSalesprovider = Provider.of<ApiServiceSalesOrderProvider>(context);
    final cartSelectionProvider =
        Provider.of<CartSelectionProvider>(context, listen: false);
    final audioprovider = Provider.of<AudioProvider>(context);
    final photoProvider = Provider.of<PhotoProvider>(context, listen: false);
    bool isRequestInProgress = false;

    print('audioPlayerId$audioPlayerId');

    return WillPopScope(
      onWillPop: () async {
        // Show confirmation dialog when the back button is pressed
        bool shouldExit = await showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Confirmation'),
              content: const Text('Do you want to go back?'),
              actions: <Widget>[
                TextButton(
                  onPressed: () {
                    Navigator.of(context)
                        .pop(false); // User does not want to exit
                  },
                  child: const Text('No'),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(true); // User wants to exit
                  },
                  child: const Text('Yes'),
                ),
              ],
            );
          },
        );

        // If the user chooses to exit, close the app
        if (shouldExit == true) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AllOrdersPage(),
            ),
          );
        }
        // If the user dismisses the dialog, default behavior is not to exit
        return shouldExit;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
          title: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  //mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Radio<int>(
                      value: 0,
                      groupValue: _selectedRadioValue,
                      onChanged: (int? value) {
                        setState(() {
                          _selectedRadioValue = value;
                          _customerType = 'Normal';
                          customerScreenProvider.clearControllers();
                        });
                      },
                    ),
                    // const SizedBox(height: 5),
                    // Text(
                    //   'Customer',
                    //   style:
                    //       TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                    // ),
                    Transform.translate(
                      offset:
                          const Offset(0, 0), // Move the text up by 8 pixels
                      child: Text(
                        'Customer',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(
                      width: 19,
                    ),
                  ],
                ),
                const SizedBox(width: 10),
                // Radio button for "Other Option"
                Column(
                  children: [
                    Transform.translate(
                      offset: const Offset(0, -8),
                      child: TextButton.icon(
                        icon: const Icon(
                          Icons.assignment,
                          color: Colors.red,
                        ),
                        label: const Text(
                          "Order Status",
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: Colors.red,
                          ),
                        ),
                        onPressed: () => _showDiscountStatus(context),
                      ),
                    ),
                  ],
                ),

                // Transform.translate(
                //   offset: const Offset(0, -8),
                //   child: TextButton.icon(
                //     // icon: const Icon(Icons.assignment),
                //     icon: const Icon(
                //       Icons.assignment,
                //       color: Colors.red, // Set the color to yellow
                //     ),
                //     label: const Text(
                //       "Held Orders",
                //       style: TextStyle(
                //           fontSize: 11,
                //           fontWeight: FontWeight.w600,
                //           color: Colors.red),
                //     ),

                //     onPressed: () {
                //       showModalBottomSheet(
                //         context: context,
                //         builder: (BuildContext context) {
                //           return FutureBuilder<List<Map<String, dynamic>>>(
                //             future:
                //                 customerScreenProvider.fetchHolderFromHive(),
                //             builder: (context, snapshot) {
                //               if (snapshot.connectionState ==
                //                   ConnectionState.waiting) {
                //                 return const Center(
                //                   child: CircularProgressIndicator(),
                //                 );
                //               } else if (snapshot.hasError) {
                //                 return Center(
                //                   child: Text('Error: ${snapshot.error}'),
                //                 );
                //               } else if (!snapshot.hasData ||
                //                   snapshot.data!.isEmpty) {
                //                 return const Center(
                //                   child: Text('No held orders'),
                //                 );
                //               } else {
                //                 final orders = snapshot.data!;
                //                 // Print all details to the console
                //                 for (var order in orders) {
                //                   print("Order detailshollld: $order");
                //                 }
                //                 return ListView.builder(
                //                   itemCount: orders.length,
                //                   itemBuilder: (context, index) {
                //                     final order = orders[index];
                //                     return ListTile(
                //                       title: Text(
                //                           'Customer: ${order['customerName']}'),
                //                       subtitle: Text(
                //                         'Delivery Date: ${order['deliveryDate']}\n'
                //                         'Delivery Time: ${order['deliveryTime']}\n'
                //                         'Event: ${order['event']}',
                //                       ),
                //                       trailing: IconButton(
                //                         icon: const Icon(Icons.delete),
                //                         onPressed: () {
                //                           customerScreenProvider
                //                               .deleteSalesOrder(
                //                                   order['salesOrderId']);
                //                           Navigator.pop(context);
                //                         },
                //                       ),
                //                       onTap: () async {
                //                         if (isRequestInProgress)
                //                           return; // Prevent duplicate requests
                //                         setState(() {
                //                           isRequestInProgress = true;
                //                         });
                //                         try {
                //                           customerScreenProvider.dateController
                //                               .text = order['deliveryDate'];
                //                           customerScreenProvider.timeController
                //                               .text = order['deliveryTime'];
                //                           customerScreenProvider
                //                               .setSelectedEvent(order['event']);
                //                           customerScreenProvider
                //                               .setSelectedDeliveryType(
                //                                   order['deliveryType']);
                //                           customerScreenProvider
                //                               .landmarkController
                //                               .text = order['landmark'] ?? '';
                //                           customerScreenProvider
                //                               .addressController
                //                               .text = order['address'] ?? '';
                //                           customerScreenProvider
                //                               .customerNameController
                //                               .text = order['customerName'];
                //                           customerScreenProvider
                //                               .mobileNoController
                //                               .text = order['customerNumber'];
                //                           customerScreenProvider
                //                               .searchController
                //                               .text = order['employeeName'];
                //                           detailsProvider
                //                               .filteredEmployeeFirstNames
                //                               .clear();

                //                           // photoScreenId = order['salesOrderId'];
                //                           // bool arePhotosAvailable =
                //                           //     await photoProvider
                //                           //         .arePhotosAvailableForCustomId(
                //                           //             photoScreenId!);
                //                           // if (!arePhotosAvailable) {
                //                           //   photoScreenId = null;
                //                           //   print(
                //                           //       "No photos available for this custom ID.");
                //                           // }

                //                           // audioPlayerId = order['salesOrderId'];
                //                           // bool isAudioAvailable =
                //                           //     await audioprovider
                //                           //         .checkAudio(audioPlayerId!);
                //                           // if (!isAudioAvailable) {
                //                           //   audioPlayerId = null;
                //                           //   print(
                //                           //       'Audio is not available or there was an error.');
                //                           // }

                //                           // holdId = order['salesOrderId'];
                //                           List.generate(
                //                               (order['itemName'] as List)
                //                                   .length, (index) {
                //                             cartProvider.addItemToCart(
                //                               CartItem(
                //                                 varianceName:
                //                                     order['varianceName']
                //                                         [index],
                //                                 itemName: order['itemName']
                //                                     [index],
                //                                 pricePerKg: order['price']
                //                                     [index],
                //                                 tax: order['tax'][index],
                //                                 itemCode: order['itemCode']
                //                                     [index],
                //                                 uom: order['uom'][index],
                //                                 quantity: order['qty'][index],
                //                                 weight: order['weight'][index],
                //                               ),
                //                             );
                //                           });
                //                           ScaffoldMessenger.of(context)
                //                               .showSnackBar(
                //                             const SnackBar(
                //                               content: Text(
                //                                   'Order data restored to form'),
                //                             ),
                //                           );
                //                           Navigator.pop(context);
                //                         } finally {
                //                           setState(() {
                //                             isRequestInProgress = false;
                //                           });
                //                         }
                //                       },
                //                     );
                //                   },
                //                 );
                //               }
                //             },
                //           );
                //         },
                //       );
                //     },
                //   ),
                // ),

                Transform.translate(
                  offset: const Offset(0, -8),
                  child: TextButton.icon(
                    // icon: const Icon(Icons.assignment),
                    icon: const Icon(
                      Icons.assignment,
                      color: Colors.red, // Set the color to yellow
                    ),
                    label: const Text(
                      "Held Orders",
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.red),
                    ),

                    onPressed: () {
                      // ----------  call exactly as before  ----------
                      showModalBottomSheet(
                        // isScrollControlled: true, // full-height sheet
                        shape: const RoundedRectangleBorder(
                          // nice rounded top
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(16)),
                        ),
                        context: context,
                        builder: (BuildContext context) {
                          return SafeArea(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // ----------  blue header  ----------
                                Container(
                                  width: double.infinity,
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 16),
                                  decoration: const BoxDecoration(
                                    color: Color(0xff0d86ff),
                                    borderRadius: BorderRadius.vertical(
                                        top: Radius.circular(16)),
                                  ),
                                  child: const Center(
                                    child: Text(
                                      'Hold Orders Status',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 18,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ),

                                // ----------  list of orders  ----------
                                Expanded(
                                  child:
                                      FutureBuilder<List<Map<String, dynamic>>>(
                                    future: customerScreenProvider
                                        .fetchHolderFromHive(),
                                    builder: (context, snapshot) {
                                      if (snapshot.connectionState ==
                                          ConnectionState.waiting) {
                                        return const Center(
                                            child: CircularProgressIndicator());
                                      } else if (snapshot.hasError) {
                                        return Center(
                                            child: Text(
                                                'Error: ${snapshot.error}'));
                                      } else if (!snapshot.hasData ||
                                          snapshot.data!.isEmpty) {
                                        return const Center(
                                            child: Text('No held orders'));
                                      }

                                      final orders = snapshot.data!;
                                      return ListView.separated(
                                        padding: const EdgeInsets.all(16),
                                        itemCount: orders.length,
                                        separatorBuilder: (_, __) =>
                                            const SizedBox(height: 12),
                                        itemBuilder: (context, index) {
                                          final order = orders[index];

                                          return Material(
                                            elevation: 2,
                                            borderRadius:
                                                BorderRadius.circular(12),
                                            child: InkWell(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                              onTap: () {
                                                final heldOrder =
                                                    HeldOrder.fromMap(order);
                                                _restoreHeldOrderData(
                                                    context, heldOrder);
                                              },
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(16),
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    // -------- customer name -----------
                                                    Text(
                                                      'Customer: ${order['customerName'] ?? '-'}',
                                                      style: const TextStyle(
                                                        fontSize: 16,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                                    ),
                                                    const Divider(height: 20),

                                                    // -------- delivery date ----------
                                                    Row(
                                                      children: [
                                                        const Icon(
                                                            Icons
                                                                .calendar_today,
                                                            size: 18),
                                                        const SizedBox(
                                                            width: 8),
                                                        Text(
                                                            'Delivery: ${order['deliveryDate']}'),
                                                      ],
                                                    ),
                                                    const SizedBox(height: 6),

                                                    // -------- delivery time ----------
                                                    Row(
                                                      children: [
                                                        const Icon(
                                                            Icons.access_time,
                                                            size: 18),
                                                        const SizedBox(
                                                            width: 8),
                                                        Text(
                                                            'Time: ${order['deliveryTime']}'),
                                                      ],
                                                    ),
                                                    const SizedBox(height: 6),

                                                    // -------- status + pill ----------
                                                    Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        const Icon(Icons.info,
                                                            size: 18),
                                                        const SizedBox(
                                                            width: 8),
                                                        Expanded(
                                                          child: Text(
                                                            'Status: ${order['status'] ?? 'Pending'}',
                                                          ),
                                                        ),
                                                        Container(
                                                          padding:
                                                              const EdgeInsets
                                                                  .symmetric(
                                                                  horizontal:
                                                                      12,
                                                                  vertical: 6),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors.orange
                                                                .shade100,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50),
                                                          ),
                                                          child: const Text(
                                                            'Held Order',
                                                            style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    const SizedBox(height: 12),

                                                    // -------- delete button ----------
                                                    Align(
                                                      alignment:
                                                          Alignment.centerRight,
                                                      child: IconButton(
                                                        icon: const Icon(Icons
                                                            .delete_outline),
                                                        splashRadius: 20,
                                                        color:
                                                            Colors.red.shade400,
                                                        tooltip:
                                                            'Delete held order',
                                                        onPressed: () {
                                                          customerScreenProvider
                                                              .deleteSalesOrder(
                                                            order[
                                                                'salesOrderId'],
                                                          );
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
                Transform.translate(
                  offset: const Offset(0, -8),
                  child: IconButton(
                    icon: Icon(
                      Icons.delete_outline,
                      color: Colors.blue, // Set the color to blue
                    ),
                    iconSize: 28,
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return Dialog(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                  12), // Reduced border radius
                            ),
                            elevation: 10,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.1,
                              padding:
                                  const EdgeInsets.all(16), // Reduced padding
                              decoration: BoxDecoration(
                                color: Colors
                                    .blueAccent, // Simplified gradient to a single color
                                borderRadius: BorderRadius.circular(
                                    12), // Reduced border radius
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.warning_amber_rounded,
                                    size: 50, // Reduced size
                                    color: Colors.white,
                                  ),
                                  const SizedBox(height: 16),
                                  const Text(
                                    "Are you sure?",
                                    style: TextStyle(
                                      fontSize: 20, // Smaller font size
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  const Text(
                                    "This action will clear all data and cannot be undone.",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 14, // Smaller font size
                                      color: Colors.white70,
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      ElevatedButton(
                                        onPressed: () {
                                          customerScreenProvider
                                              .clearControllers();
                                          audioPlayerId = null;
                                          photoScreenId = null;
                                          Navigator.of(context).pop();
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor:
                                              Colors.white, // Simplified color
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                8), // Reduced border radius
                                          ),
                                        ),
                                        child: const Text("Clear"),
                                      ),
                                      ElevatedButton(
                                        onPressed: () =>
                                            Navigator.of(context).pop(),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor:
                                              Colors.white, // Simplified color
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                8), // Reduced border radius
                                          ),
                                        ),
                                        child: const Text("Cancel"),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        body: Center(
          child: SizedBox(
            height: double.infinity,
            child: SingleChildScrollView(
              padding: EdgeInsets.zero,
              child: Form(
                key: _formKey,
                // onChanged: _validateForm,
                child: Column(
                  children: [
                    const SizedBox(height: 10),
                    CustomerSearchDropdown(),
                    // Row for Date and Time
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        const Padding(padding: EdgeInsets.all(5)),
                        Expanded(
                          child: Container(
                            child: TextFormField(
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              controller: customerScreenProvider.dateController,
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.event),
                                border: OutlineInputBorder(),
                                labelText: "Delivery Date",
                                hintText: "Choose a date",
                              ),
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                              ),
                              readOnly: true,
                              onTap: () async {
                                DateTime now = DateTime.now();

                                // Custom animated date picker
                                showGeneralDialog(
                                  context: context,
                                  barrierDismissible: true,
                                  barrierLabel: "Date Picker",
                                  pageBuilder:
                                      (context, animation1, animation2) {
                                    return Container(); // Not used
                                  },
                                  transitionBuilder: (context, a1, a2, widget) {
                                    return ScaleTransition(
                                      scale: Tween<double>(begin: 0.5, end: 1.0)
                                          .animate(a1),
                                      child: FadeTransition(
                                        opacity:
                                            Tween<double>(begin: 0.5, end: 1.0)
                                                .animate(a1),
                                        child: Dialog(
                                          backgroundColor: Colors.transparent,
                                          elevation: 0,
                                          child: Container(
                                            width: double.infinity,
                                            constraints:
                                                BoxConstraints(maxWidth: 350),
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.blue
                                                      .withOpacity(0.2),
                                                  blurRadius: 20,
                                                  spreadRadius: 5,
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  padding: EdgeInsets.all(16),
                                                  decoration: BoxDecoration(
                                                    color: Colors.blue[700],
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topLeft:
                                                          Radius.circular(20),
                                                      topRight:
                                                          Radius.circular(20),
                                                    ),
                                                  ),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Text(
                                                        "Choose Delivery Date",
                                                        style: TextStyle(
                                                          fontSize: 18,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                      Icon(
                                                        Icons.calendar_today,
                                                        color: Colors.white,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  height: 300,
                                                  child: Theme(
                                                    data: ThemeData(
                                                      colorScheme:
                                                          ColorScheme.light(
                                                        primary:
                                                            Colors.blue[700]!,
                                                        onPrimary: Colors.white,
                                                        onSurface: Colors.black,
                                                      ),
                                                    ),
                                                    child: CalendarDatePicker(
                                                      initialDate:
                                                          DateTime.now(),
                                                      firstDate: DateTime.now(),
                                                      lastDate: now.add(
                                                          const Duration(
                                                              days: 180)),
                                                      onDateChanged: (date) {
                                                        // String formattedDate =
                                                        //     DateFormat(
                                                        //             'dd-MM-yyyy')
                                                        //         .format(date);
                                                        // customerScreenProvider
                                                        //         .dateController
                                                        //         .text =
                                                        //     formattedDate;
                                                        String formattedDate =
                                                            DateFormat(
                                                                    'dd-MM-yyyy')
                                                                .format(date);
                                                        // Use provider method to update and notify
                                                        customerScreenProvider
                                                            .updateDate(
                                                                formattedDate);
                                                        Navigator.of(context)
                                                            .pop();
                                                      },
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  padding: EdgeInsets.all(16),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      TextButton(
                                                        onPressed: () {
                                                          Navigator.of(context)
                                                              .pop();
                                                        },
                                                        child: Text(
                                                          "Cancel",
                                                          style: TextStyle(
                                                            color: Colors
                                                                .grey[600],
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                  transitionDuration:
                                      Duration(milliseconds: 300),
                                );
                              },
                              validator: (value) {
                                if (_isFormValid &&
                                    (value == null || value.isEmpty)) {
                                  return 'Delivery Date is required';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),

                        const SizedBox(width: 16),
                        // Expanded(
                        //   child: TextFormField(
                        //     autovalidateMode:
                        //         AutovalidateMode.onUserInteraction,
                        //     controller: customerScreenProvider.timeController,
                        //     decoration: const InputDecoration(
                        //       border: OutlineInputBorder(),
                        //       labelText: 'Delivery Time',
                        //       labelStyle: TextStyle(fontSize: 14),
                        //       isDense: false, // Makes the field more compact
                        //       contentPadding: EdgeInsets.symmetric(
                        //           horizontal: 14, vertical: 8),
                        //     ),
                        //     style: TextStyle(fontSize: 14),
                        //     onTap: () async {
                        //       DateTime now = DateTime.now();
                        //       TimeOfDay time = TimeOfDay.now();
                        //       DateTime selectedDate = DateFormat('dd-MM-yyyy')
                        //           .parse(customerScreenProvider
                        //               .dateController.text);
                        //       bool isToday = selectedDate.year == now.year &&
                        //           selectedDate.month == now.month &&
                        //           selectedDate.day == now.day;
                        //       FocusScope.of(context).requestFocus(FocusNode());

                        //       // Show the time picker directly without any custom header
                        //       TimeOfDay? pickedTime = await showTimePicker(
                        //         context: context,
                        //         initialTime: isToday
                        //             ? TimeOfDay.fromDateTime(
                        //                 now.add(const Duration(minutes: 1)))
                        //             : const TimeOfDay(hour: 0, minute: 0),
                        //         builder: (context, child) {
                        //           return Theme(
                        //             data: ThemeData.light().copyWith(
                        //               colorScheme: ColorScheme.light(
                        //                 primary: Colors.blue[700]!,
                        //                 onPrimary: Colors.white,
                        //                 surface: Colors.white,
                        //                 onSurface: Colors.black,
                        //               ),
                        //               timePickerTheme: TimePickerThemeData(
                        //                 backgroundColor: Colors.white,
                        //                 dialBackgroundColor: Colors.blue[50],
                        //                 dialHandColor: Colors.blue[700],
                        //                 hourMinuteTextColor: Colors.blue[900],
                        //                 hourMinuteColor: Colors.blue[100],
                        //                 shape: RoundedRectangleBorder(
                        //                   borderRadius:
                        //                       BorderRadius.circular(15),
                        //                 ),
                        //               ),
                        //               dialogBackgroundColor: Colors.white,
                        //             ),
                        //             child: child!,
                        //           );
                        //         },
                        //       );

                        //       if (pickedTime != null) {
                        //         if (isToday &&
                        //             (pickedTime.hour < time.hour ||
                        //                 (pickedTime.hour == time.hour &&
                        //                     pickedTime.minute <=
                        //                         time.minute))) {
                        //           ScaffoldMessenger.of(context).showSnackBar(
                        //             const SnackBar(
                        //               content: Text(
                        //                   'Delivery time must be in the future'),
                        //             ),
                        //           );
                        //         } else {
                        //           customerScreenProvider.timeController.text =
                        //               pickedTime.format(context);
                        //         }
                        //       }
                        //     },
                        //     validator: (value) {
                        //       if (_isFormValid &&
                        //           (value == null || value.isEmpty)) {
                        //         return 'Delivery Time is required';
                        //       }
                        //       return null;
                        //     },
                        //   ),
                        // ),

                        Expanded(
                          child: TextFormField(
                            autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                            controller: customerScreenProvider.timeController,
                            decoration: InputDecoration(
                              border: const OutlineInputBorder(),
                              labelText: 'Delivery Time',
                              labelStyle: const TextStyle(fontSize: 14),
                              isDense: false,
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                              // Grey out the field if no date is selected
                              enabled: customerScreenProvider
                                  .dateController.text.isNotEmpty,
                            ),
                            style: TextStyle(
                              fontSize: 14,
                              color: customerScreenProvider
                                      .dateController.text.isNotEmpty
                                  ? Colors.black
                                  : Colors
                                      .grey, // Adjust text color when disabled
                            ),
                            readOnly: true, // Prevent manual input
                            onTap: () async {
                              // Check if delivery date is not selected
                              if (customerScreenProvider
                                  .dateController.text.isEmpty) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                        'Please select a delivery date first'),
                                    duration: Duration(seconds: 2),
                                  ),
                                );
                                return;
                              }

                              // Existing time picker logic
                              DateTime now = DateTime.now();
                              TimeOfDay time = TimeOfDay.now();
                              DateTime selectedDate = DateFormat('dd-MM-yyyy')
                                  .parse(customerScreenProvider
                                      .dateController.text);
                              bool isToday = selectedDate.year == now.year &&
                                  selectedDate.month == now.month &&
                                  selectedDate.day == now.day;

                              TimeOfDay? pickedTime = await showTimePicker(
                                context: context,
                                initialTime: isToday
                                    ? TimeOfDay.fromDateTime(
                                        now.add(const Duration(minutes: 1)))
                                    : const TimeOfDay(hour: 0, minute: 0),
                                builder: (context, child) {
                                  return Theme(
                                    data: ThemeData.light().copyWith(
                                      colorScheme: ColorScheme.light(
                                        primary: Colors.blue[700]!,
                                        onPrimary: Colors.white,
                                        surface: Colors.white,
                                        onSurface: Colors.black,
                                      ),
                                      timePickerTheme: TimePickerThemeData(
                                        backgroundColor: Colors.white,
                                        dialBackgroundColor: Colors.blue[50],
                                        dialHandColor: Colors.blue[700],
                                        hourMinuteTextColor: Colors.blue[900],
                                        hourMinuteColor: Colors.blue[100],
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                        ),
                                      ),
                                      dialogBackgroundColor: Colors.white,
                                    ),
                                    child: child!,
                                  );
                                },
                              );

                              if (pickedTime != null) {
                                if (isToday &&
                                    (pickedTime.hour < time.hour ||
                                        (pickedTime.hour == time.hour &&
                                            pickedTime.minute <=
                                                time.minute))) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                          'Delivery time must be in the future'),
                                    ),
                                  );
                                } else {
                                  customerScreenProvider.timeController.text =
                                      pickedTime.format(context);
                                }
                              }
                            },
                            validator: (value) {
                              if (_isFormValid &&
                                  (value == null || value.isEmpty)) {
                                return 'Delivery Time is required';
                              }
                              return null;
                            },
                          ),
                        ),
                        //     if (_customerType == 'Normal') ...[
                        const Padding(padding: EdgeInsets.all(5)),
                        // ],
                      ],
                    ),

                    const Padding(padding: EdgeInsets.all(5)),

                    Row(
                      children: [
                        const Padding(padding: EdgeInsets.all(5)),
                        if (_customerType == 'Normal' ||
                            _customerType == 'Company') ...[
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              value: customerScreenProvider.selectedEvent,
                              hint: const Text('Select Event',
                                  style: TextStyle(fontSize: 14)),
                              items: [
                                'Birthday',
                                'Anniversary',
                                'Wedding',
                                'Others'
                              ].map((String event) {
                                return DropdownMenuItem<String>(
                                  value: event,
                                  child: Text(event),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                customerScreenProvider
                                    .setSelectedEvent(newValue);
                              },
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                labelText: 'Event',
                                isDense: false,
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 8),
                              ),
                              style: const TextStyle(
                                  fontSize: 14, color: Colors.black),
                              dropdownColor: Colors.white,
                              validator: (value) {
                                if (_isFormValid &&
                                    (value == null || value.isEmpty)) {
                                  return 'Please select an event';
                                }
                                return null;
                              },
                            ),
                          ),
                          const Padding(padding: EdgeInsets.all(5)),
                          // Show extra text field for entering date or custom event
                          if (customerScreenProvider.selectedEvent != null &&
                              customerScreenProvider.selectedEvent!.isNotEmpty)
                            Expanded(
                              child: TextFormField(
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                readOnly:
                                    customerScreenProvider.selectedEvent !=
                                        'Others',
                                onTap: customerScreenProvider.selectedEvent !=
                                        'Others'
                                    ? () async {
                                        // DateTime? selectedDate =
                                        //     await showDatePicker(
                                        //   context: context,
                                        //   initialDate: DateTime.now(),
                                        //   firstDate: DateTime(1900),
                                        //   lastDate: DateTime(2100),
                                        //   builder: (context, child) {
                                        //     return Theme(
                                        //       data: ThemeData.light().copyWith(
                                        //         primaryColor: Colors.blue[700],
                                        //         colorScheme: ColorScheme.light(
                                        //           primary: Colors.blue[700]!,
                                        //         ),
                                        //         buttonTheme: ButtonThemeData(
                                        //           textTheme:
                                        //               ButtonTextTheme.primary,
                                        //         ),
                                        //       ),
                                        //       child: child!,
                                        //     );
                                        //   },
                                        // );
                                        // if (selectedDate != null) {
                                        //   String formattedDate =
                                        //       DateFormat('dd-MM-yyyy')
                                        //           .format(selectedDate);
                                        //   customerScreenProvider
                                        //       .birthdaydateController
                                        //       .text = formattedDate;
                                        // }
                                        DateTime now = DateTime.now();
                                        showGeneralDialog(
                                          context: context,
                                          barrierDismissible: true,
                                          barrierLabel: "Date Picker",
                                          pageBuilder: (context, animation1,
                                              animation2) {
                                            return Container(); // Not used
                                          },
                                          transitionBuilder:
                                              (context, a1, a2, widget) {
                                            return ScaleTransition(
                                              scale: Tween<double>(
                                                      begin: 0.5, end: 1.0)
                                                  .animate(a1),
                                              child: FadeTransition(
                                                opacity: Tween<double>(
                                                        begin: 0.5, end: 1.0)
                                                    .animate(a1),
                                                child: Dialog(
                                                  backgroundColor:
                                                      Colors.transparent,
                                                  elevation: 0,
                                                  child: Container(
                                                    width: double.infinity,
                                                    constraints: BoxConstraints(
                                                        maxWidth: 350),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                      color: Colors.white,
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.blue
                                                              .withOpacity(0.2),
                                                          blurRadius: 20,
                                                          spreadRadius: 5,
                                                        ),
                                                      ],
                                                    ),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Container(
                                                          padding:
                                                              EdgeInsets.all(
                                                                  16),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors
                                                                .blue[700],
                                                            borderRadius:
                                                                BorderRadius
                                                                    .only(
                                                              topLeft: Radius
                                                                  .circular(20),
                                                              topRight: Radius
                                                                  .circular(20),
                                                            ),
                                                          ),
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                "Choose Event Date",
                                                                style:
                                                                    TextStyle(
                                                                  fontSize: 18,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .calendar_today,
                                                                color: Colors
                                                                    .white,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          height: 300,
                                                          child: Theme(
                                                            data: ThemeData(
                                                              colorScheme:
                                                                  ColorScheme
                                                                      .light(
                                                                primary: Colors
                                                                    .blue[700]!,
                                                                onPrimary:
                                                                    Colors
                                                                        .white,
                                                                onSurface:
                                                                    Colors
                                                                        .black,
                                                              ),
                                                            ),
                                                            child:
                                                                CalendarDatePicker(
                                                              initialDate:
                                                                  DateTime
                                                                      .now(),
                                                              firstDate:
                                                                  DateTime
                                                                      .now(),
                                                              lastDate: now.add(
                                                                  const Duration(
                                                                      days:
                                                                          180)),
                                                              onDateChanged:
                                                                  (date) {
                                                                String
                                                                    formattedDate =
                                                                    DateFormat(
                                                                            'dd-MM-yyyy')
                                                                        .format(
                                                                            date);
                                                                customerScreenProvider
                                                                        .birthdaydateController
                                                                        .text =
                                                                    formattedDate;

                                                                Navigator.of(
                                                                        context)
                                                                    .pop();
                                                              },
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          padding:
                                                              EdgeInsets.all(
                                                                  16),
                                                          child: Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .end,
                                                            children: [
                                                              TextButton(
                                                                onPressed: () {
                                                                  Navigator.of(
                                                                          context)
                                                                      .pop();
                                                                },
                                                                child: Text(
                                                                  "Cancel",
                                                                  style:
                                                                      TextStyle(
                                                                    color: Colors
                                                                            .grey[
                                                                        600],
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                          transitionDuration:
                                              Duration(milliseconds: 300),
                                        );
                                      }
                                    : null,
                                decoration: InputDecoration(
                                  border: const OutlineInputBorder(),
                                  labelText: customerScreenProvider
                                              .selectedEvent ==
                                          'Others'
                                      ? 'Enter Event'
                                      : 'Select ${customerScreenProvider.selectedEvent} Date',
                                  isDense: false,
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 8),
                                  suffixIcon:
                                      customerScreenProvider.selectedEvent !=
                                              'Others'
                                          ? Icon(Icons.event)
                                          : null,
                                ),
                                style: const TextStyle(
                                    fontSize: 14, color: Colors.black),
                                controller: customerScreenProvider
                                    .birthdaydateController,
                                validator: (value) {
                                  if (_isFormValid &&
                                      (value == null || value.isEmpty)) {
                                    return customerScreenProvider
                                                .selectedEvent ==
                                            'Others'
                                        ? 'Please enter the event'
                                        : 'Please select a date';
                                  }
                                  return null;
                                },
                              ),
                            ),

                          const Padding(padding: EdgeInsets.all(5)),
                        ],
                      ],
                    ),
                    const Padding(padding: EdgeInsets.all(5)),
                    Row(
                      children: [
                        // if (customerScreenProvider.selectedEvent == 'Birthday')
                        if (_customerType != 'Normal' ||
                            _customerType != 'Company') ...[const SizedBox()],

                        if (_customerType == 'Normal' ||
                            _customerType == 'Company') ...[
                          const Padding(padding: EdgeInsets.all(5)),
                        ],
                        if (_customerType == 'Credit Customer') ...[
                          const Padding(padding: EdgeInsets.all(5))
                        ],

                        // const Padding(padding: EdgeInsets.all(5)),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                            value: customerScreenProvider.selectedDeliveryType,
                            hint: const Text('Delivery Type',
                                style: TextStyle(fontSize: 14)),
                            items: [
                              'Pickup by Customer',
                              'Door Delivery',
                            ].map((String type) {
                              return DropdownMenuItem<String>(
                                value: type,
                                child: Text(type),
                              );
                            }).toList(),
                            onChanged: (String? newValue) {
                              customerScreenProvider
                                  .setSelectedDeliveryType(newValue);
                            },
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'Delivery Type',
                              labelStyle: TextStyle(fontSize: 14),
                              isDense: false, // Makes the field more compact
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                            ),
                            style: TextStyle(fontSize: 14, color: Colors.black),
                            dropdownColor: Colors.white,
                            validator: (value) {
                              if (_isFormValid &&
                                  (value == null || value.isEmpty)) {
                                return 'Delivery Type is required';
                              }
                              return null;
                            },
                          ),
                        ),
                        const Padding(padding: EdgeInsets.all(5)),
                        Expanded(child: EmployeeSearchDropdown()),
                        const Padding(padding: EdgeInsets.all(5)),
                      ],
                    ),

                    //   ],

                    // Conditionally show Address and Landmark Fields if "Door Delivery" is selected
                    if (customerScreenProvider.selectedDeliveryType ==
                        'Door Delivery') ...[
                      // Row for Landmark and Address
                      const Padding(padding: EdgeInsets.all(5)),
                      Row(
                        children: [
                          const Padding(padding: EdgeInsets.all(5)),
                          Expanded(
                            child: TextFormField(
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              controller:
                                  customerScreenProvider.landmarkController,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                labelText: 'Landmark',
                                labelStyle: TextStyle(fontSize: 14),
                                isDense: false, // Makes the field more compact
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 8),
                                hintText:
                                    'e.g., Near ABC Park, Opposite XYZ Mall',
                                hintStyle: TextStyle(color: Colors.grey),
                              ),
                              style:
                                  TextStyle(fontSize: 14, color: Colors.black),
                              validator: (value) {
                                if (_isFormValid &&
                                    (value == null || value.isEmpty)) {
                                  return 'Landmark is required';
                                }
                                return null;
                              },
                            ),
                          ),
                          const Padding(padding: EdgeInsets.all(5)),
                          Expanded(
                            child: TextFormField(
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              controller:
                                  customerScreenProvider.addressController,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                labelText: 'Address',
                                labelStyle: TextStyle(fontSize: 14),
                                isDense: false, // Makes the field more compact
                                // contentPadding: EdgeInsets.symmetric(
                                //     horizontal: 14, vertical: 8),
                                hintText:
                                    'e.g., 1234 Main Street, Apartment 12',
                                hintStyle: TextStyle(color: Colors.grey),
                              ),
                              style:
                                  TextStyle(fontSize: 14, color: Colors.black),
                              validator: (value) {
                                if (_isFormValid &&
                                    (value == null || value.isEmpty)) {
                                  return 'Address is required';
                                }
                                return null;
                              },
                            ),
                          ),
                          const Padding(padding: EdgeInsets.all(5)),
                        ],
                      ),
                    ],
                    if (_customerType == 'Company')
                      Row(children: [
                        // const Padding(padding: EdgeInsets.all(5)),
                        Expanded(
                          child: customerScreenProvider
                              .buildCompanyInputFields(context),
                        )
                      ]),

                    if (_customerType == 'Credit Customer')
                      Row(children: [
                        // const Padding(padding: EdgeInsets.all(5)),
                        Expanded(
                            child:
                                //  customerScreenProvider
                                //     .buildCustomerInputFieldsforcredit(context),
                                CreditCustomerSearchDropdown())
                      ]),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        controller: customerScreenProvider.remarkController,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Remarks',
                          labelStyle: TextStyle(fontSize: 14),
                          isDense: false, // Makes the field more compact

                          hintStyle: TextStyle(color: Colors.grey),
                        ),
                        style: TextStyle(fontSize: 14, color: Colors.black),
                        validator: (value) {
                          if (_isFormValid &&
                              (value == null || value.isEmpty)) {
                            return 'Landmark is required';
                          }
                          return null;
                        },
                      ),
                    ),

                    const SizedBox(height: 28),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Audio Player and Photos in the same container
                        if (audioPlayerId == null ||
                            audioprovider.state.error != null ||
                            photoScreenId != null)
                          Flexible(
                            child: Container(
                              constraints: BoxConstraints(
                                maxWidth: 600, // Set a maximum width
                                maxHeight:
                                    150, // Set a maximum height for the combined container
                              ),
                              decoration: BoxDecoration(
                                color: Colors
                                    .white, // Background color for the container
                                borderRadius: BorderRadius.circular(
                                    12), // Rounded corners
                                // boxShadow: [
                                //   BoxShadow(
                                //     color: Colors.grey.withOpacity(0.2),
                                //     blurRadius: 10,
                                //     spreadRadius: 3,
                                //   ),
                                // ],
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  // Voice Recorder or Audio Player
                                  if (customerScreenProvider
                                          .showAudioandImage ||
                                      audioPlayerId == null ||
                                      audioprovider.state.error != null)
                                    Flexible(
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.blueGrey
                                              .shade100, // Light blue color for Audio section
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        child: VoiceRecorder(
                                          onRecordingComplete:
                                              handleRecordingComplete,
                                        ),
                                      ),
                                    ),
                                  if (audioPlayerId != null &&
                                      audioprovider.state.error == null)
                                    Flexible(
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.blueGrey
                                              .shade100, // Light blue color for Audio section
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        // child: AudioPlayerWidget(
                                        //     customId: audioPlayerId!),
                                        child: AudioPlayerWidget(
                                          filePath: recordedFilePath,
                                        ),
                                      ),
                                    ),

                                  // Photo Screen (if photoScreenId is not null)
                                  if (photoScreenId != null)
                                    Flexible(
                                      child: Container(
                                        constraints: BoxConstraints(
                                          maxWidth:
                                              100, // Max width for the photo screen
                                          maxHeight:
                                              100, // Max height for the photo screen
                                        ),
                                        decoration: BoxDecoration(
                                          color: Color.fromARGB(
                                              255, 196, 155, 155),
                                          borderRadius: BorderRadius.circular(
                                              8), // Rounded corners
                                        ),
                                        // child: PhotosScreen(
                                        //     customId: photoScreenId!),

                                        child: PhotosScreen(
                                          imagePaths: [
                                            _pickedImage1!.path,
                                            _pickedImage2!.path,
                                          ],
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),

                        // Image Picker (if no photo is selected)
                        if (photoScreenId == null)
                          Flexible(
                            child: ImagePickerWidget(
                              onImagesSelected: _onImagesSelected,
                            ),
                          ),
                      ],
                    ),

                    const SizedBox(height: 5),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Replace the existing Place Order button with this conditional
                        if (_requiresApproval())
                          CustomButton(
                            text: 'Send for Approval',
                            onPressed: globals.cartItems.isNotEmpty
                                ? () {
                                    if (_validateOrderDetails()) {
                                      print('from buttonclicked');
                                      customerScreenProvider.submitForApproval(
                                          context,
                                          cartSelectionProvider,
                                          cartProvider,
                                          recordedFilePath,
                                          apiSalesprovider,
                                          _pickedImage1,
                                          _pickedImage2,
                                          _customerType
                                          // audioPlayerId!,
                                          // holdId!,
                                          );
                                    }
                                  }
                                : () {},
                            backgroundColor: globals.cartItems.isNotEmpty
                                ? Colors.orange
                                : Colors.grey,
                            textColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 8),
                            fontSize: 16.0,
                          )
                        else
                          CustomButton(
                            text: 'Place Order',
                            onPressed: globals.cartItems.isNotEmpty
                                ? () {
                                    if (_validateOrderDetails()) {
                                      customerScreenProvider
                                          .showAdvancePaymentPopup(
                                        context,
                                        cartSelectionProvider,
                                        cartProvider,
                                        recordedFilePath,
                                        apiSalesprovider,
                                        _pickedImage1,
                                        _pickedImage2,
                                        _customerType,
                                        audioPlayerId,
                                        holdId,
                                      );
                                    }
                                    customerScreenProvider
                                        .clikedThePaymentButton();
                                  }
                                : () {},
                            backgroundColor: globals.cartItems.isNotEmpty
                                ? Colors.blue
                                : Colors.grey,
                            textColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 8),
                            fontSize: 16.0,
                          ),
                        if (_customerType == 'Normal') ...[
                          CustomButton(
                            text: 'Hold Order',
                            onPressed: globals.cartItems.isNotEmpty
                                ? () {
                                    if (_formKey.currentState!.validate()) {
                                      customerScreenProvider.holdOrers(
                                          cartProvider,
                                          recordedFilePath,
                                          apiSalesprovider,
                                          _pickedImage1,
                                          _pickedImage2);
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        const SnackBar(
                                            content: Text(
                                                'Order data saved successfully!')),
                                      );
                                      _formKey.currentState!.reset();
                                      customerScreenProvider.clearControllers();
                                      globals.cartItems.clear();
                                    }
                                  }
                                : () {},
                            backgroundColor: globals.cartItems.isNotEmpty
                                ? Colors.lightBlue
                                : Colors.grey,
                            textColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 8),
                            fontSize: 16.0,
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 10),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showDiscountStatus(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (BuildContext context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          maxChildSize: 0.9,
          minChildSize: 0.5,
          expand: false,
          builder: (context, scrollController) {
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Column(
                children: [
                  _buildApproveOrdersHeader(),
                  Expanded(
                    child: _buildApproveOrdersList(context, scrollController),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildApproveOrdersHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: Colors.blue.shade600,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          const Center(
            child: Text(
              "Approval Orders Status",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.5),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<List<HeldOrder>> fetchApproveOrdersFromHive() async {
    var approveOrderBox = await Hive.openBox('approveSalesOrderBox');

    if (approveOrderBox.isEmpty) {
      return [];
    }

    List<HeldOrder> approveOrders = [];

    for (var i = 0; i < approveOrderBox.length; i++) {
      var order = approveOrderBox.getAt(i);

      if (order != null) {
        try {
          if (order is Map<dynamic, dynamic>) {
            // Explicitly cast order to Map<String, dynamic>
            var orderMap = order.map(
              (key, value) => MapEntry(key.toString(), value),
            );

            if (orderMap.containsKey('approvalDetails') &&
                orderMap['approvalDetails'] is List &&
                (orderMap['approvalDetails'] as List).isNotEmpty) {
              var lastApprovalRaw = (orderMap['approvalDetails'] as List).last;

              if (lastApprovalRaw is Map<dynamic, dynamic>) {
                // Convert Map<dynamic, dynamic> to Map<String, dynamic>
                var lastApproval = Map<String, dynamic>.from(
                  lastApprovalRaw.map(
                    (key, value) => MapEntry(key.toString(), value),
                  ),
                );

                if (lastApproval.containsKey('approvalType') &&
                        lastApproval['approvalType'] == 'Cheque' ||
                    lastApproval['approvalType'] == 'Discount') {
                  try {
                    // Ensure the map is cast properly before using it
                    Map<String, dynamic> properlyTypedMap =
                        Map<String, dynamic>.from(orderMap);

                    HeldOrder heldOrder = HeldOrder.fromMap(properlyTypedMap);
                    approveOrders.add(heldOrder);
                  } catch (e, stackTrace) {
                    print("Error converting order at index $i: $e");
                    print("Stack Trace: $stackTrace");
                  }
                }
              } else {
                print(
                  "Warning: lastApproval is not a Map<String, dynamic>: $lastApprovalRaw",
                );
              }
            }
          } else {
            print("Warning: Order at index $i is not a valid map: $order");
          }
        } catch (e) {
          print("Error converting order at index $i: $e");
        }
      }
    }

    for (var order in approveOrders) {
      print(order.toJson());
    }

    return approveOrders;
  }

  Widget _buildApproveOrdersList(
    BuildContext context,
    ScrollController scrollController,
  ) {
    return FutureBuilder<List<HeldOrder>>(
      future: fetchApproveOrdersFromHive(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error: ${snapshot.error}',
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
            ),
          );
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(
            child: Text(
              'No held orders available',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
          );
        }

        final orders = snapshot.data!;
        return ListView.builder(
          controller: scrollController,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          itemCount: orders.length,
          itemBuilder: (context, index) {
            return _buildApproveOrderListItem(context, orders[index]);
          },
        );
      },
    );
  }

  Widget _buildApproveOrderListItem(BuildContext context, HeldOrder order) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 10),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _restoreHeldOrderData(context, order),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      'Customer: ${order.customerName}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.blueAccent,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const Divider(),
              _buildInfoRow(
                Icons.calendar_today,
                'Delivery: ${order.deliveryDate}',
              ),
              _buildInfoRow(Icons.access_time, 'Time: ${order.deliveryTime}'),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: _buildInfoRow(
                      Icons.info,
                      'Status: ${order.approvalDetails?.isNotEmpty == true ? order.approvalDetails!.last.approvalStatus ?? 'Unknown' : 'Unknown'}',
                    ),
                  ),
                  _buildStatusChip(order.status),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.blueGrey),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip(String status) {
    Color statusColor = Colors.orange; // Set all statuses to orange

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(color: statusColor, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildHeldOrdersHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: Colors.blue.shade600,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          const Center(
            child: Text(
              "Hold Orders",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.5),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeldOrdersList(
      BuildContext context, ScrollController scrollController) {
    return FutureBuilder<List<HeldOrder>>(
      future: Provider.of<CustomerScreenProvider>(context, listen: false)
          .fetchOrderStatus(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(child: Text('No held orders available'));
        }

        final orders = snapshot.data!;
        return ListView.builder(
          controller: scrollController,
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: orders.length,
          itemBuilder: (context, index) =>
              _buildHeldOrderListItem(context, orders[index]),
        );
      },
    );
  }

  Widget _buildHeldOrderListItem(BuildContext context, HeldOrder order) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      shadowColor: Colors.black.withOpacity(0.15),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _restoreHeldOrderData(context, order),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      'Customer: ${order.customerName}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Colors.blueAccent,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.redAccent),
                    onPressed: () =>
                        _deleteHeldOrder(context, order.salesOrderId),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _buildInfoRow(
                  Icons.calendar_today, 'Delivery: ${order.deliveryDate}'),
              const SizedBox(height: 4),
              _buildInfoRow(Icons.access_time, 'Time: ${order.deliveryTime}'),
              const SizedBox(height: 4),
              _buildInfoRow(
                Icons.info,
                'Status: ${order.approvalDetails?.isNotEmpty == true ? order.approvalDetails!.last.approvalStatus ?? 'Unknown' : 'Unknown'}',
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _deleteHeldOrder(BuildContext context, String orderId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Delete Held Order'),
          content:
              const Text('Are you sure you want to delete this held order?'),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: const Text('Delete', style: TextStyle(color: Colors.red)),
              onPressed: () {
                // customerScreenProvider.deleteSalesOrder(orderId);
                Navigator.of(context).pop();
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text('Held order deleted successfully')),
                );
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _restoreHeldOrderData(
      BuildContext context, HeldOrder order) async {
    if (isRequestInProgress) return;

    setState(() {
      isRequestInProgress = true;
    });

    try {
      // Use Future.microtask to perform UI updates efficiently
      await Future.microtask(() {
        final customerScreenProvider =
            Provider.of<CustomerScreenProvider>(context, listen: false);
        final audioprovider =
            Provider.of<AudioProvider>(context, listen: false);
        final cartProvider = Provider.of<CartProvider>(context, listen: false);
        final detailsProvider =
            Provider.of<DetailsProvider>(context, listen: false);
        final photoProvider =
            Provider.of<PhotoProvider>(context, listen: false);
        cartProvider.clearCart();
        customerScreenProvider.dateController.text = order.deliveryDate ?? '';
        customerScreenProvider.timeController.text = order.deliveryTime ?? '';
        customerScreenProvider.setSelectedEvent(order.event);
        customerScreenProvider.setSelectedDeliveryType(order.deliveryType);
        customerScreenProvider.landmarkController.text = order.landmark ?? '';
        customerScreenProvider.addressController.text = order.address ?? '';
        customerScreenProvider.remarkController.text = order.remarks ?? '';
        customerScreenProvider.customerNameController.text =
            order.customerName ?? '';
        customerScreenProvider.mobileNoController.text =
            order.customerNumber ?? '';
        customerScreenProvider.searchController.text = order.employeeName;
        detailsProvider.filteredEmployeeFirstNames.clear();

        // photoScreenId = order.salesOrderId;

        // photoProvider
        //     .arePhotosAvailableForCustomId(photoScreenId!)
        //     .then((arePhotosAvailable) {
        //   photoScreenId = arePhotosAvailable ? photoScreenId : null;
        //   print(arePhotosAvailable
        //       ? "Photos are available."
        //       : "No photos available.");
        // });

        // audioPlayerId = order.salesOrderId;
        // audioprovider.checkAudio(audioPlayerId!).then((isAudioAvailable) {
        //   if (!isAudioAvailable) audioPlayerId = null;
        //   print(isAudioAvailable
        //       ? 'Audio is available.'
        //       : 'Audio not available.');
        // });

        // holdId = order.salesOrderId;
        for (int index = 0; index < order.itemName.length; index++) {
          cartProvider.addItemToCart(CartItem(
            varianceName: order.varianceName[index],
            itemName: order.itemName[index],
            pricePerKg: order.price[index],
            tax: order.tax[index],
            itemCode: order.itemCode[index],
            uom: order.uom[index],
            quantity: order.qty[index],
            weight: order.weight[index],
          ));
        }
      });

      // ScaffoldMessenger.of(context).showSnackBar(
      //   const SnackBar(content: Text('Order data restored to form')),
      // );
      print('1............');
      if (context.mounted) {
        print('here we go');
        GlobalScaffold.showMessage(
          message: 'Order data restored to form',
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );
      }
      await Future.delayed(Duration(milliseconds: 100));
      Navigator.pop(context);
      print('2...........');
    } finally {
      setState(() {
        isRequestInProgress = false;
      });
    }
  }
}
