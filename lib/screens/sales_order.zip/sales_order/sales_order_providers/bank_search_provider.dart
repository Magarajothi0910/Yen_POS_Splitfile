// import 'package:flutter/material.dart';
// import 'package:hive/hive.dart';

// // class BankSearchProvider with ChangeNotifier {
// //   final String url;
// //   final String boxName;
// //   Box? _box;
// //   TextEditingController bankNameController = TextEditingController();
// //   BankSearchProvider(this.url, this.boxName) {
// //     _initBox();
// //   }

// //   Future<void> _initBox() async {
// //     _box = await Hive.openBox(boxName);
// //     notifyListeners();
// //   }

// //   List<Map<String, dynamic>> get suggestions {
// //     if (_box == null) return [];
// //     return _box!.values.cast<Map<String, dynamic>>().toList();
// //   }

// //   void fetchSuggestions(String query) {
// //     // Implement the logic to fetch suggestions based on the query.
// //     notifyListeners();
// //   }

// //   Future<bool> addBank(String bankName) async {
// //     if (_box == null) return false;
// //     try {
// //       await _box!.add({'bankName': bankName});
// //       notifyListeners();
// //       return true;
// //     } catch (e) {
// //       return false;
// //     }
// //   }
// // }

// class BankSearchProvider with ChangeNotifier {
//   final String url;
//   final String boxName;
//   Box? _box;
//   List<Map<String, dynamic>> _filteredSuggestions = [];
//   TextEditingController bankNameController = TextEditingController();
//   BankSearchProvider(this.url, this.boxName) {
//     _initBox();
//   }

//   // Future<void> _initBox() async {
//   //   _box = await Hive.openBox(boxName);
//   //   notifyListeners();
//   // }

//   Future<void> _initBox() async {
//     _box = await Hive.openBox(boxName);

//     _filteredSuggestions = _box!.values
//         .whereType<Map<dynamic, dynamic>>()
//         .map((e) => e.cast<String, dynamic>())
//         .toList();
//     notifyListeners();
//   }

//   // List<Map<String, dynamic>> get suggestions {
//   //   print(suggestions);
//   //   if (_box == null) return [];
//   //   return _box!.values
//   //       .whereType<Map<dynamic, dynamic>>()
//   //       .map((e) => e.cast<String, dynamic>())
//   //       .toList();
//   // }

//   List<Map<String, dynamic>> get suggestions {
//     print(_filteredSuggestions); // Print the filtered suggestions instead
//     if (_box == null) return [];
//     return _filteredSuggestions;
//   }

//   // void fetchSuggestions(String query) {
//   //   // Implement the logic to fetch suggestions based on the query.
//   //   notifyListeners();
//   // }

//   void fetchSuggestions(String query) {
//     if (_box != null) {
//       print('Fetching suggestions for query: $query');
//       _filteredSuggestions = _box!.values
//           .whereType<Map<dynamic, dynamic>>()
//           .map((e) => e.cast<String, dynamic>())
//           .where((bank) =>
//               bank['bankName']?.toLowerCase().contains(query.toLowerCase()) ??
//               false)
//           .toList();
//     }
//     notifyListeners();
//   }

//   Future<bool> addBank(String bankName) async {
//     if (_box == null) return false;
//     try {
//       await _box!.add({'bankName': bankName});
//       notifyListeners();
//       return true;
//     } catch (e) {
//       return false;
//     }
//   }
// }

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;

// class BankSearchProvider with ChangeNotifier {
//   final String url;
//   final String boxName;
//   Box? _box;
//   List<Map<String, dynamic>> _filteredSuggestions = [];
//   TextEditingController bankNameController = TextEditingController();

//   BankSearchProvider(this.url, this.boxName) {
//     _initBox();
//   }

//   Future<void> _initBox() async {
//     _box = await Hive.openBox(boxName);

//     // Check if the box is empty
//     if (_box!.isEmpty) {
//       await _fetchFromApiAndSave(); // Fetch from API if empty
//     }

//     // Load data into filtered suggestions
//     _filteredSuggestions = _box!.values
//         .whereType<Map<dynamic, dynamic>>()
//         .map((e) => e.cast<String, dynamic>())
//         .toList();
//     notifyListeners();
//   }

//   // Fetch bank data from API and save it to the box
//   Future<void> _fetchFromApiAndSave() async {
//     try {
//       print('Fetching banks from API...');
//       final response = await http
//           .get(Uri.parse('https://yenerp.com/masterapi/bankmasters/'));

//       if (response.statusCode == 200) {
//         List<dynamic> data = json.decode(response.body);

//         for (var bank in data) {
//           await _box!.add(bank);
//         }

//         print('Banks fetched and saved successfully.');
//       } else {
//         print('Failed to fetch banks from API: ${response.statusCode}');
//       }
//     } catch (e) {
//       print('Error fetching banks: $e');
//     }
//   }

//   List<Map<String, dynamic>> get suggestions {
//     print(_filteredSuggestions); // Print the filtered suggestions instead
//     if (_box == null) return [];
//     return _filteredSuggestions;
//   }

//   void fetchSuggestions(String query) {
//     if (_box != null) {
//       print('Fetching suggestions for query: $query');
//       _filteredSuggestions = _box!.values
//           .whereType<Map<dynamic, dynamic>>()
//           .map((e) => e.cast<String, dynamic>())
//           .where((bank) =>
//               bank['bankName']?.toLowerCase().contains(query.toLowerCase()) ??
//               false)
//           .toList();
//     }
//     notifyListeners();
//   }

//   Future<bool> addBank(String bankName) async {
//     if (_box == null) return false;
//     try {
//       await _box!.add({'bankName': bankName});
//       notifyListeners();
//       return true;
//     } catch (e) {
//       return false;
//     }
//   }
// }

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../../../hiveGlobal/hiveProvider.dart';

// class BankSearchProvider extends ChangeNotifier {
//   List<Map<String, dynamic>> suggestions = [];
//   final Hiveprovider hiveProvider;
//   TextEditingController bankNameController = TextEditingController();
//   BankSearchProvider(this.hiveProvider);

//   Future<void> fetchSuggestions(String query) async {
//     print("Starting fetchSuggestions with query: \$query");

//     // Early exit if query is empty
//     if (query.isEmpty) {
//       print("Query is empty. Clearing suggestions.");
//       suggestions = [];
//       notifyListeners();
//       return;
//     }

//     try {
//       // Load cached data from Hive first
//       final cachedData = hiveProvider.data;
//       print("Loaded cached data from Hive: \$cachedData");

//       // Check if cached data contains banks
//       final banks = cachedData?['banks'];
//       if (banks is List) {
//         print("Filtering cached banks by name.");
//         suggestions = banks
//             .where((bank) =>
//                 bank['bankName']?.toLowerCase().contains(query.toLowerCase()) ??
//                 false)
//             .map((bank) => {
//                   'bankName': bank['bankName']?.toString() ?? '',
//                 })
//             .toList();
//         print("Filtered suggestions: \$suggestions");
//       } else {
//         print("No cached banks found.");
//         suggestions = [];
//       }

//       notifyListeners();
//     } catch (e) {
//       print("Error fetching suggestions: \$e");
//       suggestions = [];
//       notifyListeners();
//     }
//   }

//   Future<bool> addBank(String bankName) async {
//     try {
//       // Add new bank to remote API
//       final response = await http.post(
//         Uri.parse('https://yenerp.com/masterapi/bankmasters/'),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({
//           'bankName': bankName,
//           'status': '1',
//         }),
//       );

//       if (response.statusCode == 200 || response.statusCode == 201) {
//         print('Bank added: \${response.body}');
//         final newBank = {
//           'bankId': response.body,
//           'bankName': bankName,
//           'status': '1',
//         };

//         // Ensure the data structure exists
//         hiveProvider.data ??= {'banks': []};

//         if (hiveProvider.data!['banks'] == null) {
//           hiveProvider.data!['banks'] = [];
//         }

//         // Add the new bank to the cached list
//         (hiveProvider.data!['banks'] as List).add(newBank);

//         // Persist the updated data to Hive
//         if (hiveProvider.boxName != null) {
//           await Hive.box(hiveProvider.boxName!).put('data', hiveProvider.data);
//           print("Bank added to Hive: \$newBank");
//         } else {
//           print("Error: hiveProvider.boxName is null");
//         }

//         // Update suggestions with the new bank
//         suggestions.add({
//           'bankName': bankName,
//         });

//         notifyListeners();
//         return true;
//       } else {
//         print("Failed to add bank to server");
//         return false;
//       }
//     } catch (e) {
//       print("Error adding bank: \$e");
//       return false;
//     }
//   }
// }

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class BankSearchProvider extends ChangeNotifier {
  List<Map<String, dynamic>> suggestions = [];
  final HiveProvider hiveProvider;
  final String boxName;
  TextEditingController bankNameController = TextEditingController();

  BankSearchProvider(this.hiveProvider, {required this.boxName});
  void updateBankName(String bankName) {
    bankNameController.text = bankName;
    notifyListeners();
  }

  @override
  void dispose() {
    bankNameController.dispose();
    super.dispose();
  }

  Future<void> fetchSuggestions(String query) async {
    print("Starting fetchSuggestions with query: $query");

    // Early exit if query is empty
    if (query.isEmpty) {
      print("Query is empty. Clearing suggestions.");
      suggestions = [];
      notifyListeners();
      return;
    }

    try {
      // Load cached data from Hive first
      final cachedData = hiveProvider.data[boxName];
      print("Loaded cached data from Hive: $cachedData");

      // Check if cached data contains banks
      final banks = cachedData?['items'];
      if (banks is List) {
        print("Filtering cached banks by name.");
        suggestions = banks
            .where((bank) =>
                bank['bankName']?.toLowerCase().contains(query.toLowerCase()) ??
                false)
            .map((bank) => {
                  'bankName': bank['bankName']?.toString() ?? '',
                })
            .toList();
        print("Filtered suggestions: $suggestions");
      } else {
        print("No cached banks found.");
        suggestions = [];
      }

      notifyListeners();
    } catch (e) {
      print("Error fetching suggestions: $e");
      suggestions = [];
      notifyListeners();
    }
  }

  Future<bool> addBank(String bankName) async {
    try {
      // Add new bank to remote API
      final response = await http.post(
        Uri.parse('https://yenerp.com/masterapi/bankmasters/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'bankName': bankName,
          'status': '1',
        }),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        print('Bank added: ${response.body}');
        final newBank = {
          'bankId': response.body,
          'bankName': bankName,
          'status': '1',
        };

        // Ensure the data structure exists
        hiveProvider.data[boxName] ??= {'banks': []};

        if (hiveProvider.data[boxName]!['banks'] == null) {
          hiveProvider.data[boxName]!['banks'] = [];
        }

        // Add the new bank to the cached list
        (hiveProvider.data[boxName]!['banks'] as List).add(newBank);

        // Persist the updated data to Hive
        await hiveProvider.addData(boxName, newBank);
        print("Bank added to Hive: $newBank");

        // Update suggestions with the new bank
        suggestions.add({
          'bankName': bankName,
        });

        notifyListeners();
        return true;
      } else {
        print("Failed to add bank to server");
        return false;
      }
    } catch (e) {
      print("Error adding bank: $e");
      return false;
    }
  }
}
