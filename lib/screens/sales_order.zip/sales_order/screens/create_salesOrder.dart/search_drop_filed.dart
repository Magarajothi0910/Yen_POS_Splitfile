import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../../Global/custom_textWidgets.dart';
import '../../../../Global/search_drop_filed.dart';
import '../../../../services/branchwise_item_fetch.dart';
import '../../../regular_mode_page/provider/regular_mode_screen_provider.dart';
import '../../sales_order_providers/cartProvider.dart';
import 'numeric_Calculator.dart';

final FocusNode focusNode = FocusNode(); // Add FocusNode

class Debouncer {
  final int milliseconds;
  Timer? _timer;

  Debouncer({this.milliseconds = 300});

  void run(VoidCallback action) {
    _timer?.cancel();
    _timer = Timer(Duration(milliseconds: milliseconds), action);
  }

  void dispose() {
    _timer?.cancel();
  }
}

class SearchDropdown extends StatefulWidget {
  const SearchDropdown({Key? key}) : super(key: key);

  @override
  _SearchDropdownState createState() => _SearchDropdownState();
}

class _SearchDropdownState extends State<SearchDropdown> {
  final TextEditingController _controller = TextEditingController();
  final TextEditingController _hiddenController = TextEditingController();
  OverlayEntry? _overlayEntry;
  final LayerLink _layerLink = LayerLink();
  final Debouncer debouncer = Debouncer(milliseconds: 300);
  bool _isQrMode = false; // QR mode toggle
  bool _isProcessing = false; // To prevent overlapping processing

  @override
  void initState() {
    super.initState();
    print("SearchDropdown initialized");
    _controller.addListener(_updateOverlay);
  }

  @override
  void dispose() {
    print("SearchDropdown dispose called");
    _controller.removeListener(_updateOverlay);
    _controller.clear(); // Clear the text controller
    _controller.dispose();
    _hiddenController.dispose(); // Dispose the hidden controller
    debouncer.dispose(); // Dispose the debouncer
    _removeOverlay();
    super.dispose();
  }

  void _updateOverlay() {
    final provider = Provider.of<RegularModeProvider>(context, listen: false);
    debouncer.run(() {
      // Print search query entered
      print("Search Query: ${_controller.text}");

      // Filter variance names based on the search query
      provider.filterVarianceNamesBySearchQuery(_controller.text);

      // If search query is not empty, show overlay
      if (_controller.text.isNotEmpty) {
        print("Ensuring overlay is visible...");
        _showOverlay();
      } else {
        print("Removing overlay due to empty input.");
        _removeOverlay();
      }
    });
  }

  void _showOverlay() {
    if (_overlayEntry == null) {
      print("Creating overlay...");
      _overlayEntry = _createOverlayEntry();
      Overlay.of(context).insert(_overlayEntry!);
    } else {
      print("Updating overlay...");
      _overlayEntry?.markNeedsBuild();
    }
  }

  void _removeOverlay() {
    if (_overlayEntry != null) {
      print("Removing overlay...");
      _overlayEntry?.remove();
      _overlayEntry = null;
    }
  }

  OverlayEntry _createOverlayEntry() {
    print("Creating compact overlay entry...");
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;

    return OverlayEntry(
      builder: (context) => GestureDetector(
        behavior:
            HitTestBehavior.translucent, // Allows detection of outside taps
        onTap: () {
          print("Tapped outside dropdown");
          _removeOverlay(); // Method to remove the overlay
        },
        child: Stack(
          children: [
            Positioned(
              width: size.width,
              child: CompositedTransformFollower(
                link: _layerLink,
                showWhenUnlinked: false,
                offset: Offset(0, size.height + 3.0),
                child: Material(
                  elevation: 6.0,
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  child: Consumer<RegularModeProvider>(
                    builder: (_, provider, __) {
                      return Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.blue.shade100.withOpacity(0.6),
                              blurRadius: 6,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                        constraints: BoxConstraints(maxHeight: 200),
                        child: provider.filteredVarianceNames.isNotEmpty
                            ? ListView.builder(
                                padding: EdgeInsets.zero,
                                itemCount:
                                    provider.filteredVarianceNames.length,
                                itemBuilder: (_, index) {
                                  final varianceName =
                                      provider.filteredVarianceNames[index];
                                  print("Displaying Item: $varianceName");

                                  return ListTile(
                                    dense: true,
                                    contentPadding: EdgeInsets.symmetric(
                                      vertical: 4.0,
                                      horizontal: 8.0,
                                    ),
                                    title: CustomText(
                                      text: varianceName,
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.blue.shade700,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    hoverColor: Colors.blue.shade50,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    onTap: () {
                                      if (index <
                                          provider
                                              .filteredVarianceNames.length) {
                                        final selectedItem = provider
                                            .getVarianceDetails(varianceName);
                                        if (selectedItem != null) {
                                          final varianceData = provider
                                              .getVarianceDetails(varianceName);
                                          final itemName =
                                              varianceData['itemName'] ??
                                                  'Unknown Item';
                                          final varianceUOM =
                                              provider.getUOMForVariance(
                                                      varianceName) ??
                                                  'Unknown UOM';
                                          print("Print itemName: ${itemName}");
                                          print("VarianceData$varianceData");
                                          print(
                                              "Tapped Variance: ${selectedItem['varianceName']}");
                                          print(
                                              "Tapped VarianceUOM: $varianceUOM");
                                          _handleItemSelection(selectedItem,
                                              varianceData, varianceUOM);
                                          _removeOverlay(); // Close overlay on selection
                                        } else {
                                          print(
                                              "Error: No data found for $varianceName");
                                        }
                                      }
                                    },
                                  );
                                },
                              )
                            : Center(
                                child: Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text(
                                    "No results found",
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ),
                              ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

// void _removeOverlay() {
//   print("Removing overlay...");
//   _overlayEntry?.remove();
//   _overlayEntry = null;
// }

  void _handleItemSelection(
      Map<String, dynamic> selectedItem, variancedata, varianceUOM) {
    print("Handling Item Selection...");
    final cartProvider = Provider.of<CartProvider>(context, listen: false);

    // Check for null values
    String varianceName = selectedItem['varianceName'] ?? '';
    String itemName = variancedata['itemName'] ?? '';
    varianceUOM = varianceUOM ?? ''; // Ensure UOM is not null

    print(
        "Handling Item Selection - varianceName: $varianceName, itemName: $itemName, UOM: $varianceUOM");

    if (varianceUOM == 'Kgs' || varianceUOM == 'Kg') {
      print("Opening Numeric Calculator for weight input...");
      showDialog(
        context: context,
        builder: (context) {
          return NumericCalculator(
            varianceName: varianceName, // Pass the varianceName here
            onValueSelected: (weight) {
              print("Weight Selected: $weight kg");
              cartProvider.addItemToCart(CartItem(
                varianceName: varianceName,
                pricePerKg:
                    (variancedata['varianceDefaultPrice'] ?? 0.0).toInt(),
                itemName: itemName,
                uom: varianceUOM,
                weight: weight,
                quantity: 1,
                isBoxItem: 'no',
                tax: variancedata['variancetax'] ?? 0,
                itemCode: variancedata['varianceItemCode'] ?? '',
              ));
            },
          );
        },
      );
    } else if (varianceUOM == 'Pcs' || varianceUOM == 'Pkt') {
      // For Pcs or Pkt, show quantity dialog
      print("Opening quantity selection dialog for Pcs/Pkt...");
      showQuantityDialog(
          context, varianceName, variancedata['varianceDefaultPrice'] ?? 0.0,
          (quantity) {
        cartProvider.addItemToCart(CartItem(
          varianceName: varianceName,
          pricePerKg: (variancedata['varianceDefaultPrice'] ?? 0.0).toInt(),
          itemName: itemName,
          uom: varianceUOM,
          weight: 0, // Set weight to 0 for Pcs or Pkt
          quantity: quantity.toInt(),
          isBoxItem: 'no',
          tax: variancedata['variancetax'] ?? 0,
          itemCode: variancedata['varianceItemCode'] ?? '',
        ));
      });
    } else {
      // For other UOM types, add to cart directly
      print("Adding item to cart with quantity 1 for other UOM types...");
      cartProvider.addItemToCart(CartItem(
        varianceName: varianceName,
        pricePerKg: (variancedata['varianceDefaultPrice'] ?? 0.0).toInt(),
        itemName: itemName,
        uom: varianceUOM,
        weight: 0,
        quantity: 1,
        isBoxItem: 'no',
        tax: variancedata['variancetax'] ?? 0,
        itemCode: variancedata['varianceItemCode'] ?? '',
      ));
    }
    _clearSelection();
  }

  void _clearSelection() {
    print("Clearing selection and removing overlay...");
    _controller.clear();
    focusNode.unfocus();
    _removeOverlay();
  }

  void _toggleQrMode() {
    setState(() {
      _isQrMode = !_isQrMode;
      if (_isQrMode) {
        focusNode.requestFocus(); // Ensure focus on the hidden field
      } else {
        focusNode.unfocus();
      }
    });
  }

  void _handleInput(String value) async {
    if (_isProcessing || !_isQrMode || value.isEmpty) return;

    setState(() {
      _isProcessing = true; // Prevent overlapping scans
    });

    try {
      // Parse the scanned data
      final Map<String, dynamic> scannedData = _parseScannedData(value);

      if (scannedData.containsKey('ItemCode')) {
        final itemCode = scannedData['ItemCode'];
        final quantity = parseToDouble(scannedData['Qty'] ?? 1);
        final uom = scannedData['UOM'] ?? '';

        // Access the item provider and check for the item
        final itemProvider = Provider.of<ItemProvider>(context, listen: false);
        final provider =
            Provider.of<RegularModeProvider>(context, listen: false);
        final result = itemProvider.checkVarianceItemCode(itemCode);

        if (result.isNotEmpty) {
          final itemData = result.first;
          final varianceName = itemData['varianceData']['varianceName'] ?? '';
          final selectedItem = provider.getVarianceDetails(varianceName);
          if (selectedItem != null) {
            final varianceData = provider.getVarianceDetails(varianceName);
            final itemName = varianceData['itemName'] ?? 'Unknown Item';
            final varianceUOM =
                provider.getUOMForVariance(varianceName) ?? 'Unknown UOM';

            print("Tapped Variance: ${selectedItem['varianceName']}");
            print("Tapped VarianceUOM: $varianceUOM");
            _handleItemSelection(selectedItem, varianceData, varianceUOM);
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Item not found for the scanned code."),
              duration: Duration(milliseconds: 500),
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Invalid QR data. 'ItemCode' not found."),
            duration: Duration(milliseconds: 500),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error: ${e.toString()}"),
          duration: const Duration(milliseconds: 500),
        ),
      );
    } finally {
      // Clear the input field and refocus for the next scan
      _controller.clear();
      // focusNode.requestFocus();
      setState(() {
        _isProcessing = false; // Al0ow new scans
      });
    }
  }

  Map<String, dynamic> _parseScannedData(String value) {
    try {
      return json.decode(value); // Try parsing JSON
    } catch (_) {
      // Parse key-value format if not JSON
      final Map<String, dynamic> parsedData = {};
      value.replaceAll('{', '').replaceAll('}', '').split(',').forEach((pair) {
        final keyValue = pair.split(':');
        if (keyValue.length == 2) {
          parsedData[keyValue[0].trim()] = keyValue[1].trim();
        }
      });
      return parsedData;
    }
  }

  double parseToDouble(dynamic value) {
    if (value is num) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        print("Tapped outside, removing overlay...");
        _removeOverlay(); // Hide the overlay when tapped outside
        focusNode.unfocus(); // Remove focus from the text field
      },
      behavior: HitTestBehavior
          .translucent, // Ensures the tap is detected even on empty space
      child: CompositedTransformTarget(
        link: _layerLink,
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: FocusScope(
                    onFocusChange: (hasFocus) {
                      if (!hasFocus) {
                        print("Lost focus, removing overlay...");
                        _removeOverlay();
                      }
                    },
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        labelText: 'Search items',
                        prefixIcon:
                            Icon(Icons.search, color: Colors.blue.shade700),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.blue.shade700, width: 2.0),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.blue.shade300, width: 1.5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        fillColor: Colors.blue.shade50,
                        filled: true,
                        labelStyle: TextStyle(color: Colors.blue.shade700),
                        hintStyle: TextStyle(color: Colors.blue.shade300),
                      ),
                      cursorColor: Colors.blue.shade700,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(
                            r'[a-zA-Z0-9\s]+')), // Only letters, numbers, and spaces
                      ],
                      style: TextStyle(color: Colors.blue.shade900),
                      onSubmitted: _handleInput,
                      onTap: () {
                        print("TextField tapped, ensuring overlay appears...");
                        _showOverlay();
                      },
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    _isQrMode ? Icons.qr_code_scanner : Icons.qr_code,
                    color: _isQrMode ? Colors.green : Colors.blue.shade700,
                  ),
                  onPressed: _toggleQrMode,
                ),
              ],
            ),
            Offstage(
              offstage: !_isQrMode,
              child: TextField(
                controller: _hiddenController,
                focusNode: focusNode,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 0.0), // Reduced height
                  isDense: true, // Reduces overall height
                  fillColor: Colors.transparent,
                  filled: true,
                ),
                style: const TextStyle(fontSize: 0), // Keep font size minimal
                keyboardType: TextInputType.none,
                onSubmitted: _handleInput,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
