// lib/Sale_order/Screens/cart_footer_section.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:yenpos/Global/globals_data.dart' as globals;
import 'package:yenpos/Global/globals_data.dart';
import 'package:yenpos/Sale_order/Provider/cartProvider.dart';
import 'package:yenpos/Sale_order/Provider/cart_selection_provider.dart';
import 'package:yenpos/Sale_order/Provider/customerScreen_provider.dart';
import 'package:yenpos/Sale_order/Provider/saleorder_ui_provider.dart';

import 'package:yenpos/Sale_order/Widgets/numeric_Calculator.dart';
import 'package:yenpos/Sale_order/Widgets/selected_items_dialogue.dart';

class CartFooterSection extends StatelessWidget {
  const CartFooterSection({Key? key}) : super(key: key);

  void _showSelectedItemsDialog(
    BuildContext context,
    CartSelectionProvider selectionProvider,
  ) {
    showDialog(
      context: context,
      builder: (context) => SelectedItemsDialog(
        itemSelectionState: selectionProvider.itemSelectionState,
        cartItems: globals.cartItems,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);
    final selectionProvider = Provider.of<CartSelectionProvider>(context);
    final customerProvider = Provider.of<CustomerScreenProvider>(context);
    final uiProvider = Provider.of<SalesOrderUIProvider>(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Row(
        children: [
          // Dropdown + Input
          Expanded(
            flex: 4,
            child: Container(
              height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.blueAccent, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    offset: const Offset(0, 2),
                    blurRadius: 6,
                  ),
                ],
              ),
              child: StatefulBuilder(
                builder: (context, setState) {
                  return Row(
                    children: [
                      // Dropdown
                      Expanded(
                        flex: 5,
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: customerProvider.getChargesList().contains(
                              customerProvider.selectedChargeType,
                            )
                                ? customerProvider.selectedChargeType
                                : "Custom Charges",
                            isExpanded: true,
                            dropdownColor: Colors.white,
                            icon: const Icon(
                              Icons.arrow_drop_down_rounded,
                              size: 22,
                            ),
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87,
                            ),
                            items: customerProvider.getChargesList().map((event) {
                              return DropdownMenuItem<String>(
                                value: event,
                                child: Text(event),
                              );
                            }).toList(),
                            onChanged: (newValue) {
                              setState(() {
                                customerProvider.selectedChargeType = newValue!;
                              });
                            },
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Input Field
                      Expanded(
                        flex: 3,
                        child: TextFormField(
                          readOnly: true,
                          showCursor: true,
                          controller: cartProvider.customChargeController,
                          focusNode: uiProvider.customChargeFocus,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(5),
                          ],
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                          decoration: InputDecoration(
                            isDense: true,
                            filled: true,
                            fillColor: Colors.grey.shade100,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 6,
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                color: Colors.blue.shade300,
                                width: 1,
                              ),
                            ),
                          ),
                          onTap: () {
                            ActiveField.activate(
                              context: context,
                              ctrl: cartProvider.customChargeController,
                              node: uiProvider.customChargeFocus,
                              numeric: true,
                              customCharge: true,
                              fieldType: "custom charge",
                              onChanged: (value) {
                                cartProvider.updateCustomCharge(value);
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 12),
          // View Button
          SizedBox(
            width: 80,
            height: 45,
            child: ElevatedButton(
              onPressed: globals.cartItems.any(
                (item) => item.boxQuantity != null && item.boxQuantity! > 0,
              )
                  ? () {
                      _showSelectedItemsDialog(context, selectionProvider);
                    }
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                disabledBackgroundColor: Colors.grey,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: EdgeInsets.zero,
              ),
              child: const Text(
                "View",
                style: TextStyle(color: Colors.white, fontSize: 13),
              ),
            ),
          ),
          const SizedBox(width: 12),
          // Total Amount
          Expanded(
            flex: 3,
            child: ValueListenableBuilder<double>(
              valueListenable: cartProvider.totalAmount,
              builder: (context, total, _) {
                return Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    'Total ₹${total.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}