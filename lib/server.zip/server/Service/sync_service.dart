import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

class SyncService {
  final String apiUrl = 'http://192.168.1.233:8888/orders/';
  final String invoiceApiUrl = 'https://yenerp.com/fastapi/invoices/';
  final String modifyApiUrl = 'http://192.168.29.8:8888/modify/';
  final String holdOrderApi = "http://192.168.1.109:8888/saleorder/";
  final String salesApprovalOrders =
      "http://192.168.29.246:8881/fastapi/approvals/";
  bool _isSyncing = false;
  bool isOnline = false;
  List<Function> syncQueue = [];

  Future<void> processSyncQueue() async {
    while (syncQueue.isNotEmpty && isOnline) {
      var task = syncQueue.removeAt(0);
      await task();
    }
  }

  void queueSync(Function syncTask) {
    syncQueue.add(syncTask);

    if (isOnline) {
      processSyncQueue();
    }
  }

  SyncService() {
    _monitorConnectivity();
    Timer.periodic(const Duration(minutes: 10), (timer) {
      if (isOnline) {
        syncUnsyncedOrders();
        syncUnsyncedInvoices();
      }
    });
  }
  void _monitorConnectivity() {
    Connectivity()
        .onConnectivityChanged
        .listen((List<ConnectivityResult> results) {
      final ConnectivityResult result =
          results.isNotEmpty ? results.first : ConnectivityResult.none;
      isOnline = result != ConnectivityResult.none;
      if (isOnline) {
        processSyncQueue();
      }
    });
  }

  Future<void> saveOrderToHive(Map<String, dynamic> order) async {
    var orderBox = await Hive.openBox('ordersBox');
    order['sync'] = 'No';
    order['edit'] = 'No'; // Initialize edit field as "No" for new orders
    await orderBox.add(order);
    print('Order saved locally with sync: No');
    print(order);

    await syncUnsyncedOrders();
  }

  Future<void> saveInvoiceToHive(Map<String, dynamic> invoice) async {
    var invoiceBox = await Hive.openBox('invoicesBox');
    invoice['sync'] = 'No';
    invoice['edit'] = 'No'; // Initialize edit field as "No" for new invoices
    await invoiceBox.add(invoice);
    print('Invoice saved locally with sync: No');
    print(invoice);
    print("Full data in invoiceBox: ${invoiceBox.toMap()}");

    // Check connectivity and try to sync after saving locally
    await syncUnsyncedInvoices();
  }

  Future<void> saveholdOrderToHive(Map<String, dynamic> order) async {
    var holdOrderBox = await Hive.openBox('holdOrders');
    order['sync'] = 'No';
    order['edit'] = 'No'; // Initialize edit field as "No" for new orders
    await holdOrderBox.add(order);
    print('Hold Order saved locally with sync: No');
    print(order);
  }

  Future<void> saveSalesApprovalOrderToHive(Map<String, dynamic> order) async {
    var salesApprovalOrderBox = await Hive.openBox('salesApprovalOrder');
    order['sync'] = 'No';
    order['edit'] = 'No'; // Initialize edit field as "No" for new orders
    await salesApprovalOrderBox.add(order);
    print('Sales Approval Order saved locally with sync: No');
    print(order);
  }

  Future<void> syncUnsyncedOrders() async {
    print("Syncing unsynced orders...");
    if (_isSyncing) return;
    _isSyncing = true;

    var orderBox = await Hive.openBox('ordersBox');
    for (int i = 0; i < orderBox.length; i++) {
      var orderData = orderBox.getAt(i);
      if (orderData is String) {
        orderData = jsonDecode(orderData) as Map<String, dynamic>;
      }

      // if (orderData is Map<String, dynamic> && orderData['sync'] == 'No') {
      //   bool success = await postOrder(orderData);
      //   if (success) {
      //     orderData['sync'] = 'Yes';
      //     await orderBox.putAt(i, orderData);
      //     print('Order ${orderData['hiveOrderId']} synced successfully.');
      //   } else {
      //     break; // Stop if a post fails
      //   }
      // }
      if (orderData is Map<String, dynamic> && orderData['sync'] == 'No') {
        queueSync(() => postOrder(orderData));
      }
    }
    _isSyncing = false;
    await patchEditedOrders();
  }

  Future<void> patchEditedOrders() async {
    print(
        "Checking orders to patch statuses or other fields if sync and edit are 'Yes'...");
    var orderBox = await Hive.openBox('ordersBox');

    for (int i = 0; i < orderBox.length; i++) {
      var orderData = orderBox.getAt(i);
      if (orderData is String) {
        orderData = jsonDecode(orderData) as Map<String, dynamic>;
      }
      if (orderData is Map<String, dynamic> &&
          orderData['sync'] == 'Yes' &&
          orderData['edit'] == 'Yes') {
        //  Case 1: fieldsEdited == "true" (Update quantities and cancelledQty)
        if (orderData['fieldsEdited'] == 'true') {
          final hiveOrderId = orderData['hiveOrderId'].toString();
          print("Attempting to patch fields for hiveOrderId: $hiveOrderId");

          // Patch quantities and cancelledQty
          bool patchedFields =
              await patchFieldsByHiveOrderId(hiveOrderId, orderData);

          if (patchedFields) {
            orderData['edit'] = 'No'; // Reset edit flag after successful patch
            orderData['fieldsEdited'] = 'false';
            await orderBox.putAt(i, orderData);
            print('Order $hiveOrderId fields patched successfully.');
          } else {
            print('Failed to patch fields for $hiveOrderId');
          }
        }

        // Case 2: statusEdited == "true" (Update status)
        if (orderData['statusEdited'] == 'true' &&
            orderData.containsKey('seathiveOrderId')) {
          final seathiveOrderId = orderData['seathiveOrderId'].toString();
          final status = orderData['status'];

          print(
              "Attempting to patch status for seathiveOrderId: $seathiveOrderId");

          // Patch status
          bool patchedStatus =
              await patchOrderStatusWithRetry(seathiveOrderId, status);

          if (patchedStatus) {
            orderData['edit'] = 'No'; // Reset edit flag after successful patch
            orderData['statusEdited'] = 'false';
            await orderBox.putAt(i, orderData);
            print(
                'Order status for $seathiveOrderId patched successfully to $status.');
          } else {
            print('Failed to patch status for $seathiveOrderId');
          }
        }
      }
    }
  }

  Future<bool> postHoldOrder(Map<String, dynamic> order) async {
    try {
      if (!isOnline) {
        queueSync(() => postHoldOrder(order));
        return false;
      }
      print('Posting hold order: ${jsonEncode(order)}');
      final response = await http.post(
        Uri.parse(holdOrderApi),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(order),
      );

      if (response.statusCode == 201 || response.statusCode == 200) {
        print('Hold order posted successfully.');
        return true;
      } else {
        print('Failed to post hold order. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error posting hold order: $e');
      return false;
    }
  }

  Future<bool> postSalesOrder(Map<String, dynamic> salesOrder) async {
    const String salesOrderApi = "http://192.168.29.8:8888/saleorder/";
    // Print the payload and URL for debugging
    print('Posting sales order (raw JSON): ${jsonEncode(salesOrder)}');
    print("Posting to URL: $salesOrderApi");

    try {
      if (!isOnline) {
        queueSync(() => postSalesOrder(salesOrder));
        return false;
      }

      // Send the POST request
      final response = await http.post(
        Uri.parse(salesOrderApi),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(salesOrder),
      );

      // Debug response details
      print('HTTP status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 201 || response.statusCode == 200) {
        print('Sales order posted successfully.');
        return true;
      } else {
        print(
            'Failed to post sales order. Status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('Error posting sales order: $e');
      return false;
    }
  }

  Future<bool> postModifyOrder(Map<String, dynamic> salesOrder) async {
    final String salesOrderApi = "http://192.168.29.8:8888/modify/";
    // Print the payload and URL for debugging
    print('Posting sales order (raw JSON): ${jsonEncode(salesOrder)}');
    print("Posting to URL: $salesOrderApi");

    try {
      if (!isOnline) {
        queueSync(() => postSalesOrder(salesOrder));
        return false;
      }

      // Send the POST request
      final response = await http.post(
        Uri.parse(salesOrderApi),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(salesOrder),
      );

      // Debug response details
      print('HTTP status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 201 || response.statusCode == 200) {
        print('Sales order posted successfully.');
        return true;
      } else {
        print(
            'Failed to post sales order. Status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('Error posting sales order: $e');
      return false;
    }
  }

  Future<bool> postAddNewCustomerOrder({
    required String name,
    required String mobile,
    String? branchId,
  }) async {
    const String endpoint = 'http://192.168.29.8:8888/customer/';

    final body = {
      'customerName': name,
      'customerPhoneNumber': mobile,
      if (branchId != null) 'branchId': branchId,
    };

    print('[HTTP] POST $endpoint');
    print('[HTTP] Payload: $body');

    try {
      if (!isOnline) {
        queueSync(() => postAddNewCustomerOrder(
              name: name,
              mobile: mobile,
              branchId: branchId,
            ));
        return false;
      }

      final res = await http.post(
        Uri.parse(endpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      print('[HTTP] status=${res.statusCode}');
      print('[HTTP] response=${res.body}');

      return res.statusCode == 200 || res.statusCode == 201;
    } catch (e) {
      print('[HTTP] ❌ $e');
      return false;
    }
  }

  Future<bool> postSalesApprovalOrder(Map<String, dynamic> order) async {
    try {
      if (!isOnline) {
        queueSync(() => postSalesApprovalOrder(order));
        return false;
      }
      print('Posting sales approval order: ${jsonEncode(order)}');
      final response = await http.post(
        Uri.parse(salesApprovalOrders),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(order),
      );

      if (response.statusCode == 201 || response.statusCode == 200) {
        print('Sales approval order posted successfully.');
        return true;
      } else {
        print(
            'Failed to post sales approval order. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error posting sales approval order: $e');
      return false;
    }
  }

  Future<bool> patchOrderStatusWithRetry(String seathiveOrderId, String status,
      {int retries = 3}) async {
    for (int attempt = 0; attempt < retries; attempt++) {
      bool success =
          await patchOrderStatusBySeathiveOrderId(seathiveOrderId, status);
      if (success) {
        return true;
      } else {
        print(
            'Retrying patch request for $seathiveOrderId... Attempt ${attempt + 1} of $retries');
      }
    }
    print(
        'Failed to patch order status after $retries attempts for $seathiveOrderId.');
    return false;
  }

  Future<bool> patchOrderStatusBySeathiveOrderId(
      String seathiveOrderId, String status) async {
    try {
      final patchUrl =
          Uri.parse('${apiUrl}patch-status/$seathiveOrderId?status=$status');
      print('Patching order status at: $patchUrl');

      final response = await http.patch(
        patchUrl,
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        print('Order status patched successfully for $seathiveOrderId.');
        return true;
      } else {
        print(
            'Failed to patch order status. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error patching order status by seathiveOrderId: $e');
      return false;
    }
  }

  Future<bool> patchFieldsByHiveOrderId(
      String hiveOrderId, Map<String, dynamic> fields) async {
    try {
      final patchUrl = Uri.parse('${apiUrl}patch-fields/$hiveOrderId');
      Map<String, dynamic> patchData = {
        'hiveOrderId': hiveOrderId,
      };

      if (fields.containsKey('quantities')) {
        patchData['quantities'] = fields['quantities'];
      }

      if (fields.containsKey('cancelledQty')) {
        patchData['cancelledQty'] = fields['cancelledQty'];
      }
      if (fields.containsKey('amounts')) {
        patchData['amounts'] = fields['amounts'];
      }
      if (fields.containsKey('totalAmount')) {
        patchData['totalAmount'] = fields['totalAmount'];
      }
      print('Patching fields for order at: $patchUrl');
      print('Patch data: ${jsonEncode(patchData)}');

      final response = await http.patch(
        patchUrl,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(patchData),
      );

      if (response.statusCode == 200) {
        print('Order fields patched successfully for $hiveOrderId.');
        return true;
      } else {
        print(
            'Failed to patch order fields. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error patching order fields by hiveOrderId: $e');
      return false;
    }
  }

  // Future<bool> postOrder(Map<String, dynamic> order) async {
  //   try {
  //     print('Posting order: ${jsonEncode(order)}');
  //     final response = await http.post(
  //       Uri.parse(apiUrl),
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(order),
  //     );

  //     if (response.statusCode == 201 || response.statusCode == 200) {
  //       print('Order posted successfully.');
  //       return true;
  //     } else {
  //       print('Failed to post order. Status code: ${response.statusCode}');
  //       print('Response body: ${response.body}');
  //       return false;
  //     }
  //   } catch (e) {
  //     print('Error posting order: $e');
  //     return false;
  //   }
  // }
  Future<bool> postOrder(Map<String, dynamic> order) async {
    try {
      if (!isOnline) {
        queueSync(() => postOrder(order));
        return false;
      }
      print('Posting order: ${jsonEncode(order)}');
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(order),
      );

      if (response.statusCode == 201 || response.statusCode == 200) {
        print('Order posted successfully.');
        return true;
      } else {
        print('Failed to post order. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error posting order: $e');
      return false;
    }
  }

  Future<bool> patchOrderTableAndSeat(
      String seathiveOrderId, int table, String seat) async {
    try {
      final patchUrl = Uri.parse(
          '${apiUrl}patch-table-seat/$seathiveOrderId?table=$table&seat=$seat');
      Map<String, dynamic> patchData = {
        'table': table,
        'seat': seat,
      };

      print('Patching table and seat for order at: $patchUrl');
      print('Patch data: ${jsonEncode(patchData)}');

      final response = await http.patch(
        patchUrl,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(patchData),
      );

      if (response.statusCode == 200) {
        print(
            'Order table and seat patched successfully for $seathiveOrderId.');
        return true;
      } else {
        print(
            'Failed to patch order table and seat. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error patching order table and seat: $e');
      return false;
    }
  }

  Future<bool> postToApproveOrder(Map<String, dynamic> salesOrder) async {
    final String salesOrderApi = "http://192.168.29.8:8888/toapprove/";
    // Print the payload and URL for debugging
    print('Posting sales order (raw JSON): ${jsonEncode(salesOrder)}');
    print("Posting to URL: $salesOrderApi");

    try {
      if (!isOnline) {
        queueSync(() => postToApproveOrder(salesOrder));
        return false;
      }

      // Send the POST request
      final response = await http.post(
        Uri.parse(salesOrderApi),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(salesOrder),
      );

      // Debug response details
      print('HTTP status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 201 || response.statusCode == 200) {
        // patchSaleOrder(salesOrder, response.body);
        print('Sales order posted successfully.');
        return true;
      } else {
        print(
            'Failed to post sales order. Status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('Error posting sales order: $e');
      return false;
    }
  }

  Future<bool> postDiscountOrder(Map<String, dynamic> salesOrder) async {
    final String salesOrderApi = "http://192.168.29.8:8888/heldorders/";
    // Print the payload and URL for debugging
    print('Posting sales order (raw JSON): ${jsonEncode(salesOrder)}');
    print("Posting to URL: $salesOrderApi");

    try {
      if (!isOnline) {
        queueSync(() => postDiscountOrder(salesOrder));
        return false;
      }

      // Send the POST request
      final response = await http.post(
        Uri.parse(salesOrderApi),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(salesOrder),
      );

      // Debug response details
      print('HTTP status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 201 || response.statusCode == 200) {
        // patchSaleOrder(salesOrder, response.body);
        print('Sales order posted successfully.');
        return true;
      } else {
        print(
            'Failed to post sales order. Status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('Error posting sales order: $e');
      return false;
    }
  }

  Future<void> syncPendingPatches() async {
    if (!isOnline) return;

    final box = await Hive.openBox('pendingPatches');
    final patches = box.values.toList();

    for (var patch in patches) {
      try {
        final response = await http.patch(
          Uri.parse(
              "http://192.168.29.8:8888/saleorder/${patch['salesOrderId']}/"),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(patch['data']),
        );

        if (response.statusCode == 200) {
          await box.delete(patch['salesOrderId']);
          print('Successfully synced pending patch: ${patch['salesOrderId']}');
        }
      } catch (e) {
        print('Error syncing pending patch ${patch['salesOrderId']}: $e');
      }
    }
  }

  Future<void> syncUnsyncedInvoices() async {
    print("Syncing unsynced invoices...");
    if (_isSyncing) return;
    _isSyncing = true;

    var invoiceBox = await Hive.openBox('invoicesBox');
    for (int i = 0; i < invoiceBox.length; i++) {
      var invoiceData = invoiceBox.getAt(i);
      if (invoiceData is String) {
        invoiceData = jsonDecode(invoiceData) as Map<String, dynamic>;
      }

      if (invoiceData is Map<String, dynamic> && invoiceData['sync'] == 'No') {
        bool success = await postInvoice(invoiceData);
        if (success) {
          invoiceData['sync'] = 'Yes';
          await invoiceBox.putAt(i, invoiceData);
          print('Invoice ${invoiceData['hiveInvoiceId']} synced successfully.');
        } else {
          break; // Stop if a post fails
        }
      }
    }
    _isSyncing = false;
  }

  Future<bool> postInvoice(Map<String, dynamic> invoice) async {
    try {
      print('Posting invoice: ${jsonEncode(invoice)}');
      invoice['cash'] = int.tryParse(invoice['cash']?.toString() ?? '') ?? 0;

      invoice['card'] = int.tryParse(invoice['card']?.toString() ?? '') ?? 0;
      invoice['upi'] = int.tryParse(invoice['upi']?.toString() ?? '') ?? 0;
      final response = await http.post(
        Uri.parse(invoiceApiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(invoice),
      );

      if (response.statusCode == 201 || response.statusCode == 200) {
        print('Invoice posted successfully.');
        return true;
      } else {
        print('Failed to post invoice. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error posting invoice: $e');
      return false;
    }
  }
  ////////////////////////////////////////////////////////

  // Future<Map<String, dynamic>?> fetchSalesOrderFromApi(
  //     String saleOrderNo) async {
  //   try {
  //     final response = await http.get(
  //       Uri.parse(
  //           'http://192.168.29.8:8888/saleorder/?saleOrderNo=$saleOrderNo'),
  //       headers: {'Content-Type': 'application/json'},
  //     );

  //     if (response.statusCode == 200) {
  //       final data = jsonDecode(response.body);
  //       return data as Map<String, dynamic>;
  //     } else {
  //       print('Failed to fetch sales order from API: ${response.statusCode}');
  //       return null;
  //     }
  //   } catch (e) {
  //     print('Error fetching sales order from API: $e');
  //     return null;
  //   }
  // }

  Future<Map<String, dynamic>?> fetchSalesOrderFromApi(
      String saleOrderNo) async {
    try {
      debugPrint('🌐 Sending HTTP GET request for saleOrderNo: $saleOrderNo');
      final response = await http.get(
        Uri.parse(
            'http://192.168.29.8:8888/saleorder/withoutpagination/?saleOrderNo=$saleOrderNo'),
        headers: {'Content-Type': 'application/json'},
      );

      debugPrint('📡 HTTP response status: ${response.statusCode}');
      debugPrint('📥 HTTP response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        debugPrint('✅ Decoded API data: ${jsonEncode(data)}');
        return data as Map<String, dynamic>;
      } else {
        debugPrint(
            '❌ Failed to fetch sales order from API: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      debugPrint('🚨 Error fetching sales order from API: $e');
      return null;
    }
  }
}
