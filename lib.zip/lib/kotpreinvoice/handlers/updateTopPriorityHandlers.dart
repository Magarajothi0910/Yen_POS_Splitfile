import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:yen_pos/Global/globals_data.dart';
import 'package:yen_pos/Server_Client/sendDataToClients.dart';

double clamp01(double value) {
  return value.clamp(0.0, 1.0);
}

double calculateOsScore(String osVersion) {
  final sdkMatch = RegExp(r'SDK (\d+)').firstMatch(osVersion);
  final int sdk = sdkMatch != null ? int.parse(sdkMatch.group(1)!) : 21;

  // Android SDK reference
  // 21 → very old, 34 → latest
  return clamp01((sdk - 21) / (34 - 21)) * 20;
}

double calculateRamScore(double totalRamGB, double freeRamGB) {
  final double totalScore = clamp01(totalRamGB / 12) * 15; // 12GB = max
  final double freeScore = clamp01(freeRamGB / totalRamGB) * 10;
  return totalScore + freeScore;
}

double calculateStorageScore(double totalGB, double freeGB) {
  final double totalScore = clamp01(totalGB / 256) * 15; // 256GB = max
  final double freeScore = clamp01(freeGB / totalGB) * 10;
  return totalScore + freeScore;
}

double calculateBatteryScore(int level, String state) {
  double score = clamp01(level / 100) * 10;

  if (state == 'charging') score += 3;
  if (state == 'full') score += 5;

  return clamp01(score / 15) * 15;
}

double calculateUsageScore(int minutes) {
  if (minutes <= 30) return 15;
  if (minutes <= 120) return 10;
  if (minutes <= 300) return 5;
  return 2;
}

int calculateDeviceScore(Map<String, dynamic> info) {
  double score = 0;

  score += calculateOsScore(info['osVersion']);
  score += calculateRamScore(
    double.parse(info['totalRamGB']),
    double.parse(info['freeRamGB']),
  );
  score += calculateStorageScore(
    double.parse(info['totalStorageGB']),
    double.parse(info['freeStorageGB']),
  );
  score += calculateBatteryScore(info['batteryLevel'], info['batteryState']);
  score += calculateUsageScore(info['dailyAppUsageMinutes']);

  return score.round().clamp(0, 100);
}

Future<void> updateTopPrioritiesAndBroadcast() async {
  try {
    final box = Hive.isBoxOpen('connectedDevices')
        ? Hive.box('connectedDevices')
        : await Hive.openBox('connectedDevices');

    List<Map<String, dynamic>> allDevices = [];

    for (final key in box.keys) {
      final raw = box.get(key);
      if (raw is! Map) continue;

      final Map<String, dynamic> data = Map<String, dynamic>.from(raw);

      allDevices.add({...data, 'deviceType': data['deviceType'] ?? 'client'});
    }

    // Calculate score for ALL devices
    List<Map<String, dynamic>> scoredDevices = allDevices.map((device) {
      final int score = calculateDeviceScore(device);

      return {...device, 'score': double.parse(score.toStringAsFixed(3))};
    }).toList();

    // Separate server and clients with scores
    Map<String, dynamic>? scoredServer;
    List<Map<String, dynamic>> scoredClients = [];

    for (var device in scoredDevices) {
      if (device['deviceType'] == 'server') {
        scoredServer = device;
      } else {
        scoredClients.add(device);
      }
    }

    // Sort ALL clients by score descending
    scoredClients.sort(
      (a, b) => (b['score'] as double).compareTo(a['score'] as double),
    );

    // Assign priority: 1 to 5 for top 5, null for others
    for (int i = 0; i < scoredClients.length; i++) {
      scoredClients[i]['priority'] = i < 5 ? i + 1 : null;
    }

    // Build final list: Server first (if exists), then ALL clients sorted
    List<Map<String, dynamic>> broadcastList = [];

    if (scoredServer != null) {
      broadcastList.add({
        'deviceType': 'server',
        'clientIp': scoredServer['clientIp'],
        'model': scoredServer['model'],
        'manufacturer': scoredServer['manufacturer'],
        'osVersion': scoredServer['osVersion'],
        'batteryLevel': scoredServer['batteryLevel'],
        'batteryState': scoredServer['batteryState'],
        'totalRamGB': scoredServer['totalRamGB'],
        'freeRamGB': scoredServer['freeRamGB'],
        'totalStorageGB': scoredServer['totalStorageGB'],
        'freeStorageGB': scoredServer['freeStorageGB'],
        'dailyAppUsageMinutes': scoredServer['dailyAppUsageMinutes'],
        'score': scoredServer['score'],
        // No priority for server
      });
    }

    // Add ALL clients (top 5 with priority, others without)
    for (var client in scoredClients) {
      broadcastList.add({
        'deviceType': 'client',
        'clientIp': client['clientIp'],
        'model': client['model'],
        'manufacturer': client['manufacturer'],
        'osVersion': client['osVersion'],
        'batteryLevel': client['batteryLevel'],
        'batteryState': client['batteryState'],
        'totalRamGB': client['totalRamGB'],
        'freeRamGB': client['freeRamGB'],
        'totalStorageGB': client['totalStorageGB'],
        'freeStorageGB': client['freeStorageGB'],
        'dailyAppUsageMinutes': client['dailyAppUsageMinutes'],
        'priority': client['priority'], // 1–5 or null
        'score': client['score'],
      });
    }

    // Save full list to Hive under a better key name
    final priorityBox = Hive.isBoxOpen('deviceInfoData')
        ? Hive.box('deviceInfoData')
        : await Hive.openBox('deviceInfoData');

    await priorityBox.put('allConnectedDevices', broadcastList);

    // Broadcast the full updated list
    final broadcastPayload = {
      'action': 'priorityUpdate',
      'allDevices': broadcastList, // Clearer name than 'topDevices'
    };

    sendDataToClients(broadcastPayload, clients);

    // channel.sink.add(jsonEncode(broadcastPayload));

    debugPrint(
      "Priority updated & broadcasted: "
      "Server: ${scoredServer != null ? 'Yes' : 'No'}, "
      "Total Clients: ${scoredClients.length}, "
      "Top 5 Prioritized: ${scoredClients.length >= 5 ? 5 : scoredClients.length}",
    );
  } catch (e, st) {
    debugPrint("Error updating priorities: $e");
    debugPrint(st.toString());
  }
}
