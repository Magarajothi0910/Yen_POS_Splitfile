// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:hive_flutter/hive_flutter.dart';
// import 'package:http/http.dart' as http;

// import '../../../hiveGlobal/hiveProvider.dart';

// class CustomerSearchProvider extends ChangeNotifier {
//   List<Map<String, dynamic>> suggestions = [];

//   Future<void> fetchSuggestions(String query) async {
//     if (query.isEmpty) {
//       suggestions = [];
//       notifyListeners();
//       return;
//     }

//     final url = Uri.parse('http://$ipAddress/fastapi/customer/');
//     try {
//       final response = await http.get(url);
//       if (response.statusCode == 200) {
//         final List customers = json.decode(response.body);
//         suggestions = customers
//             .where((customer) => customer['customerPhoneNumber']
//                 .toString()
//                 .startsWith(query)) // Filter by mobile number prefix
//             .map((customer) => {
//                   'mobileNo': customer['customerPhoneNumber'].toString(),
//                   'name': customer['customerName'].toString(),
//                 })
//             .toList();
//         notifyListeners();
//       } else {
//         throw Exception('Failed to load customers');
//       }
//     } catch (e) {
//       print(e);
//       suggestions = [];
//       notifyListeners();
//     }
//   }

//   Future<bool> addCustomer(String mobile, String name) async {
//     try {
//       final response = await http.post(
//         Uri.parse('http://$ipAddress/customer/'),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({
//           'customerPhoneNumber': mobile,
//           'customerName': name,
//           'status': '1'
//         }),
//       );
//       return response.statusCode == 200 || response.statusCode == 201;
//     } catch (e) {
//       debugPrint('Error adding customer: $e');
//       return false;
//     }
//   }
// }

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;

import '../../../hiveGlobal/hiveProvider.dart';

// class CustomerSearchProvider extends ChangeNotifier {
//   List<Map<String, dynamic>> suggestions = [];
//   final Hiveprovider hiveProvider;

//   CustomerSearchProvider(this.hiveProvider);

//   Future<void> fetchSuggestions(String query) async {
//     print("Starting fetchSuggestions with query: $query");

//     // Early exit if query is empty
//     if (query.isEmpty) {
//       print("Query is empty. Clearing suggestions.");
//       suggestions = [];
//       notifyListeners();
//       return;
//     }

//     try {
//       // Load cached data from Hive first
//       final cachedData = hiveProvider.data;
//       print("Loaded cached data from Hive: $cachedData");

//       // Check if cached data contains customers
//       final customers = cachedData?['customers'];
//       if (customers is List) {
//         print("Filtering cached customers by mobile number.");
//         suggestions = customers
//             .where((customer) =>
//                 customer['customerPhoneNumber']?.toString().contains(query) ??
//                 false)
//             .map((customer) => {
//                   'mobileNo': customer['customerPhoneNumber']?.toString() ?? '',
//                   'name': customer['customerName']?.toString() ?? '',
//                 })
//             .toList();
//         print("Filtered suggestions: $suggestions");
//       } else {
//         print("No cached customers found.");
//         suggestions = [];
//       }

//       notifyListeners();
//     } catch (e) {
//       print("Error fetching suggestions: $e");
//       suggestions = [];
//       notifyListeners();
//     }
//   }

//   Future<bool> addCustomer(String mobile, String name) async {
//     try {
//       // Add new customer to remote API
//       final response = await http.post(
//         Uri.parse('http://$ipAddress/customer/'),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({
//           'customerPhoneNumber': mobile,
//           'customerName': name,
//           'status': '1'
//         }),
//       );

//       if (response.statusCode == 200 || response.statusCode == 201) {
//         print('Customer phone${response.body}');
//         // Add customer locally to cache
//         final newCustomer = {
//           'customerId': response.body,
//           'customerPhoneNumber': mobile,
//           'customerName': name,
//           'status': '1'
//         };

//         // Ensure the data structure exists
//         hiveProvider.data ??= {'customers': []};

//         if (hiveProvider.data!['customers'] == null) {
//           hiveProvider.data!['customers'] = [];
//         }

//         // Add the new customer to the cached list
//         (hiveProvider.data!['customers'] as List).add(newCustomer);

//         // Persist the updated data to Hive
//         if (hiveProvider.boxName != null) {
//           await Hive.box(hiveProvider.boxName!).put('data', hiveProvider.data);
//           print("Customer added to Hive: $newCustomer");
//         } else {
//           print("Error: hiveProvider.boxName is null");
//         }

//         // Update suggestions with the new customer
//         suggestions.add({
//           'mobileNo': mobile,
//           'name': name,
//         });

//         notifyListeners();
//         return true;
//       } else {
//         print("Failed to add customer to server");
//         return false;
//       }
//     } catch (e) {
//       print("Error adding customer: $e");
//       return false;
//     }
//   }
// }

class CustomerSearchProvider extends ChangeNotifier {
  List<Map<String, dynamic>> suggestions = [];
  final HiveProvider hiveProvider;
  final String boxName;

  CustomerSearchProvider(this.hiveProvider, {required this.boxName});

  Future<void> fetchSuggestions(String query) async {
    print("Starting fetchSuggestions with query: $query");

    // Early exit if query is empty
    if (query.isEmpty) {
      print("Query is empty. Clearing suggestions.");
      suggestions = [];
      notifyListeners();
      return;
    }

    try {
      final cachedData = hiveProvider.data[boxName];
      print("Loaded cached data from Hive: $cachedData");

      final customers = cachedData?['items'];
      if (customers is List) {
        print("Filtering cached customers by name.");
        // suggestions = customers
        //     .where((bank) =>
        //         bank['customerPhoneNumber']
        //             ?.toString()
        //             .toLowerCase()
        //             .contains(query.toLowerCase()) ??
        //         false)
        //     .cast<Map<String, dynamic>>()
        //     .toList();
        suggestions = customers
            .where((customer) =>
                customer['customerPhoneNumber']?.toString().contains(query) ??
                false)
            .map((customer) => {
                  'mobileNo': customer['customerPhoneNumber']?.toString() ?? '',
                  'name': customer['customerName']?.toString() ?? '',
                })
            .toList();
        print("Filtered customers suggestions: $suggestions");
      } else {
        print("No cached customers found.");
        suggestions = [];
      }

      notifyListeners();
    } catch (e) {
      print("Error fetching suggestions: $e");
      suggestions = [];
      notifyListeners();
    }
  }
}
