import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../globals.dart' as globals;

class CartItem {
  final String varianceName;
  final String itemName;
  final String itemCode;
  final int pricePerKg;
  double? finalPrice;
  double? itemWiseDiscount;
  double? itemWiseDiscountAmount;
  double? discount;
  String? isBoxItem;
  final int tax;
  int? boxQuantity;
  final String uom; // Add the uom field
  int quantity;
  double weight;
  CartItem({
    required this.varianceName,
    required this.itemName,
    this.isBoxItem,
    this.boxQuantity,
    this.finalPrice,
    this.discount,
    required this.pricePerKg,
    required this.tax,
    required this.itemCode,
    required this.uom, // Initialize uom
    required this.quantity,
    required this.weight,
  });
}

class CartProvider extends ChangeNotifier {
  final List<CartItem> _closingStockItems = []; // Closing stock cart

  final List<List<CartItem>> _savedBills = [];
  int? _currentBillIndex; // Tracks the index of the currently loaded bill
  List<bool> itemSelections = [];
  void toggleItemSelection(int index) {
    itemSelections[index] = !itemSelections[index];
    notifyListeners();
  }

  List<CartItem> get closingStockItems => _closingStockItems;
  List<List<CartItem>> get savedBills => _savedBills;

  final List<Map<String, dynamic>> _addedVariances = [];
  final TextEditingController customChargeController = TextEditingController();
  List<Map<String, dynamic>> get addedVariances => _addedVariances;

  double get totalWeight {
    double total = 0;

    // Calculate the weight of predefined variances
    total += _addedVariances.fold(
        0, (sum, variance) => sum + (variance['weight'] ?? 0));

    return total;
  }

  void addVariance(Map<String, dynamic> variance) {
    _addedVariances.add(variance);
    notifyListeners(); // Notify listeners about the change
  }

  void removeVariance(Map<String, dynamic> variance) {
    _addedVariances.removeWhere(
        (item) => item['varianceName'] == variance['varianceName']);
    notifyListeners();
  }

  get items => null;

  // Main Cart Methods
  void updateQuantity(int index, int quantity) {
    print("Attempting to update quantity at index: $index");
    print("Current cart items: ${globals.cartItems}");

    if (globals.cartItems.isNotEmpty &&
        index >= 0 &&
        index < globals.cartItems.length) {
      globals.cartItems[index].quantity = quantity;
      notifyListeners();
    } else {
      print("Invalid index: $index or empty cart.");
    }
  }

  void addItemToCart(CartItem newItem) {
    // Check if an item with the same name and UOM exists but with different attributes
    int existingItemIndex = globals.cartItems.indexWhere((item) =>
        item.varianceName == newItem.varianceName &&
        item.itemName == newItem.itemName &&
        item.uom == newItem.uom &&
        item.weight == newItem.weight);

    if (existingItemIndex != -1) {
      // Update quantity for identical items
      globals.cartItems[existingItemIndex].quantity += newItem.quantity;
    } else {
      // Add a new entry for items with different weights or attributes
      globals.cartItems.add(newItem);
    }

    print("_cartItems123: ${globals.cartItems}");
    notifyListeners();
  }

  void increaseQuantity(int index) {
    globals.cartItems[index].quantity++;
    notifyListeners();
  }

  void decreaseQuantity(int index) {
    if (globals.cartItems[index].quantity > 1) {
      globals.cartItems[index].quantity--;
    } else {
      globals.cartItems.removeAt(index);
    }
    notifyListeners();
  }

  void clearCart() {
    globals.cartItems.clear();
    customChargeController.clear();
    notifyListeners();
  }

  // Closing Stock Cart Methods

  void addItemToClosingStock(CartItem newItem) {
    int existingItemIndex = _closingStockItems
        .indexWhere((item) => item.varianceName == newItem.varianceName);
    if (existingItemIndex != -1) {
      _closingStockItems[existingItemIndex].quantity += newItem.quantity;
    } else {
      _closingStockItems.add(newItem);
    }
    notifyListeners();
  }

  void increaseClosingStockQuantity(int index) {
    _closingStockItems[index].quantity++;
    notifyListeners();
  }

  void decreaseClosingStockQuantity(int index) {
    if (_closingStockItems[index].quantity > 1) {
      _closingStockItems[index].quantity--;
    } else {
      _closingStockItems.removeAt(index);
    }
    notifyListeners();
  }

  void clearClosingStockCart() {
    _closingStockItems.clear();
    notifyListeners();
  }

  // Save and Load Bill Methods

  void saveBill() {
    if (globals.cartItems.isNotEmpty) {
      if (_currentBillIndex == null) {
        _savedBills.add(List.from(globals.cartItems));
      } else {
        _savedBills[_currentBillIndex!] = List.from(globals.cartItems);
      }
      clearCart(); // Clear the cart after saving
      _currentBillIndex = null; // Reset the current bill index
      notifyListeners();
    }
  }

  void loadSavedBill(int index) {
    _currentBillIndex = index; // Set the current bill index
    globals.cartItems =
        List.from(_savedBills[index]); // Load the saved bill into the cart
    notifyListeners();
  }

  void deleteSavedBill(int index) {
    _savedBills.removeAt(index);
    notifyListeners();
  }

  void deleteCurrentBill() {
    if (_currentBillIndex != null) {
      _savedBills.removeAt(_currentBillIndex!);
      _currentBillIndex = null;
      notifyListeners();
    }
  }

  double getTotalAmount() {
    double totalAmount = 0;

    for (var item in globals.cartItems) {
      if (item.uom == 'Kgs' && item.uom == 'Kg') {
        // Calculate based on weight for items in kilograms
        totalAmount += item.weight * item.quantity * item.pricePerKg;
      } else {
        // Calculate based on quantity for items in pieces
        totalAmount += item.quantity * item.pricePerKg;
      }
    }

    final customCharge = double.tryParse(customChargeController.text) ?? 0;
    totalAmount += customCharge;
    notifyListeners();
    return totalAmount;
  }

  double calculateSubtotal() {
    double subtotal = 0.0;
    for (var item in globals.cartItems) {
      subtotal += item.quantity * item.pricePerKg;
    }
    return subtotal;
  }

  String get formattedSubtotal {
    final subtotal = calculateSubtotal();
    return NumberFormat.currency(symbol: '₹')
        .format(subtotal); // Format as currency
  }

  // Remove item from the cart by index
  void removeItemFromCart(int index) {
    if (index >= 0 && index < globals.cartItems.length) {
      globals.cartItems.removeAt(index);
      notifyListeners();
    }
  }

  void updateWeight(int index, double newWeight) {
    // Update weight for the item at the given index
    globals.cartItems[index].weight = newWeight;
    notifyListeners();
  }

  void showQuantityDialog(
      BuildContext context, int index, int currentQuantity, String uom) {
    final TextEditingController quantityController =
        TextEditingController(text: currentQuantity.toString());

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0), // Rounded corners
          ),
          title: const Text(
            'Update Quantity',
            style: TextStyle(
              color: Colors.black, // Primary color for title
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: quantityController,
                keyboardType: TextInputType.numberWithOptions(
                  decimal: uom != 'Pcs' &&
                      uom != 'Pkt', // Allow decimal only if not "Pcs" or "Pkt"
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                    RegExp(
                      uom == 'Pcs' || uom == 'Pkt' ? r'^\d+$' : r'^\d*\.?\d*',
                    ),
                  ),
                ],
                decoration: InputDecoration(
                  labelText: 'Enter quantity',
                  border: OutlineInputBorder(
                    borderRadius:
                        BorderRadius.circular(8.0), // Rounded input border
                  ),
                  filled: true,
                  fillColor:
                      Colors.grey[200], // Light background color for input
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text(
                'Cancel',
                style: TextStyle(color: Colors.grey),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                // Update quantity based on UOM and close the dialog

                final newQuantity = double.tryParse(quantityController.text);
                if (newQuantity == 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Cannot addd 0 quantity'),
                    ),
                  );
                  return;
                }
                if (newQuantity != null && newQuantity >= 0) {
                  // For "Pcs" or "Pkt", use integer values
                  if (uom == 'Pcs' || uom == 'Pkt') {
                    updateQuantity(index, newQuantity.toInt());
                  } else {
                    // For other UOMs like "Kgs", accept the float value
                    updateWeight(index, newQuantity);
                  }
                }
                Navigator.of(context).pop(); // Close the dialog
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                      8.0), // Rounded corners for the button
                ),
              ),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
